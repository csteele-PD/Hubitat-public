using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.UI;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Interfaces;
using ZWave.Programmer.Dispatchers;
using System.Windows.Forms;
using ZWave.Enums;
using ZWave.Programmer.Models;
using ZWave.Programmer.Properties;
using ZWave.Devices;
using System.Threading;
using ZWave.Framework;
using System.Drawing;
using System.Diagnostics;
using System.IO;

namespace ZWave.Programmer.Controllers
{
    /// <summary>
    /// ControllerManager class.
    /// </summary>
    public class ControllerManager : IDisposable
    {
        public bool mIsAssertRESET_NShown = false;
        public bool mIsRESET_NAvailable = false;
        public bool ShowAssertReset = true;

        private bool mIsConsoleMode = true;
        public bool IsConsoleMode
        {
            get { return mIsConsoleMode; }
            set { mIsConsoleMode = value; }
        }

        private ControllerManager()
        {
            ApplicationExitCode = GetErrorCodeByMessage("");
            mDocumentModel = new DocumentModel();
            Tools.StartHighPrecisionTimer();
        }

        private static ControllerManager mInstance;

        private ActionCollection mActions;
        private DocumentModel mDocumentModel;
        private MainForm mMainForm;
        private ZW010xForm mZW010xForm;
        private ZW030xForm mZW020xForm;
        private ZW030xForm mZW030xForm;
        private ZW040xForm mZW040xForm;
        private ZW050xForm mZW050xForm;
        private LogForm mLogForm;
        private ConsoleForm mConsoleForm;
        private UserControl mActiveView;
        private ProgressForm progressForm;


        public static int ApplicationExitCode = 255;
        public int CmdLineProgInterface = 0;
        public bool SetProgMode = false;
        private bool mUseSiliconSpi = true;
        private string mStartDeviceName = "";

        public string StartDeviceName
        {
            get { return mStartDeviceName; }
            set { mStartDeviceName = value; }
        }

        public bool UseSiliconSpi
        {
            get { return mUseSiliconSpi; }
            set
            {
                mUseSiliconSpi = value;
                if (mUseSiliconSpi == true)
                {
                    if (!IsConsoleMode)
                    {
                        this.ZW050xForm.SetProgrammingInterface(0);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the document model.
        /// </summary>
        /// <value>The document model.</value>
        public DocumentModel DocumentModel
        {
            get { return mDocumentModel; }
        }
        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>The instance.</value>
        public static ControllerManager Instance
        {
            get
            {
                if (mInstance == null)
                {
                    mInstance = new ControllerManager();
                    mInstance.Init();
                }
                return mInstance;
            }
        }
        /// <summary>
        /// Gets the actions. <see cref="ActionCollection"/>
        /// </summary>
        /// <value>The actions.</value>
        public ActionCollection Actions
        {
            get
            {
                if (mActions == null)
                {
                    mActions = new ActionCollection(this);
                }
                return mActions;
            }
        }

        public ProductionForm ProductionForm
        {
            get;
            set;
        }

        public Form ActiveParent
        {
            get
            {
                if (ProductionForm != null)
                    return ProductionForm;
                else
                    return MainForm;
            }
        }

        /// <summary>
        /// Gets or sets the Main Form.
        /// </summary>
        /// <value>The main form.</value>
        public MainForm MainForm
        {
            get
            {
                return mMainForm;
            }
            set
            {
                Instance.UnregisterView(mMainForm, new MainFormDispatcher());
                mMainForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new MainFormDispatcher());
                }

            }
        }
        /// <summary>
        /// Gets or sets the ZW010X form.
        /// </summary>
        /// <value>The ZW010X form.</value>
        public ZW010xForm ZW010xForm
        {
            get { return mZW010xForm; }
            set
            {
                Instance.UnregisterView(mZW010xForm, new ZW010xFormDispatcher());
                mZW010xForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ZW010xFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the ZW020X form.
        /// </summary>
        /// <value>The ZW020X form.</value>
        public ZW030xForm ZW020xForm
        {
            get { return mZW020xForm; }
            set
            {
                Instance.UnregisterView(mZW020xForm, new ZW020xFormDispatcher());
                mZW020xForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ZW020xFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the ZW030X form.
        /// </summary>
        /// <value>The ZW030X form.</value>
        public ZW030xForm ZW030xForm
        {
            get { return mZW030xForm; }
            set
            {
                Instance.UnregisterView(mZW030xForm, new ZW030xFormDispatcher());
                mZW030xForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ZW030xFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the ZW040X form.
        /// </summary>
        /// <value>The ZW040X form.</value>
        public ZW040xForm ZW040xForm
        {
            get { return mZW040xForm; }
            set
            {
                Instance.UnregisterView(mZW040xForm, new ZW040xFormDispatcher());
                mZW040xForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ZW040xFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the ZW050x form.
        /// </summary>
        /// <value>The ZW050x form.</value>
        public ZW050xForm ZW050xForm
        {
            get { return mZW050xForm; }
            set
            {
                Instance.UnregisterView(mZW050xForm, new ZW050xFormDispatcher());
                mZW050xForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ZW050xFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the Log form.
        /// </summary>
        /// <value>The Log form.</value>
        public LogForm LogForm
        {
            get { return mLogForm; }
            set
            {
                Instance.UnregisterView(mLogForm, new LogFormDispatcher());
                mLogForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new LogFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the Console form.
        /// </summary>
        /// <value>The Console form.</value>
        public ConsoleForm ConsoleForm
        {
            get { return mConsoleForm; }
            set
            {
                Instance.UnregisterView(mConsoleForm, new ConsoleFormDispatcher());
                mConsoleForm = value;
                if (value != null)
                {
                    Instance.RegisterView(value, new ConsoleFormDispatcher());
                }
            }
        }
        /// <summary>
        /// Gets or sets the Active view.
        /// </summary>
        /// <value>The Active view.</value>
        public UserControl ActiveView
        {
            get { return mActiveView; }
            set
            {
                mActiveView = value;
            }
        }

        /// <summary>
        /// Registers the view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="dispatcher">The dispatcher.</param>
        public void RegisterView(ContainerControl view, IViewDispatcher dispatcher)
        {
            dispatcher.Bind(view, Instance.Actions, this.DocumentModel);
        }
        /// <summary>
        /// Unregisters the view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="dispatcher">The dispatcher.</param>
        public void UnregisterView(ContainerControl view, IViewDispatcher dispatcher)
        {
            if (view != null)
                dispatcher.Drop(view, Instance.Actions, this.DocumentModel);
        }
        private ZWaveManager mZWaveManager;
        /// <summary>
        /// Gets or sets the ZWave manager.
        /// </summary>
        /// <value>The Z wave manager.</value>
        public ZWaveManager ZWaveManager
        {
            get { return mZWaveManager; }
            set { mZWaveManager = value; }
        }
        /// <summary>
        /// Inits this instance.
        /// </summary>
        private void Init()
        {
            ZWaveManager = new ZWaveManager();
            ZWaveManager.Init();
        }
        /// <summary>
        /// Starts the application.
        /// </summary>
        /// <param name="args">The args.</param>
        public void Start(string[] args)
        {
            //ComputerSystemHardwareHelper.InitEventWatcher();
            if (args != null && args.Length > 0)
            {
                ProgrammerConsole programmerConsole = new ProgrammerConsole(this);
                programmerConsole.ProcessCommandLine(args);
            }
            else
            {
                RunUI();
            }
        }

        internal void RunUI()
        {
            IsConsoleMode = false;
            string exeName = null;
            try
            {

                exeName = Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), "ZWaveProgrammerUI.exe");
                if (!File.Exists(exeName))
                {
                    var dir = Directory.GetParent(exeName);
                    while (dir != null)
                    {
                        DirectoryInfo[] dirs = null;
                        try
                        {
                            dirs = dir.GetDirectories();
                        }
                        catch { }
                        if (dirs != null && dirs.FirstOrDefault(x => x.Name == "ZWaveProgrammerUI") != null)
                        {
                            exeName = Path.Combine(dir.FullName, @"ZWaveProgrammerUI\bin\Debug\ZWaveProgrammerUI.exe");
                            break;
                        }
                        dir = dir.Parent;
                    }
                }
            }
            catch (ArgumentNullException) { }
            catch (ArgumentException) { }
            catch (PathTooLongException) { }
            if (exeName != null && File.Exists(exeName))
            {
                ProcessStartInfo psi = new ProcessStartInfo(exeName);
                Process.Start(psi);
            }
        }

        /// <summary>
        /// Called when [process exit].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        static void OnProcessExit(object sender, EventArgs e)
        {
            if (mInstance != null)
            {
                mInstance.Dispose();
            }
            //ComputerSystemHardwareHelper.CloseAndDisposeEventWatcher();
        }
        /// <summary>
        /// Called when [unhandled exception].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.UnhandledExceptionEventArgs"/> instance containing the event data.</param>
        static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Tools._writeDebugDiagnosticExceptionMessage(string.Format("Exception {0} occured", e.ExceptionObject.GetType().FullName));
            //LogManager.Instance.WriteLog(string.Format("Exception {0} occured", e.ExceptionObject.GetType().FullName), LogDetailLevel.Short);
            //NotificationForm nf = new NotificationForm(e.ExceptionObject.GetType().FullName, e.ExceptionObject.ToString());
            //nf.Text = "Error";
            ////((Exception)e.ExceptionObject).TargetSite.GetMethodBody()
            //switch (nf.ShowDialog())
            //{
            //    case DialogResult.Abort:
            //        Application.Exit();
            //        break;
            //    case DialogResult.Ignore:
            //        return;
            //    case DialogResult.OK:
            //        break;
            //    default:
            //        break;
            //}
        }
        #region IDisposable Members

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this.progressForm != null && !this.progressForm.IsDisposed)
                {
                    this.progressForm.Dispose();
                }
                UnregisterView(this.MainForm, new MainFormDispatcher());
            }
        }

        #endregion

        private bool isBusy = false;
        internal void DoAction(EventHandler eventHandler, string progressInfo, bool canCancel, byte commandType)
        {
            if (isBusy) return;
            Actions.LogFormActions.ClearData();
            isBusy = true;
            System.Windows.Forms.Application.DoEvents();
            if (progressForm == null)
            {
                progressForm = new ProgressForm();
                progressForm.OnCancel += new EventHandler(ProgressFormOnCancel);
            }
            progressForm.Owner = MainForm;
            progressForm.ProgressDelegate = eventHandler;
            InvokeMainFormAction(() =>
                progressForm.ProgressInfo = progressInfo);
            progressForm.SetInfo("");
            ShowMessageInStatus(progressInfo, false);
            progressForm.CanCancel = canCancel;
            progressForm.CommandType = commandType;

            progressForm.Owner = this.ActiveParent;
            if (!IsConsoleMode)
            {
                InvokeMainFormAction(() =>
                    progressForm.ShowDialog(this.ActiveParent));
            }
            if (progressForm.ProgressException != null)
            {
                DocumentModel.Device = null;
                this.ShowMessage(progressForm.ProgressException.Message, true);
                this.MainForm.Focus();
            }
            isBusy = false;
        }

        void ProgressFormOnCancel(object sender, EventArgs e)
        {
            ProgressForm form = (ProgressForm)sender;
            isBusy = false;
        }

        internal void ShowConsoleInfo(string data)
        {
            ShowConsoleInfo(data, null, false);
        }

        internal void ShowConsoleInfo(string data, string header, bool isWarning)
        {
            if (IsConsoleMode)
            {
                ShowMessage(data, false);
            }
            else
            {
                InvokeMainFormAction(() =>
                {
                    this.ConsoleForm.ContentTextBox.Text = data;
                    if (header != null)
                    {
                        this.ConsoleForm.ShowHeader(true, header, isWarning);
                    }
                    else
                    {
                        this.ConsoleForm.ShowHeader(false, header, isWarning);
                    }
                });
            }
        }

        internal bool ShowConsoleConfirmMessage(string message, bool useAnyKey)
        {
            bool ret = false;
            Console.Write(message);
            if (useAnyKey)
            {
                Console.WriteLine();
                Console.Write("Press any key to continue...");
                try
                {
                    Console.ReadKey();
                }
                catch (InvalidOperationException iopEx) { }
                ret = true;
            }
            else
            {
                Console.Write(" (Y/N)");
                bool isPipedParam = false;
                try
                {
                    //Prevent multiple input before actual ReadKey
                    while (Console.KeyAvailable)
                    {
                        Console.ReadKey(true);
                    }

                    ConsoleKeyInfo cki = Console.ReadKey();
                    ret = cki.Key == ConsoleKey.Y;
                }
                catch (InvalidOperationException iopEx)
                {
                    isPipedParam = true;
                }

                if (isPipedParam)
                {
                    var consoleInput = Console.ReadLine();
                    ret = consoleInput.Trim().ToLowerInvariant() == "y";
                }
            }
            Console.WriteLine();
            return ret;
        }

        internal void ShowProgrammerStatus(string message, bool isError)
        {
            if (this.MainForm != null && !this.MainForm.IsDisposed)
            {
                this.MainForm.Invoke(new EventHandler(delegate
                {
                    string status = Resources.MsgStatusLabel + message;
                    status = status.Replace("\r", "");
                    status = status.Replace("\n", " ");
                    if (this.ProductionForm != null)
                    {
                        ProductionForm.SetStatusMessage(status, isError);
                    }
                    if (this.MainForm != null && !this.MainForm.IsDisposed)
                    {
                        this.MainForm.ProgrammerStatusLabel.Text = status;
                    }
                }));
            }
        }

        internal void ShowMessageInStatus(string message, bool isError)
        {
            if (!IsConsoleMode)
            {
                ShowProgrammerStatus(message, isError);
            }
            else
            {
                ShowMessage(message, isError);
            }
        }

        internal void ShowMessageInConsole(string message)
        {
            if (IsConsoleMode)
            {
                ShowMessage(message, false);
            }
        }

        internal void ShowMessage(string message, bool isError)
        {
            if (IsConsoleMode)
            {
                if (isError)
                {
                    ApplicationExitCode = GetErrorCodeByMessage(message);
                }
                else
                {
                    ApplicationExitCode = 0;
                }
                Console.WriteLine(message);
            }
            else
            {
                ShowProgrammerStatus(message, isError);
                if (this.ProductionForm != null && !this.ProductionForm.IsDisposed)
                {
                    this.MainForm.Invoke(new EventHandler(delegate
                    {
                        ProductionForm.AddLogMessage(message, isError);
                    }));
                }
                else if (this.MainForm != null && !this.MainForm.IsDisposed)
                {
                    this.MainForm.Invoke(new EventHandler(delegate
                        {
                            MessageBox.Show(this.ActiveParent, message, AboutForm.AssemblyProduct, MessageBoxButtons.OK, (isError == true) ? MessageBoxIcon.Exclamation : MessageBoxIcon.Information);
                        }));
                }
            }
        }

        private int GetErrorCodeByMessage(string message)
        {
            if (message == Resources.ErrorCantCompareEEPROM) return 1;
            else if (message == Resources.ErrorCantCompareFlash) return 2;
            else if (message == Resources.ErrorCantCompareSRAM) return 3;
            else if (message == Resources.ErrorCantDetectDevice) return 4;
            else if (message == Resources.ErrorCantEraseEEPROM) return 5;
            else if (message == Resources.ErrorCantEraseFlash) return 6;
            else if (message == Resources.ErrorCantGetFirmwareVersion) return 7;
            else if (message == Resources.ErrorCantInitEEPROM) return 8;
            else if (message == Resources.ErrorCantLockBitsRead) return 9;
            else if (message == Resources.ErrorCantLockBitsSet) return 10;
            else if (message == Resources.ErrorCantReadAppRfSettings) return 11;
            else if (message == Resources.ErrorCantReadEEPROM) return 12;
            else if (message == Resources.ErrorCantReadEEPROMOptions) return 13;
            else if (message == Resources.ErrorCantReadFlash) return 14;
            else if (message == Resources.ErrorCantReadFlashOptions) return 15;
            else if (message == Resources.ErrorCantReadGeneralRfSettings) return 16;
            else if (message == Resources.ErrorCantReadHomeId) return 17;
            else if (message == Resources.ErrorCantReadSram) return 18;
            else if (message == Resources.ErrorCantResetZWaveModule) return 19;
            else if (message == Resources.ErrorCantSetBootLoaderMode) return 20;
            else if (message == Resources.ErrorCantSetChipWorkingMode) return 21;
            else if (message == Resources.ErrorCantSetProgrammingMode) return 22;
            else if (message == Resources.ErrorCantUpgradeFirmware) return 23;
            else if (message == Resources.ErrorCantWriteAppRfSettings) return 24;
            else if (message == Resources.ErrorCantWriteEEPROM) return 25;
            else if (message == Resources.ErrorCantWriteFlash) return 26;
            else if (message == Resources.ErrorCantWriteFlashOptions) return 27;
            else if (message == Resources.ErrorCantWriteGeneralRfSettings) return 28;
            else if (message == Resources.ErrorCantWriteHomeId) return 29;
            else if (message == Resources.ErrorCantWriteSram) return 30;
            else if (message == Resources.ErrorCompareEepromFailed) return 31;
            else if (message == Resources.ErrorCompareSRAMFailed) return 32;
            else if (message == Resources.ErrorEEPROMHexFileNotSpecified) return 33;
            else if (message == Resources.ErrorFlashHexFileNotSpecified) return 34;
            else if (message == Resources.ErrorHexFileDataOutOfRange) return 35;
            else if (message == Resources.ErrorHexFileNotValid) return 36;
            else if (message == Resources.ErrorInvalidEndHomeId) return 37;
            else if (message == Resources.ErrorRfFrequencyNotSelected) return 38;
            else if (message == Resources.ErrorStartEndHomeIdEmpty) return 39;
            else if (message == Resources.ErrorUndefinedRfSettings) return 40;
            else if (message == Resources.ErrorCantInitMtp) return 41;
            else if (message == Resources.ErrorCantReadMtp) return 42;
            else if (message == Resources.ErrorCantEraseMtp) return 43;
            else if (message == Resources.ErrorCantProgramMtp) return 44;
            else if (message == Resources.ErrorCantCompareMtp) return 45;
            else if (message == Resources.ErrorProgramMtpFailed) return 46;
            else if (message == Resources.ErrorCompareMtpFailed) return 47;
            else if (message == Resources.ErrorMtpHexFileNotSpecified) return 48;
            else if (message == Resources.ErrorHexFileReadingFailed) return 49;
            else if (message.Contains("Read/Write operation timeout.")) return 50;
            else return 251;
        }

        internal DialogResult ShowConfirmMessage(string message, bool isError)
        {
            DialogResult result = DialogResult.None;
            this.MainForm.Invoke(new EventHandler(delegate
            {
                result = MessageBox.Show(this.ActiveParent, message, AboutForm.AssemblyProduct, MessageBoxButtons.YesNo, (isError == true) ? MessageBoxIcon.Exclamation : MessageBoxIcon.Information);
            }));

            return result;
        }

        internal bool ShowMessage(string message, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            if (IsConsoleMode)
            {
                return ShowConsoleConfirmMessage(message, buttons == MessageBoxButtons.OK);
            }
            else
            {
                if (ProductionForm != null && buttons == MessageBoxButtons.OK &&
                    message != null && !message.Contains("RESET_N"))
                {
                    this.MainForm.Invoke(new EventHandler(delegate
                    {
                        ProductionForm.AddLogMessage(message, false);
                    }));
                    return true;
                }
                else
                {
                    DialogResult result = DialogResult.None;
                    this.MainForm.Invoke(new EventHandler(delegate
                    {
                        result = MessageBox.Show(this.ActiveParent, message, AboutForm.AssemblyProduct, buttons, icon);
                    }));
                    return result == DialogResult.Yes || result == DialogResult.OK;
                }
            }
        }

        internal void SetActiveViewByChipType(ChipTypes chipType)
        {
            switch (chipType)
            {
                case ChipTypes.ZW010x:
                    {
                        this.MainForm.ZW010xToolStripMenuItem.Checked = true;
                        this.Actions.MainFormActions.OnZW010xClick(this.MainForm.ZW010xToolStripMenuItem, new EventArgs());
                    } break;
                case ChipTypes.ZW020x:
                    {
                        this.MainForm.ZW020xToolStripMenuItem.Checked = true;
                        this.Actions.MainFormActions.OnZW020xClick(this.MainForm.ZW020xToolStripMenuItem, new EventArgs());
                    } break;
                case ChipTypes.ZW030x:
                    {
                        this.MainForm.ZW030xToolStripMenuItem.Checked = true;
                        this.Actions.MainFormActions.OnZW030xClick(this.MainForm.ZW030xToolStripMenuItem, new EventArgs());
                    } break;
                case ChipTypes.ZW040x:
                    {
                        this.MainForm.ZW040xToolStripMenuItem.Checked = true;
                        this.Actions.MainFormActions.OnZW040xClick(this.MainForm.ZW040xToolStripMenuItem, new EventArgs());
                    } break;
                case ChipTypes.ZW050x:
                    {
                        this.MainForm.ZW050xToolStripMenuItem.Checked = true;
                        this.Actions.MainFormActions.OnZW050xClick(this.MainForm.ZW050xToolStripMenuItem, new EventArgs());
                    } break;
            }
        }

        internal void SetProgressInfo(string info)
        {
            if (!IsConsoleMode)
            {
                if (progressForm != null && !progressForm.IsDisposed)
                {
                    progressForm.SetProgressInfo(info);
                }
            }
            else
            {
                Console.WriteLine(info);
            }
        }

        internal void ChangeProgressInfo(ProgressStatuses progressStatus, int current, int total)
        {
            if (!IsConsoleMode)
            {

                if (progressForm != null && !progressForm.IsDisposed)
                {
                    string info;
                    switch (progressStatus)
                    {
                        case ProgressStatuses.Read:
                            {
                                info = String.Format("{0} / {1} bytes read...              ", current, total);
                            }
                            break;
                        case ProgressStatuses.Write:
                            {
                                info = String.Format("{0} / {1} bytes written...               ", current, total);
                            }
                            break;
                        default:
                            {
                                info = "";
                            }
                            break;
                    }
                    progressForm.SetInfo(info);
                    if (String.IsNullOrEmpty(info))
                    {
                        ShowMessageInStatus(progressForm.ProgressInfo, false);
                    }
                    else
                    {
                        ShowMessageInStatus(progressForm.ProgressInfo + " " + info, false);
                    }
                }
            }
            else
            {
                switch (progressStatus)
                {
                    case ProgressStatuses.Read:
                        {
                            Console.Write(String.Format("\b {0} / {1} bytes read...\r", current, total));
                        }
                        break;
                    case ProgressStatuses.Write:
                        {
                            Console.Write(String.Format("\b {0} / {1} bytes written...\r", current, total));
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("");
                        }
                        break;
                }

            }
        }

        internal void UpdateFrequencies()
        {
            if (Instance.ZW020xForm != null && !Instance.ZW020xForm.IsDisposed)
            {
                UpdateFrequenciesLow(Instance.ZW020xForm.FrequencyComboBox);
                /*Instance.ZW020xForm.RadioButton870_42.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.RadioButton910_42.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.UsTfRadioButton.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.EuTfRadioButton.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;

                Instance.ZW020xForm.UsRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.EuRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.HkRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.AnzRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW020xForm.MyRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;*/
            }
            if (Instance.ZW030xForm != null && !Instance.ZW030xForm.IsDisposed)
            {
                UpdateFrequenciesLow(Instance.ZW030xForm.FrequencyComboBox);
                /*Instance.ZW030xForm.RadioButton870_42.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.RadioButton910_42.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.UsTfRadioButton.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.EuTfRadioButton.Visible = Instance.DocumentModel.Settings.UseTestFrequencies;

                Instance.ZW030xForm.UsRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.EuRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.HkRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.AnzRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;
                Instance.ZW030xForm.MyRadioButton.Visible = !Instance.DocumentModel.Settings.UseTestFrequencies;*/
            }
            if (Instance.ZW050xForm != null && !Instance.ZW050xForm.IsDisposed)
            {
                UpdateFrequenciesLow(Instance.ZW050xForm.FrequencyComboBox);
            }
        }

        private static void UpdateFrequenciesLow(ComboBox frequencyComboBox)
        {
            FrequencyWrapper selectedItem = (FrequencyWrapper)frequencyComboBox.SelectedItem;
            frequencyComboBox.Items.Clear();
            if (Instance.DocumentModel.Settings.UseTestFrequencies)
            {
                frequencyComboBox.Items.Add(new FrequencyWrapper(" ", 0xFF));	//actually this item means
                // "Frequency which is set in input HEX file" or "Do not change the frequency"
                // or "Frerquency unknown" or "Frequency is not set" depend from which operation is
                //  performed ("Program", "Set Option", etc.)
                frequencyComboBox.Items.Add(new FrequencyWrapper("866.42 MHz (TF1 EU)", MemoryLayout.RF_866));
                frequencyComboBox.Items.Add(new FrequencyWrapper("870.42 MHz (TF2 EU)", MemoryLayout.RF_870));
                frequencyComboBox.Items.Add(new FrequencyWrapper("906.42 MHz (TF3 US)", MemoryLayout.RF_906));
                frequencyComboBox.Items.Add(new FrequencyWrapper("910.42 MHz (TF4 US)", MemoryLayout.RF_910));
            }
            else
            {
                frequencyComboBox.Items.Add(new FrequencyWrapper(" ", 0xFF)); //... same as above ^^^
                frequencyComboBox.Items.Add(new FrequencyWrapper("US", MemoryLayout.RF_US));
                frequencyComboBox.Items.Add(new FrequencyWrapper("EU", MemoryLayout.RF_EU));
                frequencyComboBox.Items.Add(new FrequencyWrapper("ANZ", MemoryLayout.RF_ANZ));
                frequencyComboBox.Items.Add(new FrequencyWrapper("HK", MemoryLayout.RF_HK));
                frequencyComboBox.Items.Add(new FrequencyWrapper("MY", MemoryLayout.RF_MY));
                frequencyComboBox.Items.Add(new FrequencyWrapper("IN", MemoryLayout.RF_IN));
                frequencyComboBox.Items.Add(new FrequencyWrapper("RU", MemoryLayout.RF_RU));
                frequencyComboBox.Items.Add(new FrequencyWrapper("IL", MemoryLayout.RF_IL));
            }
            if (selectedItem != null)
            {
                foreach (FrequencyWrapper freqWrapper in frequencyComboBox.Items)
                {
                    if (freqWrapper.Frequency == selectedItem.Frequency)
                    {
                        frequencyComboBox.SelectedItem = freqWrapper;
                    }
                }

            }
            else
            {
                frequencyComboBox.SelectedIndex = 0;
            }
        }

        bool deviceFirmwareVersionDetectShowInConsole = true;
        internal bool DeviceFirmwareVersionDetect()
        {
            bool result = false;
            if (this.DocumentModel.Device != null)
            {
                int version, revision;
                string firmware = Resources.MsgFirmwareVersionLabel;
                try
                {
                    if (DocumentModel.Device.GetCurrentFirmwareVersion(out version, out revision))
                    {
                        result = true;
                        firmware += String.Format("{0}.{1:D2}", version, revision);
                    }
                }
                catch (Exception)
                {
                }
                if (!result)
                {
                    firmware += "N/A";
                    this.UseSiliconSpi = false;
                }
                if (this.MainForm != null && !this.MainForm.IsDisposed)
                {
                    this.MainForm.Invoke(new Action(() =>
                    {
                        this.MainForm.FirmwareStatusLabel.Text = firmware;
                    }));
                }
                else if (deviceFirmwareVersionDetectShowInConsole)
                {
                    Console.WriteLine(Resources.CaptionZWaveProgrammer + " " + firmware);
                    deviceFirmwareVersionDetectShowInConsole = false;
                }
            }
            return result;
        }

        public bool InvokeMainFormAction(Action action)
        {
            if (this.MainForm != null && !this.MainForm.IsDisposed)
            {
                this.MainForm.InvokeAction(action);
                return true;
            }
            else
                return false;
        }

        // Called on application UI startup to open and init the device
        internal void DeviceInit()
        {
            InvokeMainFormAction(() =>
                this.MainForm.FirmwareStatusLabel.Text = Resources.MsgFirmwareVersionLabel + "N/A");

            ShowAssertReset = false;

            List<Win32PnPEntityClass> ports = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices();
            if (!String.IsNullOrEmpty(Settings.Default.LastUsedDevice))
            {
                try
                {
                    int progInterface = Instance.GetProgrammingInterface();
                    bool isAutoProg = false;
                    if (progInterface == 0 && DocumentModel.PortInfo != null)
                    {
                        InitSpi();
                        //if (this.ZW050xForm != null && !this.ZW050xForm.IsDisposed)
                        //{
                        //    this.ZW050xForm.BeginInvoke(new EventHandler(delegate
                        //    {
                        //        this.ZW050xForm.SetProgrammingInterface(1);
                        //        this.mIsRESET_NAvailable = true;
                        //        this.IsAtmegaDetected = false;
                        //    }));
                        //}
                    }
                    else if (progInterface == 1)
                    {
                        //if (!ShowMessage("Are you able to control the RESET_N signal?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation))
                        //{
                        mIsRESET_NAvailable = false;

                        AutoProgDevice _device = new AutoProgDevice(DocumentModel.PortInfo, mInstance);
                        try
                        {
                            isAutoProg = _device.SetProgrammingMode(true);
                            mIsRESET_NAvailable = false;
                        }
                        catch
                        {

                        }

                        if (!isAutoProg)
                        {
                            if (DocumentModel.PortInfo != null)
                            {
                                this.StartDeviceName = DocumentModel.PortInfo.DeviceID;
                            }
                            if (_device.Type != AutoProgDeviceTypes.UART)
                            {
                                try
                                {
                                    _device.ZWAutoProgrammingMode();
                                    _device.ZWZnifferAutoProgrammingMode();
                                    _device.Close();
                                    mIsRESET_NAvailable = false;
                                    #region switch port
                                    bool portExists = false;
                                    //Search removed device
                                    for (int i = 0; i < 10; i++)
                                    {
                                        portExists = false;
                                        Thread.Sleep(1000);
                                        foreach (Win32PnPEntityClass p in ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices())
                                        {
                                            if (p.Caption == DocumentModel.PortInfo.Caption)
                                            {
                                                portExists = true;
                                            }
                                        }
                                        if (!portExists)
                                            break;
                                    }

                                    if (!portExists)
                                    {
                                        //Search new device
                                        Win32PnPEntityClass newDevice = null;
                                        for (int i = 0; i < 31; i++)
                                        {
                                            foreach (Win32PnPEntityClass _p in ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices())
                                            {
                                                portExists = false;
                                                foreach (Win32PnPEntityClass p in ports)
                                                {
                                                    if (_p.Caption == p.Caption)
                                                    {
                                                        portExists = true;
                                                        break;
                                                    }
                                                }
                                                if (!portExists && _p.Caption.Contains("Sigma Designs ZWave programming interface"))
                                                {
                                                    newDevice = _p;
                                                    break;
                                                }
                                            }
                                            if (newDevice != null)
                                                break;
                                            Thread.Sleep(1000);
                                            if (i == 30)
                                            {
                                                if (!IsConsoleMode)
                                                {
                                                    if (ShowConfirmMessage("Sigma designs programming interface not found.\nDo you want to wait 30 seconds more?", false) == DialogResult.Yes)
                                                    {
                                                        i = 0;
                                                    }
                                                    else
                                                    {
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    if (ShowConsoleConfirmMessage("Sigma designs programming interface not found.\nDo you want to wait 30 seconds more?", false))
                                                    {
                                                        i = 0;
                                                    }
                                                    else
                                                    {
                                                        break;
                                                    }
                                                }
                                            }
                                        }

                                        if (newDevice != null)
                                        {
                                            DocumentModel.PortInfo = newDevice;
                                            //_device.Close();
                                            _device = new AutoProgDevice(DocumentModel.PortInfo, mInstance);
                                            if (!IsConsoleMode)
                                            {
                                                Settings.Default.LastUsedDevice = DocumentModel.PortInfo.DeviceID;
                                                InvokeMainFormAction(() =>
                                                    this.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: " + DocumentModel.PortInfo.DeviceID);
                                                Settings.Default.Save();
                                            }

                                        }
                                        else
                                        {
                                            return;
                                        }
                                    }

                                    #endregion
                                }
                                catch
                                {

                                }
                            }

                            try
                            {
                                isAutoProg = _device.SetProgrammingMode(true);
                                mIsRESET_NAvailable = false;
                            }
                            catch
                            {
                                //mIsRESET_NAvailable = ShowMessage("Are you able to control the RESET_N signal?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                                mIsRESET_NAvailable = true;
                            }
                        }
                        _device.Close();

                    }
                    ShowMessageInStatus("Device initialization completed.", false);
                }
                catch (Exception ex)
                {
                    ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            ShowAssertReset = true;
        }

        public void ClearZW050xFormData()
        {
            if (this.ZW050xForm != null && !this.ZW050xForm.IsDisposed)
            {
                this.ZW050xForm.BeginInvoke(new EventHandler(delegate
                {
                    this.ZW050xForm.ClearData();
                }));
                Instance.ShowConsoleInfo("");
            }
        }

        public void InitSpi()
        {
            if (DocumentModel.Settings.WriteOnPcbButton)
            {
                DocumentModel.Device = ZWaveManager.ApplicationLayer.CreateDevice();
                if (DocumentModel.Device != null)
                {
                    try
                    {
                        //assign event hadler before opening the device, because it can be called during open:
                        DocumentModel.Device.ApplicationCommandHandlerEvent += new ZWave.Events.DeviceAppCommandHandlerEventHandler(Device_ApplicationCommandHandlerEvent);
                        DocumentModel.Device.Open(DocumentModel.PortInfo.DeviceID);
                    }
                    catch
                    {
                    }
                }
            }
            //this.DoAction(new EventHandler(delegate
            //    {
            this.Actions.ProgrammerActions.UpgradeLatestFirmware();
        }

        public void AssertReset()
        {
            if (mIsRESET_NAvailable)
            {
                Tools._writeDebugDiagnosticMessage("AssertReset");
                mIsAssertRESET_NShown = false;
                if (this.ShowAssertReset)
                {
                    ShowMessage("Assert RESET_N signal (press and hold reset button)", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    mIsAssertRESET_NShown = true;
                    Thread.Sleep(2000);
                }
            }
        }

        void Device_ApplicationCommandHandlerEvent(ZWave.Events.DeviceAppCommandHandlerEventArgs args)
        {
            if (args.CommandClassKey == 0x00 && args.SourceNodeId == 0x00 && args.CommandBuffer != null)
            {
                if (args.CommandBuffer.Length >= (int)ProgrammerFrameInfo.ProgrammerFrameSizeMin)
                {
                    switch ((ProgrammerCommandTypes)args.CommandKey)
                    {
                        case ProgrammerCommandTypes.FUNC_ID_BUTTON_PRESSED:
                            if (DocumentModel.Settings.WriteOnPcbButton)
                            {
                                if (args.CommandBuffer.Length >= (int)ProgrammerFrameInfo.ProgrammerFrameButtonPressedSize)
                                {
                                    if ((args.CommandBuffer[(int)ProgrammerFrameInfo.ProgrammerFrameButtonStateOffset]
                                        & (byte)ProgrammerFrameInfo.ProgrammerFrameButtonStateS1Pressed) != 0)
                                    {
                                        if (!DocumentModel.DeviceBusy
                                            && !DocumentModel.DeviceProgramButtonPressed)
                                        {
                                            DocumentModel.DeviceProgramButtonPressed = true;
                                            Thread t = new Thread(new ThreadStart(delegate
                                            {
                                                Actions.ProgrammerActions.OnFlashProgramClick(null, null);
                                                DocumentModel.DeviceProgramButtonPressed = false;
                                            }));
                                            t.Start();
                                        }
                                    }
                                }
                            }
                            break;
                    }
                }
            }
        }

        // Called on application shutdown to open and init the device
        internal void DeviceDeinit()
        {
            int progInterface = Instance.GetProgrammingInterface();
            if (progInterface == 0)
            {
                if (DocumentModel.Device != null)
                {
                    if (DocumentModel.Device.ConnectionStatus == ConnectionStatuses.Opened)
                    {
                        try
                        {
                            DocumentModel.Device.Close();
                        }
                        catch
                        {
                        }
                    }
                    DocumentModel.Device.ApplicationCommandHandlerEvent -= new ZWave.Events.DeviceAppCommandHandlerEventHandler(Device_ApplicationCommandHandlerEvent);
                    DocumentModel.Device.Dispose();
                    DocumentModel.Device = null;
                }
            }
            else if (progInterface == 1)
            {
                //TODO
            }
            else if (progInterface == 2)
            {
                //TODO
            }
        }

        // Called before each action to open device for that action
        internal IDevice DeviceOpen()
        {
            int progInterface = Instance.GetProgrammingInterface();
            if (progInterface == 0)
            {
                if (!DocumentModel.Settings.WriteOnPcbButton || DocumentModel.Device == null)
                {
                    if (DocumentModel.Device == null)
                    {
                        if (DocumentModel.PortInfo == null)
                        {
                            throw new Exception(Resources.MsgInterfaceNotSelected);
                        }
                        DocumentModel.Device = ZWaveManager.ApplicationLayer.CreateDevice();
                        if (DocumentModel.Device != null)
                        {
                            //assign event hadler before opening the device, because it can be called during open:
                            DocumentModel.Device.ApplicationCommandHandlerEvent += new ZWave.Events.DeviceAppCommandHandlerEventHandler(Device_ApplicationCommandHandlerEvent);
                            DocumentModel.Device.Open(DocumentModel.PortInfo.DeviceID);
                        }
                    }
                }
                this.DeviceFirmwareVersionDetect();

                DocumentModel.DeviceBusy = true;
                return DocumentModel.Device;
            }
            else if (progInterface == 1 && DocumentModel.PortInfo != null && DocumentModel.PortInfo.Description.Contains("Silicon"))
            {
                if (!DocumentModel.Settings.WriteOnPcbButton || DocumentModel.Device == null)
                {
                    if (DocumentModel.Device == null)
                    {
                        if (DocumentModel.PortInfo == null)
                        {
                            throw new Exception(Resources.MsgInterfaceNotSelected);
                        }
                        DocumentModel.Device = ZWaveManager.ApplicationLayer.CreateDevice();
                        if (DocumentModel.Device != null)
                        {
                            //assign event hadler before opening the device, because it can be called during open:
                            DocumentModel.Device.ApplicationCommandHandlerEvent += new ZWave.Events.DeviceAppCommandHandlerEventHandler(Device_ApplicationCommandHandlerEvent);
                            DocumentModel.Device.Open(DocumentModel.PortInfo.DeviceID);
                        }
                    }
                }
                this.DeviceFirmwareVersionDetect();

                DocumentModel.DeviceBusy = true;
                return DocumentModel.Device;
            }
            else if (progInterface == 1)
            {
                //TODO
                return null;
            }
            else if (progInterface == 2)
            {
                //TODO
                return null;
            }
            return null;
        }

        // Called after each action to close device for that action
        internal void DeviceClose()
        {
            if (!DocumentModel.Settings.WriteOnPcbButton)
            {
                if (DocumentModel.Device != null)
                {
                    DocumentModel.Device.Close();
                    DocumentModel.Device.ApplicationCommandHandlerEvent -= new ZWave.Events.DeviceAppCommandHandlerEventHandler(Device_ApplicationCommandHandlerEvent);
                    DocumentModel.Device.Dispose();
                    DocumentModel.Device = null;
                }
            }
            DocumentModel.DeviceBusy = false;
        }

        public int GetProgrammingInterface()
        {
            if (Instance.ZW050xForm != null && !Instance.ZW050xForm.IsDisposed)
            {
                int result = Instance.ZW050xForm.GetProgrammingInterface();
                if (result == 1 || result == 2)
                    return 1;
                else
                    return 0;
            }
            else
            {
                return CmdLineProgInterface;
            }
        }

        public void DeassertReset()
        {
            if (mIsRESET_NAvailable && mIsAssertRESET_NShown)
            {
                ShowMessage("De-assert RESET_N signal (release reset button)", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                mIsAssertRESET_NShown = false;
                Thread.Sleep(1000);
            }
        }

        internal void RestoreSelectedDevice()
        {
            if (!String.IsNullOrEmpty(Instance.StartDeviceName))
            {
                if (Instance.DocumentModel.PortInfo != null && Instance.DocumentModel.PortInfo.Caption.Contains("Sigma Designs ZWave programming interface"))
                {
                    Win32PnPEntityClass _port = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(Instance.DocumentModel.PortInfo.DeviceID);
                    if (_port != null)
                    {
                        try
                        {
                            Instance.Actions.ProgrammerActions.DeviceReset(
                                Instance.DocumentModel.PortInfo,
                                Instance.GetProgrammingInterface());
                            Thread.Sleep(1000);

                        }
                        catch { }
                    }
                }
                Win32PnPEntityClass port = null;
                for (int i = 0; i < 60; i++)
                {
                    port = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(Instance.StartDeviceName);
                    if (port != null)
                    {
                        SelectPort(port);
                        break;
                    }
                    Thread.Sleep(1000);
                }
                if (port == null)
                {
                    SelectEmptyPort();
                }
            }
        }
        private void SelectEmptyPort()
        {
            if (Instance.DocumentModel.PortInfo != null && Instance.DocumentModel.PortInfo.Caption.Contains("Sigma Designs"))
            {
                Instance.DocumentModel.PortInfo = null;
                if (!IsConsoleMode)
                {
                    Settings.Default.LastUsedDevice = "";
                    InvokeMainFormAction(() =>
                        this.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: None");
                    Settings.Default.Save();
                }
            }
        }

        private void SelectPort(Win32PnPEntityClass port)
        {
            Instance.DocumentModel.PortInfo = port;
            if (!IsConsoleMode)
            {
                Settings.Default.LastUsedDevice = Instance.DocumentModel.PortInfo.DeviceID;
                InvokeMainFormAction(() =>
                    this.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: " + Instance.DocumentModel.PortInfo.DeviceID);
                Settings.Default.Save();
            }
        }
    }

}
