﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZWave.Programmer.Controls
{
    public partial class TextBoxEx : TextBox
    {
        Color initColor;
        public TextBoxEx()
        {
            InitializeComponent();
            initColor = this.ForeColor;
        }

        private string originalData;
        public override string Text
        {
            get
            {
                return base.Text;
            }
            set
            {
                base.Text = value;
                originalData = base.Text;
                this.Modified = false;
                ChangeForeColor();
            }
        }

        public void ClearHasChanges()
        {
            originalData = base.Text;
            this.Modified = false;
            ChangeForeColor();
        }

        private void ChangeForeColor()
        {
            if (this.Modified)
                this.ForeColor = Color.Green;
            else
                this.ForeColor = initColor;
        }

        private void TextBoxEx_Validating(object sender, CancelEventArgs e)
        {
            this.Modified = this.Text != originalData;
            ChangeForeColor();
        }

        private void TextBoxEx_KeyPress(object sender, KeyPressEventArgs e)
        {
            this.Modified = this.Text != originalData;
            ChangeForeColor();
        }

        private void TextBoxEx_TextChanged(object sender, EventArgs e)
        {
            this.Modified = this.Text != originalData;
            ChangeForeColor();
        }
    }
}
