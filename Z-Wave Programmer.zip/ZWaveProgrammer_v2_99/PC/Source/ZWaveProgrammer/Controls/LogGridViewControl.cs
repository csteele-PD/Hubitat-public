using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Design;
using System.Threading;
using ZWave.Framework;

namespace ZWave.Programmer.Controls
{
    public partial class LogGridViewControl : UserControl
    {
        public LogGridViewControl()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to clear the list?", "Log View", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;
            Clear();
        }

        public void Clear()
        {
            logTextBox.Text = "";
        }

        public void AddText(string message)
        {
            if (logTextBox.Lines.Length > 1000000)
            {
                Clear();
            }
            logTextBox.AppendText(message);
        }

        /// <summary>
        /// Registers the menu.
        /// </summary>
        /// <param name="mainMenu">The main menu.</param>
        public void RegisterMenu(MenuStrip mainMenu)
        {
            ToolStripMenuItem logMenu = null;
            foreach (ToolStripItem var in mainMenu.Items)
            {
                if (var is ToolStripMenuItem)
                {
                    if (var.Text == "Log")
                    {
                        logMenu = var as ToolStripMenuItem;
                        break;
                    }
                }
            }
            if (logMenu == null)
            {
                logMenu = new ToolStripMenuItem();
                logMenu.Text = "Log";
                mainMenu.Items.Add(logMenu);
            }
            logMenu.DropDownItems.Clear();
            ToolStripItem clearMenuItem = CreateAsToolStripButton(btnClear);
            clearMenuItem.Click += btnClear_Click;
            logMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { clearMenuItem });
        }

        private ToolStripItem CreateAsToolStripButton(ToolStripButton btn)
        {
            ToolStripItem ret = new ToolStripMenuItem();
            ret.Text = btn.Text;
            ret.ToolTipText = btn.ToolTipText;
            ret.Image = btn.Image;
            return ret;
        }

        public TextBox LogTextBox
        {
            get { return logTextBox; }
        }
    }
}
