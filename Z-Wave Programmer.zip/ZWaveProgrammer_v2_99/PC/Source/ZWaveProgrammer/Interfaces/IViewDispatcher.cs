using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Models;
using System.Windows.Forms;

namespace ZWave.Programmer.Interfaces
{
    /// <summary>
    /// Defines methods for binding views (windows forms) and controller extentions <see cref="BaseAction"/>
    /// </summary>
    public interface IViewDispatcher
    {
        void Bind(ContainerControl view, ActionCollection actions, DocumentModel documentModel);
        void Drop(ContainerControl view, ActionCollection actions, DocumentModel documentModel);
    }
}
