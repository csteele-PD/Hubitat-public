using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Z-Wave Programmer")]
[assembly: AssemblyDescription("Z-Wave tool for programming the Z-Wave 100/200/300/400/500 Series chips, programming the EEPROM on the Z-Wave modules and handling the configuration settings of Z-Wave modules.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sigma Designs")]
[assembly: AssemblyProduct("Z-Wave Programmer")]
[assembly: AssemblyCopyright("� 2011-2016 Sigma Designs. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("220d0dea-e5b5-4cc8-a10a-60423f2d2dc3")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.99.36.14463")]

