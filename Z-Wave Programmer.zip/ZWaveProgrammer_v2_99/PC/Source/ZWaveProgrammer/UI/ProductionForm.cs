﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZWave.Framework;
using ZWave.Programmer.Models;
using ZWave.Enums;
using System.IO;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Properties;
using System.Threading;

namespace ZWave.Programmer.UI
{
    public partial class ProductionForm : Form
    {
        public List<string> ConnPorts { get; set; }
        public event EventHandler ProgramClick;
        //private string StartDeviceName { get; set; }
        private DocumentModel DocumentModel { get; set; }
        public ProductionForm(DocumentModel documentModel)
        {
            InitializeComponent();
            gbCONN1.Visible = false;
            gbCONN2.Visible = false;
            gbCONN3.Visible = false;
            gbCONN4.Visible = false;
            gbCONN5.Visible = false;
            gbCONN6.Visible = false;
            DocumentModel = documentModel;
            ConnPorts = new List<string>();
            addConnButton.Enabled = true;
            ConnPorts.Add(DocumentModel.PortInfo.DeviceID);
            try
            {
                SetLastCONN(DocumentModel.PortInfo.Caption);
                string hexFile = DocumentModel.GetFlashHexFilePath((ChipTypes)DocumentModel.SelectedChipType);
                fullPathLabel.Text = Path.GetDirectoryName(hexFile); ;
                hexFileLabel.Text = Path.GetFileName(hexFile);
            }
            catch { }

            redBar.Visible = false;
            greenBar.Visible = true;
            statusLabel.Text = "Prepare device for programming  and press 'Program' when ready";
            ClearLabels();
            ClearLogs();
        }



        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void programButton_Click(object sender, EventArgs e)
        {
            ClearLogs();
            statusLabel.Text = "Programming...";
            greenBar.Visible = false;
            redBar.Visible = true;
            programButton.Enabled = false;
            exitButton.Enabled = false;

            if (ConnPorts.Count > 0)
            {
                ProgrammInner(sender, e, ConnPorts[0], sStatusLabelOK1, sStatusLabelError1, logTextBox1);
            }
            if (ConnPorts.Count > 1)
            {
                Thread.Sleep(3000);
                ProgrammInner(sender, e, ConnPorts[1], sStatusLabelOK2, sStatusLabelError2, logTextBox2);
            }
            if (ConnPorts.Count > 2)
            {
                Thread.Sleep(3000);
                ProgrammInner(sender, e, ConnPorts[2], sStatusLabelOK3, sStatusLabelError3, logTextBox3);
            }
            if (ConnPorts.Count > 3)
            {
                Thread.Sleep(3000);
                ProgrammInner(sender, e, ConnPorts[3], sStatusLabelOK4, sStatusLabelError4, logTextBox4);
            }
            if (ConnPorts.Count > 4)
            {
                Thread.Sleep(3000);
                ProgrammInner(sender, e, ConnPorts[4], sStatusLabelOK5, sStatusLabelError5, logTextBox5);
            }
            if (ConnPorts.Count > 5)
            {
                Thread.Sleep(3000);
                ProgrammInner(sender, e, ConnPorts[5], sStatusLabelOK6, sStatusLabelError6, logTextBox6);
            }

            redBar.Visible = false;
            greenBar.Visible = true;
            programButton.Enabled = true;
            exitButton.Enabled = true;
            statusLabel.Text = "Prepare device for programming  and press 'Program' when ready";
        }

        private void ProgrammInner(object sender, EventArgs e, string connPort, Label lOK, Label lError, TextBox textBox)
        {
            SetCurrentLogTextBox(textBox);
            SetCurrentLabelOK(lOK);
            SetCurrentLabelError(lError);
            var port = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(connPort);
            if (port != null)
            {
                DocumentModel.PortInfo = port;

                lOK.Text = "";
                lError.Text = "";
                lError.Visible = false;
                lOK.Visible = true;
                if (ProgramClick != null)
                    ProgramClick(sender, e);
            }
            else
            {
                lError.Text = "Can't connect to Serial Port: " + connPort + ". Close Production form and select another Serial Port";
                lError.Visible = true;
                lOK.Visible = false;
            }
        }

        public TextBox logTextBox;
        public Label labelOK;
        public Label labelError;
        
        private void SetCurrentLogTextBox(TextBox textBox)
        {
            logTextBox = textBox;
        }
        private void SetCurrentLabelOK(Label lOK)
        {
            labelOK = lOK;
        }
        private void SetCurrentLabelError(Label lError)
        {
            labelError = lError;
        }

        private void ClearLabels()
        {
            sStatusLabelOK1.Text = "";
            sStatusLabelError1.Text = "";
            sStatusLabelError1.Visible = false;
            sStatusLabelOK1.Visible = true;

            sStatusLabelOK2.Text = "";
            sStatusLabelError2.Text = "";
            sStatusLabelError2.Visible = false;
            sStatusLabelOK2.Visible = true;

            sStatusLabelOK3.Text = "";
            sStatusLabelError3.Text = "";
            sStatusLabelError3.Visible = false;
            sStatusLabelOK3.Visible = true;

            sStatusLabelOK4.Text = "";
            sStatusLabelError4.Text = "";
            sStatusLabelError4.Visible = false;
            sStatusLabelOK4.Visible = true;

            sStatusLabelOK5.Text = "";
            sStatusLabelError5.Text = "";
            sStatusLabelError5.Visible = false;
            sStatusLabelOK5.Visible = true;

            sStatusLabelOK6.Text = "";
            sStatusLabelError6.Text = "";
            sStatusLabelError6.Visible = false;
            sStatusLabelOK6.Visible = true;
        }

        private void ClearLogs()
        {
            logTextBox1.Clear();
            logTextBox1.BackColor = Color.White;
            logTextBox2.Clear();
            logTextBox2.BackColor = Color.White;
            logTextBox3.Clear();
            logTextBox3.BackColor = Color.White;
            logTextBox4.Clear();
            logTextBox4.BackColor = Color.White;
            logTextBox5.Clear();
            logTextBox5.BackColor = Color.White;
            logTextBox6.Clear();
            logTextBox6.BackColor = Color.White;
        }

        private void addConnButton_Click(object sender, EventArgs e)
        {
            if (ConnPorts.Count < 6)
            {
                SettingsForm settingsForm = new SettingsForm();
                settingsForm.OnLoadInterfaces += new EventHandler(SettingsOnLoadInterfaces);
                if (settingsForm.ShowDialog() == DialogResult.OK)
                {
                    var PortInfo = settingsForm.SelectedPortInfo;
                    ConnPorts.Add(PortInfo.DeviceID);
                    SetLastCONN(PortInfo.Caption);
                }
                settingsForm.OnLoadInterfaces -= new EventHandler(SettingsOnLoadInterfaces);
                if (ConnPorts.Count == 6)
                    addConnButton.Enabled = false;
            }
        }

        private void SetLastCONN(string text)
        {
            switch (ConnPorts.Count)
            {
                case 1:
                    gbCONN1.Visible = true;
                    gbCONN1.Text = text;
                    gridPanel.SetColumnSpan(gbCONN1, 3);
                    gridPanel.SetRowSpan(gbCONN1, 2);
                    break;
                case 2:
                    gbCONN2.Visible = true;
                    gbCONN2.Text = text;
                    gridPanel.SetColumnSpan(gbCONN1, 1);
                    gridPanel.SetRowSpan(gbCONN1, 2);
                    gridPanel.SetColumnSpan(gbCONN2, 1);
                    gridPanel.SetRowSpan(gbCONN2, 2);
                    break;
                case 3:
                    gbCONN3.Visible = true;
                    gbCONN3.Text = text;
                    gridPanel.SetColumnSpan(gbCONN1, 1);
                    gridPanel.SetRowSpan(gbCONN1, 2);
                    gridPanel.SetColumnSpan(gbCONN2, 1);
                    gridPanel.SetRowSpan(gbCONN2, 2);
                    gridPanel.SetColumnSpan(gbCONN3, 1);
                    gridPanel.SetRowSpan(gbCONN3, 2);
                    break;
                case 4:
                    gbCONN4.Visible = true;
                    gbCONN4.Text = text;
                    gridPanel.SetColumnSpan(gbCONN1, 1);
                    gridPanel.SetRowSpan(gbCONN1, 1);
                    gridPanel.SetColumnSpan(gbCONN2, 1);
                    gridPanel.SetRowSpan(gbCONN2, 1);
                    gridPanel.SetColumnSpan(gbCONN3, 1);
                    gridPanel.SetRowSpan(gbCONN3, 1);
                    break;
                case 5:
                    gbCONN5.Visible = true;
                    gbCONN5.Text = text;
                    break;
                case 6:
                    gbCONN6.Visible = true;
                    gbCONN6.Text = text;
                    break;
                default:
                    break;
            }
            gridPanel.PerformLayout();
        }

        private void SettingsOnLoadInterfaces(object sender, EventArgs e)
        {
            if (sender is SettingsForm)
            {
                List<Win32PnPEntityClass> interfaces = new List<Win32PnPEntityClass>();
                SettingsForm form = sender as SettingsForm;
                try
                {
                    interfaces = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices();
                }
                catch (System.Management.ManagementException)
                {
                    //ControllerManager.ShowMessage(mEx.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception)
                {
                    //ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                form.InterfacesListBox.Items.Clear();
                form.NoCommInterfacesLabel.Text = "";
                if (interfaces != null && interfaces.Count > 0)
                {
                    form.InterfacesListBox.Enabled = true;
                    foreach (Win32PnPEntityClass serialPortInfo in interfaces)
                    {
                        if (!String.IsNullOrEmpty(Settings.Default.LastUsedDevice) && Settings.Default.LastUsedDevice == serialPortInfo.DeviceID)
                        {
                            form.SelectedPortInfo = serialPortInfo;
                            form.InterfacesListBox.Items.Add(new InterfaceWrapper(serialPortInfo), true);
                        }
                        else
                        {
                            form.InterfacesListBox.Items.Add(new InterfaceWrapper(serialPortInfo), false);
                        }
                    }
                }
                else
                {
                    form.InterfacesListBox.Enabled = false;
                    form.NoCommInterfacesLabel.Text = Resources.MsgNoCommInterfaces;
                }
            }
        }

        public void AddLogMessage(string message, bool isError)
        {
            logTextBox.AppendText(message + Environment.NewLine);
            if (isError)
                logTextBox.BackColor = Color.Pink;
        }

        public void SetStatusMessage(string status, bool isError)
        {
            labelOK.Text = status;
            labelError.Text = status;
            if (isError)
            {
                labelOK.Visible = false;
                labelError.Visible = true;
            }
            else
            {
                labelOK.Visible = true;
                labelError.Visible = false;
            }
        }
    }
}
