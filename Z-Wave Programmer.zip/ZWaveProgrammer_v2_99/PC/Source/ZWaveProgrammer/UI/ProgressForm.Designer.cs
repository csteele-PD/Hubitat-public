namespace ZWave.Programmer.UI
{
    partial class ProgressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProgressInfo = new System.Windows.Forms.Label();
            this.cmdAbort = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.waitingBar = new ZWave.Programmer.Controls.GradientWaitingBar();
            this.SuspendLayout();
            // 
            // lblProgressInfo
            // 
            this.lblProgressInfo.Location = new System.Drawing.Point(12, 9);
            this.lblProgressInfo.Name = "lblProgressInfo";
            this.lblProgressInfo.Size = new System.Drawing.Size(429, 54);
            this.lblProgressInfo.TabIndex = 1;
            this.lblProgressInfo.Text = "Progress ... \r\n.\r\n.";
            // 
            // cmdAbort
            // 
            this.cmdAbort.Location = new System.Drawing.Point(181, 104);
            this.cmdAbort.Name = "cmdAbort";
            this.cmdAbort.Size = new System.Drawing.Size(90, 23);
            this.cmdAbort.TabIndex = 4;
            this.cmdAbort.Text = "Abort Action";
            this.cmdAbort.UseVisualStyleBackColor = true;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(12, 63);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(0, 13);
            this.lblInfo.TabIndex = 5;
            // 
            // waitingBar
            // 
            this.waitingBar.BackColor = System.Drawing.Color.White;
            this.waitingBar.GradientColor1 = System.Drawing.Color.White;
            this.waitingBar.GradientColor2 = System.Drawing.Color.RoyalBlue;
            this.waitingBar.Interval = 20;
            this.waitingBar.Location = new System.Drawing.Point(15, 79);
            this.waitingBar.Name = "waitingBar";
            this.waitingBar.ScrollWAY = ZWave.Programmer.Controls.ScrollGradientAlignTypes.HORIZONTAL;
            this.waitingBar.Size = new System.Drawing.Size(426, 18);
            this.waitingBar.Speed = 5;
            this.waitingBar.TabIndex = 2;
            this.waitingBar.Text = "gradientWaitingBar1";
            // 
            // ProgressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 139);
            this.ControlBox = false;
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.cmdAbort);
            this.Controls.Add(this.waitingBar);
            this.Controls.Add(this.lblProgressInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ProgressForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = " Z-Wave Programmer";
            this.Load += new System.EventHandler(this.ProgressForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProgressInfo;
        private ZWave.Programmer.Controls.GradientWaitingBar waitingBar;
        private System.Windows.Forms.Button cmdAbort;
        private System.Windows.Forms.Label lblInfo;
    }
}