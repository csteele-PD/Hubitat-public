namespace ZWave.Programmer.UI
{
    partial class LogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogForm));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.logGridViewControl = new ZWave.Programmer.Controls.LogGridViewControl();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Magenta;
            this.imageList1.Images.SetKeyName(0, "InsertTabControl.bmp");
            this.imageList1.Images.SetKeyName(1, "EditCode.bmp");
            this.imageList1.Images.SetKeyName(2, "Input.bmp");
            this.imageList1.Images.SetKeyName(3, "Output.bmp");
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Data Packet";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Time";
            // 
            // logGridViewControl
            // 
            this.logGridViewControl.BackColor = System.Drawing.SystemColors.Control;
            this.logGridViewControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logGridViewControl.Location = new System.Drawing.Point(0, 0);
            this.logGridViewControl.Margin = new System.Windows.Forms.Padding(2);
            this.logGridViewControl.Name = "logGridViewControl";
            this.logGridViewControl.Size = new System.Drawing.Size(784, 411);
            this.logGridViewControl.TabIndex = 0;
            // 
            // LogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.logGridViewControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "LogForm";
            this.Text = "Log";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        public ZWave.Programmer.Controls.LogGridViewControl logGridViewControl;
    }
}