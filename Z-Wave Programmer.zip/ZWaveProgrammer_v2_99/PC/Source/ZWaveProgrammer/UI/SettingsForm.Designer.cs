namespace ZWave.Programmer.UI
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainTabControl = new System.Windows.Forms.TabControl();
            this.communicationTabPage = new System.Windows.Forms.TabPage();
            this.lblEmpty = new System.Windows.Forms.Label();
            this.interfacesListBox = new System.Windows.Forms.CheckedListBox();
            this.otherTabPage = new System.Windows.Forms.TabPage();
            this.settingsPropertyGrid = new System.Windows.Forms.PropertyGrid();
            this.cmdCancel = new System.Windows.Forms.Button();
            this.cmdOK = new System.Windows.Forms.Button();
            this.cmdApply = new System.Windows.Forms.Button();
            this.cmdDefaults = new System.Windows.Forms.Button();
            this.mainTabControl.SuspendLayout();
            this.communicationTabPage.SuspendLayout();
            this.otherTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainTabControl
            // 
            this.mainTabControl.Controls.Add(this.communicationTabPage);
            this.mainTabControl.Controls.Add(this.otherTabPage);
            this.mainTabControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.mainTabControl.Location = new System.Drawing.Point(0, 0);
            this.mainTabControl.Name = "mainTabControl";
            this.mainTabControl.SelectedIndex = 0;
            this.mainTabControl.Size = new System.Drawing.Size(395, 378);
            this.mainTabControl.TabIndex = 0;
            // 
            // communicationTabPage
            // 
            this.communicationTabPage.Controls.Add(this.lblEmpty);
            this.communicationTabPage.Controls.Add(this.interfacesListBox);
            this.communicationTabPage.Location = new System.Drawing.Point(4, 22);
            this.communicationTabPage.Name = "communicationTabPage";
            this.communicationTabPage.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.communicationTabPage.Size = new System.Drawing.Size(387, 352);
            this.communicationTabPage.TabIndex = 0;
            this.communicationTabPage.Text = "Communication";
            this.communicationTabPage.UseVisualStyleBackColor = true;
            // 
            // lblEmpty
            // 
            this.lblEmpty.AutoSize = true;
            this.lblEmpty.ForeColor = System.Drawing.Color.Red;
            this.lblEmpty.Location = new System.Drawing.Point(7, 313);
            this.lblEmpty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmpty.Name = "lblEmpty";
            this.lblEmpty.Size = new System.Drawing.Size(0, 13);
            this.lblEmpty.TabIndex = 5;
            // 
            // interfacesListBox
            // 
            this.interfacesListBox.CheckOnClick = true;
            this.interfacesListBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.interfacesListBox.FormattingEnabled = true;
            this.interfacesListBox.HorizontalScrollbar = true;
            this.interfacesListBox.Location = new System.Drawing.Point(3, 3);
            this.interfacesListBox.Name = "interfacesListBox";
            this.interfacesListBox.Size = new System.Drawing.Size(381, 304);
            this.interfacesListBox.TabIndex = 2;
            this.interfacesListBox.SelectedIndexChanged += new System.EventHandler(this.interfacesListBox_SelectedIndexChanged);
            this.interfacesListBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.interfacesListBox_ItemCheck);
            // 
            // otherTabPage
            // 
            this.otherTabPage.Controls.Add(this.settingsPropertyGrid);
            this.otherTabPage.Location = new System.Drawing.Point(4, 25);
            this.otherTabPage.Name = "otherTabPage";
            this.otherTabPage.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.otherTabPage.Size = new System.Drawing.Size(387, 349);
            this.otherTabPage.TabIndex = 1;
            this.otherTabPage.Text = "Other";
            this.otherTabPage.UseVisualStyleBackColor = true;
            // 
            // settingsPropertyGrid
            // 
            this.settingsPropertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.settingsPropertyGrid.Location = new System.Drawing.Point(3, 3);
            this.settingsPropertyGrid.Name = "settingsPropertyGrid";
            this.settingsPropertyGrid.Size = new System.Drawing.Size(381, 343);
            this.settingsPropertyGrid.TabIndex = 1;
            // 
            // cmdCancel
            // 
            this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cmdCancel.Location = new System.Drawing.Point(314, 399);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(75, 23);
            this.cmdCancel.TabIndex = 8;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = true;
            // 
            // cmdOK
            // 
            this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.cmdOK.Location = new System.Drawing.Point(232, 399);
            this.cmdOK.Name = "cmdOK";
            this.cmdOK.Size = new System.Drawing.Size(75, 23);
            this.cmdOK.TabIndex = 7;
            this.cmdOK.Text = "OK";
            this.cmdOK.UseVisualStyleBackColor = true;
            // 
            // cmdApply
            // 
            this.cmdApply.Location = new System.Drawing.Point(150, 399);
            this.cmdApply.Name = "cmdApply";
            this.cmdApply.Size = new System.Drawing.Size(75, 23);
            this.cmdApply.TabIndex = 6;
            this.cmdApply.Text = "Apply";
            this.cmdApply.UseVisualStyleBackColor = true;
            // 
            // cmdDefaults
            // 
            this.cmdDefaults.Location = new System.Drawing.Point(5, 399);
            this.cmdDefaults.Name = "cmdDefaults";
            this.cmdDefaults.Size = new System.Drawing.Size(75, 23);
            this.cmdDefaults.TabIndex = 5;
            this.cmdDefaults.Text = "Defaults";
            this.cmdDefaults.UseVisualStyleBackColor = true;
            // 
            // SettingsForm
            // 
            this.AcceptButton = this.cmdOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cmdCancel;
            this.ClientSize = new System.Drawing.Size(395, 434);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdOK);
            this.Controls.Add(this.cmdApply);
            this.Controls.Add(this.cmdDefaults);
            this.Controls.Add(this.mainTabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingsForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.SettingsForm_Load);
            this.mainTabControl.ResumeLayout(false);
            this.communicationTabPage.ResumeLayout(false);
            this.communicationTabPage.PerformLayout();
            this.otherTabPage.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl mainTabControl;
        private System.Windows.Forms.TabPage communicationTabPage;
        private System.Windows.Forms.TabPage otherTabPage;
        private System.Windows.Forms.Button cmdCancel;
        private System.Windows.Forms.Button cmdOK;
        private System.Windows.Forms.Button cmdApply;
        private System.Windows.Forms.Button cmdDefaults;
        private System.Windows.Forms.CheckedListBox interfacesListBox;
        private System.Windows.Forms.PropertyGrid settingsPropertyGrid;
        private System.Windows.Forms.Label lblEmpty;
    }
}