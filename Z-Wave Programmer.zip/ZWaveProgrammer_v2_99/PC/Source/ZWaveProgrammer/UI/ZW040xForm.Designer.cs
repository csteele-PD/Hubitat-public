namespace ZWave.Programmer.UI
{
    partial class ZW040xForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.calibrateAndProgrammButton = new System.Windows.Forms.Button();
            this.flashBrowseHexFileButton = new System.Windows.Forms.Button();
            this.flashReadButton = new System.Windows.Forms.Button();
            this.flashProgramButton = new System.Windows.Forms.Button();
            this.flashCompareButton = new System.Windows.Forms.Button();
            this.flashWriteButton = new System.Windows.Forms.Button();
            this.sramWiteAndRunModeButton = new System.Windows.Forms.Button();
            this.sramCompareButton = new System.Windows.Forms.Button();
            this.sramWriteButton = new System.Windows.Forms.Button();
            this.sramReadButton = new System.Windows.Forms.Button();
            this.changeHomeIdButton = new System.Windows.Forms.Button();
            this.readHomeIdButton = new System.Windows.Forms.Button();
            this.eepromProgramButton = new System.Windows.Forms.Button();
            this.eepromCompareButton = new System.Windows.Forms.Button();
            this.eepromEraseButton = new System.Windows.Forms.Button();
            this.eepromBrowseHexFileButton = new System.Windows.Forms.Button();
            this.eepromReadButton = new System.Windows.Forms.Button();
            this.mtpProgramButton = new System.Windows.Forms.Button();
            this.mtpCompareButton = new System.Windows.Forms.Button();
            this.mtpReadButton = new System.Windows.Forms.Button();
            this.mtpEraseButton = new System.Windows.Forms.Button();
            this.crcCheckButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.productionButton = new System.Windows.Forms.Button();
            this.flashWriteOptionsButton = new System.Windows.Forms.Button();
            this.flashHexFileNameLabel = new System.Windows.Forms.Label();
            this.flashReadOptionsButton = new System.Windows.Forms.Button();
            this.sramOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.calibrationValueTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lowTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lowTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lowTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.lowTxPowerLabel = new System.Windows.Forms.Label();
            this.normalTxPowerLabel = new System.Windows.Forms.Label();
            this.flashHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.sramLowTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.sramNormalTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.sramLowTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.sramNormalTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.sramLowTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.sramNormalTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.sramWriteOptionsButton = new System.Windows.Forms.Button();
            this.sramReadOptionsButton = new System.Windows.Forms.Button();
            this.sramHexFileNameLabel = new System.Windows.Forms.Label();
            this.sramBrowseHexFileButton = new System.Windows.Forms.Button();
            this.sramOperationModesGroupBox = new System.Windows.Forms.GroupBox();
            this.modeExecOutOfSRAMRadioButton = new System.Windows.Forms.RadioButton();
            this.modeDevelopmentRadioButton = new System.Windows.Forms.RadioButton();
            this.sramHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.homeIdSettingsGroupBox = new System.Windows.Forms.GroupBox();
            this.autoIncrementHomeIdGroupBox = new System.Windows.Forms.GroupBox();
            this.endHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.startHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.endHomeIdLabel = new System.Windows.Forms.Label();
            this.startHomeIdLabel = new System.Windows.Forms.Label();
            this.autoIncrementHomeIdCheckBox = new System.Windows.Forms.CheckBox();
            this.readHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.currentHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.readHomeIdLabel = new System.Windows.Forms.Label();
            this.currentHomeIdLabel = new System.Windows.Forms.Label();
            this.eepromHexFileNameLabel = new System.Windows.Forms.Label();
            this.eepromHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.lockBitsGroupBox = new System.Windows.Forms.GroupBox();
            this.lockBitsSetButton = new System.Windows.Forms.Button();
            this.lockBitsReadButton = new System.Windows.Forms.Button();
            this.setModemCheckBox = new System.Windows.Forms.CheckBox();
            this.disableDevModeCheckBox = new System.Windows.Forms.CheckBox();
            this.disableReadBackCheckBox = new System.Windows.Forms.CheckBox();
            this.mtpGroupBox = new System.Windows.Forms.GroupBox();
            this.mtpAutoEraseCheckBox = new System.Windows.Forms.CheckBox();
            this.mtpHexFileNameLabel = new System.Windows.Forms.Label();
            this.mtpHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.mtpBrowseHexFileButton = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.sramOptionsGroupBox.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.sramOperationModesGroupBox.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.homeIdSettingsGroupBox.SuspendLayout();
            this.autoIncrementHomeIdGroupBox.SuspendLayout();
            this.lockBitsGroupBox.SuspendLayout();
            this.mtpGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // calibrateAndProgrammButton
            // 
            this.calibrateAndProgrammButton.Location = new System.Drawing.Point(93, 68);
            this.calibrateAndProgrammButton.Name = "calibrateAndProgrammButton";
            this.calibrateAndProgrammButton.Size = new System.Drawing.Size(158, 23);
            this.calibrateAndProgrammButton.TabIndex = 8;
            this.calibrateAndProgrammButton.Text = "Calibrate, Program and Verify";
            this.mainToolTip.SetToolTip(this.calibrateAndProgrammButton, "Ctrl+P");
            this.calibrateAndProgrammButton.UseVisualStyleBackColor = true;
            // 
            // flashBrowseHexFileButton
            // 
            this.flashBrowseHexFileButton.Location = new System.Drawing.Point(407, 10);
            this.flashBrowseHexFileButton.Name = "flashBrowseHexFileButton";
            this.flashBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.flashBrowseHexFileButton.TabIndex = 2;
            this.flashBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.flashBrowseHexFileButton, "Ctrl+O");
            this.flashBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // flashReadButton
            // 
            this.flashReadButton.Location = new System.Drawing.Point(11, 39);
            this.flashReadButton.Name = "flashReadButton";
            this.flashReadButton.Size = new System.Drawing.Size(75, 23);
            this.flashReadButton.TabIndex = 3;
            this.flashReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.flashReadButton, "Ctrl+R");
            this.flashReadButton.UseVisualStyleBackColor = true;
            // 
            // flashProgramButton
            // 
            this.flashProgramButton.Location = new System.Drawing.Point(93, 39);
            this.flashProgramButton.Name = "flashProgramButton";
            this.flashProgramButton.Size = new System.Drawing.Size(158, 23);
            this.flashProgramButton.TabIndex = 4;
            this.flashProgramButton.Text = "Program and Verify";
            this.mainToolTip.SetToolTip(this.flashProgramButton, "Ctrl+P");
            this.flashProgramButton.UseVisualStyleBackColor = true;
            // 
            // flashCompareButton
            // 
            this.flashCompareButton.Location = new System.Drawing.Point(257, 39);
            this.flashCompareButton.Name = "flashCompareButton";
            this.flashCompareButton.Size = new System.Drawing.Size(75, 23);
            this.flashCompareButton.TabIndex = 5;
            this.flashCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.flashCompareButton, "Ctrl+M");
            this.flashCompareButton.UseVisualStyleBackColor = true;
            // 
            // flashWriteButton
            // 
            this.flashWriteButton.Location = new System.Drawing.Point(10, 68);
            this.flashWriteButton.Name = "flashWriteButton";
            this.flashWriteButton.Size = new System.Drawing.Size(75, 23);
            this.flashWriteButton.TabIndex = 7;
            this.flashWriteButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.flashWriteButton, "Ctrl+W");
            this.flashWriteButton.UseVisualStyleBackColor = true;
            // 
            // sramWiteAndRunModeButton
            // 
            this.sramWiteAndRunModeButton.Location = new System.Drawing.Point(172, 38);
            this.sramWiteAndRunModeButton.Name = "sramWiteAndRunModeButton";
            this.sramWiteAndRunModeButton.Size = new System.Drawing.Size(237, 23);
            this.sramWiteAndRunModeButton.TabIndex = 32;
            this.sramWiteAndRunModeButton.Text = "Program SRAM and Run Selected Mode";
            this.mainToolTip.SetToolTip(this.sramWiteAndRunModeButton, "Ctrl+Alt+P");
            this.sramWiteAndRunModeButton.UseVisualStyleBackColor = true;
            // 
            // sramCompareButton
            // 
            this.sramCompareButton.Location = new System.Drawing.Point(334, 13);
            this.sramCompareButton.Name = "sramCompareButton";
            this.sramCompareButton.Size = new System.Drawing.Size(75, 23);
            this.sramCompareButton.TabIndex = 1;
            this.sramCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.sramCompareButton, "Ctrl+Alt+C");
            this.sramCompareButton.UseVisualStyleBackColor = true;
            // 
            // sramWriteButton
            // 
            this.sramWriteButton.Location = new System.Drawing.Point(253, 13);
            this.sramWriteButton.Name = "sramWriteButton";
            this.sramWriteButton.Size = new System.Drawing.Size(75, 23);
            this.sramWriteButton.TabIndex = 0;
            this.sramWriteButton.Text = "Write";
            this.mainToolTip.SetToolTip(this.sramWriteButton, "Ctrl+Alt+W");
            this.sramWriteButton.UseVisualStyleBackColor = true;
            // 
            // sramReadButton
            // 
            this.sramReadButton.Location = new System.Drawing.Point(172, 13);
            this.sramReadButton.Name = "sramReadButton";
            this.sramReadButton.Size = new System.Drawing.Size(75, 23);
            this.sramReadButton.TabIndex = 0;
            this.sramReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.sramReadButton, "Ctrl+Alt+R");
            this.sramReadButton.UseVisualStyleBackColor = true;
            // 
            // changeHomeIdButton
            // 
            this.changeHomeIdButton.Location = new System.Drawing.Point(22, 88);
            this.changeHomeIdButton.Name = "changeHomeIdButton";
            this.changeHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.changeHomeIdButton.TabIndex = 4;
            this.changeHomeIdButton.Text = "Set";
            this.mainToolTip.SetToolTip(this.changeHomeIdButton, "Shift+W");
            this.changeHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // readHomeIdButton
            // 
            this.readHomeIdButton.Location = new System.Drawing.Point(109, 88);
            this.readHomeIdButton.Name = "readHomeIdButton";
            this.readHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.readHomeIdButton.TabIndex = 5;
            this.readHomeIdButton.Text = "Get";
            this.mainToolTip.SetToolTip(this.readHomeIdButton, "Shift+R");
            this.readHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // eepromProgramButton
            // 
            this.eepromProgramButton.Location = new System.Drawing.Point(257, 39);
            this.eepromProgramButton.Name = "eepromProgramButton";
            this.eepromProgramButton.Size = new System.Drawing.Size(75, 23);
            this.eepromProgramButton.TabIndex = 5;
            this.eepromProgramButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.eepromProgramButton, "Alt+P");
            this.eepromProgramButton.UseVisualStyleBackColor = true;
            // 
            // eepromCompareButton
            // 
            this.eepromCompareButton.Location = new System.Drawing.Point(338, 39);
            this.eepromCompareButton.Name = "eepromCompareButton";
            this.eepromCompareButton.Size = new System.Drawing.Size(75, 23);
            this.eepromCompareButton.TabIndex = 6;
            this.eepromCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.eepromCompareButton, "Alt+M");
            this.eepromCompareButton.UseVisualStyleBackColor = true;
            // 
            // eepromEraseButton
            // 
            this.eepromEraseButton.Location = new System.Drawing.Point(11, 39);
            this.eepromEraseButton.Name = "eepromEraseButton";
            this.eepromEraseButton.Size = new System.Drawing.Size(75, 23);
            this.eepromEraseButton.TabIndex = 3;
            this.eepromEraseButton.Text = "Erase";
            this.mainToolTip.SetToolTip(this.eepromEraseButton, "Alt+E");
            this.eepromEraseButton.UseVisualStyleBackColor = true;
            // 
            // eepromBrowseHexFileButton
            // 
            this.eepromBrowseHexFileButton.Location = new System.Drawing.Point(385, 10);
            this.eepromBrowseHexFileButton.Name = "eepromBrowseHexFileButton";
            this.eepromBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.eepromBrowseHexFileButton.TabIndex = 2;
            this.eepromBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.eepromBrowseHexFileButton, "Alt+O");
            this.eepromBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // eepromReadButton
            // 
            this.eepromReadButton.Location = new System.Drawing.Point(92, 39);
            this.eepromReadButton.Name = "eepromReadButton";
            this.eepromReadButton.Size = new System.Drawing.Size(75, 23);
            this.eepromReadButton.TabIndex = 4;
            this.eepromReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.eepromReadButton, "Alt+R");
            this.eepromReadButton.UseVisualStyleBackColor = true;
            // 
            // mtpProgramButton
            // 
            this.mtpProgramButton.Location = new System.Drawing.Point(260, 62);
            this.mtpProgramButton.Name = "mtpProgramButton";
            this.mtpProgramButton.Size = new System.Drawing.Size(75, 23);
            this.mtpProgramButton.TabIndex = 6;
            this.mtpProgramButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.mtpProgramButton, "Alt+P");
            this.mtpProgramButton.UseVisualStyleBackColor = true;
            // 
            // mtpCompareButton
            // 
            this.mtpCompareButton.Location = new System.Drawing.Point(341, 62);
            this.mtpCompareButton.Name = "mtpCompareButton";
            this.mtpCompareButton.Size = new System.Drawing.Size(75, 23);
            this.mtpCompareButton.TabIndex = 7;
            this.mtpCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.mtpCompareButton, "Alt+M");
            this.mtpCompareButton.UseVisualStyleBackColor = true;
            // 
            // mtpReadButton
            // 
            this.mtpReadButton.Location = new System.Drawing.Point(95, 62);
            this.mtpReadButton.Name = "mtpReadButton";
            this.mtpReadButton.Size = new System.Drawing.Size(75, 23);
            this.mtpReadButton.TabIndex = 5;
            this.mtpReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.mtpReadButton, "Alt+R");
            this.mtpReadButton.UseVisualStyleBackColor = true;
            // 
            // mtpEraseButton
            // 
            this.mtpEraseButton.Location = new System.Drawing.Point(14, 62);
            this.mtpEraseButton.Name = "mtpEraseButton";
            this.mtpEraseButton.Size = new System.Drawing.Size(75, 23);
            this.mtpEraseButton.TabIndex = 4;
            this.mtpEraseButton.Text = "Erase";
            this.mainToolTip.SetToolTip(this.mtpEraseButton, "Alt+E");
            this.mtpEraseButton.UseVisualStyleBackColor = true;
            // 
            // crcCheckButton
            // 
            this.crcCheckButton.Enabled = false;
            this.crcCheckButton.Location = new System.Drawing.Point(257, 68);
            this.crcCheckButton.Name = "crcCheckButton";
            this.crcCheckButton.Size = new System.Drawing.Size(75, 23);
            this.crcCheckButton.TabIndex = 6;
            this.crcCheckButton.Text = "Check CRC";
            this.crcCheckButton.UseVisualStyleBackColor = true;
            this.crcCheckButton.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(450, 287);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.productionButton);
            this.tabPage1.Controls.Add(this.calibrateAndProgrammButton);
            this.tabPage1.Controls.Add(this.flashWriteOptionsButton);
            this.tabPage1.Controls.Add(this.flashHexFileNameLabel);
            this.tabPage1.Controls.Add(this.flashReadOptionsButton);
            this.tabPage1.Controls.Add(this.flashBrowseHexFileButton);
            this.tabPage1.Controls.Add(this.sramOptionsGroupBox);
            this.tabPage1.Controls.Add(this.flashReadButton);
            this.tabPage1.Controls.Add(this.flashProgramButton);
            this.tabPage1.Controls.Add(this.flashHexFileNameTextBox);
            this.tabPage1.Controls.Add(this.crcCheckButton);
            this.tabPage1.Controls.Add(this.flashCompareButton);
            this.tabPage1.Controls.Add(this.flashWriteButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(442, 261);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "OTP Memory";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // productionButton
            // 
            this.productionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productionButton.ForeColor = System.Drawing.Color.RoyalBlue;
            this.productionButton.Location = new System.Drawing.Point(339, 39);
            this.productionButton.Name = "productionButton";
            this.productionButton.Size = new System.Drawing.Size(96, 52);
            this.productionButton.TabIndex = 12;
            this.productionButton.Text = "Production";
            this.productionButton.UseVisualStyleBackColor = true;
            this.productionButton.Visible = false;
            // 
            // flashWriteOptionsButton
            // 
            this.flashWriteOptionsButton.Enabled = false;
            this.flashWriteOptionsButton.Location = new System.Drawing.Point(360, 134);
            this.flashWriteOptionsButton.Name = "flashWriteOptionsButton";
            this.flashWriteOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.flashWriteOptionsButton.TabIndex = 11;
            this.flashWriteOptionsButton.Text = "Set Options";
            this.flashWriteOptionsButton.UseVisualStyleBackColor = true;
            this.flashWriteOptionsButton.Visible = false;
            // 
            // flashHexFileNameLabel
            // 
            this.flashHexFileNameLabel.AutoSize = true;
            this.flashHexFileNameLabel.Location = new System.Drawing.Point(8, 15);
            this.flashHexFileNameLabel.Name = "flashHexFileNameLabel";
            this.flashHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.flashHexFileNameLabel.TabIndex = 0;
            this.flashHexFileNameLabel.Text = "HEX File:";
            // 
            // flashReadOptionsButton
            // 
            this.flashReadOptionsButton.Location = new System.Drawing.Point(360, 110);
            this.flashReadOptionsButton.Name = "flashReadOptionsButton";
            this.flashReadOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.flashReadOptionsButton.TabIndex = 10;
            this.flashReadOptionsButton.Text = "Get Options";
            this.flashReadOptionsButton.UseVisualStyleBackColor = true;
            // 
            // sramOptionsGroupBox
            // 
            this.sramOptionsGroupBox.Controls.Add(this.calibrationValueTextBox);
            this.sramOptionsGroupBox.Controls.Add(this.label9);
            this.sramOptionsGroupBox.Controls.Add(this.label3);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh2TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh2TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.label2);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh1TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh1TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.label1);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh0TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh0TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerLabel);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerLabel);
            this.sramOptionsGroupBox.Location = new System.Drawing.Point(6, 105);
            this.sramOptionsGroupBox.Name = "sramOptionsGroupBox";
            this.sramOptionsGroupBox.Size = new System.Drawing.Size(328, 146);
            this.sramOptionsGroupBox.TabIndex = 9;
            this.sramOptionsGroupBox.TabStop = false;
            this.sramOptionsGroupBox.Text = "Options";
            // 
            // calibrationValueTextBox
            // 
            this.calibrationValueTextBox.Location = new System.Drawing.Point(101, 109);
            this.calibrationValueTextBox.MaxLength = 2;
            this.calibrationValueTextBox.Name = "calibrationValueTextBox";
            this.calibrationValueTextBox.Size = new System.Drawing.Size(88, 20);
            this.calibrationValueTextBox.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Calibration value:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Channel 2:";
            // 
            // lowTxPowerCh2TextBox
            // 
            this.lowTxPowerCh2TextBox.Location = new System.Drawing.Point(205, 83);
            this.lowTxPowerCh2TextBox.MaxLength = 2;
            this.lowTxPowerCh2TextBox.Name = "lowTxPowerCh2TextBox";
            this.lowTxPowerCh2TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh2TextBox.TabIndex = 10;
            // 
            // normalTxPowerCh2TextBox
            // 
            this.normalTxPowerCh2TextBox.Location = new System.Drawing.Point(101, 83);
            this.normalTxPowerCh2TextBox.MaxLength = 2;
            this.normalTxPowerCh2TextBox.Name = "normalTxPowerCh2TextBox";
            this.normalTxPowerCh2TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh2TextBox.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Channel 1:";
            // 
            // lowTxPowerCh1TextBox
            // 
            this.lowTxPowerCh1TextBox.Location = new System.Drawing.Point(205, 57);
            this.lowTxPowerCh1TextBox.MaxLength = 2;
            this.lowTxPowerCh1TextBox.Name = "lowTxPowerCh1TextBox";
            this.lowTxPowerCh1TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh1TextBox.TabIndex = 7;
            // 
            // normalTxPowerCh1TextBox
            // 
            this.normalTxPowerCh1TextBox.Location = new System.Drawing.Point(101, 57);
            this.normalTxPowerCh1TextBox.MaxLength = 2;
            this.normalTxPowerCh1TextBox.Name = "normalTxPowerCh1TextBox";
            this.normalTxPowerCh1TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh1TextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Channel 0:";
            // 
            // lowTxPowerCh0TextBox
            // 
            this.lowTxPowerCh0TextBox.Location = new System.Drawing.Point(205, 31);
            this.lowTxPowerCh0TextBox.MaxLength = 2;
            this.lowTxPowerCh0TextBox.Name = "lowTxPowerCh0TextBox";
            this.lowTxPowerCh0TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh0TextBox.TabIndex = 4;
            // 
            // normalTxPowerCh0TextBox
            // 
            this.normalTxPowerCh0TextBox.Location = new System.Drawing.Point(101, 31);
            this.normalTxPowerCh0TextBox.MaxLength = 2;
            this.normalTxPowerCh0TextBox.Name = "normalTxPowerCh0TextBox";
            this.normalTxPowerCh0TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh0TextBox.TabIndex = 3;
            // 
            // lowTxPowerLabel
            // 
            this.lowTxPowerLabel.AutoSize = true;
            this.lowTxPowerLabel.Location = new System.Drawing.Point(202, 14);
            this.lowTxPowerLabel.Name = "lowTxPowerLabel";
            this.lowTxPowerLabel.Size = new System.Drawing.Size(78, 13);
            this.lowTxPowerLabel.TabIndex = 1;
            this.lowTxPowerLabel.Text = "Low Tx Power:";
            // 
            // normalTxPowerLabel
            // 
            this.normalTxPowerLabel.AutoSize = true;
            this.normalTxPowerLabel.Location = new System.Drawing.Point(98, 15);
            this.normalTxPowerLabel.Name = "normalTxPowerLabel";
            this.normalTxPowerLabel.Size = new System.Drawing.Size(91, 13);
            this.normalTxPowerLabel.TabIndex = 0;
            this.normalTxPowerLabel.Text = "Normal Tx Power:";
            // 
            // flashHexFileNameTextBox
            // 
            this.flashHexFileNameTextBox.Location = new System.Drawing.Point(65, 12);
            this.flashHexFileNameTextBox.Name = "flashHexFileNameTextBox";
            this.flashHexFileNameTextBox.ReadOnly = true;
            this.flashHexFileNameTextBox.Size = new System.Drawing.Size(337, 20);
            this.flashHexFileNameTextBox.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.sramWriteOptionsButton);
            this.tabPage2.Controls.Add(this.sramReadOptionsButton);
            this.tabPage2.Controls.Add(this.sramHexFileNameLabel);
            this.tabPage2.Controls.Add(this.sramBrowseHexFileButton);
            this.tabPage2.Controls.Add(this.sramOperationModesGroupBox);
            this.tabPage2.Controls.Add(this.sramHexFileNameTextBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(442, 261);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SRAM";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.sramLowTxPowerCh2TextBox);
            this.groupBox1.Controls.Add(this.sramNormalTxPowerCh2TextBox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.sramLowTxPowerCh1TextBox);
            this.groupBox1.Controls.Add(this.sramNormalTxPowerCh1TextBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.sramLowTxPowerCh0TextBox);
            this.groupBox1.Controls.Add(this.sramNormalTxPowerCh0TextBox);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(6, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(328, 114);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Channel 2:";
            // 
            // sramLowTxPowerCh2TextBox
            // 
            this.sramLowTxPowerCh2TextBox.Location = new System.Drawing.Point(205, 83);
            this.sramLowTxPowerCh2TextBox.MaxLength = 2;
            this.sramLowTxPowerCh2TextBox.Name = "sramLowTxPowerCh2TextBox";
            this.sramLowTxPowerCh2TextBox.Size = new System.Drawing.Size(75, 20);
            this.sramLowTxPowerCh2TextBox.TabIndex = 11;
            // 
            // sramNormalTxPowerCh2TextBox
            // 
            this.sramNormalTxPowerCh2TextBox.Location = new System.Drawing.Point(101, 83);
            this.sramNormalTxPowerCh2TextBox.MaxLength = 2;
            this.sramNormalTxPowerCh2TextBox.Name = "sramNormalTxPowerCh2TextBox";
            this.sramNormalTxPowerCh2TextBox.Size = new System.Drawing.Size(88, 20);
            this.sramNormalTxPowerCh2TextBox.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Channel 1:";
            // 
            // sramLowTxPowerCh1TextBox
            // 
            this.sramLowTxPowerCh1TextBox.Location = new System.Drawing.Point(205, 57);
            this.sramLowTxPowerCh1TextBox.MaxLength = 2;
            this.sramLowTxPowerCh1TextBox.Name = "sramLowTxPowerCh1TextBox";
            this.sramLowTxPowerCh1TextBox.Size = new System.Drawing.Size(75, 20);
            this.sramLowTxPowerCh1TextBox.TabIndex = 8;
            // 
            // sramNormalTxPowerCh1TextBox
            // 
            this.sramNormalTxPowerCh1TextBox.Location = new System.Drawing.Point(101, 57);
            this.sramNormalTxPowerCh1TextBox.MaxLength = 2;
            this.sramNormalTxPowerCh1TextBox.Name = "sramNormalTxPowerCh1TextBox";
            this.sramNormalTxPowerCh1TextBox.Size = new System.Drawing.Size(88, 20);
            this.sramNormalTxPowerCh1TextBox.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Channel 0:";
            // 
            // sramLowTxPowerCh0TextBox
            // 
            this.sramLowTxPowerCh0TextBox.Location = new System.Drawing.Point(205, 31);
            this.sramLowTxPowerCh0TextBox.MaxLength = 2;
            this.sramLowTxPowerCh0TextBox.Name = "sramLowTxPowerCh0TextBox";
            this.sramLowTxPowerCh0TextBox.Size = new System.Drawing.Size(75, 20);
            this.sramLowTxPowerCh0TextBox.TabIndex = 5;
            // 
            // sramNormalTxPowerCh0TextBox
            // 
            this.sramNormalTxPowerCh0TextBox.Location = new System.Drawing.Point(101, 31);
            this.sramNormalTxPowerCh0TextBox.MaxLength = 2;
            this.sramNormalTxPowerCh0TextBox.Name = "sramNormalTxPowerCh0TextBox";
            this.sramNormalTxPowerCh0TextBox.Size = new System.Drawing.Size(88, 20);
            this.sramNormalTxPowerCh0TextBox.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(202, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Low Tx Power:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(98, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Normal Tx Power:";
            // 
            // sramWriteOptionsButton
            // 
            this.sramWriteOptionsButton.Location = new System.Drawing.Point(345, 135);
            this.sramWriteOptionsButton.Name = "sramWriteOptionsButton";
            this.sramWriteOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.sramWriteOptionsButton.TabIndex = 39;
            this.sramWriteOptionsButton.Text = "Set Options";
            this.sramWriteOptionsButton.UseVisualStyleBackColor = true;
            // 
            // sramReadOptionsButton
            // 
            this.sramReadOptionsButton.Location = new System.Drawing.Point(345, 110);
            this.sramReadOptionsButton.Name = "sramReadOptionsButton";
            this.sramReadOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.sramReadOptionsButton.TabIndex = 40;
            this.sramReadOptionsButton.Text = "Get Options";
            this.sramReadOptionsButton.UseVisualStyleBackColor = true;
            // 
            // sramHexFileNameLabel
            // 
            this.sramHexFileNameLabel.AutoSize = true;
            this.sramHexFileNameLabel.Location = new System.Drawing.Point(8, 15);
            this.sramHexFileNameLabel.Name = "sramHexFileNameLabel";
            this.sramHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.sramHexFileNameLabel.TabIndex = 29;
            this.sramHexFileNameLabel.Text = "HEX File:";
            // 
            // sramBrowseHexFileButton
            // 
            this.sramBrowseHexFileButton.Location = new System.Drawing.Point(385, 10);
            this.sramBrowseHexFileButton.Name = "sramBrowseHexFileButton";
            this.sramBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.sramBrowseHexFileButton.TabIndex = 31;
            this.sramBrowseHexFileButton.Text = "...";
            this.sramBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // sramOperationModesGroupBox
            // 
            this.sramOperationModesGroupBox.Controls.Add(this.modeExecOutOfSRAMRadioButton);
            this.sramOperationModesGroupBox.Controls.Add(this.modeDevelopmentRadioButton);
            this.sramOperationModesGroupBox.Controls.Add(this.sramWiteAndRunModeButton);
            this.sramOperationModesGroupBox.Controls.Add(this.sramCompareButton);
            this.sramOperationModesGroupBox.Controls.Add(this.sramWriteButton);
            this.sramOperationModesGroupBox.Controls.Add(this.sramReadButton);
            this.sramOperationModesGroupBox.Location = new System.Drawing.Point(6, 38);
            this.sramOperationModesGroupBox.Name = "sramOperationModesGroupBox";
            this.sramOperationModesGroupBox.Size = new System.Drawing.Size(416, 66);
            this.sramOperationModesGroupBox.TabIndex = 34;
            this.sramOperationModesGroupBox.TabStop = false;
            this.sramOperationModesGroupBox.Text = "Operation mode:";
            // 
            // modeExecOutOfSRAMRadioButton
            // 
            this.modeExecOutOfSRAMRadioButton.AutoSize = true;
            this.modeExecOutOfSRAMRadioButton.Location = new System.Drawing.Point(6, 41);
            this.modeExecOutOfSRAMRadioButton.Name = "modeExecOutOfSRAMRadioButton";
            this.modeExecOutOfSRAMRadioButton.Size = new System.Drawing.Size(130, 17);
            this.modeExecOutOfSRAMRadioButton.TabIndex = 0;
            this.modeExecOutOfSRAMRadioButton.TabStop = true;
            this.modeExecOutOfSRAMRadioButton.Text = "Execute Out of SRAM";
            this.modeExecOutOfSRAMRadioButton.UseVisualStyleBackColor = true;
            // 
            // modeDevelopmentRadioButton
            // 
            this.modeDevelopmentRadioButton.AutoSize = true;
            this.modeDevelopmentRadioButton.Location = new System.Drawing.Point(6, 19);
            this.modeDevelopmentRadioButton.Name = "modeDevelopmentRadioButton";
            this.modeDevelopmentRadioButton.Size = new System.Drawing.Size(88, 17);
            this.modeDevelopmentRadioButton.TabIndex = 0;
            this.modeDevelopmentRadioButton.TabStop = true;
            this.modeDevelopmentRadioButton.Text = "Development";
            this.modeDevelopmentRadioButton.UseVisualStyleBackColor = true;
            // 
            // sramHexFileNameTextBox
            // 
            this.sramHexFileNameTextBox.Location = new System.Drawing.Point(65, 12);
            this.sramHexFileNameTextBox.Name = "sramHexFileNameTextBox";
            this.sramHexFileNameTextBox.ReadOnly = true;
            this.sramHexFileNameTextBox.Size = new System.Drawing.Size(314, 20);
            this.sramHexFileNameTextBox.TabIndex = 30;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.homeIdSettingsGroupBox);
            this.tabPage3.Controls.Add(this.eepromProgramButton);
            this.tabPage3.Controls.Add(this.eepromHexFileNameLabel);
            this.tabPage3.Controls.Add(this.eepromCompareButton);
            this.tabPage3.Controls.Add(this.eepromEraseButton);
            this.tabPage3.Controls.Add(this.eepromBrowseHexFileButton);
            this.tabPage3.Controls.Add(this.eepromHexFileNameTextBox);
            this.tabPage3.Controls.Add(this.eepromReadButton);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(442, 261);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "External Non-Volatile Memory";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // homeIdSettingsGroupBox
            // 
            this.homeIdSettingsGroupBox.Controls.Add(this.autoIncrementHomeIdGroupBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.changeHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdLabel);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdLabel);
            this.homeIdSettingsGroupBox.Location = new System.Drawing.Point(11, 77);
            this.homeIdSettingsGroupBox.Name = "homeIdSettingsGroupBox";
            this.homeIdSettingsGroupBox.Size = new System.Drawing.Size(402, 126);
            this.homeIdSettingsGroupBox.TabIndex = 7;
            this.homeIdSettingsGroupBox.TabStop = false;
            this.homeIdSettingsGroupBox.Text = "Home Id Settings";
            // 
            // autoIncrementHomeIdGroupBox
            // 
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.endHomeIdTextBox);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.startHomeIdTextBox);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.endHomeIdLabel);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.startHomeIdLabel);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.autoIncrementHomeIdCheckBox);
            this.autoIncrementHomeIdGroupBox.Location = new System.Drawing.Point(199, 15);
            this.autoIncrementHomeIdGroupBox.Name = "autoIncrementHomeIdGroupBox";
            this.autoIncrementHomeIdGroupBox.Size = new System.Drawing.Size(189, 100);
            this.autoIncrementHomeIdGroupBox.TabIndex = 42;
            this.autoIncrementHomeIdGroupBox.TabStop = false;
            // 
            // endHomeIdTextBox
            // 
            this.endHomeIdTextBox.Location = new System.Drawing.Point(83, 53);
            this.endHomeIdTextBox.Name = "endHomeIdTextBox";
            this.endHomeIdTextBox.Size = new System.Drawing.Size(91, 20);
            this.endHomeIdTextBox.TabIndex = 4;
            // 
            // startHomeIdTextBox
            // 
            this.startHomeIdTextBox.Location = new System.Drawing.Point(83, 27);
            this.startHomeIdTextBox.Name = "startHomeIdTextBox";
            this.startHomeIdTextBox.Size = new System.Drawing.Size(91, 20);
            this.startHomeIdTextBox.TabIndex = 2;
            // 
            // endHomeIdLabel
            // 
            this.endHomeIdLabel.AutoSize = true;
            this.endHomeIdLabel.Location = new System.Drawing.Point(6, 56);
            this.endHomeIdLabel.Name = "endHomeIdLabel";
            this.endHomeIdLabel.Size = new System.Drawing.Size(72, 13);
            this.endHomeIdLabel.TabIndex = 3;
            this.endHomeIdLabel.Text = "End Home Id:";
            // 
            // startHomeIdLabel
            // 
            this.startHomeIdLabel.AutoSize = true;
            this.startHomeIdLabel.Location = new System.Drawing.Point(6, 30);
            this.startHomeIdLabel.Name = "startHomeIdLabel";
            this.startHomeIdLabel.Size = new System.Drawing.Size(75, 13);
            this.startHomeIdLabel.TabIndex = 1;
            this.startHomeIdLabel.Text = "Start Home Id:";
            // 
            // autoIncrementHomeIdCheckBox
            // 
            this.autoIncrementHomeIdCheckBox.AutoSize = true;
            this.autoIncrementHomeIdCheckBox.Location = new System.Drawing.Point(6, 0);
            this.autoIncrementHomeIdCheckBox.Name = "autoIncrementHomeIdCheckBox";
            this.autoIncrementHomeIdCheckBox.Size = new System.Drawing.Size(98, 17);
            this.autoIncrementHomeIdCheckBox.TabIndex = 0;
            this.autoIncrementHomeIdCheckBox.Text = "Auto Increment";
            this.autoIncrementHomeIdCheckBox.UseVisualStyleBackColor = true;
            // 
            // readHomeIdTextBox
            // 
            this.readHomeIdTextBox.Location = new System.Drawing.Point(81, 53);
            this.readHomeIdTextBox.Name = "readHomeIdTextBox";
            this.readHomeIdTextBox.ReadOnly = true;
            this.readHomeIdTextBox.Size = new System.Drawing.Size(107, 20);
            this.readHomeIdTextBox.TabIndex = 3;
            // 
            // currentHomeIdTextBox
            // 
            this.currentHomeIdTextBox.Location = new System.Drawing.Point(81, 27);
            this.currentHomeIdTextBox.Name = "currentHomeIdTextBox";
            this.currentHomeIdTextBox.Size = new System.Drawing.Size(107, 20);
            this.currentHomeIdTextBox.TabIndex = 1;
            // 
            // readHomeIdLabel
            // 
            this.readHomeIdLabel.AutoSize = true;
            this.readHomeIdLabel.Location = new System.Drawing.Point(19, 56);
            this.readHomeIdLabel.Name = "readHomeIdLabel";
            this.readHomeIdLabel.Size = new System.Drawing.Size(36, 13);
            this.readHomeIdLabel.TabIndex = 2;
            this.readHomeIdLabel.Text = "Read:";
            // 
            // currentHomeIdLabel
            // 
            this.currentHomeIdLabel.AutoSize = true;
            this.currentHomeIdLabel.Location = new System.Drawing.Point(19, 30);
            this.currentHomeIdLabel.Name = "currentHomeIdLabel";
            this.currentHomeIdLabel.Size = new System.Drawing.Size(56, 13);
            this.currentHomeIdLabel.TabIndex = 0;
            this.currentHomeIdLabel.Text = "Current Id:";
            // 
            // eepromHexFileNameLabel
            // 
            this.eepromHexFileNameLabel.AutoSize = true;
            this.eepromHexFileNameLabel.Location = new System.Drawing.Point(8, 15);
            this.eepromHexFileNameLabel.Name = "eepromHexFileNameLabel";
            this.eepromHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.eepromHexFileNameLabel.TabIndex = 0;
            this.eepromHexFileNameLabel.Text = "HEX File:";
            // 
            // eepromHexFileNameTextBox
            // 
            this.eepromHexFileNameTextBox.Location = new System.Drawing.Point(65, 12);
            this.eepromHexFileNameTextBox.Name = "eepromHexFileNameTextBox";
            this.eepromHexFileNameTextBox.ReadOnly = true;
            this.eepromHexFileNameTextBox.Size = new System.Drawing.Size(314, 20);
            this.eepromHexFileNameTextBox.TabIndex = 1;
            // 
            // lockBitsGroupBox
            // 
            this.lockBitsGroupBox.Controls.Add(this.lockBitsSetButton);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsReadButton);
            this.lockBitsGroupBox.Controls.Add(this.setModemCheckBox);
            this.lockBitsGroupBox.Controls.Add(this.disableDevModeCheckBox);
            this.lockBitsGroupBox.Controls.Add(this.disableReadBackCheckBox);
            this.lockBitsGroupBox.Location = new System.Drawing.Point(0, 287);
            this.lockBitsGroupBox.Name = "lockBitsGroupBox";
            this.lockBitsGroupBox.Size = new System.Drawing.Size(450, 80);
            this.lockBitsGroupBox.TabIndex = 1;
            this.lockBitsGroupBox.TabStop = false;
            this.lockBitsGroupBox.Text = "Lock Bits";
            // 
            // lockBitsSetButton
            // 
            this.lockBitsSetButton.Location = new System.Drawing.Point(88, 43);
            this.lockBitsSetButton.Name = "lockBitsSetButton";
            this.lockBitsSetButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsSetButton.TabIndex = 4;
            this.lockBitsSetButton.Text = "Set";
            this.lockBitsSetButton.UseVisualStyleBackColor = true;
            // 
            // lockBitsReadButton
            // 
            this.lockBitsReadButton.Location = new System.Drawing.Point(7, 43);
            this.lockBitsReadButton.Name = "lockBitsReadButton";
            this.lockBitsReadButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsReadButton.TabIndex = 3;
            this.lockBitsReadButton.Text = "Get";
            this.lockBitsReadButton.UseVisualStyleBackColor = true;
            // 
            // setModemCheckBox
            // 
            this.setModemCheckBox.AutoSize = true;
            this.setModemCheckBox.Enabled = false;
            this.setModemCheckBox.Location = new System.Drawing.Point(303, 20);
            this.setModemCheckBox.Name = "setModemCheckBox";
            this.setModemCheckBox.Size = new System.Drawing.Size(80, 17);
            this.setModemCheckBox.TabIndex = 2;
            this.setModemCheckBox.Text = "Set Modem";
            this.setModemCheckBox.UseVisualStyleBackColor = true;
            this.setModemCheckBox.Visible = false;
            // 
            // disableDevModeCheckBox
            // 
            this.disableDevModeCheckBox.AutoSize = true;
            this.disableDevModeCheckBox.Location = new System.Drawing.Point(141, 20);
            this.disableDevModeCheckBox.Name = "disableDevModeCheckBox";
            this.disableDevModeCheckBox.Size = new System.Drawing.Size(157, 17);
            this.disableDevModeCheckBox.TabIndex = 1;
            this.disableDevModeCheckBox.Text = "Disable Development Mode";
            this.disableDevModeCheckBox.UseVisualStyleBackColor = true;
            // 
            // disableReadBackCheckBox
            // 
            this.disableReadBackCheckBox.AutoSize = true;
            this.disableReadBackCheckBox.Location = new System.Drawing.Point(15, 20);
            this.disableReadBackCheckBox.Name = "disableReadBackCheckBox";
            this.disableReadBackCheckBox.Size = new System.Drawing.Size(118, 17);
            this.disableReadBackCheckBox.TabIndex = 0;
            this.disableReadBackCheckBox.Text = "Disable Read Back";
            this.disableReadBackCheckBox.UseVisualStyleBackColor = true;
            // 
            // mtpGroupBox
            // 
            this.mtpGroupBox.Controls.Add(this.mtpAutoEraseCheckBox);
            this.mtpGroupBox.Controls.Add(this.mtpProgramButton);
            this.mtpGroupBox.Controls.Add(this.mtpCompareButton);
            this.mtpGroupBox.Controls.Add(this.mtpReadButton);
            this.mtpGroupBox.Controls.Add(this.mtpEraseButton);
            this.mtpGroupBox.Controls.Add(this.mtpHexFileNameLabel);
            this.mtpGroupBox.Controls.Add(this.mtpHexFileNameTextBox);
            this.mtpGroupBox.Controls.Add(this.mtpBrowseHexFileButton);
            this.mtpGroupBox.Location = new System.Drawing.Point(0, 367);
            this.mtpGroupBox.Name = "mtpGroupBox";
            this.mtpGroupBox.Size = new System.Drawing.Size(450, 98);
            this.mtpGroupBox.TabIndex = 2;
            this.mtpGroupBox.TabStop = false;
            this.mtpGroupBox.Text = "MTP";
            // 
            // mtpAutoEraseCheckBox
            // 
            this.mtpAutoEraseCheckBox.Location = new System.Drawing.Point(67, 14);
            this.mtpAutoEraseCheckBox.Name = "mtpAutoEraseCheckBox";
            this.mtpAutoEraseCheckBox.Size = new System.Drawing.Size(348, 17);
            this.mtpAutoEraseCheckBox.TabIndex = 0;
            this.mtpAutoEraseCheckBox.Text = "Erase MTP automatically after OTP or SRAM Program";
            this.mtpAutoEraseCheckBox.UseVisualStyleBackColor = true;
            // 
            // mtpHexFileNameLabel
            // 
            this.mtpHexFileNameLabel.AutoSize = true;
            this.mtpHexFileNameLabel.Location = new System.Drawing.Point(10, 37);
            this.mtpHexFileNameLabel.Name = "mtpHexFileNameLabel";
            this.mtpHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.mtpHexFileNameLabel.TabIndex = 1;
            this.mtpHexFileNameLabel.Text = "HEX File:";
            // 
            // mtpHexFileNameTextBox
            // 
            this.mtpHexFileNameTextBox.Location = new System.Drawing.Point(67, 34);
            this.mtpHexFileNameTextBox.Name = "mtpHexFileNameTextBox";
            this.mtpHexFileNameTextBox.ReadOnly = true;
            this.mtpHexFileNameTextBox.Size = new System.Drawing.Size(314, 20);
            this.mtpHexFileNameTextBox.TabIndex = 2;
            // 
            // mtpBrowseHexFileButton
            // 
            this.mtpBrowseHexFileButton.Location = new System.Drawing.Point(387, 32);
            this.mtpBrowseHexFileButton.Name = "mtpBrowseHexFileButton";
            this.mtpBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.mtpBrowseHexFileButton.TabIndex = 3;
            this.mtpBrowseHexFileButton.Text = "...";
            this.mtpBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // ZW040xForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.mtpGroupBox);
            this.Controls.Add(this.lockBitsGroupBox);
            this.Controls.Add(this.tabControl1);
            this.Name = "ZW040xForm";
            this.Size = new System.Drawing.Size(450, 523);
            this.SizeChanged += new System.EventHandler(this.ZW040xForm_SizeChanged);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.sramOptionsGroupBox.ResumeLayout(false);
            this.sramOptionsGroupBox.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.sramOperationModesGroupBox.ResumeLayout(false);
            this.sramOperationModesGroupBox.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.homeIdSettingsGroupBox.ResumeLayout(false);
            this.homeIdSettingsGroupBox.PerformLayout();
            this.autoIncrementHomeIdGroupBox.ResumeLayout(false);
            this.autoIncrementHomeIdGroupBox.PerformLayout();
            this.lockBitsGroupBox.ResumeLayout(false);
            this.lockBitsGroupBox.PerformLayout();
            this.mtpGroupBox.ResumeLayout(false);
            this.mtpGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip mainToolTip;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button calibrateAndProgrammButton;
        private System.Windows.Forms.Button flashWriteOptionsButton;
        private System.Windows.Forms.Label flashHexFileNameLabel;
        private System.Windows.Forms.Button flashReadOptionsButton;
        private System.Windows.Forms.Button flashBrowseHexFileButton;
        private System.Windows.Forms.GroupBox sramOptionsGroupBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox lowTxPowerCh2TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh2TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lowTxPowerCh1TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh1TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lowTxPowerCh0TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh0TextBox;
        private System.Windows.Forms.Label lowTxPowerLabel;
        private System.Windows.Forms.Label normalTxPowerLabel;
        private System.Windows.Forms.Button flashReadButton;
        private System.Windows.Forms.Button flashProgramButton;
        private System.Windows.Forms.TextBox flashHexFileNameTextBox;
        private System.Windows.Forms.Button crcCheckButton;
        private System.Windows.Forms.Button flashCompareButton;
        private System.Windows.Forms.Button flashWriteButton;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button sramWriteOptionsButton;
        private System.Windows.Forms.Button sramReadOptionsButton;
        private System.Windows.Forms.Label sramHexFileNameLabel;
        private System.Windows.Forms.Button sramBrowseHexFileButton;
        private System.Windows.Forms.GroupBox sramOperationModesGroupBox;
        private System.Windows.Forms.RadioButton modeExecOutOfSRAMRadioButton;
        private System.Windows.Forms.RadioButton modeDevelopmentRadioButton;
        private System.Windows.Forms.Button sramWiteAndRunModeButton;
        private System.Windows.Forms.Button sramCompareButton;
        private System.Windows.Forms.Button sramWriteButton;
        private System.Windows.Forms.Button sramReadButton;
        private System.Windows.Forms.TextBox sramHexFileNameTextBox;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox homeIdSettingsGroupBox;
        private System.Windows.Forms.GroupBox autoIncrementHomeIdGroupBox;
        private System.Windows.Forms.TextBox endHomeIdTextBox;
        private System.Windows.Forms.TextBox startHomeIdTextBox;
        private System.Windows.Forms.Label endHomeIdLabel;
        private System.Windows.Forms.Label startHomeIdLabel;
        private System.Windows.Forms.CheckBox autoIncrementHomeIdCheckBox;
        private System.Windows.Forms.Button changeHomeIdButton;
        private System.Windows.Forms.Button readHomeIdButton;
        private System.Windows.Forms.TextBox readHomeIdTextBox;
        private System.Windows.Forms.TextBox currentHomeIdTextBox;
        private System.Windows.Forms.Label readHomeIdLabel;
        private System.Windows.Forms.Label currentHomeIdLabel;
        private System.Windows.Forms.Button eepromProgramButton;
        private System.Windows.Forms.Label eepromHexFileNameLabel;
        private System.Windows.Forms.Button eepromCompareButton;
        private System.Windows.Forms.Button eepromEraseButton;
        private System.Windows.Forms.Button eepromBrowseHexFileButton;
        private System.Windows.Forms.TextBox eepromHexFileNameTextBox;
        private System.Windows.Forms.Button eepromReadButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox sramLowTxPowerCh2TextBox;
        private System.Windows.Forms.TextBox sramNormalTxPowerCh2TextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox sramLowTxPowerCh1TextBox;
        private System.Windows.Forms.TextBox sramNormalTxPowerCh1TextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox sramLowTxPowerCh0TextBox;
        private System.Windows.Forms.TextBox sramNormalTxPowerCh0TextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox lockBitsGroupBox;
        private System.Windows.Forms.Button lockBitsSetButton;
        private System.Windows.Forms.Button lockBitsReadButton;
        private System.Windows.Forms.CheckBox setModemCheckBox;
        private System.Windows.Forms.CheckBox disableDevModeCheckBox;
        private System.Windows.Forms.CheckBox disableReadBackCheckBox;
        private System.Windows.Forms.GroupBox mtpGroupBox;
        private System.Windows.Forms.CheckBox mtpAutoEraseCheckBox;
        private System.Windows.Forms.Button mtpProgramButton;
        private System.Windows.Forms.Button mtpCompareButton;
        private System.Windows.Forms.Button mtpReadButton;
        private System.Windows.Forms.Button mtpEraseButton;
        private System.Windows.Forms.Label mtpHexFileNameLabel;
        private System.Windows.Forms.TextBox mtpHexFileNameTextBox;
        private System.Windows.Forms.Button mtpBrowseHexFileButton;
        private System.Windows.Forms.TextBox calibrationValueTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button productionButton;

    }
}