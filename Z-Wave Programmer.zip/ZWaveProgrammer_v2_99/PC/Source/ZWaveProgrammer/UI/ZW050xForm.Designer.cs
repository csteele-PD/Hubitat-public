namespace ZWave.Programmer.UI
{
    partial class ZW050xForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.flashEraseButton = new System.Windows.Forms.Button();
            this.calibrateAndProgrammButton = new System.Windows.Forms.Button();
            this.flashBrowseHexFileButton = new System.Windows.Forms.Button();
            this.flashReadButton = new System.Windows.Forms.Button();
            this.flashCompareButton = new System.Windows.Forms.Button();
            this.sramWiteAndRunModeButton = new System.Windows.Forms.Button();
            this.sramCompareButton = new System.Windows.Forms.Button();
            this.sramWriteButton = new System.Windows.Forms.Button();
            this.sramReadButton = new System.Windows.Forms.Button();
            this.changeHomeIdButton = new System.Windows.Forms.Button();
            this.readHomeIdButton = new System.Windows.Forms.Button();
            this.eepromProgramButton = new System.Windows.Forms.Button();
            this.eepromCompareButton = new System.Windows.Forms.Button();
            this.eepromEraseButton = new System.Windows.Forms.Button();
            this.eepromBrowseHexFileButton = new System.Windows.Forms.Button();
            this.eepromReadButton = new System.Windows.Forms.Button();
            this.nvrReadButton = new System.Windows.Forms.Button();
            this.nvrWrteButton = new System.Windows.Forms.Button();
            this.eepromReadModulesButton = new System.Windows.Forms.Button();
            this.labPub = new System.Windows.Forms.Label();
            this.labPrv = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.productionButton = new System.Windows.Forms.Button();
            this.currentInterfaceLabel = new System.Windows.Forms.Label();
            this.lockBitsGroupBox = new System.Windows.Forms.GroupBox();
            this.buttonSetAPM = new System.Windows.Forms.Button();
            this.protectSectorTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label20 = new System.Windows.Forms.Label();
            this.autoprog1CheckBox = new System.Windows.Forms.CheckBox();
            this.autoprog0CheckBox = new System.Windows.Forms.CheckBox();
            this.readBackProtectionCheckBox = new System.Windows.Forms.CheckBox();
            this.lockBitsSetButton = new System.Windows.Forms.Button();
            this.lockBitsReadButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tbDsk = new ZWave.Programmer.Controls.TextBoxEx();
            this.btnGetS2Keys = new System.Windows.Forms.Button();
            this.chkGenerateS2 = new System.Windows.Forms.CheckBox();
            this.tbPub = new ZWave.Programmer.Controls.TextBoxEx();
            this.tbPrv = new ZWave.Programmer.Controls.TextBoxEx();
            this.chkAddS2 = new System.Windows.Forms.CheckBox();
            this.flashHexFileNameLabel = new System.Windows.Forms.Label();
            this.sramOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.frequencyComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.flashWriteOptionsButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lowTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.flashReadOptionsButton = new System.Windows.Forms.Button();
            this.normalTxPowerCh2TextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lowTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerCh1TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lowTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerCh0TextBox = new System.Windows.Forms.TextBox();
            this.lowTxPowerLabel = new System.Windows.Forms.Label();
            this.normalTxPowerLabel = new System.Windows.Forms.Label();
            this.flashHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.sramHexFileNameLabel = new System.Windows.Forms.Label();
            this.sramBrowseHexFileButton = new System.Windows.Forms.Button();
            this.sramHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbNvmModuleType = new ZWave.Programmer.Controls.TextBoxEx();
            this.tbNvmModuleData = new ZWave.Programmer.Controls.TextBoxEx();
            this.eepromGetModuleButton = new System.Windows.Forms.Button();
            this.eepromSetModuleButton = new System.Windows.Forms.Button();
            this.homeIdSettingsGroupBox = new System.Windows.Forms.GroupBox();
            this.startHomeIdLabel = new System.Windows.Forms.Label();
            this.endHomeIdLabel = new System.Windows.Forms.Label();
            this.endHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.startHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.readHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.autoIncrementHomeIdCheckBox = new System.Windows.Forms.CheckBox();
            this.currentHomeIdTextBox = new System.Windows.Forms.TextBox();
            this.readHomeIdLabel = new System.Windows.Forms.Label();
            this.currentHomeIdLabel = new System.Windows.Forms.Label();
            this.eepromHexFileNameLabel = new System.Windows.Forms.Label();
            this.eepromHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.crc16TextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.revTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label19 = new System.Windows.Forms.Label();
            this.txcal2TextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label6 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pinsTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.txcal1TextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label16 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pidTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.nvmcsTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.nvmpTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label11 = new System.Windows.Forms.Label();
            this.vidTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label10 = new System.Windows.Forms.Label();
            this.nvmsTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.ccalTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nvmtTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.uuidTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.sawcTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.sawbTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.hwTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.label23 = new System.Windows.Forms.Label();
            this.tagTextBox = new ZWave.Programmer.Controls.TextBoxEx();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label21 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.epS2Keypair = new System.Windows.Forms.ErrorProvider(this.components);
            this.lockBitsGroupBox.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.sramOptionsGroupBox.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.homeIdSettingsGroupBox.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epS2Keypair)).BeginInit();
            this.SuspendLayout();
            // 
            // flashEraseButton
            // 
            this.flashEraseButton.Location = new System.Drawing.Point(90, 186);
            this.flashEraseButton.Name = "flashEraseButton";
            this.flashEraseButton.Size = new System.Drawing.Size(174, 23);
            this.flashEraseButton.TabIndex = 6;
            this.flashEraseButton.Text = "Erase code space and lock bits";
            this.mainToolTip.SetToolTip(this.flashEraseButton, "Ctrl+E");
            this.flashEraseButton.UseVisualStyleBackColor = true;
            // 
            // calibrateAndProgrammButton
            // 
            this.calibrateAndProgrammButton.Location = new System.Drawing.Point(90, 157);
            this.calibrateAndProgrammButton.Name = "calibrateAndProgrammButton";
            this.calibrateAndProgrammButton.Size = new System.Drawing.Size(174, 23);
            this.calibrateAndProgrammButton.TabIndex = 4;
            this.calibrateAndProgrammButton.Text = "Calibrate, Program and Verify";
            this.mainToolTip.SetToolTip(this.calibrateAndProgrammButton, "Ctrl+P");
            this.calibrateAndProgrammButton.UseVisualStyleBackColor = true;
            // 
            // flashBrowseHexFileButton
            // 
            this.flashBrowseHexFileButton.Location = new System.Drawing.Point(408, 6);
            this.flashBrowseHexFileButton.Name = "flashBrowseHexFileButton";
            this.flashBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.flashBrowseHexFileButton.TabIndex = 2;
            this.flashBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.flashBrowseHexFileButton, "Ctrl+O");
            this.flashBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // flashReadButton
            // 
            this.flashReadButton.Location = new System.Drawing.Point(9, 157);
            this.flashReadButton.Name = "flashReadButton";
            this.flashReadButton.Size = new System.Drawing.Size(75, 23);
            this.flashReadButton.TabIndex = 3;
            this.flashReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.flashReadButton, "Ctrl+R");
            this.flashReadButton.UseVisualStyleBackColor = true;
            // 
            // flashCompareButton
            // 
            this.flashCompareButton.Location = new System.Drawing.Point(9, 186);
            this.flashCompareButton.Name = "flashCompareButton";
            this.flashCompareButton.Size = new System.Drawing.Size(75, 23);
            this.flashCompareButton.TabIndex = 5;
            this.flashCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.flashCompareButton, "Ctrl+M");
            this.flashCompareButton.UseVisualStyleBackColor = true;
            // 
            // sramWiteAndRunModeButton
            // 
            this.sramWiteAndRunModeButton.Location = new System.Drawing.Point(199, 33);
            this.sramWiteAndRunModeButton.Name = "sramWiteAndRunModeButton";
            this.sramWiteAndRunModeButton.Size = new System.Drawing.Size(237, 23);
            this.sramWiteAndRunModeButton.TabIndex = 6;
            this.sramWiteAndRunModeButton.Text = "Program SRAM and execute out of SRAM";
            this.mainToolTip.SetToolTip(this.sramWiteAndRunModeButton, "Ctrl+Alt+P");
            this.sramWiteAndRunModeButton.UseVisualStyleBackColor = true;
            // 
            // sramCompareButton
            // 
            this.sramCompareButton.Location = new System.Drawing.Point(6, 62);
            this.sramCompareButton.Name = "sramCompareButton";
            this.sramCompareButton.Size = new System.Drawing.Size(75, 23);
            this.sramCompareButton.TabIndex = 5;
            this.sramCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.sramCompareButton, "Ctrl+Alt+C");
            this.sramCompareButton.UseVisualStyleBackColor = true;
            // 
            // sramWriteButton
            // 
            this.sramWriteButton.Location = new System.Drawing.Point(87, 33);
            this.sramWriteButton.Name = "sramWriteButton";
            this.sramWriteButton.Size = new System.Drawing.Size(75, 23);
            this.sramWriteButton.TabIndex = 4;
            this.sramWriteButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.sramWriteButton, "Ctrl+Alt+W");
            this.sramWriteButton.UseVisualStyleBackColor = true;
            // 
            // sramReadButton
            // 
            this.sramReadButton.Location = new System.Drawing.Point(6, 33);
            this.sramReadButton.Name = "sramReadButton";
            this.sramReadButton.Size = new System.Drawing.Size(75, 23);
            this.sramReadButton.TabIndex = 3;
            this.sramReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.sramReadButton, "Ctrl+Alt+R");
            this.sramReadButton.UseVisualStyleBackColor = true;
            // 
            // changeHomeIdButton
            // 
            this.changeHomeIdButton.Location = new System.Drawing.Point(87, 71);
            this.changeHomeIdButton.Name = "changeHomeIdButton";
            this.changeHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.changeHomeIdButton.TabIndex = 4;
            this.changeHomeIdButton.Text = "Set";
            this.mainToolTip.SetToolTip(this.changeHomeIdButton, "Shift+W");
            this.changeHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // readHomeIdButton
            // 
            this.readHomeIdButton.Location = new System.Drawing.Point(6, 71);
            this.readHomeIdButton.Name = "readHomeIdButton";
            this.readHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.readHomeIdButton.TabIndex = 5;
            this.readHomeIdButton.Text = "Get";
            this.mainToolTip.SetToolTip(this.readHomeIdButton, "Shift+R");
            this.readHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // eepromProgramButton
            // 
            this.eepromProgramButton.Location = new System.Drawing.Point(87, 33);
            this.eepromProgramButton.Name = "eepromProgramButton";
            this.eepromProgramButton.Size = new System.Drawing.Size(75, 23);
            this.eepromProgramButton.TabIndex = 5;
            this.eepromProgramButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.eepromProgramButton, "Alt+P");
            this.eepromProgramButton.UseVisualStyleBackColor = true;
            // 
            // eepromCompareButton
            // 
            this.eepromCompareButton.Location = new System.Drawing.Point(87, 62);
            this.eepromCompareButton.Name = "eepromCompareButton";
            this.eepromCompareButton.Size = new System.Drawing.Size(75, 23);
            this.eepromCompareButton.TabIndex = 6;
            this.eepromCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.eepromCompareButton, "Alt+M");
            this.eepromCompareButton.UseVisualStyleBackColor = true;
            // 
            // eepromEraseButton
            // 
            this.eepromEraseButton.Location = new System.Drawing.Point(6, 62);
            this.eepromEraseButton.Name = "eepromEraseButton";
            this.eepromEraseButton.Size = new System.Drawing.Size(75, 23);
            this.eepromEraseButton.TabIndex = 3;
            this.eepromEraseButton.Text = "Erase";
            this.mainToolTip.SetToolTip(this.eepromEraseButton, "Alt+E");
            this.eepromEraseButton.UseVisualStyleBackColor = true;
            // 
            // eepromBrowseHexFileButton
            // 
            this.eepromBrowseHexFileButton.Location = new System.Drawing.Point(408, 6);
            this.eepromBrowseHexFileButton.Name = "eepromBrowseHexFileButton";
            this.eepromBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.eepromBrowseHexFileButton.TabIndex = 2;
            this.eepromBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.eepromBrowseHexFileButton, "Alt+O");
            this.eepromBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // eepromReadButton
            // 
            this.eepromReadButton.Location = new System.Drawing.Point(6, 33);
            this.eepromReadButton.Name = "eepromReadButton";
            this.eepromReadButton.Size = new System.Drawing.Size(75, 23);
            this.eepromReadButton.TabIndex = 4;
            this.eepromReadButton.Text = "Read All";
            this.mainToolTip.SetToolTip(this.eepromReadButton, "Alt+R");
            this.eepromReadButton.UseVisualStyleBackColor = true;
            // 
            // nvrReadButton
            // 
            this.nvrReadButton.Location = new System.Drawing.Point(280, 327);
            this.nvrReadButton.Name = "nvrReadButton";
            this.nvrReadButton.Size = new System.Drawing.Size(75, 23);
            this.nvrReadButton.TabIndex = 30;
            this.nvrReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.nvrReadButton, "Ctrl+R");
            this.nvrReadButton.UseVisualStyleBackColor = true;
            // 
            // nvrWrteButton
            // 
            this.nvrWrteButton.Location = new System.Drawing.Point(361, 327);
            this.nvrWrteButton.Name = "nvrWrteButton";
            this.nvrWrteButton.Size = new System.Drawing.Size(75, 23);
            this.nvrWrteButton.TabIndex = 31;
            this.nvrWrteButton.Text = "Write";
            this.mainToolTip.SetToolTip(this.nvrWrteButton, "Ctrl+W");
            this.nvrWrteButton.UseVisualStyleBackColor = true;
            // 
            // eepromReadModulesButton
            // 
            this.eepromReadModulesButton.Location = new System.Drawing.Point(300, 35);
            this.eepromReadModulesButton.Name = "eepromReadModulesButton";
            this.eepromReadModulesButton.Size = new System.Drawing.Size(136, 23);
            this.eepromReadModulesButton.TabIndex = 8;
            this.eepromReadModulesButton.Text = "Read NVM Modules";
            this.mainToolTip.SetToolTip(this.eepromReadModulesButton, "Alt+R");
            this.eepromReadModulesButton.UseVisualStyleBackColor = true;
            // 
            // labPub
            // 
            this.labPub.AutoSize = true;
            this.labPub.Enabled = false;
            this.labPub.Location = new System.Drawing.Point(6, 107);
            this.labPub.Margin = new System.Windows.Forms.Padding(10);
            this.labPub.Name = "labPub";
            this.labPub.Size = new System.Drawing.Size(23, 13);
            this.labPub.TabIndex = 0;
            this.labPub.Text = "Pu:";
            this.mainToolTip.SetToolTip(this.labPub, "Public key");
            // 
            // labPrv
            // 
            this.labPrv.AutoSize = true;
            this.labPrv.Enabled = false;
            this.labPrv.Location = new System.Drawing.Point(6, 81);
            this.labPrv.Margin = new System.Windows.Forms.Padding(10);
            this.labPrv.Name = "labPrv";
            this.labPrv.Size = new System.Drawing.Size(20, 13);
            this.labPrv.TabIndex = 0;
            this.labPrv.Text = "Pr:";
            this.mainToolTip.SetToolTip(this.labPrv, "Private key");
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Enabled = false;
            this.label24.Location = new System.Drawing.Point(6, 133);
            this.label24.Margin = new System.Windows.Forms.Padding(10);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 32;
            this.label24.Text = "DSK:";
            this.mainToolTip.SetToolTip(this.label24, "Private key");
            // 
            // productionButton
            // 
            this.productionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productionButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.productionButton.Location = new System.Drawing.Point(360, 157);
            this.productionButton.Name = "productionButton";
            this.productionButton.Size = new System.Drawing.Size(76, 52);
            this.productionButton.TabIndex = 8;
            this.productionButton.Text = "Production";
            this.productionButton.UseVisualStyleBackColor = true;
            this.productionButton.Visible = false;
            // 
            // currentInterfaceLabel
            // 
            this.currentInterfaceLabel.AutoSize = true;
            this.currentInterfaceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentInterfaceLabel.Location = new System.Drawing.Point(165, 8);
            this.currentInterfaceLabel.Name = "currentInterfaceLabel";
            this.currentInterfaceLabel.Size = new System.Drawing.Size(37, 13);
            this.currentInterfaceLabel.TabIndex = 0;
            this.currentInterfaceLabel.Text = "None";
            // 
            // lockBitsGroupBox
            // 
            this.lockBitsGroupBox.Controls.Add(this.buttonSetAPM);
            this.lockBitsGroupBox.Controls.Add(this.protectSectorTextBox);
            this.lockBitsGroupBox.Controls.Add(this.label20);
            this.lockBitsGroupBox.Controls.Add(this.autoprog1CheckBox);
            this.lockBitsGroupBox.Controls.Add(this.autoprog0CheckBox);
            this.lockBitsGroupBox.Controls.Add(this.readBackProtectionCheckBox);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsSetButton);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsReadButton);
            this.lockBitsGroupBox.Location = new System.Drawing.Point(0, 421);
            this.lockBitsGroupBox.Name = "lockBitsGroupBox";
            this.lockBitsGroupBox.Size = new System.Drawing.Size(448, 98);
            this.lockBitsGroupBox.TabIndex = 2;
            this.lockBitsGroupBox.TabStop = false;
            this.lockBitsGroupBox.Text = "Lock Bits";
            // 
            // buttonSetAPM
            // 
            this.buttonSetAPM.Location = new System.Drawing.Point(366, 68);
            this.buttonSetAPM.Name = "buttonSetAPM";
            this.buttonSetAPM.Size = new System.Drawing.Size(75, 23);
            this.buttonSetAPM.TabIndex = 7;
            this.buttonSetAPM.Text = "Set APM";
            this.buttonSetAPM.UseVisualStyleBackColor = true;
            // 
            // protectSectorTextBox
            // 
            this.protectSectorTextBox.Location = new System.Drawing.Point(85, 42);
            this.protectSectorTextBox.Name = "protectSectorTextBox";
            this.protectSectorTextBox.Size = new System.Drawing.Size(355, 20);
            this.protectSectorTextBox.TabIndex = 4;
            this.toolTip1.SetToolTip(this.protectSectorTextBox, "Type sector numbers and/or\r\nsector ranges separated by commas.\r\nFor example, type" +
                    " 0, 1, 3, 6, 17-63");
            this.protectSectorTextBox.Leave += new System.EventHandler(this.protectSectorTextBox_Leave);
            this.protectSectorTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.protectSectorTextBox_KeyPress);
            this.protectSectorTextBox.Enter += new System.EventHandler(this.protectSectorTextBox_Enter);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 45);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Protect sector";
            // 
            // autoprog1CheckBox
            // 
            this.autoprog1CheckBox.AutoSize = true;
            this.autoprog1CheckBox.Location = new System.Drawing.Point(244, 19);
            this.autoprog1CheckBox.Name = "autoprog1CheckBox";
            this.autoprog1CheckBox.Size = new System.Drawing.Size(82, 17);
            this.autoprog1CheckBox.TabIndex = 2;
            this.autoprog1CheckBox.Text = "Auto Prog 1";
            this.autoprog1CheckBox.UseVisualStyleBackColor = true;
            this.autoprog1CheckBox.Visible = false;
            // 
            // autoprog0CheckBox
            // 
            this.autoprog0CheckBox.AutoSize = true;
            this.autoprog0CheckBox.Location = new System.Drawing.Point(146, 19);
            this.autoprog0CheckBox.Name = "autoprog0CheckBox";
            this.autoprog0CheckBox.Size = new System.Drawing.Size(82, 17);
            this.autoprog0CheckBox.TabIndex = 1;
            this.autoprog0CheckBox.Text = "Auto Prog 0";
            this.autoprog0CheckBox.UseVisualStyleBackColor = true;
            this.autoprog0CheckBox.Visible = false;
            // 
            // readBackProtectionCheckBox
            // 
            this.readBackProtectionCheckBox.AutoSize = true;
            this.readBackProtectionCheckBox.Location = new System.Drawing.Point(6, 19);
            this.readBackProtectionCheckBox.Name = "readBackProtectionCheckBox";
            this.readBackProtectionCheckBox.Size = new System.Drawing.Size(129, 17);
            this.readBackProtectionCheckBox.TabIndex = 0;
            this.readBackProtectionCheckBox.Text = "Read back protection";
            this.readBackProtectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // lockBitsSetButton
            // 
            this.lockBitsSetButton.Location = new System.Drawing.Point(85, 68);
            this.lockBitsSetButton.Name = "lockBitsSetButton";
            this.lockBitsSetButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsSetButton.TabIndex = 6;
            this.lockBitsSetButton.Text = "Set";
            this.lockBitsSetButton.UseVisualStyleBackColor = true;
            // 
            // lockBitsReadButton
            // 
            this.lockBitsReadButton.Location = new System.Drawing.Point(6, 68);
            this.lockBitsReadButton.Name = "lockBitsReadButton";
            this.lockBitsReadButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsReadButton.TabIndex = 5;
            this.lockBitsReadButton.Text = "Get";
            this.lockBitsReadButton.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(450, 383);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tbDsk);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.btnGetS2Keys);
            this.tabPage1.Controls.Add(this.chkGenerateS2);
            this.tabPage1.Controls.Add(this.tbPub);
            this.tabPage1.Controls.Add(this.tbPrv);
            this.tabPage1.Controls.Add(this.chkAddS2);
            this.tabPage1.Controls.Add(this.productionButton);
            this.tabPage1.Controls.Add(this.flashEraseButton);
            this.tabPage1.Controls.Add(this.calibrateAndProgrammButton);
            this.tabPage1.Controls.Add(this.flashHexFileNameLabel);
            this.tabPage1.Controls.Add(this.flashBrowseHexFileButton);
            this.tabPage1.Controls.Add(this.sramOptionsGroupBox);
            this.tabPage1.Controls.Add(this.flashReadButton);
            this.tabPage1.Controls.Add(this.flashHexFileNameTextBox);
            this.tabPage1.Controls.Add(this.flashCompareButton);
            this.tabPage1.Controls.Add(this.labPub);
            this.tabPage1.Controls.Add(this.labPrv);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(442, 357);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Flash Code Memory";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tbDsk
            // 
            this.tbDsk.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDsk.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbDsk.Location = new System.Drawing.Point(40, 131);
            this.tbDsk.MaxLength = 64;
            this.tbDsk.Name = "tbDsk";
            this.tbDsk.ReadOnly = true;
            this.tbDsk.Size = new System.Drawing.Size(396, 20);
            this.tbDsk.TabIndex = 28;
            this.tbDsk.Text = "12345-12345-12345-12345-12345-12345-12345-12345";
            // 
            // btnGetS2Keys
            // 
            this.btnGetS2Keys.Location = new System.Drawing.Point(270, 157);
            this.btnGetS2Keys.Name = "btnGetS2Keys";
            this.btnGetS2Keys.Size = new System.Drawing.Size(85, 23);
            this.btnGetS2Keys.TabIndex = 31;
            this.btnGetS2Keys.Text = "Get S2 keypair";
            this.btnGetS2Keys.UseVisualStyleBackColor = true;
            // 
            // chkGenerateS2
            // 
            this.chkGenerateS2.AutoSize = true;
            this.chkGenerateS2.Checked = true;
            this.chkGenerateS2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkGenerateS2.Location = new System.Drawing.Point(9, 56);
            this.chkGenerateS2.Name = "chkGenerateS2";
            this.chkGenerateS2.Size = new System.Drawing.Size(123, 17);
            this.chkGenerateS2.TabIndex = 29;
            this.chkGenerateS2.Text = "Generate S2 keypair";
            this.chkGenerateS2.UseVisualStyleBackColor = true;
            // 
            // tbPub
            // 
            this.tbPub.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPub.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbPub.Location = new System.Drawing.Point(30, 105);
            this.tbPub.MaxLength = 64;
            this.tbPub.Name = "tbPub";
            this.tbPub.ReadOnly = true;
            this.tbPub.Size = new System.Drawing.Size(406, 20);
            this.tbPub.TabIndex = 28;
            this.tbPub.Text = "11223344556677889900AAbbCCddEEff11223344556677889900AAbbCCddEEff";
            this.tbPub.TextChanged += new System.EventHandler(this.tbPub_TextChanged);
            // 
            // tbPrv
            // 
            this.tbPrv.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPrv.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbPrv.Location = new System.Drawing.Point(30, 79);
            this.tbPrv.MaxLength = 64;
            this.tbPrv.Name = "tbPrv";
            this.tbPrv.ReadOnly = true;
            this.tbPrv.Size = new System.Drawing.Size(406, 20);
            this.tbPrv.TabIndex = 28;
            this.tbPrv.Text = "11223344556677889900AAbbCCddEEff11223344556677889900AAbbCCddEEff";
            // 
            // chkAddS2
            // 
            this.chkAddS2.AutoSize = true;
            this.chkAddS2.Location = new System.Drawing.Point(9, 33);
            this.chkAddS2.Name = "chkAddS2";
            this.chkAddS2.Size = new System.Drawing.Size(98, 17);
            this.chkAddS2.TabIndex = 9;
            this.chkAddS2.Text = "Add S2 keypair";
            this.chkAddS2.UseVisualStyleBackColor = true;
            // 
            // flashHexFileNameLabel
            // 
            this.flashHexFileNameLabel.AutoSize = true;
            this.flashHexFileNameLabel.Location = new System.Drawing.Point(6, 10);
            this.flashHexFileNameLabel.Name = "flashHexFileNameLabel";
            this.flashHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.flashHexFileNameLabel.TabIndex = 0;
            this.flashHexFileNameLabel.Text = "HEX File:";
            // 
            // sramOptionsGroupBox
            // 
            this.sramOptionsGroupBox.Controls.Add(this.frequencyComboBox);
            this.sramOptionsGroupBox.Controls.Add(this.label9);
            this.sramOptionsGroupBox.Controls.Add(this.flashWriteOptionsButton);
            this.sramOptionsGroupBox.Controls.Add(this.label3);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh2TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.flashReadOptionsButton);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh2TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.label2);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh1TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh1TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.label1);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerCh0TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerCh0TextBox);
            this.sramOptionsGroupBox.Controls.Add(this.lowTxPowerLabel);
            this.sramOptionsGroupBox.Controls.Add(this.normalTxPowerLabel);
            this.sramOptionsGroupBox.Location = new System.Drawing.Point(0, 215);
            this.sramOptionsGroupBox.Name = "sramOptionsGroupBox";
            this.sramOptionsGroupBox.Size = new System.Drawing.Size(440, 140);
            this.sramOptionsGroupBox.TabIndex = 7;
            this.sramOptionsGroupBox.TabStop = false;
            this.sramOptionsGroupBox.Text = "Options";
            // 
            // frequencyComboBox
            // 
            this.frequencyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.frequencyComboBox.FormattingEnabled = true;
            this.frequencyComboBox.Location = new System.Drawing.Point(80, 109);
            this.frequencyComboBox.Margin = new System.Windows.Forms.Padding(0);
            this.frequencyComboBox.Name = "frequencyComboBox";
            this.frequencyComboBox.Size = new System.Drawing.Size(87, 21);
            this.frequencyComboBox.TabIndex = 12;
            this.frequencyComboBox.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Frequency:";
            this.label9.Visible = false;
            // 
            // flashWriteOptionsButton
            // 
            this.flashWriteOptionsButton.Location = new System.Drawing.Point(360, 80);
            this.flashWriteOptionsButton.Name = "flashWriteOptionsButton";
            this.flashWriteOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.flashWriteOptionsButton.TabIndex = 14;
            this.flashWriteOptionsButton.Text = "Set Options";
            this.flashWriteOptionsButton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Channel 2:";
            // 
            // lowTxPowerCh2TextBox
            // 
            this.lowTxPowerCh2TextBox.Location = new System.Drawing.Point(184, 83);
            this.lowTxPowerCh2TextBox.MaxLength = 2;
            this.lowTxPowerCh2TextBox.Name = "lowTxPowerCh2TextBox";
            this.lowTxPowerCh2TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh2TextBox.TabIndex = 10;
            // 
            // flashReadOptionsButton
            // 
            this.flashReadOptionsButton.Location = new System.Drawing.Point(280, 81);
            this.flashReadOptionsButton.Name = "flashReadOptionsButton";
            this.flashReadOptionsButton.Size = new System.Drawing.Size(75, 23);
            this.flashReadOptionsButton.TabIndex = 13;
            this.flashReadOptionsButton.Text = "Get Options";
            this.flashReadOptionsButton.UseVisualStyleBackColor = true;
            // 
            // normalTxPowerCh2TextBox
            // 
            this.normalTxPowerCh2TextBox.Location = new System.Drawing.Point(80, 83);
            this.normalTxPowerCh2TextBox.MaxLength = 2;
            this.normalTxPowerCh2TextBox.Name = "normalTxPowerCh2TextBox";
            this.normalTxPowerCh2TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh2TextBox.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Channel 1:";
            // 
            // lowTxPowerCh1TextBox
            // 
            this.lowTxPowerCh1TextBox.Location = new System.Drawing.Point(184, 57);
            this.lowTxPowerCh1TextBox.MaxLength = 2;
            this.lowTxPowerCh1TextBox.Name = "lowTxPowerCh1TextBox";
            this.lowTxPowerCh1TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh1TextBox.TabIndex = 7;
            // 
            // normalTxPowerCh1TextBox
            // 
            this.normalTxPowerCh1TextBox.Location = new System.Drawing.Point(80, 57);
            this.normalTxPowerCh1TextBox.MaxLength = 2;
            this.normalTxPowerCh1TextBox.Name = "normalTxPowerCh1TextBox";
            this.normalTxPowerCh1TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh1TextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Channel 0:";
            // 
            // lowTxPowerCh0TextBox
            // 
            this.lowTxPowerCh0TextBox.Location = new System.Drawing.Point(184, 31);
            this.lowTxPowerCh0TextBox.MaxLength = 2;
            this.lowTxPowerCh0TextBox.Name = "lowTxPowerCh0TextBox";
            this.lowTxPowerCh0TextBox.Size = new System.Drawing.Size(75, 20);
            this.lowTxPowerCh0TextBox.TabIndex = 4;
            // 
            // normalTxPowerCh0TextBox
            // 
            this.normalTxPowerCh0TextBox.Location = new System.Drawing.Point(80, 31);
            this.normalTxPowerCh0TextBox.MaxLength = 2;
            this.normalTxPowerCh0TextBox.Name = "normalTxPowerCh0TextBox";
            this.normalTxPowerCh0TextBox.Size = new System.Drawing.Size(88, 20);
            this.normalTxPowerCh0TextBox.TabIndex = 3;
            // 
            // lowTxPowerLabel
            // 
            this.lowTxPowerLabel.AutoSize = true;
            this.lowTxPowerLabel.Location = new System.Drawing.Point(181, 14);
            this.lowTxPowerLabel.Name = "lowTxPowerLabel";
            this.lowTxPowerLabel.Size = new System.Drawing.Size(78, 13);
            this.lowTxPowerLabel.TabIndex = 1;
            this.lowTxPowerLabel.Text = "Low Tx Power:";
            // 
            // normalTxPowerLabel
            // 
            this.normalTxPowerLabel.AutoSize = true;
            this.normalTxPowerLabel.Location = new System.Drawing.Point(77, 15);
            this.normalTxPowerLabel.Name = "normalTxPowerLabel";
            this.normalTxPowerLabel.Size = new System.Drawing.Size(91, 13);
            this.normalTxPowerLabel.TabIndex = 0;
            this.normalTxPowerLabel.Text = "Normal Tx Power:";
            // 
            // flashHexFileNameTextBox
            // 
            this.flashHexFileNameTextBox.Location = new System.Drawing.Point(63, 7);
            this.flashHexFileNameTextBox.Name = "flashHexFileNameTextBox";
            this.flashHexFileNameTextBox.ReadOnly = true;
            this.flashHexFileNameTextBox.Size = new System.Drawing.Size(339, 20);
            this.flashHexFileNameTextBox.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.sramWiteAndRunModeButton);
            this.tabPage2.Controls.Add(this.sramCompareButton);
            this.tabPage2.Controls.Add(this.sramHexFileNameLabel);
            this.tabPage2.Controls.Add(this.sramWriteButton);
            this.tabPage2.Controls.Add(this.sramBrowseHexFileButton);
            this.tabPage2.Controls.Add(this.sramReadButton);
            this.tabPage2.Controls.Add(this.sramHexFileNameTextBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(442, 357);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SRAM";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // sramHexFileNameLabel
            // 
            this.sramHexFileNameLabel.AutoSize = true;
            this.sramHexFileNameLabel.Location = new System.Drawing.Point(6, 10);
            this.sramHexFileNameLabel.Name = "sramHexFileNameLabel";
            this.sramHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.sramHexFileNameLabel.TabIndex = 0;
            this.sramHexFileNameLabel.Text = "HEX File:";
            // 
            // sramBrowseHexFileButton
            // 
            this.sramBrowseHexFileButton.Location = new System.Drawing.Point(408, 6);
            this.sramBrowseHexFileButton.Name = "sramBrowseHexFileButton";
            this.sramBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.sramBrowseHexFileButton.TabIndex = 2;
            this.sramBrowseHexFileButton.Text = "...";
            this.sramBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // sramHexFileNameTextBox
            // 
            this.sramHexFileNameTextBox.Location = new System.Drawing.Point(63, 7);
            this.sramHexFileNameTextBox.Name = "sramHexFileNameTextBox";
            this.sramHexFileNameTextBox.ReadOnly = true;
            this.sramHexFileNameTextBox.Size = new System.Drawing.Size(339, 20);
            this.sramHexFileNameTextBox.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.eepromReadModulesButton);
            this.tabPage3.Controls.Add(this.homeIdSettingsGroupBox);
            this.tabPage3.Controls.Add(this.eepromProgramButton);
            this.tabPage3.Controls.Add(this.eepromHexFileNameLabel);
            this.tabPage3.Controls.Add(this.eepromCompareButton);
            this.tabPage3.Controls.Add(this.eepromEraseButton);
            this.tabPage3.Controls.Add(this.eepromBrowseHexFileButton);
            this.tabPage3.Controls.Add(this.eepromHexFileNameTextBox);
            this.tabPage3.Controls.Add(this.eepromReadButton);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(442, 357);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "External Non-Volatile Memory";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.tbNvmModuleType);
            this.groupBox1.Controls.Add(this.tbNvmModuleData);
            this.groupBox1.Controls.Add(this.eepromGetModuleButton);
            this.groupBox1.Controls.Add(this.eepromSetModuleButton);
            this.groupBox1.Location = new System.Drawing.Point(0, 91);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(440, 129);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NVM Module";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(7, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 13);
            this.label22.TabIndex = 31;
            this.label22.Text = "Type:";
            // 
            // tbNvmModuleType
            // 
            this.tbNvmModuleType.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNvmModuleType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbNvmModuleType.Location = new System.Drawing.Point(47, 18);
            this.tbNvmModuleType.MaxLength = 2;
            this.tbNvmModuleType.Name = "tbNvmModuleType";
            this.tbNvmModuleType.Size = new System.Drawing.Size(31, 20);
            this.tbNvmModuleType.TabIndex = 29;
            this.tbNvmModuleType.Text = "06";
            // 
            // tbNvmModuleData
            // 
            this.tbNvmModuleData.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNvmModuleData.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbNvmModuleData.Location = new System.Drawing.Point(5, 45);
            this.tbNvmModuleData.Multiline = true;
            this.tbNvmModuleData.Name = "tbNvmModuleData";
            this.tbNvmModuleData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbNvmModuleData.Size = new System.Drawing.Size(429, 78);
            this.tbNvmModuleData.TabIndex = 30;
            // 
            // eepromGetModuleButton
            // 
            this.eepromGetModuleButton.Location = new System.Drawing.Point(85, 15);
            this.eepromGetModuleButton.Name = "eepromGetModuleButton";
            this.eepromGetModuleButton.Size = new System.Drawing.Size(46, 23);
            this.eepromGetModuleButton.TabIndex = 8;
            this.eepromGetModuleButton.Text = "Get";
            this.eepromGetModuleButton.UseVisualStyleBackColor = true;
            // 
            // eepromSetModuleButton
            // 
            this.eepromSetModuleButton.Location = new System.Drawing.Point(137, 15);
            this.eepromSetModuleButton.Name = "eepromSetModuleButton";
            this.eepromSetModuleButton.Size = new System.Drawing.Size(46, 23);
            this.eepromSetModuleButton.TabIndex = 8;
            this.eepromSetModuleButton.Text = "Set";
            this.eepromSetModuleButton.UseVisualStyleBackColor = true;
            // 
            // homeIdSettingsGroupBox
            // 
            this.homeIdSettingsGroupBox.Controls.Add(this.startHomeIdLabel);
            this.homeIdSettingsGroupBox.Controls.Add(this.endHomeIdLabel);
            this.homeIdSettingsGroupBox.Controls.Add(this.endHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.startHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.changeHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.autoIncrementHomeIdCheckBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdLabel);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdLabel);
            this.homeIdSettingsGroupBox.Location = new System.Drawing.Point(0, 226);
            this.homeIdSettingsGroupBox.Name = "homeIdSettingsGroupBox";
            this.homeIdSettingsGroupBox.Size = new System.Drawing.Size(440, 101);
            this.homeIdSettingsGroupBox.TabIndex = 7;
            this.homeIdSettingsGroupBox.TabStop = false;
            this.homeIdSettingsGroupBox.Text = "Home Id Settings";
            // 
            // startHomeIdLabel
            // 
            this.startHomeIdLabel.AutoSize = true;
            this.startHomeIdLabel.Location = new System.Drawing.Point(290, 22);
            this.startHomeIdLabel.Name = "startHomeIdLabel";
            this.startHomeIdLabel.Size = new System.Drawing.Size(75, 13);
            this.startHomeIdLabel.TabIndex = 1;
            this.startHomeIdLabel.Text = "Start Home Id:";
            // 
            // endHomeIdLabel
            // 
            this.endHomeIdLabel.AutoSize = true;
            this.endHomeIdLabel.Location = new System.Drawing.Point(290, 48);
            this.endHomeIdLabel.Name = "endHomeIdLabel";
            this.endHomeIdLabel.Size = new System.Drawing.Size(72, 13);
            this.endHomeIdLabel.TabIndex = 3;
            this.endHomeIdLabel.Text = "End Home Id:";
            // 
            // endHomeIdTextBox
            // 
            this.endHomeIdTextBox.Location = new System.Drawing.Point(374, 45);
            this.endHomeIdTextBox.Name = "endHomeIdTextBox";
            this.endHomeIdTextBox.Size = new System.Drawing.Size(60, 20);
            this.endHomeIdTextBox.TabIndex = 4;
            // 
            // startHomeIdTextBox
            // 
            this.startHomeIdTextBox.Location = new System.Drawing.Point(374, 19);
            this.startHomeIdTextBox.Name = "startHomeIdTextBox";
            this.startHomeIdTextBox.Size = new System.Drawing.Size(60, 20);
            this.startHomeIdTextBox.TabIndex = 2;
            // 
            // readHomeIdTextBox
            // 
            this.readHomeIdTextBox.Location = new System.Drawing.Point(68, 45);
            this.readHomeIdTextBox.Name = "readHomeIdTextBox";
            this.readHomeIdTextBox.ReadOnly = true;
            this.readHomeIdTextBox.Size = new System.Drawing.Size(60, 20);
            this.readHomeIdTextBox.TabIndex = 3;
            // 
            // autoIncrementHomeIdCheckBox
            // 
            this.autoIncrementHomeIdCheckBox.AutoSize = true;
            this.autoIncrementHomeIdCheckBox.Location = new System.Drawing.Point(186, 22);
            this.autoIncrementHomeIdCheckBox.Name = "autoIncrementHomeIdCheckBox";
            this.autoIncrementHomeIdCheckBox.Size = new System.Drawing.Size(98, 17);
            this.autoIncrementHomeIdCheckBox.TabIndex = 0;
            this.autoIncrementHomeIdCheckBox.Text = "Auto Increment";
            this.autoIncrementHomeIdCheckBox.UseVisualStyleBackColor = true;
            // 
            // currentHomeIdTextBox
            // 
            this.currentHomeIdTextBox.Location = new System.Drawing.Point(68, 19);
            this.currentHomeIdTextBox.Name = "currentHomeIdTextBox";
            this.currentHomeIdTextBox.Size = new System.Drawing.Size(60, 20);
            this.currentHomeIdTextBox.TabIndex = 1;
            // 
            // readHomeIdLabel
            // 
            this.readHomeIdLabel.AutoSize = true;
            this.readHomeIdLabel.Location = new System.Drawing.Point(6, 48);
            this.readHomeIdLabel.Name = "readHomeIdLabel";
            this.readHomeIdLabel.Size = new System.Drawing.Size(36, 13);
            this.readHomeIdLabel.TabIndex = 2;
            this.readHomeIdLabel.Text = "Read:";
            // 
            // currentHomeIdLabel
            // 
            this.currentHomeIdLabel.AutoSize = true;
            this.currentHomeIdLabel.Location = new System.Drawing.Point(6, 22);
            this.currentHomeIdLabel.Name = "currentHomeIdLabel";
            this.currentHomeIdLabel.Size = new System.Drawing.Size(56, 13);
            this.currentHomeIdLabel.TabIndex = 0;
            this.currentHomeIdLabel.Text = "Current Id:";
            // 
            // eepromHexFileNameLabel
            // 
            this.eepromHexFileNameLabel.AutoSize = true;
            this.eepromHexFileNameLabel.Location = new System.Drawing.Point(6, 10);
            this.eepromHexFileNameLabel.Name = "eepromHexFileNameLabel";
            this.eepromHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.eepromHexFileNameLabel.TabIndex = 0;
            this.eepromHexFileNameLabel.Text = "HEX File:";
            // 
            // eepromHexFileNameTextBox
            // 
            this.eepromHexFileNameTextBox.Location = new System.Drawing.Point(63, 7);
            this.eepromHexFileNameTextBox.Name = "eepromHexFileNameTextBox";
            this.eepromHexFileNameTextBox.ReadOnly = true;
            this.eepromHexFileNameTextBox.Size = new System.Drawing.Size(339, 20);
            this.eepromHexFileNameTextBox.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Controls.Add(this.groupBox2);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.nvrReadButton);
            this.tabPage4.Controls.Add(this.nvrWrteButton);
            this.tabPage4.Controls.Add(this.tagTextBox);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(442, 357);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "NVR";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.crc16TextBox);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.revTextBox);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txcal2TextBox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.pinsTextBox);
            this.groupBox3.Controls.Add(this.txcal1TextBox);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.pidTextBox);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.nvmcsTextBox);
            this.groupBox3.Controls.Add(this.nvmpTextBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.vidTextBox);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.nvmsTextBox);
            this.groupBox3.Controls.Add(this.ccalTextBox);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.nvmtTextBox);
            this.groupBox3.Controls.Add(this.uuidTextBox);
            this.groupBox3.Controls.Add(this.sawcTextBox);
            this.groupBox3.Controls.Add(this.sawbTextBox);
            this.groupBox3.Location = new System.Drawing.Point(0, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(440, 249);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Protocol and peripheral drivers area:";
            // 
            // crc16TextBox
            // 
            this.crc16TextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.crc16TextBox.Location = new System.Drawing.Point(398, 225);
            this.crc16TextBox.MaxLength = 5;
            this.crc16TextBox.Name = "crc16TextBox";
            this.crc16TextBox.ReadOnly = true;
            this.crc16TextBox.Size = new System.Drawing.Size(38, 20);
            this.crc16TextBox.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(194, 228);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "CRC (CRC16):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "NVR layout revision (REV):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(194, 182);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(213, 13);
            this.label18.TabIndex = 24;
            this.label18.Text = "Frequency Calibration 924.4MHz (TXCAL2):";
            // 
            // revTextBox
            // 
            this.revTextBox.ForeColor = System.Drawing.Color.Green;
            this.revTextBox.Location = new System.Drawing.Point(162, 18);
            this.revTextBox.MaxLength = 2;
            this.revTextBox.Name = "revTextBox";
            this.revTextBox.Size = new System.Drawing.Size(24, 20);
            this.revTextBox.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(194, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(213, 13);
            this.label19.TabIndex = 22;
            this.label19.Text = "Frequency Calibration 868.4MHz (TXCAL1):";
            // 
            // txcal2TextBox
            // 
            this.txcal2TextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txcal2TextBox.Location = new System.Drawing.Point(412, 179);
            this.txcal2TextBox.MaxLength = 2;
            this.txcal2TextBox.Name = "txcal2TextBox";
            this.txcal2TextBox.Size = new System.Drawing.Size(24, 20);
            this.txcal2TextBox.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Pin Swap (PINS):";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(194, 136);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(113, 13);
            this.label17.TabIndex = 18;
            this.label17.Text = "USB Product ID (PID):";
            // 
            // pinsTextBox
            // 
            this.pinsTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pinsTextBox.Location = new System.Drawing.Point(162, 41);
            this.pinsTextBox.MaxLength = 2;
            this.pinsTextBox.Name = "pinsTextBox";
            this.pinsTextBox.Size = new System.Drawing.Size(24, 20);
            this.pinsTextBox.TabIndex = 5;
            // 
            // txcal1TextBox
            // 
            this.txcal1TextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txcal1TextBox.Location = new System.Drawing.Point(412, 156);
            this.txcal1TextBox.MaxLength = 2;
            this.txcal1TextBox.Name = "txcal1TextBox";
            this.txcal1TextBox.Size = new System.Drawing.Size(24, 20);
            this.txcal1TextBox.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 136);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "USB Vendor ID (VID):";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "NVM Chip Select (NVMCS):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(194, 113);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(198, 13);
            this.label13.TabIndex = 14;
            this.label13.Text = "Non-Volatile-Memory Page Size (NVMP):";
            // 
            // pidTextBox
            // 
            this.pidTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pidTextBox.Location = new System.Drawing.Point(398, 133);
            this.pidTextBox.MaxLength = 5;
            this.pidTextBox.Name = "pidTextBox";
            this.pidTextBox.Size = new System.Drawing.Size(38, 20);
            this.pidTextBox.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 205);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(148, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Universally Unique ID (UUID):";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(194, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(170, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Non-Volatile-Memory Size (NVMS):";
            // 
            // nvmcsTextBox
            // 
            this.nvmcsTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nvmcsTextBox.Location = new System.Drawing.Point(162, 64);
            this.nvmcsTextBox.MaxLength = 2;
            this.nvmcsTextBox.Name = "nvmcsTextBox";
            this.nvmcsTextBox.Size = new System.Drawing.Size(24, 20);
            this.nvmcsTextBox.TabIndex = 9;
            // 
            // nvmpTextBox
            // 
            this.nvmpTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nvmpTextBox.Location = new System.Drawing.Point(398, 110);
            this.nvmpTextBox.MaxLength = 5;
            this.nvmpTextBox.Name = "nvmpTextBox";
            this.nvmpTextBox.Size = new System.Drawing.Size(38, 20);
            this.nvmpTextBox.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(194, 67);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Non-Volatile-Memory Type (NVMT):";
            // 
            // vidTextBox
            // 
            this.vidTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.vidTextBox.Location = new System.Drawing.Point(148, 133);
            this.vidTextBox.MaxLength = 5;
            this.vidTextBox.Name = "vidTextBox";
            this.vidTextBox.Size = new System.Drawing.Size(38, 20);
            this.vidTextBox.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(194, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "SAW Bandwidth (SAWB):";
            // 
            // nvmsTextBox
            // 
            this.nvmsTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nvmsTextBox.Location = new System.Drawing.Point(398, 87);
            this.nvmsTextBox.MaxLength = 5;
            this.nvmsTextBox.Name = "nvmsTextBox";
            this.nvmsTextBox.Size = new System.Drawing.Size(38, 20);
            this.nvmsTextBox.TabIndex = 13;
            // 
            // ccalTextBox
            // 
            this.ccalTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ccalTextBox.Location = new System.Drawing.Point(162, 156);
            this.ccalTextBox.MaxLength = 2;
            this.ccalTextBox.Name = "ccalTextBox";
            this.ccalTextBox.Size = new System.Drawing.Size(24, 20);
            this.ccalTextBox.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(194, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(163, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "SAW Center Frequency (SAWC):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Crystal Calibration (CCAL):";
            // 
            // nvmtTextBox
            // 
            this.nvmtTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nvmtTextBox.Location = new System.Drawing.Point(412, 64);
            this.nvmtTextBox.MaxLength = 2;
            this.nvmtTextBox.Name = "nvmtTextBox";
            this.nvmtTextBox.Size = new System.Drawing.Size(24, 20);
            this.nvmtTextBox.TabIndex = 11;
            // 
            // uuidTextBox
            // 
            this.uuidTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.uuidTextBox.Location = new System.Drawing.Point(161, 202);
            this.uuidTextBox.MaxLength = 48;
            this.uuidTextBox.Name = "uuidTextBox";
            this.uuidTextBox.Size = new System.Drawing.Size(275, 20);
            this.uuidTextBox.TabIndex = 27;
            // 
            // sawcTextBox
            // 
            this.sawcTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.sawcTextBox.Location = new System.Drawing.Point(382, 18);
            this.sawcTextBox.MaxLength = 8;
            this.sawcTextBox.Name = "sawcTextBox";
            this.sawcTextBox.Size = new System.Drawing.Size(54, 20);
            this.sawcTextBox.TabIndex = 3;
            // 
            // sawbTextBox
            // 
            this.sawbTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.sawbTextBox.Location = new System.Drawing.Point(412, 41);
            this.sawbTextBox.MaxLength = 2;
            this.sawbTextBox.Name = "sawbTextBox";
            this.sawbTextBox.Size = new System.Drawing.Size(24, 20);
            this.sawbTextBox.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.hwTextBox);
            this.groupBox2.Location = new System.Drawing.Point(0, 254);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(440, 42);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Application area:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 21);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(121, 13);
            this.label25.TabIndex = 36;
            this.label25.Text = "Hardware version (HW):";
            // 
            // hwTextBox
            // 
            this.hwTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.hwTextBox.Location = new System.Drawing.Point(162, 18);
            this.hwTextBox.MaxLength = 2;
            this.hwTextBox.Name = "hwTextBox";
            this.hwTextBox.Size = new System.Drawing.Size(24, 20);
            this.hwTextBox.TabIndex = 37;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 305);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 13);
            this.label23.TabIndex = 34;
            this.label23.Text = "Production Tag:";
            // 
            // tagTextBox
            // 
            this.tagTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tagTextBox.Location = new System.Drawing.Point(92, 302);
            this.tagTextBox.MaxLength = 5;
            this.tagTextBox.Name = "tagTextBox";
            this.tagTextBox.ReadOnly = true;
            this.tagTextBox.Size = new System.Drawing.Size(138, 20);
            this.tagTextBox.TabIndex = 35;
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Protect sector";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 8);
            this.label21.Margin = new System.Windows.Forms.Padding(10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(153, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "Current Programming Interface:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.currentInterfaceLabel);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(450, 30);
            this.panel1.TabIndex = 3;
            // 
            // epS2Keypair
            // 
            this.epS2Keypair.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epS2Keypair.ContainerControl = this;
            // 
            // ZW050xForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lockBitsGroupBox);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ZW050xForm";
            this.Size = new System.Drawing.Size(450, 523);
            this.SizeChanged += new System.EventHandler(this.ZW050xForm_SizeChanged);
            this.lockBitsGroupBox.ResumeLayout(false);
            this.lockBitsGroupBox.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.sramOptionsGroupBox.ResumeLayout(false);
            this.sramOptionsGroupBox.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.homeIdSettingsGroupBox.ResumeLayout(false);
            this.homeIdSettingsGroupBox.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epS2Keypair)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolTip mainToolTip;
        private System.Windows.Forms.GroupBox lockBitsGroupBox;
        private System.Windows.Forms.Button lockBitsSetButton;
        private System.Windows.Forms.Button lockBitsReadButton;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button flashEraseButton;
        private System.Windows.Forms.Button calibrateAndProgrammButton;
        private System.Windows.Forms.Button flashWriteOptionsButton;
        private System.Windows.Forms.Label flashHexFileNameLabel;
        private System.Windows.Forms.Button flashReadOptionsButton;
        private System.Windows.Forms.Button flashBrowseHexFileButton;
        private System.Windows.Forms.GroupBox sramOptionsGroupBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox lowTxPowerCh2TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh2TextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lowTxPowerCh1TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh1TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lowTxPowerCh0TextBox;
        private System.Windows.Forms.TextBox normalTxPowerCh0TextBox;
        private System.Windows.Forms.Label lowTxPowerLabel;
        private System.Windows.Forms.Label normalTxPowerLabel;
        private System.Windows.Forms.Button flashReadButton;
        private System.Windows.Forms.TextBox flashHexFileNameTextBox;
        private System.Windows.Forms.Button flashCompareButton;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button sramWiteAndRunModeButton;
        private System.Windows.Forms.Button sramCompareButton;
        private System.Windows.Forms.Label sramHexFileNameLabel;
        private System.Windows.Forms.Button sramWriteButton;
        private System.Windows.Forms.Button sramBrowseHexFileButton;
        private System.Windows.Forms.Button sramReadButton;
        private System.Windows.Forms.TextBox sramHexFileNameTextBox;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox homeIdSettingsGroupBox;
        private System.Windows.Forms.TextBox endHomeIdTextBox;
        private System.Windows.Forms.TextBox startHomeIdTextBox;
        private System.Windows.Forms.Label endHomeIdLabel;
        private System.Windows.Forms.Label startHomeIdLabel;
        private System.Windows.Forms.CheckBox autoIncrementHomeIdCheckBox;
        private System.Windows.Forms.Button changeHomeIdButton;
        private System.Windows.Forms.Button readHomeIdButton;
        private System.Windows.Forms.TextBox readHomeIdTextBox;
        private System.Windows.Forms.TextBox currentHomeIdTextBox;
        private System.Windows.Forms.Label readHomeIdLabel;
        private System.Windows.Forms.Label currentHomeIdLabel;
        private System.Windows.Forms.Button eepromProgramButton;
        private System.Windows.Forms.Label eepromHexFileNameLabel;
        private System.Windows.Forms.Button eepromCompareButton;
        private System.Windows.Forms.Button eepromEraseButton;
        private System.Windows.Forms.Button eepromBrowseHexFileButton;
        private System.Windows.Forms.TextBox eepromHexFileNameTextBox;
        private System.Windows.Forms.Button eepromReadButton;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label6;
        private Controls.TextBoxEx pinsTextBox;
        private System.Windows.Forms.Label label5;
        private Controls.TextBoxEx ccalTextBox;
        private Controls.TextBoxEx revTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private Controls.TextBoxEx nvmtTextBox;
        private System.Windows.Forms.Label label10;
        private Controls.TextBoxEx sawbTextBox;
        private System.Windows.Forms.Label label8;
        private Controls.TextBoxEx sawcTextBox;
        private System.Windows.Forms.Label label7;
        private Controls.TextBoxEx nvmcsTextBox;
        private System.Windows.Forms.Label label14;
        private Controls.TextBoxEx uuidTextBox;
        private System.Windows.Forms.Label label13;
        private Controls.TextBoxEx nvmpTextBox;
        private System.Windows.Forms.Label label12;
        private Controls.TextBoxEx nvmsTextBox;
        private System.Windows.Forms.Label label15;
        private Controls.TextBoxEx crc16TextBox;
        private System.Windows.Forms.Button nvrReadButton;
        private System.Windows.Forms.Button nvrWrteButton;
        private System.Windows.Forms.Label label16;
        private Controls.TextBoxEx vidTextBox;
        private System.Windows.Forms.Label label17;
        private Controls.TextBoxEx pidTextBox;
        private System.Windows.Forms.ComboBox frequencyComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label18;
        private Controls.TextBoxEx txcal2TextBox;
        private System.Windows.Forms.Label label19;
        private Controls.TextBoxEx txcal1TextBox;
        private System.Windows.Forms.Label currentInterfaceLabel;
        private Controls.TextBoxEx protectSectorTextBox;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox autoprog1CheckBox;
        private System.Windows.Forms.CheckBox autoprog0CheckBox;
        private System.Windows.Forms.CheckBox readBackProtectionCheckBox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button buttonSetAPM;
        private System.Windows.Forms.Button productionButton;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.CheckBox chkAddS2;
        public System.Windows.Forms.Label labPub;
        public System.Windows.Forms.Label labPrv;
        public System.Windows.Forms.Button eepromReadModulesButton;
        public System.Windows.Forms.Button eepromGetModuleButton;
        public ZWave.Programmer.Controls.TextBoxEx tbNvmModuleData;
        public ZWave.Programmer.Controls.TextBoxEx tbNvmModuleType;
        public System.Windows.Forms.Button eepromSetModuleButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label22;
        public System.Windows.Forms.CheckBox chkGenerateS2;
        private System.Windows.Forms.Button btnGetS2Keys;
        private System.Windows.Forms.Label label23;
        private ZWave.Programmer.Controls.TextBoxEx tagTextBox;
        public System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private ZWave.Programmer.Controls.TextBoxEx hwTextBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ErrorProvider epS2Keypair;
        private ZWave.Programmer.Controls.TextBoxEx tbPub;
        private ZWave.Programmer.Controls.TextBoxEx tbPrv;
        private ZWave.Programmer.Controls.TextBoxEx tbDsk;

    }
}