using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Interfaces;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// Main Form class.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainForm"/> class.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        #region IView Members

        internal System.Windows.Forms.MenuStrip MainMenu
        {
            get { return mainMenu; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ViewToolStripMenuItem
        {
            get { return viewToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ToolsToolStripMenuItem
        {
            get { return toolsToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem SettingsToolStripMenuItem
        {
            get { return settingsToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem HelpToolStripMenuItem
        {
            get { return helpToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem AboutToolStripMenuItem
        {
            get { return aboutToolStripMenuItem; }
        }

        internal System.Windows.Forms.StatusStrip MainStatusStrip
        {
            get { return mainStatusStrip; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ZW010xToolStripMenuItem
        {
            get { return zW010xToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ZW020xToolStripMenuItem
        {
            get { return zW020xToolStripMenuItem; }
        }

        public System.Windows.Forms.ToolStripMenuItem ZW030xToolStripMenuItem
        {
            get { return zW030xToolStripMenuItem; }
        }

        public System.Windows.Forms.ToolStripMenuItem ZW040xToolStripMenuItem
        {
            get { return zW040xToolStripMenuItem; }
        }

        public System.Windows.Forms.ToolStripMenuItem ZW050xToolStripMenuItem
        {
            get { return zW050xToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem LogToolStripMenuItem
        {
            get { return logToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem
        {
            get { return exitToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripStatusLabel SelectedSerialPortStatusLabel
        {
            get { return selectedSerialPortStatusLabel; }
        }
        internal System.Windows.Forms.ToolStripMenuItem DetectTargetToolStripMenuItem
        {
            get { return detectTargetToolStripMenuItem; }
        }
        internal System.Windows.Forms.ToolStripMenuItem UpgradeFirmwareToolStripMenuItem
        {
            get { return upgrageFirmwareToolStripMenuItem; }
        }
        internal System.Windows.Forms.ToolStripMenuItem UploadFirmwareToolStripMenuItem
        {
            get { return uploadFirmwareToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripStatusLabel FirmwareStatusLabel
        {
            get { return firmwareStatusLabel; }
        }

        internal System.Windows.Forms.ToolStripStatusLabel ProgrammerStatusLabel
        {
            get { return programmerStatusLabel; }
        }

        internal System.Windows.Forms.ToolStripMenuItem ResetZWaveModuleToolStripMenuItem
        {
            get { return resetZWaveModuleToolStripMenuItem; }
        }

        internal System.Windows.Forms.ToolStripMenuItem CalibrateToolStripMenuItem
        {
            get { return calibrateToolStripMenuItem; }
        }

        #endregion

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutForm about = new AboutForm();
            about.ShowDialog();
        }

        public void InvokeAction(Action action)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<Action>(InvokeAction), action);
            }
            else
                action();
        }
    }
}