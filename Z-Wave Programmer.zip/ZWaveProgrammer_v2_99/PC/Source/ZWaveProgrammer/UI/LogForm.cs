using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Classes;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// LogForm class. Represents the Log View.
    /// </summary>
    public partial class LogForm : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogForm"/> class.
        /// </summary>
        public LogForm()
        {
            InitializeComponent();
        }
    }
}