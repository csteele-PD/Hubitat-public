namespace ZWave.Programmer.UI
{
    partial class ZW030xForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.eepromGroupBox = new System.Windows.Forms.GroupBox();
            this.homeIdSettingsGroupBox = new System.Windows.Forms.GroupBox();
            this.autoIncrementHomeIdGroupBox = new System.Windows.Forms.GroupBox();
            this.endHomeIdTextBox = new ZWave.Programmer.Controls.HomeIdTextBox();
            this.startHomeIdTextBox = new ZWave.Programmer.Controls.HomeIdTextBox();
            this.endHomeIdLabel = new System.Windows.Forms.Label();
            this.startHomeIdLabel = new System.Windows.Forms.Label();
            this.autoIncrementHomeIdCheckBox = new System.Windows.Forms.CheckBox();
            this.changeHomeIdButton = new System.Windows.Forms.Button();
            this.readHomeIdButton = new System.Windows.Forms.Button();
            this.readHomeIdTextBox = new ZWave.Programmer.Controls.HomeIdTextBox();
            this.currentHomeIdTextBox = new ZWave.Programmer.Controls.HomeIdTextBox();
            this.readHomeIdLabel = new System.Windows.Forms.Label();
            this.currentHomeIdLabel = new System.Windows.Forms.Label();
            this.eepromProgramButton = new System.Windows.Forms.Button();
            this.eepromCompareButton = new System.Windows.Forms.Button();
            this.eepromHexFileNameLabel = new System.Windows.Forms.Label();
            this.eepromHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.eepromReadButton = new System.Windows.Forms.Button();
            this.eepromBrowseHexFileButton = new System.Windows.Forms.Button();
            this.eepromEraseButton = new System.Windows.Forms.Button();
            this.flashOptionsMainGroupBox = new System.Windows.Forms.GroupBox();
            this.productionButton = new System.Windows.Forms.Button();
            this.frequencyGroupBox = new System.Windows.Forms.GroupBox();
            this.frequencyComboBox = new System.Windows.Forms.ComboBox();
            this.flashWriteOptionsButton = new System.Windows.Forms.Button();
            this.flashReadOptionsButton = new System.Windows.Forms.Button();
            this.flashOptionsGroupBox = new System.Windows.Forms.GroupBox();
            this.lowTxPowerTextBox = new System.Windows.Forms.TextBox();
            this.normalTxPowerTextBox = new System.Windows.Forms.TextBox();
            this.lowTxPowerLabel = new System.Windows.Forms.Label();
            this.normalTxPowerLabel = new System.Windows.Forms.Label();
            this.flashProgramButton = new System.Windows.Forms.Button();
            this.flashWriteButton = new System.Windows.Forms.Button();
            this.flashCompareButton = new System.Windows.Forms.Button();
            this.flashHexFileNameLabel = new System.Windows.Forms.Label();
            this.flashHexFileNameTextBox = new System.Windows.Forms.TextBox();
            this.flashReadButton = new System.Windows.Forms.Button();
            this.flashBrowseHexFileButton = new System.Windows.Forms.Button();
            this.flashEraseButton = new System.Windows.Forms.Button();
            this.lockBitsGroupBox = new System.Windows.Forms.GroupBox();
            this.lockBitsBootSectorSizeComboBox = new System.Windows.Forms.ComboBox();
            this.lockBitsBootSectorSizeLabel = new System.Windows.Forms.Label();
            this.lockBitsSetButton = new System.Windows.Forms.Button();
            this.lockBitsReadButton = new System.Windows.Forms.Button();
            this.lockBitsBootBlockLockCheckBox = new System.Windows.Forms.CheckBox();
            this.lockBitsDisableFlashReadCheckBox = new System.Windows.Forms.CheckBox();
            this.mainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.eepromGroupBox.SuspendLayout();
            this.homeIdSettingsGroupBox.SuspendLayout();
            this.autoIncrementHomeIdGroupBox.SuspendLayout();
            this.flashOptionsMainGroupBox.SuspendLayout();
            this.frequencyGroupBox.SuspendLayout();
            this.flashOptionsGroupBox.SuspendLayout();
            this.lockBitsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // eepromGroupBox
            // 
            this.eepromGroupBox.Controls.Add(this.homeIdSettingsGroupBox);
            this.eepromGroupBox.Controls.Add(this.eepromProgramButton);
            this.eepromGroupBox.Controls.Add(this.eepromCompareButton);
            this.eepromGroupBox.Controls.Add(this.eepromHexFileNameLabel);
            this.eepromGroupBox.Controls.Add(this.eepromHexFileNameTextBox);
            this.eepromGroupBox.Controls.Add(this.eepromReadButton);
            this.eepromGroupBox.Controls.Add(this.eepromBrowseHexFileButton);
            this.eepromGroupBox.Controls.Add(this.eepromEraseButton);
            this.eepromGroupBox.Location = new System.Drawing.Point(3, 200);
            this.eepromGroupBox.Name = "eepromGroupBox";
            this.eepromGroupBox.Size = new System.Drawing.Size(444, 220);
            this.eepromGroupBox.TabIndex = 1;
            this.eepromGroupBox.TabStop = false;
            this.eepromGroupBox.Text = "External Non-Volatile Memory";
            // 
            // homeIdSettingsGroupBox
            // 
            this.homeIdSettingsGroupBox.Controls.Add(this.autoIncrementHomeIdGroupBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.changeHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdButton);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdTextBox);
            this.homeIdSettingsGroupBox.Controls.Add(this.readHomeIdLabel);
            this.homeIdSettingsGroupBox.Controls.Add(this.currentHomeIdLabel);
            this.homeIdSettingsGroupBox.Location = new System.Drawing.Point(13, 86);
            this.homeIdSettingsGroupBox.Name = "homeIdSettingsGroupBox";
            this.homeIdSettingsGroupBox.Size = new System.Drawing.Size(402, 126);
            this.homeIdSettingsGroupBox.TabIndex = 7;
            this.homeIdSettingsGroupBox.TabStop = false;
            this.homeIdSettingsGroupBox.Text = "Home Id Settings";
            // 
            // autoIncrementHomeIdGroupBox
            // 
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.endHomeIdTextBox);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.startHomeIdTextBox);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.endHomeIdLabel);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.startHomeIdLabel);
            this.autoIncrementHomeIdGroupBox.Controls.Add(this.autoIncrementHomeIdCheckBox);
            this.autoIncrementHomeIdGroupBox.Location = new System.Drawing.Point(199, 15);
            this.autoIncrementHomeIdGroupBox.Name = "autoIncrementHomeIdGroupBox";
            this.autoIncrementHomeIdGroupBox.Size = new System.Drawing.Size(189, 100);
            this.autoIncrementHomeIdGroupBox.TabIndex = 42;
            this.autoIncrementHomeIdGroupBox.TabStop = false;
            // 
            // endHomeIdTextBox
            // 
            this.endHomeIdTextBox.Enabled = false;
            this.endHomeIdTextBox.Location = new System.Drawing.Point(83, 53);
            this.endHomeIdTextBox.MaxLength = 8;
            this.endHomeIdTextBox.Name = "endHomeIdTextBox";
            this.endHomeIdTextBox.Size = new System.Drawing.Size(91, 20);
            this.endHomeIdTextBox.TabIndex = 4;
            // 
            // startHomeIdTextBox
            // 
            this.startHomeIdTextBox.Enabled = false;
            this.startHomeIdTextBox.Location = new System.Drawing.Point(83, 27);
            this.startHomeIdTextBox.MaxLength = 8;
            this.startHomeIdTextBox.Name = "startHomeIdTextBox";
            this.startHomeIdTextBox.Size = new System.Drawing.Size(91, 20);
            this.startHomeIdTextBox.TabIndex = 2;
            // 
            // endHomeIdLabel
            // 
            this.endHomeIdLabel.AutoSize = true;
            this.endHomeIdLabel.Location = new System.Drawing.Point(6, 56);
            this.endHomeIdLabel.Name = "endHomeIdLabel";
            this.endHomeIdLabel.Size = new System.Drawing.Size(72, 13);
            this.endHomeIdLabel.TabIndex = 3;
            this.endHomeIdLabel.Text = "End Home Id:";
            // 
            // startHomeIdLabel
            // 
            this.startHomeIdLabel.AutoSize = true;
            this.startHomeIdLabel.Location = new System.Drawing.Point(6, 30);
            this.startHomeIdLabel.Name = "startHomeIdLabel";
            this.startHomeIdLabel.Size = new System.Drawing.Size(75, 13);
            this.startHomeIdLabel.TabIndex = 1;
            this.startHomeIdLabel.Text = "Start Home Id:";
            // 
            // autoIncrementHomeIdCheckBox
            // 
            this.autoIncrementHomeIdCheckBox.AutoSize = true;
            this.autoIncrementHomeIdCheckBox.Location = new System.Drawing.Point(6, 0);
            this.autoIncrementHomeIdCheckBox.Name = "autoIncrementHomeIdCheckBox";
            this.autoIncrementHomeIdCheckBox.Size = new System.Drawing.Size(98, 17);
            this.autoIncrementHomeIdCheckBox.TabIndex = 0;
            this.autoIncrementHomeIdCheckBox.Text = "Auto Increment";
            this.autoIncrementHomeIdCheckBox.UseVisualStyleBackColor = true;
            // 
            // changeHomeIdButton
            // 
            this.changeHomeIdButton.Location = new System.Drawing.Point(22, 88);
            this.changeHomeIdButton.Name = "changeHomeIdButton";
            this.changeHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.changeHomeIdButton.TabIndex = 4;
            this.changeHomeIdButton.Text = "Set";
            this.mainToolTip.SetToolTip(this.changeHomeIdButton, "Alt+F1");
            this.changeHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // readHomeIdButton
            // 
            this.readHomeIdButton.Location = new System.Drawing.Point(109, 88);
            this.readHomeIdButton.Name = "readHomeIdButton";
            this.readHomeIdButton.Size = new System.Drawing.Size(75, 23);
            this.readHomeIdButton.TabIndex = 5;
            this.readHomeIdButton.Text = "Get";
            this.mainToolTip.SetToolTip(this.readHomeIdButton, "Alt+F2");
            this.readHomeIdButton.UseVisualStyleBackColor = true;
            // 
            // readHomeIdTextBox
            // 
            this.readHomeIdTextBox.Location = new System.Drawing.Point(81, 53);
            this.readHomeIdTextBox.MaxLength = 8;
            this.readHomeIdTextBox.Name = "readHomeIdTextBox";
            this.readHomeIdTextBox.ReadOnly = true;
            this.readHomeIdTextBox.Size = new System.Drawing.Size(107, 20);
            this.readHomeIdTextBox.TabIndex = 3;
            // 
            // currentHomeIdTextBox
            // 
            this.currentHomeIdTextBox.Location = new System.Drawing.Point(81, 27);
            this.currentHomeIdTextBox.MaxLength = 8;
            this.currentHomeIdTextBox.Name = "currentHomeIdTextBox";
            this.currentHomeIdTextBox.Size = new System.Drawing.Size(107, 20);
            this.currentHomeIdTextBox.TabIndex = 1;
            // 
            // readHomeIdLabel
            // 
            this.readHomeIdLabel.AutoSize = true;
            this.readHomeIdLabel.Location = new System.Drawing.Point(19, 56);
            this.readHomeIdLabel.Name = "readHomeIdLabel";
            this.readHomeIdLabel.Size = new System.Drawing.Size(36, 13);
            this.readHomeIdLabel.TabIndex = 2;
            this.readHomeIdLabel.Text = "Read:";
            // 
            // currentHomeIdLabel
            // 
            this.currentHomeIdLabel.AutoSize = true;
            this.currentHomeIdLabel.Location = new System.Drawing.Point(19, 30);
            this.currentHomeIdLabel.Name = "currentHomeIdLabel";
            this.currentHomeIdLabel.Size = new System.Drawing.Size(56, 13);
            this.currentHomeIdLabel.TabIndex = 0;
            this.currentHomeIdLabel.Text = "Current Id:";
            // 
            // eepromProgramButton
            // 
            this.eepromProgramButton.Location = new System.Drawing.Point(259, 47);
            this.eepromProgramButton.Name = "eepromProgramButton";
            this.eepromProgramButton.Size = new System.Drawing.Size(75, 23);
            this.eepromProgramButton.TabIndex = 5;
            this.eepromProgramButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.eepromProgramButton, "Alt+P");
            this.eepromProgramButton.UseVisualStyleBackColor = true;
            // 
            // eepromCompareButton
            // 
            this.eepromCompareButton.Location = new System.Drawing.Point(340, 47);
            this.eepromCompareButton.Name = "eepromCompareButton";
            this.eepromCompareButton.Size = new System.Drawing.Size(75, 23);
            this.eepromCompareButton.TabIndex = 6;
            this.eepromCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.eepromCompareButton, "Alt+M");
            this.eepromCompareButton.UseVisualStyleBackColor = true;
            // 
            // eepromHexFileNameLabel
            // 
            this.eepromHexFileNameLabel.AutoSize = true;
            this.eepromHexFileNameLabel.Location = new System.Drawing.Point(10, 23);
            this.eepromHexFileNameLabel.Name = "eepromHexFileNameLabel";
            this.eepromHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.eepromHexFileNameLabel.TabIndex = 0;
            this.eepromHexFileNameLabel.Text = "HEX File:";
            // 
            // eepromHexFileNameTextBox
            // 
            this.eepromHexFileNameTextBox.Location = new System.Drawing.Point(67, 20);
            this.eepromHexFileNameTextBox.Name = "eepromHexFileNameTextBox";
            this.eepromHexFileNameTextBox.ReadOnly = true;
            this.eepromHexFileNameTextBox.Size = new System.Drawing.Size(314, 20);
            this.eepromHexFileNameTextBox.TabIndex = 1;
            // 
            // eepromReadButton
            // 
            this.eepromReadButton.Location = new System.Drawing.Point(94, 47);
            this.eepromReadButton.Name = "eepromReadButton";
            this.eepromReadButton.Size = new System.Drawing.Size(75, 23);
            this.eepromReadButton.TabIndex = 4;
            this.eepromReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.eepromReadButton, "Alt+R");
            this.eepromReadButton.UseVisualStyleBackColor = true;
            // 
            // eepromBrowseHexFileButton
            // 
            this.eepromBrowseHexFileButton.Location = new System.Drawing.Point(387, 18);
            this.eepromBrowseHexFileButton.Name = "eepromBrowseHexFileButton";
            this.eepromBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.eepromBrowseHexFileButton.TabIndex = 2;
            this.eepromBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.eepromBrowseHexFileButton, "Alt+O");
            this.eepromBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // eepromEraseButton
            // 
            this.eepromEraseButton.Location = new System.Drawing.Point(13, 47);
            this.eepromEraseButton.Name = "eepromEraseButton";
            this.eepromEraseButton.Size = new System.Drawing.Size(75, 23);
            this.eepromEraseButton.TabIndex = 3;
            this.eepromEraseButton.Text = "Erase";
            this.mainToolTip.SetToolTip(this.eepromEraseButton, "Alt+E");
            this.eepromEraseButton.UseVisualStyleBackColor = true;
            // 
            // flashOptionsMainGroupBox
            // 
            this.flashOptionsMainGroupBox.Controls.Add(this.productionButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.frequencyGroupBox);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashWriteOptionsButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashReadOptionsButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashOptionsGroupBox);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashProgramButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashWriteButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashCompareButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashHexFileNameLabel);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashHexFileNameTextBox);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashReadButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashBrowseHexFileButton);
            this.flashOptionsMainGroupBox.Controls.Add(this.flashEraseButton);
            this.flashOptionsMainGroupBox.Location = new System.Drawing.Point(3, 3);
            this.flashOptionsMainGroupBox.Name = "flashOptionsMainGroupBox";
            this.flashOptionsMainGroupBox.Size = new System.Drawing.Size(444, 197);
            this.flashOptionsMainGroupBox.TabIndex = 0;
            this.flashOptionsMainGroupBox.TabStop = false;
            this.flashOptionsMainGroupBox.Text = "Flash";
            // 
            // productionButton
            // 
            this.productionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productionButton.ForeColor = System.Drawing.Color.RoyalBlue;
            this.productionButton.Location = new System.Drawing.Point(319, 46);
            this.productionButton.Name = "productionButton";
            this.productionButton.Size = new System.Drawing.Size(96, 52);
            this.productionButton.TabIndex = 12;
            this.productionButton.Text = "Production";
            this.productionButton.UseVisualStyleBackColor = true;
            this.productionButton.Visible = false;
            // 
            // frequencyGroupBox
            // 
            this.frequencyGroupBox.Controls.Add(this.frequencyComboBox);
            this.frequencyGroupBox.Location = new System.Drawing.Point(215, 107);
            this.frequencyGroupBox.Name = "frequencyGroupBox";
            this.frequencyGroupBox.Padding = new System.Windows.Forms.Padding(12, 6, 6, 3);
            this.frequencyGroupBox.Size = new System.Drawing.Size(105, 74);
            this.frequencyGroupBox.TabIndex = 9;
            this.frequencyGroupBox.TabStop = false;
            this.frequencyGroupBox.Text = "Frequency";
            // 
            // frequencyComboBox
            // 
            this.frequencyComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frequencyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.frequencyComboBox.FormattingEnabled = true;
            this.frequencyComboBox.Location = new System.Drawing.Point(12, 19);
            this.frequencyComboBox.Name = "frequencyComboBox";
            this.frequencyComboBox.Size = new System.Drawing.Size(87, 21);
            this.frequencyComboBox.TabIndex = 0;
            // 
            // flashWriteOptionsButton
            // 
            this.flashWriteOptionsButton.Location = new System.Drawing.Point(326, 136);
            this.flashWriteOptionsButton.Name = "flashWriteOptionsButton";
            this.flashWriteOptionsButton.Size = new System.Drawing.Size(89, 23);
            this.flashWriteOptionsButton.TabIndex = 11;
            this.flashWriteOptionsButton.Text = "Set Options";
            this.mainToolTip.SetToolTip(this.flashWriteOptionsButton, "Shift+W");
            this.flashWriteOptionsButton.UseVisualStyleBackColor = true;
            // 
            // flashReadOptionsButton
            // 
            this.flashReadOptionsButton.Location = new System.Drawing.Point(326, 107);
            this.flashReadOptionsButton.Name = "flashReadOptionsButton";
            this.flashReadOptionsButton.Size = new System.Drawing.Size(89, 23);
            this.flashReadOptionsButton.TabIndex = 10;
            this.flashReadOptionsButton.Text = "Get Options";
            this.mainToolTip.SetToolTip(this.flashReadOptionsButton, "Shift+R");
            this.flashReadOptionsButton.UseVisualStyleBackColor = true;
            // 
            // flashOptionsGroupBox
            // 
            this.flashOptionsGroupBox.Controls.Add(this.lowTxPowerTextBox);
            this.flashOptionsGroupBox.Controls.Add(this.normalTxPowerTextBox);
            this.flashOptionsGroupBox.Controls.Add(this.lowTxPowerLabel);
            this.flashOptionsGroupBox.Controls.Add(this.normalTxPowerLabel);
            this.flashOptionsGroupBox.Location = new System.Drawing.Point(13, 107);
            this.flashOptionsGroupBox.Name = "flashOptionsGroupBox";
            this.flashOptionsGroupBox.Size = new System.Drawing.Size(192, 74);
            this.flashOptionsGroupBox.TabIndex = 8;
            this.flashOptionsGroupBox.TabStop = false;
            this.flashOptionsGroupBox.Text = "Options";
            // 
            // lowTxPowerTextBox
            // 
            this.lowTxPowerTextBox.Location = new System.Drawing.Point(113, 42);
            this.lowTxPowerTextBox.MaxLength = 2;
            this.lowTxPowerTextBox.Name = "lowTxPowerTextBox";
            this.lowTxPowerTextBox.Size = new System.Drawing.Size(59, 20);
            this.lowTxPowerTextBox.TabIndex = 3;
            // 
            // normalTxPowerTextBox
            // 
            this.normalTxPowerTextBox.Location = new System.Drawing.Point(113, 19);
            this.normalTxPowerTextBox.MaxLength = 2;
            this.normalTxPowerTextBox.Name = "normalTxPowerTextBox";
            this.normalTxPowerTextBox.Size = new System.Drawing.Size(59, 20);
            this.normalTxPowerTextBox.TabIndex = 1;
            // 
            // lowTxPowerLabel
            // 
            this.lowTxPowerLabel.AutoSize = true;
            this.lowTxPowerLabel.Location = new System.Drawing.Point(16, 45);
            this.lowTxPowerLabel.Name = "lowTxPowerLabel";
            this.lowTxPowerLabel.Size = new System.Drawing.Size(78, 13);
            this.lowTxPowerLabel.TabIndex = 2;
            this.lowTxPowerLabel.Text = "Low Tx Power:";
            // 
            // normalTxPowerLabel
            // 
            this.normalTxPowerLabel.AutoSize = true;
            this.normalTxPowerLabel.Location = new System.Drawing.Point(16, 22);
            this.normalTxPowerLabel.Name = "normalTxPowerLabel";
            this.normalTxPowerLabel.Size = new System.Drawing.Size(91, 13);
            this.normalTxPowerLabel.TabIndex = 0;
            this.normalTxPowerLabel.Text = "Normal Tx Power:";
            // 
            // flashProgramButton
            // 
            this.flashProgramButton.Location = new System.Drawing.Point(83, 49);
            this.flashProgramButton.Name = "flashProgramButton";
            this.flashProgramButton.Size = new System.Drawing.Size(118, 23);
            this.flashProgramButton.TabIndex = 6;
            this.flashProgramButton.Text = "Program and Verify";
            this.mainToolTip.SetToolTip(this.flashProgramButton, "Ctrl+P");
            this.flashProgramButton.UseVisualStyleBackColor = true;
            // 
            // flashWriteButton
            // 
            this.flashWriteButton.Location = new System.Drawing.Point(83, 78);
            this.flashWriteButton.Name = "flashWriteButton";
            this.flashWriteButton.Size = new System.Drawing.Size(65, 23);
            this.flashWriteButton.TabIndex = 5;
            this.flashWriteButton.Text = "Program";
            this.mainToolTip.SetToolTip(this.flashWriteButton, "Ctrl+W");
            this.flashWriteButton.UseVisualStyleBackColor = true;
            // 
            // flashCompareButton
            // 
            this.flashCompareButton.Location = new System.Drawing.Point(207, 49);
            this.flashCompareButton.Name = "flashCompareButton";
            this.flashCompareButton.Size = new System.Drawing.Size(65, 23);
            this.flashCompareButton.TabIndex = 7;
            this.flashCompareButton.Text = "Compare";
            this.mainToolTip.SetToolTip(this.flashCompareButton, "Ctrl+M");
            this.flashCompareButton.UseVisualStyleBackColor = true;
            // 
            // flashHexFileNameLabel
            // 
            this.flashHexFileNameLabel.AutoSize = true;
            this.flashHexFileNameLabel.Location = new System.Drawing.Point(10, 25);
            this.flashHexFileNameLabel.Name = "flashHexFileNameLabel";
            this.flashHexFileNameLabel.Size = new System.Drawing.Size(51, 13);
            this.flashHexFileNameLabel.TabIndex = 0;
            this.flashHexFileNameLabel.Text = "HEX File:";
            // 
            // flashHexFileNameTextBox
            // 
            this.flashHexFileNameTextBox.Location = new System.Drawing.Point(67, 22);
            this.flashHexFileNameTextBox.Name = "flashHexFileNameTextBox";
            this.flashHexFileNameTextBox.ReadOnly = true;
            this.flashHexFileNameTextBox.Size = new System.Drawing.Size(314, 20);
            this.flashHexFileNameTextBox.TabIndex = 1;
            // 
            // flashReadButton
            // 
            this.flashReadButton.Location = new System.Drawing.Point(12, 49);
            this.flashReadButton.Name = "flashReadButton";
            this.flashReadButton.Size = new System.Drawing.Size(65, 23);
            this.flashReadButton.TabIndex = 4;
            this.flashReadButton.Text = "Read";
            this.mainToolTip.SetToolTip(this.flashReadButton, "Ctrl+R");
            this.flashReadButton.UseVisualStyleBackColor = true;
            // 
            // flashBrowseHexFileButton
            // 
            this.flashBrowseHexFileButton.Location = new System.Drawing.Point(387, 20);
            this.flashBrowseHexFileButton.Name = "flashBrowseHexFileButton";
            this.flashBrowseHexFileButton.Size = new System.Drawing.Size(28, 23);
            this.flashBrowseHexFileButton.TabIndex = 2;
            this.flashBrowseHexFileButton.Text = "...";
            this.mainToolTip.SetToolTip(this.flashBrowseHexFileButton, "Ctrl+O");
            this.flashBrowseHexFileButton.UseVisualStyleBackColor = true;
            // 
            // flashEraseButton
            // 
            this.flashEraseButton.Location = new System.Drawing.Point(12, 78);
            this.flashEraseButton.Name = "flashEraseButton";
            this.flashEraseButton.Size = new System.Drawing.Size(65, 23);
            this.flashEraseButton.TabIndex = 3;
            this.flashEraseButton.Text = "Erase";
            this.mainToolTip.SetToolTip(this.flashEraseButton, "Ctrl+E");
            this.flashEraseButton.UseVisualStyleBackColor = true;
            // 
            // lockBitsGroupBox
            // 
            this.lockBitsGroupBox.Controls.Add(this.lockBitsBootSectorSizeComboBox);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsBootSectorSizeLabel);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsSetButton);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsReadButton);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsBootBlockLockCheckBox);
            this.lockBitsGroupBox.Controls.Add(this.lockBitsDisableFlashReadCheckBox);
            this.lockBitsGroupBox.Location = new System.Drawing.Point(3, 420);
            this.lockBitsGroupBox.Name = "lockBitsGroupBox";
            this.lockBitsGroupBox.Size = new System.Drawing.Size(444, 74);
            this.lockBitsGroupBox.TabIndex = 2;
            this.lockBitsGroupBox.TabStop = false;
            this.lockBitsGroupBox.Text = "Lock Bits";
            // 
            // lockBitsBootSectorSizeComboBox
            // 
            this.lockBitsBootSectorSizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lockBitsBootSectorSizeComboBox.FormattingEnabled = true;
            this.lockBitsBootSectorSizeComboBox.Items.AddRange(new object[] {
            "32768 bytes (all)",
            "16384 bytes",
            "  8192 bytes",
            "  4096 bytes",
            "  2048 bytes",
            "  1024 bytes",
            "    512 bytes",
            "        0 bytes"});
            this.lockBitsBootSectorSizeComboBox.Location = new System.Drawing.Point(304, 37);
            this.lockBitsBootSectorSizeComboBox.Name = "lockBitsBootSectorSizeComboBox";
            this.lockBitsBootSectorSizeComboBox.Size = new System.Drawing.Size(111, 21);
            this.lockBitsBootSectorSizeComboBox.TabIndex = 3;
            // 
            // lockBitsBootSectorSizeLabel
            // 
            this.lockBitsBootSectorSizeLabel.AutoSize = true;
            this.lockBitsBootSectorSizeLabel.Location = new System.Drawing.Point(302, 21);
            this.lockBitsBootSectorSizeLabel.Name = "lockBitsBootSectorSizeLabel";
            this.lockBitsBootSectorSizeLabel.Size = new System.Drawing.Size(89, 13);
            this.lockBitsBootSectorSizeLabel.TabIndex = 2;
            this.lockBitsBootSectorSizeLabel.Text = "Boot Sector Size:";
            // 
            // lockBitsSetButton
            // 
            this.lockBitsSetButton.Location = new System.Drawing.Point(88, 43);
            this.lockBitsSetButton.Name = "lockBitsSetButton";
            this.lockBitsSetButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsSetButton.TabIndex = 5;
            this.lockBitsSetButton.Text = "Set";
            this.lockBitsSetButton.UseVisualStyleBackColor = true;
            // 
            // lockBitsReadButton
            // 
            this.lockBitsReadButton.Location = new System.Drawing.Point(7, 43);
            this.lockBitsReadButton.Name = "lockBitsReadButton";
            this.lockBitsReadButton.Size = new System.Drawing.Size(75, 23);
            this.lockBitsReadButton.TabIndex = 4;
            this.lockBitsReadButton.Text = "Get";
            this.lockBitsReadButton.UseVisualStyleBackColor = true;
            // 
            // lockBitsBootBlockLockCheckBox
            // 
            this.lockBitsBootBlockLockCheckBox.AutoSize = true;
            this.lockBitsBootBlockLockCheckBox.Location = new System.Drawing.Point(141, 20);
            this.lockBitsBootBlockLockCheckBox.Name = "lockBitsBootBlockLockCheckBox";
            this.lockBitsBootBlockLockCheckBox.Size = new System.Drawing.Size(155, 17);
            this.lockBitsBootBlockLockCheckBox.TabIndex = 1;
            this.lockBitsBootBlockLockCheckBox.Text = "Boot Block Write Protected";
            this.lockBitsBootBlockLockCheckBox.UseVisualStyleBackColor = true;
            // 
            // lockBitsDisableFlashReadCheckBox
            // 
            this.lockBitsDisableFlashReadCheckBox.AutoSize = true;
            this.lockBitsDisableFlashReadCheckBox.Location = new System.Drawing.Point(15, 20);
            this.lockBitsDisableFlashReadCheckBox.Name = "lockBitsDisableFlashReadCheckBox";
            this.lockBitsDisableFlashReadCheckBox.Size = new System.Drawing.Size(118, 17);
            this.lockBitsDisableFlashReadCheckBox.TabIndex = 0;
            this.lockBitsDisableFlashReadCheckBox.Text = "Disable Flash Read";
            this.lockBitsDisableFlashReadCheckBox.UseVisualStyleBackColor = true;
            // 
            // ZW030xForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.lockBitsGroupBox);
            this.Controls.Add(this.eepromGroupBox);
            this.Controls.Add(this.flashOptionsMainGroupBox);
            this.Name = "ZW030xForm";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.Size = new System.Drawing.Size(450, 523);
            this.eepromGroupBox.ResumeLayout(false);
            this.eepromGroupBox.PerformLayout();
            this.homeIdSettingsGroupBox.ResumeLayout(false);
            this.homeIdSettingsGroupBox.PerformLayout();
            this.autoIncrementHomeIdGroupBox.ResumeLayout(false);
            this.autoIncrementHomeIdGroupBox.PerformLayout();
            this.flashOptionsMainGroupBox.ResumeLayout(false);
            this.flashOptionsMainGroupBox.PerformLayout();
            this.frequencyGroupBox.ResumeLayout(false);
            this.flashOptionsGroupBox.ResumeLayout(false);
            this.flashOptionsGroupBox.PerformLayout();
            this.lockBitsGroupBox.ResumeLayout(false);
            this.lockBitsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox eepromGroupBox;
        private System.Windows.Forms.Button eepromProgramButton;
        private System.Windows.Forms.Button eepromCompareButton;
        private System.Windows.Forms.Label eepromHexFileNameLabel;
        private System.Windows.Forms.TextBox eepromHexFileNameTextBox;
        private System.Windows.Forms.Button eepromReadButton;
        private System.Windows.Forms.Button eepromBrowseHexFileButton;
        private System.Windows.Forms.Button eepromEraseButton;
        private System.Windows.Forms.GroupBox flashOptionsMainGroupBox;
        private System.Windows.Forms.Button flashWriteOptionsButton;
        private System.Windows.Forms.Button flashReadOptionsButton;
        private System.Windows.Forms.GroupBox flashOptionsGroupBox;
        private System.Windows.Forms.TextBox lowTxPowerTextBox;
        private System.Windows.Forms.TextBox normalTxPowerTextBox;
        private System.Windows.Forms.Label lowTxPowerLabel;
        private System.Windows.Forms.Label normalTxPowerLabel;
        private System.Windows.Forms.Button flashProgramButton;
        private System.Windows.Forms.Button flashWriteButton;
        private System.Windows.Forms.Button flashCompareButton;
        private System.Windows.Forms.Label flashHexFileNameLabel;
        private System.Windows.Forms.TextBox flashHexFileNameTextBox;
        private System.Windows.Forms.Button flashReadButton;
        private System.Windows.Forms.Button flashBrowseHexFileButton;
        private System.Windows.Forms.Button flashEraseButton;
        private System.Windows.Forms.GroupBox homeIdSettingsGroupBox;
        private System.Windows.Forms.GroupBox autoIncrementHomeIdGroupBox;
        private ZWave.Programmer.Controls.HomeIdTextBox endHomeIdTextBox;
        private ZWave.Programmer.Controls.HomeIdTextBox startHomeIdTextBox;
        private System.Windows.Forms.Label endHomeIdLabel;
        private System.Windows.Forms.Label startHomeIdLabel;
        private System.Windows.Forms.CheckBox autoIncrementHomeIdCheckBox;
        private System.Windows.Forms.Button changeHomeIdButton;
        private System.Windows.Forms.Button readHomeIdButton;
        private ZWave.Programmer.Controls.HomeIdTextBox readHomeIdTextBox;
        private ZWave.Programmer.Controls.HomeIdTextBox currentHomeIdTextBox;
        private System.Windows.Forms.Label readHomeIdLabel;
        private System.Windows.Forms.Label currentHomeIdLabel;
		private System.Windows.Forms.GroupBox lockBitsGroupBox;
		private System.Windows.Forms.ComboBox lockBitsBootSectorSizeComboBox;
		private System.Windows.Forms.Label lockBitsBootSectorSizeLabel;
		private System.Windows.Forms.Button lockBitsSetButton;
		private System.Windows.Forms.Button lockBitsReadButton;
		private System.Windows.Forms.CheckBox lockBitsBootBlockLockCheckBox;
        private System.Windows.Forms.CheckBox lockBitsDisableFlashReadCheckBox;
        private System.Windows.Forms.ToolTip mainToolTip;
        private System.Windows.Forms.GroupBox frequencyGroupBox;
        private System.Windows.Forms.ComboBox frequencyComboBox;
        private System.Windows.Forms.Button productionButton;
    }
}