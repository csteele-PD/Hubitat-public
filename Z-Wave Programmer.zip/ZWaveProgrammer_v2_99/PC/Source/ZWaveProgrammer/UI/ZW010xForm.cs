using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Classes;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// ZW010xForm class. Represents the ZW010x View
    /// </summary>
    public partial class ZW010xForm : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ZW010xForm"/> class.
        /// </summary>
        public ZW010xForm()
        {
            InitializeComponent();
        }

        #region View Members
        internal System.Windows.Forms.Button FlashProgramButton
        {
            get { return flashProgramButton; }
        }
        internal System.Windows.Forms.Button FlashWriteButton
        {
            get { return flashWriteButton; }
        }
        internal System.Windows.Forms.Button FlashCompareButton
        {
            get { return flashCompareButton; }
        }
        internal System.Windows.Forms.TextBox FlashHexFileNameTextBox
        {
            get { return flashHexFileNameTextBox; }
        }
        internal System.Windows.Forms.Button FlashReadButton
        {
            get { return flashReadButton; }
        }
        internal System.Windows.Forms.Button FlashBrowseHexFileButton
        {
            get { return flashBrowseHexFileButton; }
        }
        internal System.Windows.Forms.Button FlashEraseButton
        {
            get { return flashEraseButton; }
        }
        internal System.Windows.Forms.TextBox TxMatchTextBox
        {
            get { return txMatchTextBox; }
        }
        internal System.Windows.Forms.TextBox RxMatchTextBox
        {
            get { return rxMatchTextBox; }
        }
        internal System.Windows.Forms.TextBox LowTxPowerTextBox
        {
            get { return lowTxPowerTextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerTextBox
        {
            get { return normalTxPowerTextBox; }
        }
        internal System.Windows.Forms.RadioButton EuRadioButton
        {
            get { return euRadioButton; }
        }
        internal System.Windows.Forms.RadioButton UsRadioButton
        {
            get { return usRadioButton; }
        }
        internal System.Windows.Forms.Button FlashReadOptionsButton
        {
            get { return flashReadOptionsButton; }
        }
        internal ZWave.Programmer.Controls.HomeIdTextBox CurrentHomeIdTextBox
        {
            get { return currentHomeIdTextBox; }
        }
        internal System.Windows.Forms.Button EepromProgramButton
        {
            get { return eepromProgramButton; }
        }
        internal System.Windows.Forms.Button EepromCompareButton
        {
            get { return eepromCompareButton; }
        }
        internal System.Windows.Forms.TextBox EepromHexFileNameTextBox
        {
            get { return eepromHexFileNameTextBox; }
        }
        internal System.Windows.Forms.Button EepromReadButton
        {
            get { return eepromReadButton; }
        }
        internal System.Windows.Forms.Button EepromBrowseHexFileButton
        {
            get { return eepromBrowseHexFileButton; }
        }
        internal System.Windows.Forms.Button EepromEraseButton
        {
            get { return eepromEraseButton; }
        }
        internal ZWave.Programmer.Controls.HomeIdTextBox EndHomeIdTextBox
        {
            get { return endHomeIdTextBox; }
        }
        internal ZWave.Programmer.Controls.HomeIdTextBox StartHomeIdTextBox
        {
            get { return startHomeIdTextBox; }
        }
        internal System.Windows.Forms.CheckBox AutoIncrementHomeIdCheckBox
        {
            get { return autoIncrementHomeIdCheckBox; }
        }
        internal System.Windows.Forms.Button ChangeHomeIdButton
        {
            get { return changeHomeIdButton; }
        }
        internal System.Windows.Forms.Button ReadHomeIdButton
        {
            get { return readHomeIdButton; }
        }
        internal ZWave.Programmer.Controls.HomeIdTextBox ReadHomeIdTextBox
        {
            get { return readHomeIdTextBox; }
        }
        internal System.Windows.Forms.RadioButton DefaultRadioButton
        {
            get { return defaultRadioButton; }
        }
		internal System.Windows.Forms.CheckBox LockBitsDisableFlashReadCheckBox
		{
			get { return lockBitsDisableFlashReadCheckBox; }
		}
		internal System.Windows.Forms.CheckBox LockBitsBootBlockLockCheckBox
		{
			get { return lockBitsBootBlockLockCheckBox; }
		}
		internal System.Windows.Forms.ComboBox LockBitsBootSectorSizeComboBox
		{
			get { return lockBitsBootSectorSizeComboBox; }
		}
		internal System.Windows.Forms.Button LockBitsReadButton
		{
			get { return lockBitsReadButton; }
		}
		internal System.Windows.Forms.Button LockBitsSetButton
		{
			get { return lockBitsSetButton; }
		}
		#endregion
    }
}