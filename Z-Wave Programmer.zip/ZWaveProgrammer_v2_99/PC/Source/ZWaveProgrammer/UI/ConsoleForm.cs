using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Classes;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// ConsoleForm class. Represents the Console View.
    /// </summary>
    public partial class ConsoleForm : UserControl
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="ConsoleForm"/> class.
        /// </summary>
        public ConsoleForm()
        {
            InitializeComponent();
        }

        public void ShowSramWarning(bool visible)
        {
            ShowHeader(visible, "Warning! You can't rely on the content of the data in 0x500-0x507 and 0xE00-0xFFF", true);
        }

        public void ShowHeader(bool visible, string header, bool isWarning)
        {
            labelHeader.Visible = visible;
            if (header != null)
            {
                labelHeader.Text = header;
                if (isWarning)
                {
                    labelHeader.ForeColor = Color.Red;
                }
                else
                {
                    labelHeader.ForeColor = this.ForeColor;
                }
            }
        }


        #region View Members

        internal System.Windows.Forms.TextBox ContentTextBox
        {
            get { return contentTextBox; }
        }
        internal System.Windows.Forms.ToolStripButton ClearToolStripButton
        {
            get { return clearToolStripButton; }
        }

        internal System.Windows.Forms.ToolStripButton SaveToolStripButton
        {
            get { return saveToolStripButton; }
        }

        internal System.Windows.Forms.ToolStripButton CopyToolStripButton
        {
            get { return copyToolStripButton; }
        }

        #endregion
    }
}