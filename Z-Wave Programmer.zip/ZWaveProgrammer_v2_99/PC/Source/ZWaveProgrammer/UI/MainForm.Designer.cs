namespace ZWave.Programmer.UI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zW010xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zW020xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zW030xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zW040xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zW050xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.logToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detectTargetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetZWaveModuleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.upgrageFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.calibrateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainStatusStrip = new System.Windows.Forms.StatusStrip();
            this.selectedSerialPortStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.firmwareStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.programmerStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.mainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.mainTabControl = new System.Windows.Forms.TabControl();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.ConsoleForm = new ZWave.Programmer.UI.ConsoleForm();
            this.mainMenu.SuspendLayout();
            this.mainStatusStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(834, 24);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "menuStrip1";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zW010xToolStripMenuItem,
            this.zW020xToolStripMenuItem,
            this.zW030xToolStripMenuItem,
            this.zW040xToolStripMenuItem,
            this.zW050xToolStripMenuItem,
            this.toolStripMenuItem2,
            this.logToolStripMenuItem,
            this.toolStripMenuItem3,
            this.exitToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // zW010xToolStripMenuItem
            // 
            this.zW010xToolStripMenuItem.CheckOnClick = true;
            this.zW010xToolStripMenuItem.Name = "zW010xToolStripMenuItem";
            this.zW010xToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.zW010xToolStripMenuItem.Text = "ZW010x";
            this.zW010xToolStripMenuItem.ToolTipText = "100 Series chip (F1) - Select the ZW010x tab.";
            // 
            // zW020xToolStripMenuItem
            // 
            this.zW020xToolStripMenuItem.CheckOnClick = true;
            this.zW020xToolStripMenuItem.Name = "zW020xToolStripMenuItem";
            this.zW020xToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.zW020xToolStripMenuItem.Text = "ZW020x";
            this.zW020xToolStripMenuItem.ToolTipText = "200 Series chip (F2) - Select the ZW020x tab.";
            // 
            // zW030xToolStripMenuItem
            // 
            this.zW030xToolStripMenuItem.CheckOnClick = true;
            this.zW030xToolStripMenuItem.Name = "zW030xToolStripMenuItem";
            this.zW030xToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.zW030xToolStripMenuItem.Text = "ZW030x";
            this.zW030xToolStripMenuItem.ToolTipText = "300 Series chip (F3) - Select the ZW030x tab.";
            // 
            // zW040xToolStripMenuItem
            // 
            this.zW040xToolStripMenuItem.CheckOnClick = true;
            this.zW040xToolStripMenuItem.Name = "zW040xToolStripMenuItem";
            this.zW040xToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.zW040xToolStripMenuItem.Text = "ZW040x";
            this.zW040xToolStripMenuItem.ToolTipText = "400 Series chip (F4) - Select the ZW040x tab.";
            // 
            // zW050xToolStripMenuItem
            // 
            this.zW050xToolStripMenuItem.CheckOnClick = true;
            this.zW050xToolStripMenuItem.Name = "zW050xToolStripMenuItem";
            this.zW050xToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.zW050xToolStripMenuItem.Text = "ZW050x";
            this.zW050xToolStripMenuItem.ToolTipText = "500 Series chip (F5) - Select the ZW050x tab.";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(126, 6);
            // 
            // logToolStripMenuItem
            // 
            this.logToolStripMenuItem.CheckOnClick = true;
            this.logToolStripMenuItem.Name = "logToolStripMenuItem";
            this.logToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.logToolStripMenuItem.Text = "Log";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(126, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detectTargetToolStripMenuItem,
            this.resetZWaveModuleToolStripMenuItem,
            this.upgrageFirmwareToolStripMenuItem,
            this.uploadFirmwareToolStripMenuItem,
            this.toolStripMenuItem5,
            this.calibrateToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // detectTargetToolStripMenuItem
            // 
            this.detectTargetToolStripMenuItem.Name = "detectTargetToolStripMenuItem";
            this.detectTargetToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.detectTargetToolStripMenuItem.Text = "Detect Target";
            this.detectTargetToolStripMenuItem.ToolTipText = "Detect Target (Ctrl+D)";
            // 
            // resetZWaveModuleToolStripMenuItem
            // 
            this.resetZWaveModuleToolStripMenuItem.Name = "resetZWaveModuleToolStripMenuItem";
            this.resetZWaveModuleToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.resetZWaveModuleToolStripMenuItem.Text = "Reset Z-Wave Module";
            this.resetZWaveModuleToolStripMenuItem.ToolTipText = "Reset Z-Wave Module - Generate reset event without physically pushing the reset b" +
                "utton on the ZDP0xx programmer.";
            // 
            // upgrageFirmwareToolStripMenuItem
            // 
            this.upgrageFirmwareToolStripMenuItem.Name = "upgrageFirmwareToolStripMenuItem";
            this.upgrageFirmwareToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.upgrageFirmwareToolStripMenuItem.Text = "Upgrade Atmel Firmware";
            this.upgrageFirmwareToolStripMenuItem.ToolTipText = "Upgrade Firmware - Compare the firmware version of the actual ZDP0xx programmer. " +
                "If older, update the firmware to the version bundled with this version of the PC" +
                " programmer.";
            // 
            // uploadFirmwareToolStripMenuItem
            // 
            this.uploadFirmwareToolStripMenuItem.Name = "uploadFirmwareToolStripMenuItem";
            this.uploadFirmwareToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.uploadFirmwareToolStripMenuItem.Text = "Upload Atmel Firmware...";
            this.uploadFirmwareToolStripMenuItem.ToolTipText = "Upload Firmware from a file selected by the user.";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(205, 6);
            // 
            // calibrateToolStripMenuItem
            // 
            this.calibrateToolStripMenuItem.Name = "calibrateToolStripMenuItem";
            this.calibrateToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.calibrateToolStripMenuItem.Text = "Calibrate";
            this.calibrateToolStripMenuItem.ToolTipText = "Calibrate - Calibrate module using dedicated calibration hardware connected to th" +
                "e ZDP0xx programmer.";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // mainStatusStrip
            // 
            this.mainStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectedSerialPortStatusLabel,
            this.firmwareStatusLabel,
            this.programmerStatusLabel});
            this.mainStatusStrip.Location = new System.Drawing.Point(0, 579);
            this.mainStatusStrip.Name = "mainStatusStrip";
            this.mainStatusStrip.Size = new System.Drawing.Size(834, 22);
            this.mainStatusStrip.TabIndex = 1;
            this.mainStatusStrip.Text = "statusStrip1";
            // 
            // selectedSerialPortStatusLabel
            // 
            this.selectedSerialPortStatusLabel.Name = "selectedSerialPortStatusLabel";
            this.selectedSerialPortStatusLabel.Size = new System.Drawing.Size(95, 17);
            this.selectedSerialPortStatusLabel.Text = "Serial Port: None";
            // 
            // firmwareStatusLabel
            // 
            this.firmwareStatusLabel.Name = "firmwareStatusLabel";
            this.firmwareStatusLabel.Size = new System.Drawing.Size(126, 17);
            this.firmwareStatusLabel.Text = "Atmel Firmware: None";
            // 
            // programmerStatusLabel
            // 
            this.programmerStatusLabel.Name = "programmerStatusLabel";
            this.programmerStatusLabel.Size = new System.Drawing.Size(253, 17);
            this.programmerStatusLabel.Text = "Status: Z-Wave programmer started and ready.";
            this.programmerStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mainTabControl
            // 
            this.mainTabControl.Location = new System.Drawing.Point(4, 27);
            this.mainTabControl.Name = "mainTabControl";
            this.mainTabControl.SelectedIndex = 0;
            this.mainTabControl.Size = new System.Drawing.Size(460, 549);
            this.mainTabControl.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(470, 29);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(3);
            this.panel1.Size = new System.Drawing.Size(360, 19);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Output";
            // 
            // ConsoleForm
            // 
            this.ConsoleForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ConsoleForm.Location = new System.Drawing.Point(470, 48);
            this.ConsoleForm.Name = "ConsoleForm";
            this.ConsoleForm.Size = new System.Drawing.Size(360, 528);
            this.ConsoleForm.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 601);
            this.Controls.Add(this.mainTabControl);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ConsoleForm);
            this.Controls.Add(this.mainStatusStrip);
            this.Controls.Add(this.mainMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.mainMenu;
            this.MinimumSize = new System.Drawing.Size(600, 640);
            this.Name = "MainForm";
            this.Text = "Z-Wave Programmer";
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.mainStatusStrip.ResumeLayout(false);
            this.mainStatusStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip mainStatusStrip;
        private System.Windows.Forms.ToolStripMenuItem zW010xToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zW020xToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zW030xToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zW040xToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem logToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel selectedSerialPortStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem detectTargetToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem upgrageFirmwareToolStripMenuItem;
		private System.Windows.Forms.ToolStripStatusLabel firmwareStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem resetZWaveModuleToolStripMenuItem;
        private System.Windows.Forms.ToolTip mainToolTip;
		private System.Windows.Forms.ToolStripStatusLabel programmerStatusLabel;
		private System.Windows.Forms.ToolStripMenuItem uploadFirmwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem calibrateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zW050xToolStripMenuItem;
        public System.Windows.Forms.TabControl mainTabControl;
        public ConsoleForm ConsoleForm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
    }
}