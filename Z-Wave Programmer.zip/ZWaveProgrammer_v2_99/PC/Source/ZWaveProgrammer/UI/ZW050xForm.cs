using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Classes;
using ZWave.Framework;
using System.Linq;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// ZW050xForm class. Represents the ZW050x View
    /// </summary>
    public partial class ZW050xForm : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ZW050xForm"/> class.
        /// </summary>
        public ZW050xForm()
        {
            InitializeComponent();
#if !DEBUG
            buttonSetAPM.Visible = false;
#endif
        }

        #region View Members
        internal System.Windows.Forms.Button ProductionButton
        {
            get { return productionButton; }
        }
        internal System.Windows.Forms.Button FlashCompareButton
        {
            get { return flashCompareButton; }
        }
        internal System.Windows.Forms.TextBox FlashHexFileNameTextBox
        {
            get { return flashHexFileNameTextBox; }
        }
        internal System.Windows.Forms.Button FlashEraseButton
        {
            get { return flashEraseButton; }
        }
        internal System.Windows.Forms.Button FlashReadButton
        {
            get { return flashReadButton; }
        }
        internal System.Windows.Forms.Button FlashBrowseHexFileButton
        {
            get { return flashBrowseHexFileButton; }
        }
        internal System.Windows.Forms.Button SramWriteButton
        {
            get { return sramWriteButton; }
        }
        internal System.Windows.Forms.Button SramReadButton
        {
            get { return sramReadButton; }
        }
        internal System.Windows.Forms.Button SramCompareButton
        {
            get { return sramCompareButton; }
        }
        internal System.Windows.Forms.Button LockBitsSetButton
        {
            get { return lockBitsSetButton; }
        }
        internal System.Windows.Forms.Button LockBitsReadButton
        {
            get { return lockBitsReadButton; }
        }
        internal System.Windows.Forms.TextBox SramHexFileNameTextBox
        {
            get { return sramHexFileNameTextBox; }
        }
        internal System.Windows.Forms.Button SramBrowseHexFileButton
        {
            get { return sramBrowseHexFileButton; }
        }
        internal System.Windows.Forms.GroupBox OptionsGroupBox
        {
            get { return sramOptionsGroupBox; }
        }
        internal System.Windows.Forms.TextBox LowTxPowerCh0TextBox
        {
            get { return lowTxPowerCh0TextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerCh0TextBox
        {
            get { return normalTxPowerCh0TextBox; }
        }
        internal System.Windows.Forms.TextBox LowTxPowerCh1TextBox
        {
            get { return lowTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerCh1TextBox
        {
            get { return normalTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox LowTxPowerCh2TextBox
        {
            get { return lowTxPowerCh2TextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerCh2TextBox
        {
            get { return normalTxPowerCh2TextBox; }
        }
        internal System.Windows.Forms.Button FlashReadOptionsButton
        {
            get { return flashReadOptionsButton; }
        }
        internal System.Windows.Forms.Button FlashWriteOptionsButton
        {
            get { return flashWriteOptionsButton; }
        }
        internal System.Windows.Forms.GroupBox SramOptionsGroupBox
        {
            get { return sramOptionsGroupBox; }
        }
        internal System.Windows.Forms.Button SramWriteAndRunModeButton
        {
            get { return sramWiteAndRunModeButton; }
        }
        internal System.Windows.Forms.TextBox EndHomeIdTextBox
        {
            get { return endHomeIdTextBox; }
        }
        internal System.Windows.Forms.TextBox StartHomeIdTextBox
        {
            get { return startHomeIdTextBox; }
        }
        internal System.Windows.Forms.CheckBox AutoIncrementHomeIdCheckBox
        {
            get { return autoIncrementHomeIdCheckBox; }
        }
        internal System.Windows.Forms.Button ChangeHomeIdButton
        {
            get { return changeHomeIdButton; }
        }
        internal System.Windows.Forms.Button ReadHomeIdButton
        {
            get { return readHomeIdButton; }
        }
        internal System.Windows.Forms.TextBox ReadHomeIdTextBox
        {
            get { return readHomeIdTextBox; }
        }
        internal System.Windows.Forms.TextBox CurrentHomeIdTextBox
        {
            get { return currentHomeIdTextBox; }
        }
        internal System.Windows.Forms.Button EepromProgramButton
        {
            get { return eepromProgramButton; }
        }
        internal System.Windows.Forms.Button EepromCompareButton
        {
            get { return eepromCompareButton; }
        }
        internal System.Windows.Forms.TextBox EepromHexFileNameTextBox
        {
            get { return eepromHexFileNameTextBox; }
        }
        internal System.Windows.Forms.Button EepromReadButton
        {
            get { return eepromReadButton; }
        }

        internal System.Windows.Forms.Button EepromBrowseHexFileButton
        {
            get { return eepromBrowseHexFileButton; }
        }

        internal System.Windows.Forms.Button EepromEraseButton
        {
            get { return eepromEraseButton; }
        }

        internal System.Windows.Forms.Button CalibrateAndProgrammButton
        {
            get { return calibrateAndProgrammButton; }
        }

        internal System.Windows.Forms.Button GetS2KeysButton
        {
            get { return btnGetS2Keys; }
        }

        internal System.Windows.Forms.TextBox PinsTextBox
        {
            get { return pinsTextBox; }
        }

        internal System.Windows.Forms.TextBox CcalTextBox
        {
            get { return ccalTextBox; }
        }

        internal System.Windows.Forms.TextBox RevTextBox
        {
            get { return revTextBox; }
        }

        internal System.Windows.Forms.TextBox NvmtTextBox
        {
            get { return nvmtTextBox; }
        }

        internal System.Windows.Forms.TextBox SawbTextBox
        {
            get { return sawbTextBox; }
        }
        internal System.Windows.Forms.TextBox SawcTextBox
        {
            get { return sawcTextBox; }
        }

        internal System.Windows.Forms.TextBox NvmcsTextBox
        {
            get { return nvmcsTextBox; }
        }
        internal System.Windows.Forms.TextBox UuidTextBox
        {
            get { return uuidTextBox; }
        }

        internal System.Windows.Forms.TextBox NvmpTextBox
        {
            get { return nvmpTextBox; }
        }

        internal System.Windows.Forms.TextBox NvmsTextBox
        {
            get { return nvmsTextBox; }
        }

        internal System.Windows.Forms.TextBox Crc16TextBox
        {
            get { return crc16TextBox; }
        }

        internal System.Windows.Forms.TextBox TagTextBox
        {
            get { return tagTextBox; }
        }

        internal System.Windows.Forms.Button NvrReadButton
        {
            get { return nvrReadButton; }
        }

        internal System.Windows.Forms.Button NvrWrteButton
        {
            get { return nvrWrteButton; }
        }

        internal System.Windows.Forms.TextBox VidTextBox
        {
            get { return vidTextBox; }
        }

        internal System.Windows.Forms.TextBox PidTextBox
        {
            get { return pidTextBox; }
        }


        internal System.Windows.Forms.TextBox Txcal2TextBox
        {
            get { return txcal2TextBox; }
        }

        internal System.Windows.Forms.TextBox Txcal1TextBox
        {
            get { return txcal1TextBox; }
        }

        internal System.Windows.Forms.TextBox HwTextBox
        {
            get { return hwTextBox; }
        }

        private int progInterface = -1;

        public int GetProgrammingInterface()
        {
            return progInterface;
        }

        public void SetProgrammingInterface(int prgInterface)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new EventHandler(delegate
                {
                    SetProgrammingInterface(prgInterface);
                }));
            }
            else
            {
                progInterface = prgInterface;
                CalibrateAndProgrammButton.Text = "Calibrate, Program and Verify";
                if (progInterface == 0)
                    currentInterfaceLabel.Text = "SPI";
                else if (progInterface == 1)
                    currentInterfaceLabel.Text = "UART";
                else if (progInterface == 2)
                {
                    currentInterfaceLabel.Text = "USB";
                    CalibrateAndProgrammButton.Text = "Program and Verify";
                }
                else
                    currentInterfaceLabel.Text = "None";
            }
        }

        public System.Windows.Forms.TextBox ProtectSectorTextBox
        {
            get { return protectSectorTextBox; }
        }

        public System.Windows.Forms.CheckBox Autoprog1CheckBox
        {
            get { return autoprog1CheckBox; }
        }


        public System.Windows.Forms.CheckBox Autoprog0CheckBox
        {
            get { return autoprog0CheckBox; }
        }

        public System.Windows.Forms.CheckBox ReadBackProtectionCheckBox
        {
            get { return readBackProtectionCheckBox; }
        }

        public System.Windows.Forms.ComboBox FrequencyComboBox
        {
            get { return frequencyComboBox; }
        }
        #endregion

        public void ClearData()
        {
            lowTxPowerCh2TextBox.Text = "";
            normalTxPowerCh2TextBox.Text = "";
            lowTxPowerCh1TextBox.Text = "";
            normalTxPowerCh1TextBox.Text = "";
            lowTxPowerCh0TextBox.Text = "";
            normalTxPowerCh0TextBox.Text = "";
            readHomeIdTextBox.Text = "";
            currentHomeIdTextBox.Text = "";

            pinsTextBox.Text = "";
            ccalTextBox.Text = "";
            revTextBox.Text = "";
            nvmtTextBox.Text = "";
            sawbTextBox.Text = "";
            sawcTextBox.Text = "";
            nvmcsTextBox.Text = "";
            uuidTextBox.Text = "";
            nvmpTextBox.Text = "";
            nvmsTextBox.Text = "";
            crc16TextBox.Text = "";
            tagTextBox.Text = "";
            vidTextBox.Text = "";
            pidTextBox.Text = "";
            txcal2TextBox.Text = "";
            txcal1TextBox.Text = "";
            hwTextBox.Text = "";

            protectSectorTextBox.Text = "";
            readBackProtectionCheckBox.Checked = false;
        }
        private void protectSectorTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
                && e.KeyChar != ','
                && e.KeyChar != ' '
                && e.KeyChar != '-')
            {
                e.Handled = true;
            }
        }

        public System.Windows.Forms.Button ButtonSetAPM
        {
            get { return buttonSetAPM; }
        }

        private void ZW050xForm_SizeChanged(object sender, EventArgs e)
        {
            tabControl1.Refresh();
        }
        const string NO_SECTORS_PROTECTED = "<no sectors protected>";
        private void protectSectorTextBox_Enter(object sender, EventArgs e)
        {
            if (protectSectorTextBox.Text == NO_SECTORS_PROTECTED)
            {
                protectSectorTextBox.Text = "";
            }
        }

        private void protectSectorTextBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(protectSectorTextBox.Text))
            {
                protectSectorTextBox.Text = NO_SECTORS_PROTECTED;
            }
        }

        private void tbPub_TextChanged(object sender, EventArgs e)
        {
            bool hasValue = false;
            StringBuilder sbDsk = new StringBuilder();
            if (tbPub.Text != null)
            {
                try
                {
                    byte[] keyPub = Tools.GetBytes(tbPub.Text);
                    if (keyPub != null && keyPub.Length > 15)
                    {

                        for (int i = 0; i < 16; i += 2)
                        {
                            if (i >= 14)
                            {
                                sbDsk.AppendLine(Tools.GetInt32(keyPub.Skip(i).Take(2).ToArray()).ToString("00000"));
                            }
                            else
                            {
                                sbDsk.AppendLine(Tools.GetInt32(keyPub.Skip(i).Take(2).ToArray()).ToString("00000") + "-");
                            }
                        }
                        hasValue = true;
                    }
                }
                catch
                {
                }
            }
            if (hasValue)
            {
                tbDsk.Text = sbDsk.ToString();
            }
            else
            {
                tbDsk.Text = "";
            }
        }

        internal void UpdateAvailabilityS2Keypair(bool isAddSecurity2Keys, bool isGenerateSecurity2Keys)
        {
            labPrv.Enabled = isAddSecurity2Keys && !isGenerateSecurity2Keys;
            tbPrv.ReadOnly = !(isAddSecurity2Keys && !isGenerateSecurity2Keys);
            labPub.Enabled = isAddSecurity2Keys && !isGenerateSecurity2Keys;
            tbPub.ReadOnly = !(isAddSecurity2Keys && !isGenerateSecurity2Keys);
        }

        internal void SetS2PrivateKey(string privateKey)
        {
            tbPrv.Text = privateKey;
            epS2Keypair.Clear();
        }

        internal void SetS2PublicKey(string publicKey)
        {
            tbPub.Text = publicKey;
            epS2Keypair.Clear();
        }

        internal void SetS2Keypair(string privateKey, string publicKey, string error)
        {
            tbPrv.Text = privateKey;
            tbPub.Text = publicKey;
            if (error != null)
            {
                epS2Keypair.SetIconAlignment(tbPrv, ErrorIconAlignment.MiddleRight);
                epS2Keypair.SetIconPadding(tbPrv, -18);
                epS2Keypair.SetIconAlignment(tbPub, ErrorIconAlignment.MiddleRight);
                epS2Keypair.SetIconPadding(tbPub, -18);
                epS2Keypair.SetError(tbPrv, error);
                epS2Keypair.SetError(tbPub, error);
            }
        }

        internal string GetS2PrivateKey()
        {
            return tbPrv.Text;
        }

        internal string GetS2PublicKey()
        {
            return tbPub.Text;
        }

        internal void ClearHasChanges()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(ClearHasChanges));
            }
            else
            {
                tbPrv.ClearHasChanges();
                tbPub.ClearHasChanges();
                epS2Keypair.Clear();
            }
        }
    }
}