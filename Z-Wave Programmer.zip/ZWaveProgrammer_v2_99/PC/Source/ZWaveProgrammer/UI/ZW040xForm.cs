using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ZWave.Programmer.Classes;

namespace ZWave.Programmer.UI
{
    /// <summary>
    /// ZW040xForm class. Represents the ZW040x View
    /// </summary>
    public partial class ZW040xForm : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ZW040xForm"/> class.
        /// </summary>
        public ZW040xForm()
        {
            InitializeComponent();
		}

		#region View Members
        internal System.Windows.Forms.Button ProductionButton
        {
            get { return productionButton; }
        }
        internal System.Windows.Forms.Button FlashProgramButton
		{
			get { return flashProgramButton; }
		}
		internal System.Windows.Forms.Button FlashWriteButton
		{
			get { return flashWriteButton; }
		}
		internal System.Windows.Forms.Button FlashCompareButton
		{
			get { return flashCompareButton; }
		}
		internal System.Windows.Forms.TextBox FlashHexFileNameTextBox
		{
			get { return flashHexFileNameTextBox; }
		}
		internal System.Windows.Forms.Button FlashReadButton
		{
			get { return flashReadButton; }
		}
		internal System.Windows.Forms.Button FlashBrowseHexFileButton
		{
			get { return flashBrowseHexFileButton; }
		}
		internal System.Windows.Forms.Button SramWriteButton
		{
			get { return sramWriteButton; }
		}
		internal System.Windows.Forms.Button SramReadButton
		{
			get { return sramReadButton; }
		}
		internal System.Windows.Forms.Button CrcCheckButton
		{
			get { return crcCheckButton; }
		}
		internal System.Windows.Forms.CheckBox DisableDevModeCheckBox
		{
			get { return disableDevModeCheckBox; }
		}
		internal System.Windows.Forms.CheckBox DisableReadBackCheckBox
		{
			get { return disableReadBackCheckBox; }
		}
		internal System.Windows.Forms.CheckBox SetModemCheckBox
		{
			get { return setModemCheckBox; }
		}
		internal System.Windows.Forms.Button SramCompareButton
		{
			get { return sramCompareButton; }
		}
		internal System.Windows.Forms.Button LockBitsSetButton
		{
			get { return lockBitsSetButton; }
		}
		internal System.Windows.Forms.Button LockBitsReadButton
		{
			get { return lockBitsReadButton; }
		}
		internal System.Windows.Forms.TextBox SramHexFileNameTextBox
		{
			get { return sramHexFileNameTextBox; }
		}
		internal System.Windows.Forms.Button SramBrowseHexFileButton
		{
			get { return sramBrowseHexFileButton; }
		}
		internal System.Windows.Forms.GroupBox OptionsGroupBox
		{
			get { return sramOptionsGroupBox; }
		}
		internal System.Windows.Forms.TextBox LowTxPowerCh0TextBox
		{
			get { return lowTxPowerCh0TextBox; }
		}
		internal System.Windows.Forms.TextBox NormalTxPowerCh0TextBox
		{
			get { return normalTxPowerCh0TextBox; }
		}
        internal System.Windows.Forms.TextBox LowTxPowerCh1TextBox
        {
            get { return lowTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerCh1TextBox
        {
            get { return normalTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox LowTxPowerCh2TextBox
        {
            get { return lowTxPowerCh2TextBox; }
        }
        internal System.Windows.Forms.TextBox NormalTxPowerCh2TextBox
        {
            get { return normalTxPowerCh2TextBox; }
        }
		internal System.Windows.Forms.Button FlashReadOptionsButton
		{
			get { return flashReadOptionsButton; }
		}
		internal System.Windows.Forms.Button FlashWriteOptionsButton
		{
			get { return flashWriteOptionsButton; }
		}
        internal System.Windows.Forms.GroupBox SramOptionsGroupBox
        {
            get { return sramOptionsGroupBox; }
        }
		internal System.Windows.Forms.TextBox SramLowTxPowerCh0TextBox
		{
			get { return sramLowTxPowerCh0TextBox; }
		}
		internal System.Windows.Forms.TextBox SramNormalTxPowerCh0TextBox
		{
			get { return sramNormalTxPowerCh0TextBox; }
		}
        internal System.Windows.Forms.TextBox SramLowTxPowerCh1TextBox
        {
            get { return sramLowTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox SramNormalTxPowerCh1TextBox
        {
            get { return sramNormalTxPowerCh1TextBox; }
        }
        internal System.Windows.Forms.TextBox SramLowTxPowerCh2TextBox
        {
            get { return sramLowTxPowerCh2TextBox; }
        }
        internal System.Windows.Forms.TextBox SramNormalTxPowerCh2TextBox
        {
            get { return sramNormalTxPowerCh2TextBox; }
        }
		internal System.Windows.Forms.Button SramReadOptionsButton
		{
			get { return sramReadOptionsButton; }
		}
		internal System.Windows.Forms.Button SramWriteOptionsButton
		{
			get { return sramWriteOptionsButton; }
		}
		internal System.Windows.Forms.Button SramWriteAndRunModeButton
		{
			get { return sramWiteAndRunModeButton; }
		}
		internal System.Windows.Forms.TextBox EndHomeIdTextBox
		{
			get { return endHomeIdTextBox; }
		}
		internal System.Windows.Forms.TextBox StartHomeIdTextBox
		{
			get { return startHomeIdTextBox; }
		}
		internal System.Windows.Forms.CheckBox AutoIncrementHomeIdCheckBox
		{
			get { return autoIncrementHomeIdCheckBox; }
		}
		internal System.Windows.Forms.Button ChangeHomeIdButton
		{
			get { return changeHomeIdButton; }
		}
		internal System.Windows.Forms.Button ReadHomeIdButton
		{
			get { return readHomeIdButton; }
		}
		internal System.Windows.Forms.TextBox ReadHomeIdTextBox
		{
			get { return readHomeIdTextBox; }
		}
		internal System.Windows.Forms.TextBox CurrentHomeIdTextBox
		{
			get { return currentHomeIdTextBox; }
		}
		internal System.Windows.Forms.Button EepromProgramButton
		{
			get { return eepromProgramButton; }
		}
		internal System.Windows.Forms.Button EepromCompareButton
		{
			get { return eepromCompareButton; }
		}
		internal System.Windows.Forms.TextBox EepromHexFileNameTextBox
		{
			get { return eepromHexFileNameTextBox; }
		}
		internal System.Windows.Forms.Button EepromReadButton
		{
			get { return eepromReadButton; }
		}
		internal System.Windows.Forms.Button EepromBrowseHexFileButton
		{
			get { return eepromBrowseHexFileButton; }
		}
		internal System.Windows.Forms.Button EepromEraseButton
		{
			get { return eepromEraseButton; }
		}
		internal System.Windows.Forms.GroupBox SramOperationModesGroupBox
		{
			get { return sramOperationModesGroupBox; }
		}
		internal System.Windows.Forms.RadioButton ModeExecOutOfSRAMRadioButton
		{
			get { return modeExecOutOfSRAMRadioButton; }
		}
		internal System.Windows.Forms.RadioButton ModeDevelopmentRadioButton
		{
			get { return modeDevelopmentRadioButton; }
		}
		internal System.Windows.Forms.GroupBox MtpGroupBox
		{
			get { return mtpGroupBox; }
		}
		internal System.Windows.Forms.Button MtpProgramButton
		{
			get { return  mtpProgramButton; }
		}
		internal System.Windows.Forms.Button MtpCompareButton
		{
			get { return  mtpCompareButton; }
		}
		internal System.Windows.Forms.Button MtpReadButton
		{
			get { return  mtpReadButton; }
		}
		internal System.Windows.Forms.Button MtpEraseButton
		{
			get { return  mtpEraseButton; }
		}
		internal System.Windows.Forms.Label MtpHexFileNameLabel
		{
			get { return  mtpHexFileNameLabel; }
		}
		internal System.Windows.Forms.TextBox MtpHexFileNameTextBox
		{
			get { return  mtpHexFileNameTextBox; }
		}
		internal System.Windows.Forms.Button MtpBrowseHexFileButton
		{
			get { return  mtpBrowseHexFileButton; }
		}
		internal System.Windows.Forms.CheckBox MtpAutoEraseCheckBox
		{
			get { return  mtpAutoEraseCheckBox; }
		}
        
        internal System.Windows.Forms.Button CalibrateAndProgrammButton
        {
            get { return calibrateAndProgrammButton; }
        }

        internal System.Windows.Forms.TextBox CalibrationValueTextBox
        {
            get { return calibrationValueTextBox; }
        }
		#endregion

        private void ZW040xForm_SizeChanged(object sender, EventArgs e)
        {
            tabControl1.Refresh();
        }
	}
}