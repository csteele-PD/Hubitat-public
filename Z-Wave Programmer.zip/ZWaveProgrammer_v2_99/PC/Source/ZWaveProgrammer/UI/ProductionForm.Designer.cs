﻿namespace ZWave.Programmer.UI
{
    partial class ProductionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.programButton = new System.Windows.Forms.Button();
            this.logTextBox1 = new System.Windows.Forms.TextBox();
            this.fullPathLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.greenBar = new ZWave.Programmer.Controls.GradientBar();
            this.label3 = new System.Windows.Forms.Label();
            this.hexFileLabel = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.sStatusLabelOK1 = new System.Windows.Forms.Label();
            this.sStatusLabelError1 = new System.Windows.Forms.Label();
            this.gbCONN1 = new System.Windows.Forms.GroupBox();
            this.gridPanel = new System.Windows.Forms.TableLayoutPanel();
            this.gbCONN6 = new System.Windows.Forms.GroupBox();
            this.logTextBox6 = new System.Windows.Forms.TextBox();
            this.sStatusLabelError6 = new System.Windows.Forms.Label();
            this.sStatusLabelOK6 = new System.Windows.Forms.Label();
            this.gbCONN3 = new System.Windows.Forms.GroupBox();
            this.logTextBox3 = new System.Windows.Forms.TextBox();
            this.sStatusLabelError3 = new System.Windows.Forms.Label();
            this.sStatusLabelOK3 = new System.Windows.Forms.Label();
            this.gbCONN4 = new System.Windows.Forms.GroupBox();
            this.logTextBox4 = new System.Windows.Forms.TextBox();
            this.sStatusLabelError4 = new System.Windows.Forms.Label();
            this.sStatusLabelOK4 = new System.Windows.Forms.Label();
            this.gbCONN5 = new System.Windows.Forms.GroupBox();
            this.logTextBox5 = new System.Windows.Forms.TextBox();
            this.sStatusLabelError5 = new System.Windows.Forms.Label();
            this.sStatusLabelOK5 = new System.Windows.Forms.Label();
            this.gbCONN2 = new System.Windows.Forms.GroupBox();
            this.logTextBox2 = new System.Windows.Forms.TextBox();
            this.sStatusLabelError2 = new System.Windows.Forms.Label();
            this.sStatusLabelOK2 = new System.Windows.Forms.Label();
            this.addConnButton = new System.Windows.Forms.Button();
            this.redBar = new ZWave.Programmer.Controls.GradientWaitingBar();
            this.gbCONN1.SuspendLayout();
            this.gridPanel.SuspendLayout();
            this.gbCONN6.SuspendLayout();
            this.gbCONN3.SuspendLayout();
            this.gbCONN4.SuspendLayout();
            this.gbCONN5.SuspendLayout();
            this.gbCONN2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Hex File:";
            // 
            // programButton
            // 
            this.programButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.programButton.Location = new System.Drawing.Point(12, 80);
            this.programButton.Name = "programButton";
            this.programButton.Size = new System.Drawing.Size(128, 64);
            this.programButton.TabIndex = 2;
            this.programButton.Text = "Program";
            this.programButton.UseVisualStyleBackColor = true;
            this.programButton.Click += new System.EventHandler(this.programButton_Click);
            // 
            // logTextBox1
            // 
            this.logTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox1.Location = new System.Drawing.Point(3, 16);
            this.logTextBox1.Multiline = true;
            this.logTextBox1.Name = "logTextBox1";
            this.logTextBox1.ReadOnly = true;
            this.logTextBox1.Size = new System.Drawing.Size(311, 117);
            this.logTextBox1.TabIndex = 4;
            // 
            // fullPathLabel
            // 
            this.fullPathLabel.Location = new System.Drawing.Point(96, 43);
            this.fullPathLabel.Name = "fullPathLabel";
            this.fullPathLabel.Size = new System.Drawing.Size(886, 34);
            this.fullPathLabel.TabIndex = 6;
            this.fullPathLabel.Text = "C:\\";
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(854, 611);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(128, 48);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // greenBar
            // 
            this.greenBar.BackColor = System.Drawing.Color.White;
            this.greenBar.GradientColor1 = System.Drawing.Color.LimeGreen;
            this.greenBar.GradientColor2 = System.Drawing.Color.Lime;
            this.greenBar.Location = new System.Drawing.Point(146, 80);
            this.greenBar.Name = "greenBar";
            this.greenBar.ScrollWAY = ZWave.Programmer.Controls.GradientBar.SCROLLGRADIENTALIGN.HORIZONTAL;
            this.greenBar.Size = new System.Drawing.Size(64, 64);
            this.greenBar.Speed = 5;
            this.greenBar.TabIndex = 8;
            this.greenBar.Text = "gradientBar1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Directory:";
            // 
            // hexFileLabel
            // 
            this.hexFileLabel.Location = new System.Drawing.Point(96, 9);
            this.hexFileLabel.Name = "hexFileLabel";
            this.hexFileLabel.Size = new System.Drawing.Size(886, 34);
            this.hexFileLabel.TabIndex = 11;
            this.hexFileLabel.Text = "*.hex";
            // 
            // statusLabel
            // 
            this.statusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusLabel.Location = new System.Drawing.Point(216, 80);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(632, 64);
            this.statusLabel.TabIndex = 13;
            this.statusLabel.Text = "COM1";
            // 
            // sStatusLabelOK1
            // 
            this.sStatusLabelOK1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK1.Location = new System.Drawing.Point(3, 174);
            this.sStatusLabelOK1.Name = "sStatusLabelOK1";
            this.sStatusLabelOK1.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelOK1.TabIndex = 15;
            this.sStatusLabelOK1.Text = "COM1";
            this.sStatusLabelOK1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelError1
            // 
            this.sStatusLabelError1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError1.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError1.Location = new System.Drawing.Point(3, 133);
            this.sStatusLabelError1.Name = "sStatusLabelError1";
            this.sStatusLabelError1.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelError1.TabIndex = 16;
            this.sStatusLabelError1.Text = "COM1";
            this.sStatusLabelError1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // gbCONN1
            // 
            this.gbCONN1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN1.Controls.Add(this.logTextBox1);
            this.gbCONN1.Controls.Add(this.sStatusLabelError1);
            this.gbCONN1.Controls.Add(this.sStatusLabelOK1);
            this.gbCONN1.Location = new System.Drawing.Point(3, 3);
            this.gbCONN1.Name = "gbCONN1";
            this.gbCONN1.Size = new System.Drawing.Size(317, 218);
            this.gbCONN1.TabIndex = 0;
            this.gbCONN1.TabStop = false;
            this.gbCONN1.Text = "COM1";
            // 
            // gridPanel
            // 
            this.gridPanel.ColumnCount = 3;
            this.gridPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.gridPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.gridPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.gridPanel.Controls.Add(this.gbCONN6, 2, 1);
            this.gridPanel.Controls.Add(this.gbCONN3, 2, 0);
            this.gridPanel.Controls.Add(this.gbCONN4, 0, 1);
            this.gridPanel.Controls.Add(this.gbCONN5, 1, 1);
            this.gridPanel.Controls.Add(this.gbCONN2, 1, 0);
            this.gridPanel.Controls.Add(this.gbCONN1, 0, 0);
            this.gridPanel.Location = new System.Drawing.Point(12, 150);
            this.gridPanel.Name = "gridPanel";
            this.gridPanel.RowCount = 2;
            this.gridPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.gridPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.gridPanel.Size = new System.Drawing.Size(970, 449);
            this.gridPanel.TabIndex = 14;
            // 
            // gbCONN6
            // 
            this.gbCONN6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN6.Controls.Add(this.logTextBox6);
            this.gbCONN6.Controls.Add(this.sStatusLabelError6);
            this.gbCONN6.Controls.Add(this.sStatusLabelOK6);
            this.gbCONN6.Location = new System.Drawing.Point(649, 227);
            this.gbCONN6.Name = "gbCONN6";
            this.gbCONN6.Size = new System.Drawing.Size(318, 219);
            this.gbCONN6.TabIndex = 17;
            this.gbCONN6.TabStop = false;
            this.gbCONN6.Text = "COM1";
            // 
            // logTextBox6
            // 
            this.logTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox6.Location = new System.Drawing.Point(3, 16);
            this.logTextBox6.Multiline = true;
            this.logTextBox6.Name = "logTextBox6";
            this.logTextBox6.ReadOnly = true;
            this.logTextBox6.Size = new System.Drawing.Size(312, 118);
            this.logTextBox6.TabIndex = 4;
            // 
            // sStatusLabelError6
            // 
            this.sStatusLabelError6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError6.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError6.Location = new System.Drawing.Point(3, 134);
            this.sStatusLabelError6.Name = "sStatusLabelError6";
            this.sStatusLabelError6.Size = new System.Drawing.Size(312, 41);
            this.sStatusLabelError6.TabIndex = 16;
            this.sStatusLabelError6.Text = "COM1";
            this.sStatusLabelError6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelOK6
            // 
            this.sStatusLabelOK6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK6.Location = new System.Drawing.Point(3, 175);
            this.sStatusLabelOK6.Name = "sStatusLabelOK6";
            this.sStatusLabelOK6.Size = new System.Drawing.Size(312, 41);
            this.sStatusLabelOK6.TabIndex = 15;
            this.sStatusLabelOK6.Text = "COM1";
            this.sStatusLabelOK6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // gbCONN3
            // 
            this.gbCONN3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN3.Controls.Add(this.logTextBox3);
            this.gbCONN3.Controls.Add(this.sStatusLabelError3);
            this.gbCONN3.Controls.Add(this.sStatusLabelOK3);
            this.gbCONN3.Location = new System.Drawing.Point(649, 3);
            this.gbCONN3.Name = "gbCONN3";
            this.gbCONN3.Size = new System.Drawing.Size(318, 218);
            this.gbCONN3.TabIndex = 17;
            this.gbCONN3.TabStop = false;
            this.gbCONN3.Text = "COM1";
            // 
            // logTextBox3
            // 
            this.logTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox3.Location = new System.Drawing.Point(3, 16);
            this.logTextBox3.Multiline = true;
            this.logTextBox3.Name = "logTextBox3";
            this.logTextBox3.ReadOnly = true;
            this.logTextBox3.Size = new System.Drawing.Size(312, 117);
            this.logTextBox3.TabIndex = 4;
            // 
            // sStatusLabelError3
            // 
            this.sStatusLabelError3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError3.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError3.Location = new System.Drawing.Point(3, 133);
            this.sStatusLabelError3.Name = "sStatusLabelError3";
            this.sStatusLabelError3.Size = new System.Drawing.Size(312, 41);
            this.sStatusLabelError3.TabIndex = 16;
            this.sStatusLabelError3.Text = "COM1";
            this.sStatusLabelError3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelOK3
            // 
            this.sStatusLabelOK3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK3.Location = new System.Drawing.Point(3, 174);
            this.sStatusLabelOK3.Name = "sStatusLabelOK3";
            this.sStatusLabelOK3.Size = new System.Drawing.Size(312, 41);
            this.sStatusLabelOK3.TabIndex = 15;
            this.sStatusLabelOK3.Text = "COM1";
            this.sStatusLabelOK3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // gbCONN4
            // 
            this.gbCONN4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN4.Controls.Add(this.logTextBox4);
            this.gbCONN4.Controls.Add(this.sStatusLabelError4);
            this.gbCONN4.Controls.Add(this.sStatusLabelOK4);
            this.gbCONN4.Location = new System.Drawing.Point(3, 227);
            this.gbCONN4.Name = "gbCONN4";
            this.gbCONN4.Size = new System.Drawing.Size(317, 219);
            this.gbCONN4.TabIndex = 3;
            this.gbCONN4.TabStop = false;
            this.gbCONN4.Text = "COM1";
            // 
            // logTextBox4
            // 
            this.logTextBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox4.Location = new System.Drawing.Point(3, 16);
            this.logTextBox4.Multiline = true;
            this.logTextBox4.Name = "logTextBox4";
            this.logTextBox4.ReadOnly = true;
            this.logTextBox4.Size = new System.Drawing.Size(311, 118);
            this.logTextBox4.TabIndex = 4;
            // 
            // sStatusLabelError4
            // 
            this.sStatusLabelError4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError4.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError4.Location = new System.Drawing.Point(3, 134);
            this.sStatusLabelError4.Name = "sStatusLabelError4";
            this.sStatusLabelError4.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelError4.TabIndex = 16;
            this.sStatusLabelError4.Text = "COM1";
            this.sStatusLabelError4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelOK4
            // 
            this.sStatusLabelOK4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK4.Location = new System.Drawing.Point(3, 175);
            this.sStatusLabelOK4.Name = "sStatusLabelOK4";
            this.sStatusLabelOK4.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelOK4.TabIndex = 15;
            this.sStatusLabelOK4.Text = "COM1";
            this.sStatusLabelOK4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // gbCONN5
            // 
            this.gbCONN5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN5.Controls.Add(this.logTextBox5);
            this.gbCONN5.Controls.Add(this.sStatusLabelError5);
            this.gbCONN5.Controls.Add(this.sStatusLabelOK5);
            this.gbCONN5.Location = new System.Drawing.Point(326, 227);
            this.gbCONN5.Name = "gbCONN5";
            this.gbCONN5.Size = new System.Drawing.Size(317, 219);
            this.gbCONN5.TabIndex = 2;
            this.gbCONN5.TabStop = false;
            this.gbCONN5.Text = "COM1";
            // 
            // logTextBox5
            // 
            this.logTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox5.Location = new System.Drawing.Point(3, 16);
            this.logTextBox5.Multiline = true;
            this.logTextBox5.Name = "logTextBox5";
            this.logTextBox5.ReadOnly = true;
            this.logTextBox5.Size = new System.Drawing.Size(311, 118);
            this.logTextBox5.TabIndex = 4;
            // 
            // sStatusLabelError5
            // 
            this.sStatusLabelError5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError5.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError5.Location = new System.Drawing.Point(3, 134);
            this.sStatusLabelError5.Name = "sStatusLabelError5";
            this.sStatusLabelError5.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelError5.TabIndex = 16;
            this.sStatusLabelError5.Text = "COM1";
            this.sStatusLabelError5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelOK5
            // 
            this.sStatusLabelOK5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK5.Location = new System.Drawing.Point(3, 175);
            this.sStatusLabelOK5.Name = "sStatusLabelOK5";
            this.sStatusLabelOK5.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelOK5.TabIndex = 15;
            this.sStatusLabelOK5.Text = "COM1";
            this.sStatusLabelOK5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // gbCONN2
            // 
            this.gbCONN2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCONN2.Controls.Add(this.logTextBox2);
            this.gbCONN2.Controls.Add(this.sStatusLabelError2);
            this.gbCONN2.Controls.Add(this.sStatusLabelOK2);
            this.gbCONN2.Location = new System.Drawing.Point(326, 3);
            this.gbCONN2.Name = "gbCONN2";
            this.gbCONN2.Size = new System.Drawing.Size(317, 218);
            this.gbCONN2.TabIndex = 1;
            this.gbCONN2.TabStop = false;
            this.gbCONN2.Text = "COM1";
            // 
            // logTextBox2
            // 
            this.logTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox2.Location = new System.Drawing.Point(3, 16);
            this.logTextBox2.Multiline = true;
            this.logTextBox2.Name = "logTextBox2";
            this.logTextBox2.ReadOnly = true;
            this.logTextBox2.Size = new System.Drawing.Size(311, 117);
            this.logTextBox2.TabIndex = 4;
            // 
            // sStatusLabelError2
            // 
            this.sStatusLabelError2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelError2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelError2.ForeColor = System.Drawing.Color.Red;
            this.sStatusLabelError2.Location = new System.Drawing.Point(3, 133);
            this.sStatusLabelError2.Name = "sStatusLabelError2";
            this.sStatusLabelError2.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelError2.TabIndex = 16;
            this.sStatusLabelError2.Text = "COM1";
            this.sStatusLabelError2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // sStatusLabelOK2
            // 
            this.sStatusLabelOK2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.sStatusLabelOK2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sStatusLabelOK2.Location = new System.Drawing.Point(3, 174);
            this.sStatusLabelOK2.Name = "sStatusLabelOK2";
            this.sStatusLabelOK2.Size = new System.Drawing.Size(311, 41);
            this.sStatusLabelOK2.TabIndex = 15;
            this.sStatusLabelOK2.Text = "COM1";
            this.sStatusLabelOK2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // addConnButton
            // 
            this.addConnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addConnButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.addConnButton.Location = new System.Drawing.Point(854, 80);
            this.addConnButton.Name = "addConnButton";
            this.addConnButton.Size = new System.Drawing.Size(128, 64);
            this.addConnButton.TabIndex = 15;
            this.addConnButton.Text = "Add Port";
            this.addConnButton.UseVisualStyleBackColor = true;
            this.addConnButton.Click += new System.EventHandler(this.addConnButton_Click);
            // 
            // redBar
            // 
            this.redBar.BackColor = System.Drawing.Color.White;
            this.redBar.GradientColor1 = System.Drawing.Color.Maroon;
            this.redBar.GradientColor2 = System.Drawing.Color.Red;
            this.redBar.Interval = 40;
            this.redBar.Location = new System.Drawing.Point(146, 80);
            this.redBar.Name = "redBar";
            this.redBar.ScrollWAY = ZWave.Programmer.Controls.ScrollGradientAlignTypes.VERTICAL;
            this.redBar.Size = new System.Drawing.Size(64, 64);
            this.redBar.Speed = 5;
            this.redBar.TabIndex = 12;
            this.redBar.Text = "gradientWaitingBar1";
            // 
            // ProductionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(994, 671);
            this.ControlBox = false;
            this.Controls.Add(this.addConnButton);
            this.Controls.Add(this.gridPanel);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.redBar);
            this.Controls.Add(this.hexFileLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.greenBar);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.fullPathLabel);
            this.Controls.Add(this.programButton);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductionForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Production";
            this.gbCONN1.ResumeLayout(false);
            this.gbCONN1.PerformLayout();
            this.gridPanel.ResumeLayout(false);
            this.gbCONN6.ResumeLayout(false);
            this.gbCONN6.PerformLayout();
            this.gbCONN3.ResumeLayout(false);
            this.gbCONN3.PerformLayout();
            this.gbCONN4.ResumeLayout(false);
            this.gbCONN4.PerformLayout();
            this.gbCONN5.ResumeLayout(false);
            this.gbCONN5.PerformLayout();
            this.gbCONN2.ResumeLayout(false);
            this.gbCONN2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button programButton;
        private System.Windows.Forms.Button exitButton;
        private ZWave.Programmer.Controls.GradientBar greenBar;
        public System.Windows.Forms.Label fullPathLabel;
        public System.Windows.Forms.TextBox logTextBox1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label hexFileLabel;
        private ZWave.Programmer.Controls.GradientWaitingBar redBar;
        public System.Windows.Forms.Label statusLabel;
        public System.Windows.Forms.Label sStatusLabelOK1;
        public System.Windows.Forms.Label sStatusLabelError1;
        private System.Windows.Forms.GroupBox gbCONN1;
        private System.Windows.Forms.TableLayoutPanel gridPanel;
        private System.Windows.Forms.GroupBox gbCONN2;
        public System.Windows.Forms.TextBox logTextBox2;
        public System.Windows.Forms.Label sStatusLabelError2;
        public System.Windows.Forms.Label sStatusLabelOK2;
        private System.Windows.Forms.GroupBox gbCONN4;
        public System.Windows.Forms.TextBox logTextBox4;
        public System.Windows.Forms.Label sStatusLabelError4;
        public System.Windows.Forms.Label sStatusLabelOK4;
        private System.Windows.Forms.GroupBox gbCONN5;
        public System.Windows.Forms.TextBox logTextBox5;
        public System.Windows.Forms.Label sStatusLabelError5;
        public System.Windows.Forms.Label sStatusLabelOK5;
        private System.Windows.Forms.GroupBox gbCONN6;
        public System.Windows.Forms.TextBox logTextBox6;
        public System.Windows.Forms.Label sStatusLabelError6;
        public System.Windows.Forms.Label sStatusLabelOK6;
        private System.Windows.Forms.GroupBox gbCONN3;
        public System.Windows.Forms.TextBox logTextBox3;
        public System.Windows.Forms.Label sStatusLabelError3;
        public System.Windows.Forms.Label sStatusLabelOK3;
        private System.Windows.Forms.Button addConnButton;

    }
}