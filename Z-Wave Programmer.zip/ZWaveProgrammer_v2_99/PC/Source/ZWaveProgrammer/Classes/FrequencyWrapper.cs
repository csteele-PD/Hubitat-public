using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Programmer.Classes
{
    public class FrequencyWrapper
    {
        public FrequencyWrapper()
        {
        }
        
        public FrequencyWrapper(string name, byte frequency)
        {
            this.Name = name;
            this.Frequency = frequency;
        }

        private string mName;
        public string Name
        {
            get { return mName; }
            set { mName = value; }
        }

        private byte mFrequency;
        public byte Frequency
        {
            get { return mFrequency; }
            set { mFrequency = value; }
        }
        
        public override string ToString()
        {
            return this.Name;
        }
    }
}
