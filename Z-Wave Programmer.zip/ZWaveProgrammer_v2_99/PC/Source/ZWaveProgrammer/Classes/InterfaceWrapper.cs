using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Framework;

namespace ZWave.Programmer.Classes
{
    internal class InterfaceWrapper
    {

        public InterfaceWrapper(Win32PnPEntityClass portInfo)
        {
            mPortInfo = portInfo;
        }
        private Win32PnPEntityClass mPortInfo;
        public Win32PnPEntityClass PortInfo
        {
            get { return mPortInfo; }
            set { mPortInfo = value; }
        }

        public override string ToString()
        {
            return String.Format("{0}:", PortInfo.Caption);
        }
    }
}
