using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Framework;
using System.IO.Ports;
using System.Threading;
using ZWave.Enums;
using ZWave.Events;
using ZWave.Devices;
using ZWave.SerialPortApplication.Devices;
using ZWave.Programmer.Controllers;
using System.Runtime.InteropServices;
using System.IO;
using Microsoft.Win32.SafeHandles;

namespace ZWave.Programmer.Classes
{
    public class AutoProgDevice : IProgrammableDevice, IDisposable
    {
        public int DEFAULT_TIMEOUT = 5000;
        public int READ_LOCKBITS_TIMEOUT = 1000;


        const byte FUNC_ID_AUTO_PROGRAMMING = 0x27;

        const int FLASH_PAGES_COUNT = 64;
        const int FLASH_PAGE_SIZE = 2048;
        const int FLASH_SIZE = 131072;

        const int SRAM_PAGES_COUNT = 2;
        const int SRAM_PAGE_SIZE = 2048;
        const int SRAM_SIZE = 4096;


        //Enable Interface
        const byte PROG_EN_0_BYTE = 0xAC;
        const byte PROG_EN_1_BYTE = 0x53;
        const byte PROG_EN_2_BYTE = 0xAA;
        const byte PROG_EN_3_BYTE = 0x55;

        //Read Signature
        const byte READ_SIG_FLASH_0_BYTE = 0x30;
        const byte READ_SIG_FLASH_2_BYTE = 0xFF;
        const byte READ_SIG_FLASH_3_BYTE = 0xFF;
        const int NO_OF_SIGNATURE = 7;

        //Read Flash
        const byte READ_FLASH_MEM_0_BYTE = 0x10;
        const byte READ_FLASH_MEM_2_BYTE = 0xFF;
        const byte READ_FLASH_MEM_3_BYTE = 0xFF;

        const int TRIADES_COUNT = 683;
        const byte CONT_READ_MEM_0_BYTE = 0xA0;
        const byte CONT_READ_MEM_1_BYTE = 0x00;
        const byte CONT_READ_MEM_2_BYTE = 0x00;
        const byte CONT_READ_MEM_3_BYTE = 0x00;

        //Erase Chip
        const byte ERASE_CHIP_0_BYTE = 0x0A;
        const byte ERASE_CHIP_1_BYTE = 0x00;
        const byte ERASE_CHIP_2_BYTE = 0x00;
        const byte ERASE_CHIP_3_BYTE = 0x00;

        const byte SECTOR_ERASE_ZW050X = 0x0B;

        //Check State
        const byte CHK_STATE_0_BYTE = 0x7F;
        const byte CHK_STATE_1_BYTE = 0xFE;
        const byte CHK_STATE_2_BYTE = 0x00;
        const byte CHK_STATE_3_BYTE = 0x00;

        //Run CRC Check
        const byte RUN_CRC_CHK_0_BYTE = 0xC3;
        const byte RUN_CRC_CHK_1_BYTE = 0x00;
        const byte RUN_CRC_CHK_2_BYTE = 0x00;
        const byte RUN_CRC_CHK_3_BYTE = 0x00;

        //Write SRAM
        const byte WRITE_SRAM_1_BYTE = 0x04;
        const byte WRITE_SRAM_4_BYTE = 0x00;

        const byte CONTINUE_WRITE_1_BYTE = 0x80;
        const byte CONTINUE_WRITE_2_BYTE = 0x00;
        const byte CONTINUE_WRITE_3_BYTE = 0x00;
        const byte CONTINUE_WRITE_4_BYTE = 0x00;

        const byte WRITE_FLASH_ZW050X = 0x20;

        //Read Lock Bits 
        const byte FLASH_READ_LOCK_1_BYTE = 0xF1;
        const byte FLASH_READ_LOCK_3_BYTE = 0xFF;
        const byte FLASH_READ_LOCK_4_BYTE = 0xFF;

        //Write Lock Bits. 
        const byte FLASH_WRITE_LOCK_1_BYTE = 0xF0;
        const byte FLASH_WRITE_LOCK_3_BYTE = 0xFF;


        //Read SRAM
        const byte READ_SRAM_1_BYTE = 0x06;
        const byte READ_SRAM_4_BYTE = 0xFF;
        //Enable EooS
        const byte ENABLE_EOOS_MODE_1_BYTE = 0xC0;
        const byte ENABLE_EOOS_MODE_2_BYTE = 0x00;
        const byte ENABLE_EOOS_MODE_3_BYTE = 0x00;
        const byte ENABLE_EOOS_MODE_4_BYTE = 0x00;

        //Enable EooS
        const byte DISABLE_EOOS_MODE_1_BYTE = 0xD0;
        const byte DISABLE_EOOS_MODE_2_BYTE = 0xFF;
        const byte DISABLE_EOOS_MODE_3_BYTE = 0xFF;
        const byte DISABLE_EOOS_MODE_4_BYTE = 0xFF;

        const byte NVR_SET_0_BYTE = 0xFE;
        const byte NVR_SET_1_BYTE = 0x00;

        const byte NVR_READ_0_BYTE = 0xF2;
        const byte NVR_READ_3_BYTE = 0xFF;

        const int MAX_UART_SYNCS = 6;

        public AutoProgDeviceTypes Type { get; set; }

        public event Events.ProgressChangedEventHandler FlashProgressChanged;

        SerialPort mPort;
        ControllerManager mControllerManager;
        private Win32PnPEntityClass mPortInfo;
        internal bool isInAutoProg = false;

        public string HardwareID
        {
            get
            {
                if (mPortInfo != null)
                {
                    return mPortInfo.HardwareID;
                }

                return "";
            }
        }

        public AutoProgDevice(Win32PnPEntityClass portInfo, ControllerManager controllerManager)
        {
            mControllerManager = controllerManager;
            mPortInfo = portInfo;
            Initialize(portInfo);
        }

        private void ReInitialize()
        {
            if (mPort.IsOpen)
                Close();
            Dispose();
            string deviceId = mPortInfo.DeviceID;
            for (int i = 0; i < 10; i++)
            {
                mPortInfo = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(deviceId);
                if (mPortInfo != null)
                    break;
                Thread.Sleep(1000);
            }
            mControllerManager.DocumentModel.PortInfo = mPortInfo;
            Initialize(mPortInfo);
        }

        private void Initialize(Win32PnPEntityClass portInfo)
        {
            Type = AutoProgDeviceTypes.UART;

            if (portInfo.Description.ToUpper().Contains("Sigma Designs ZWave programming interface".ToUpper()))
            {
                if (portInfo.HardwareID == "0001")
                    Type = AutoProgDeviceTypes.SD_USB_0001;
                else
                    Type = AutoProgDeviceTypes.SD_USB_0000;
                _packetSize = 1;
            }
            else
            {
                if (!portInfo.Name.Contains("Silicon"))
                {
                    if (portInfo.Description.ToUpper().Contains("UZB") || portInfo.Description.ToUpper().Contains("ZCOM")
                    || portInfo.Name.Contains("USB"))
                    {
                        if (portInfo.HardwareID == "0001")
                            Type = AutoProgDeviceTypes.UZB_0001;
                        else
                            Type = AutoProgDeviceTypes.UZB_0000;
                    }
                    _packetSize = 2;
                    if (!mControllerManager.SetProgMode)
                    {
                        if (mControllerManager.mIsRESET_NAvailable == true)
                        {
                            //setProgrammingModeResponseCount = 2;
                        }
                    }
                }
            }
            //Init SerialPort
            InitSerialPort(portInfo);
        }
        private int _packetSize = 30;
        public bool IsOpen
        {
            get
            {
                if (mPort != null)
                {
                    return mPort.IsOpen;
                }
                return false;
            }
        }

        private void InitSerialPort(Win32PnPEntityClass portInfo)
        {
            try
            {
                string deviceName = portInfo.DeviceID;
                if (!deviceName.StartsWith("COM"))
                {
                    deviceName = portInfo.Name.Substring(portInfo.Name.LastIndexOf("(COM")).Replace("(", string.Empty).Replace(")", string.Empty);
                }
                if (mPort == null)
                {
                    if (Type == AutoProgDeviceTypes.SD_USB_0000 || Type == AutoProgDeviceTypes.SD_USB_0001)
                    {
                        mPort = new SerialPort(deviceName, 115200, Parity.None, 8, StopBits.One);
                    }
                    else
                    {
                        mPort = new SerialPort(deviceName, 115200, Parity.None, 8, StopBits.Two);
                    }
                    Tools._writeDebugDiagnosticMessage("InitSerialPort4 " + deviceName);
                    mPort.Open();
                    mPort.ReadExisting();

                }
                else if (mPort.PortName != deviceName)
                {
                    Tools._writeDebugDiagnosticMessage("another port is already opened " + deviceName);
                    throw new Exception("another port is already opened");
                }
                else if (mPort.IsOpen)
                {
                    Tools._writeDebugDiagnosticMessage("port is already opened " + deviceName);
                    throw new Exception("port is already opened");
                }
                else if (!mPort.IsOpen)
                {
                    Tools._writeDebugDiagnosticMessage("InitSerialPort5 " + deviceName);
                    mPort.Open();
                    mPort.ReadExisting();
                }
                GC.SuppressFinalize(mPort.BaseStream);
            }
            catch (Exception ex)
            {
                throw ex;
                //mControllerManager.ShowMessage("Can't open device... " + ex.Message, true);
            }

        }

        private byte mChipType = (byte)ChipTypes.ZW050x;

        public byte ChipType
        {
            get { return mChipType; }
            set { mChipType = value; }
        }

        public int FlashSize
        {
            get { return FLASH_SIZE; }
        }

        public int SramSize
        {
            get { return SRAM_SIZE; }
        }

        public void ZWAutoProgrammingMode()
        {
            //01 03 00 27 DB 
            byte[] buffer = new byte[5];
            buffer[0] = 0x01;
            buffer[1] = 0x03;
            buffer[2] = 0;
            buffer[3] = FUNC_ID_AUTO_PROGRAMMING;

            byte calcChksum = 0xFF;
            calcChksum ^= 0x03;                          // Length
            calcChksum ^= 0x00;                          // Type
            calcChksum ^= FUNC_ID_AUTO_PROGRAMMING;      // Command

            buffer[4] = calcChksum;

            try
            {
                writeAndReadCommandUart(buffer, 1, 1000, false);
                int delayMs = 2000;
                while (
                    responseBuffer != null &&
                    (responseBuffer.Count > 0 || (responseBuffer.Count == 1 && responseBuffer[0] != 0x06)) &&
                    delayMs < 10000)
                {
                    Thread.Sleep(delayMs);
                    delayMs *= 2;
                    writeAndReadCommandUart(buffer, 1, 1000, false);
                }
            }
            catch (IOException ex)
            { }
        }

        public void ZWZnifferAutoProgrammingMode()
        {
            //if called after successful SerialApiSwitch exception will be thrown
            byte[] buffer = new byte[3] { 0x23, 0x12, 0x00 };
            try
            {
                writeAndReadCommandUart(buffer, 0);
                Thread.Sleep(100);
            }
            catch { }
        }

        public void SetBusyLedState(bool state)
        {
        }

        public bool SetProgrammingMode(bool enable)
        {
            bool result = false;
            if (enable)
            {
                mControllerManager.mIsRESET_NAvailable = false;
                if (Type == AutoProgDeviceTypes.UART)
                {
                    //TO#05400
                    /*
                    1. Set RESET_N low
                    2. send Enable Interface command
                    3. Send Read Sig command
                    4. Send Read State Command
                    5. If FSMBusy bit is set then set RESET_N high (SPI) 
                       or instruct user to releae RESET_N (UART) and got to step 2
                     */
                    mControllerManager.mIsRESET_NAvailable = true;
                    mControllerManager.AssertReset();
                    result = SetProgrammingModeLow();
                    //3
                    byte[] request = new byte[] { READ_SIG_FLASH_0_BYTE, 0, READ_SIG_FLASH_2_BYTE, READ_SIG_FLASH_3_BYTE };

                    writeAndReadCommandUart(request, 4);

                    if (responseBuffer != null && responseBuffer.Count == 4 &&
                        (responseBuffer[0] == READ_SIG_FLASH_0_BYTE && responseBuffer[1] == 0
                        && responseBuffer[2] == READ_SIG_FLASH_2_BYTE))
                    {
                        //???
                    }
                    //3
                    byte state = FlashCheckState();
                    if (state == 0x08)
                    {
                        mControllerManager.DeassertReset();
                        mControllerManager.mIsRESET_NAvailable = false;
                        result = SetProgrammingModeLow();
                    }
                    else
                    {
                        //???
                    }
                    //TO#05400
                }
                else if (Type == AutoProgDeviceTypes.SD_USB_0000)
                {
                    // in Sigma Programming Interface mode
                    result = SetProgrammingModeLow();
                    SyncDevice(false);
                }
                else if (Type == AutoProgDeviceTypes.SD_USB_0001)
                {
                    SyncDevice(false);
                    // in USBLoader mode
                    ZWAutoProgrammingMode();
                    try
                    {
                        ResetAndWait();

                    }
                    catch { }
                    ReInitialize();
                    result = SetProgrammingModeLow();
                    SyncDevice(false);
                }
                else if (Type == AutoProgDeviceTypes.UZB_0000 || Type == AutoProgDeviceTypes.UZB_0001)
                {
                    // in UZB mode
                }
                else
                {
                    try
                    {
                        ReadData(1, 100, false);
                        result = SetProgrammingModeLow();
                        Thread.Sleep(500);
                        if (result == false)
                        {
                            //int noOfSync = SyncDevice(false);
                            //if (noOfSync == MAX_UART_SYNCS)
                            {
                                mControllerManager.mIsRESET_NAvailable = true;
                            }
                        }
                        else
                        {
                            SyncDevice(false);
                            isInAutoProg = true;
                        }
                    }
                    catch (Exception)
                    {
                        result = SyncEnableProg();
                        if (!result)
                        {
                            mControllerManager.mIsRESET_NAvailable = true;
                        }
                        else
                        {
                            SyncDevice(false);
                            isInAutoProg = true;
                        }
                    }

                    if (mControllerManager.mIsRESET_NAvailable)
                    {
                        isInAutoProg = false;
                        mControllerManager.AssertReset();
                        mPort.DiscardInBuffer();
                        mPort.DiscardOutBuffer();
                        result = SetProgrammingModeLow();
                        if (result == false)
                        {
                            SyncDevice(false);
                        }
                    }
                }

            }
            else
            {
                if (isInAutoProg)
                {
                    if (!mPortInfo.Description.Contains("Sigma Designs ZWave programming interface"))
                    {
                        Reset();
                    }
                    Thread.Sleep(400);// Avoid Assert RESET_N message
                }
                mControllerManager.DeassertReset();
                result = true;
            }
            return result;
        }

        private bool SyncEnableProg()
        {
            bool result = false;
            int noOfSync = 0;
            while (noOfSync < 5)
            {
                try
                {
                    noOfSync++;
                    result = SetProgrammingModeLow();
                    if (result) break;
                }
                catch
                {
                    if (noOfSync < 4)
                    {
                        writeAndReadCommandUart(new byte[] { 0x00 }, 0);
                    }
                    noOfSync++;
                }
            }
            return result;
        }

        private bool SetProgrammingModeLow()
        {
            byte[] request = new byte[] { PROG_EN_0_BYTE, PROG_EN_1_BYTE, PROG_EN_2_BYTE, PROG_EN_3_BYTE };
            writeAndReadCommandUart(request, 2, 500, true);
            if (responseBuffer != null && responseBuffer.Count > 0)
            {
                if (responseBuffer.Count == 2)
                {
                    if (responseBuffer[0] == PROG_EN_0_BYTE && responseBuffer[1] == PROG_EN_1_BYTE)
                    {
                        ReadData(2, 1000);
                    }
                }

                for (int i = 0; i < 2; i++)
                {
                    if (responseBuffer.Count >= 2 &&
                        responseBuffer[responseBuffer.Count - 2] == PROG_EN_2_BYTE &&
                        responseBuffer[responseBuffer.Count - 1] == PROG_EN_3_BYTE)
                    {
                        mControllerManager.SetProgMode = true;
                        return true;
                    }
                    ReadData(2, 1000);
                }
            }
            return false;
        }

        public void ReadSignatureBits()
        {
            //Check device sync
            SyncDevice(false);

            List<byte> signature = new List<byte>();
            for (int i = 0; i < NO_OF_SIGNATURE; i++)
            {
                byte[] request = new byte[] { READ_SIG_FLASH_0_BYTE, (byte)i, READ_SIG_FLASH_2_BYTE, READ_SIG_FLASH_3_BYTE };

                writeAndReadCommandUart(request, 4);

                if (responseBuffer != null && responseBuffer.Count == 4 &&
                    (responseBuffer[0] == READ_SIG_FLASH_0_BYTE && responseBuffer[1] == (byte)i
                    && responseBuffer[2] == READ_SIG_FLASH_2_BYTE))
                {
                    signature.Add(responseBuffer[3]);
                }
            }
            if (signature.Count == NO_OF_SIGNATURE)
            {
                //Commented for testing
                if (signature[0] == 0x7f && signature[1] == 0x7f && signature[2] == 0x7f && signature[3] == 0x7f
                   && signature[4] == 0x1f && signature[5] == 0x04)
                {
                    this.ChipType = (byte)ChipTypes.ZW050x;
                }
            }
        }

        public int SyncDevice(bool waitForResponse)
        {
            int oldTimeout = DEFAULT_TIMEOUT;
            DEFAULT_TIMEOUT = 500;
            int noOfSync = 0;
            while (noOfSync < MAX_UART_SYNCS)
            {
                byte[] request = new byte[] { READ_SIG_FLASH_0_BYTE, 0, READ_SIG_FLASH_2_BYTE, READ_SIG_FLASH_3_BYTE };
                writeAndReadCommandUart(request, 4);
                if (responseBuffer != null && responseBuffer.Count >= 4)
                {
                    int len = responseBuffer.Count;
                    if (responseBuffer[len - 4] != READ_SIG_FLASH_0_BYTE ||
                        responseBuffer[len - 3] != 0 ||
                        responseBuffer[len - 2] != READ_SIG_FLASH_2_BYTE ||
                        responseBuffer[len - 1] != 0x7f)
                    {
                        if (waitForResponse)
                            writeAndReadCommandUart(new byte[] { 0x00 }, 1);
                        else
                            writeAndReadCommandUart(new byte[] { 0x00 }, 0);
                        noOfSync++;
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    noOfSync++;
                }
            }
            DEFAULT_TIMEOUT = oldTimeout;
            return noOfSync;
        }

        public byte ReadLockBit(int lockBitIndex)
        {
            byte[] request = new byte[] { FLASH_READ_LOCK_1_BYTE, (byte)lockBitIndex, FLASH_READ_LOCK_3_BYTE, FLASH_READ_LOCK_4_BYTE };
            writeAndReadCommandUart(request, 4, READ_LOCKBITS_TIMEOUT, true);
            if (responseBuffer != null && responseBuffer.Count == 4 &&
                responseBuffer[0] == FLASH_READ_LOCK_1_BYTE)
            {
                return responseBuffer[3];
            }
            return 0;
        }

        public bool WriteLockBit(int lockBitIndex, byte lockBitData)
        {
            byte[] request = new byte[] { FLASH_WRITE_LOCK_1_BYTE, (byte)lockBitIndex, FLASH_WRITE_LOCK_3_BYTE, lockBitData };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4 && responseBuffer[1] == (byte)lockBitIndex && responseBuffer[3] == lockBitData)
            {
                return true;
            }
            return false;
        }

        public byte[] ReadSRAM()
        {
            List<byte> result = new List<byte>();
            byte[] _request = new byte[] { READ_SRAM_1_BYTE, 0x00, 0x00, READ_SRAM_4_BYTE };
            writeAndReadCommandUart(_request, (int)_request.Length);
            if (responseBuffer != null && responseBuffer.Count == 4)
            {
                result.Add(responseBuffer[3]);
                for (int i = 0; i < (SRAM_SIZE - 1) / 3; i++)
                {
                    _request = new byte[] { CONT_READ_MEM_0_BYTE, CONT_READ_MEM_1_BYTE, CONT_READ_MEM_2_BYTE, CONT_READ_MEM_3_BYTE };
                    writeAndReadCommandUart(_request, (int)_request.Length);
                    if (responseBuffer != null && responseBuffer.Count == 4)
                    {
                        result.Add(responseBuffer[1]);
                        result.Add(responseBuffer[2]);
                        result.Add(responseBuffer[3]);
                    }
                }
            }
            Tools._writeDebugDiagnosticMessage("Stop", true, false);
            return result.ToArray();
        }

        public void Close()
        {
            if (mPort != null)
            {
                Tools._writeDebugDiagnosticMessage("" + mPort.PortName, true, true, 1);
                try
                {
                    mPort.ReadExisting();
                    GC.ReRegisterForFinalize(mPort.BaseStream);
                    mPort.Close();
                    mPort.Dispose();
                }
                catch (IOException)
                {
                }
                catch (Exception)
                {
                }
                mPort = null;
            }
        }

        public void FlashErase(bool isAsic)
        {
            byte[] request = new byte[] { ERASE_CHIP_0_BYTE, ERASE_CHIP_1_BYTE, ERASE_CHIP_2_BYTE, ERASE_CHIP_3_BYTE };
            byte[] response = new byte[] { ERASE_CHIP_0_BYTE, ERASE_CHIP_1_BYTE, ERASE_CHIP_2_BYTE, ERASE_CHIP_3_BYTE };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4 &&
                (responseBuffer[0] == ERASE_CHIP_0_BYTE &&
                responseBuffer[1] == ERASE_CHIP_1_BYTE &&
                responseBuffer[2] == ERASE_CHIP_2_BYTE &&
                responseBuffer[3] == ERASE_CHIP_3_BYTE))
            {
                Thread.Sleep(200);
                if (!FlashCheckStateRecursive(10, 1000))
                {
                    throw new Exception("Unable erase Flash");
                }
            }
            else
            {
                throw new Exception("Unable erase Flash");
            }
        }

        public byte[] FlashRead(bool isAsic)
        {
            Tools._writeDebugDiagnosticMessage("Start", true, false);
            List<byte> result = new List<byte>();
            for (int i = 0; i < FLASH_PAGES_COUNT; i++)
            {
                byte[] page = ReadPage(i);
                if (page != null)
                {
                    Tools._writeDebugDiagnosticMessage("Page:" + i.ToString() + " " + page.Length.ToString(), true, false);
                    result.AddRange(page);
                    if (FlashProgressChanged != null)
                    {
                        FlashProgressChanged(new ProgressChangedEventArgs(ProgressStatuses.Read, page.Length * (i + 1), this.FlashSize));
                    }
                }
            }
            Tools._writeDebugDiagnosticMessage("Stop", true, false);
            return result.ToArray();
        }

        public byte[] ReadPage(int pageIndex)
        {
            List<byte> result = new List<byte>();
            List<byte> _request = new List<byte>();
            _request.AddRange(new byte[] { READ_FLASH_MEM_0_BYTE, (byte)pageIndex, READ_FLASH_MEM_2_BYTE, READ_FLASH_MEM_3_BYTE });
            writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
            if (responseBuffer != null && responseBuffer.Count == 4)
            {
                result.Add(responseBuffer[3]);
                int numOfTriplets = ((FLASH_PAGE_SIZE - 1) / 3);
                int packetSize = this._packetSize;
                int packetCount = numOfTriplets / packetSize;
                for (int p = 0; p < packetCount; p++)
                {
                    _request.Clear();
                    for (int i = 0; i < packetSize; i++)
                    {
                        _request.AddRange(new byte[] { CONT_READ_MEM_0_BYTE, CONT_READ_MEM_1_BYTE, CONT_READ_MEM_2_BYTE, CONT_READ_MEM_3_BYTE });
                    }
                    writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
                    result.AddRange(getData(responseBuffer));
                }
                _request.Clear();
                for (int i = 0; i < (numOfTriplets % packetSize) + 1; i++)
                {
                    _request.AddRange(new byte[] { CONT_READ_MEM_0_BYTE, CONT_READ_MEM_1_BYTE, CONT_READ_MEM_2_BYTE, CONT_READ_MEM_3_BYTE });
                }
                writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
                result.AddRange(getData(responseBuffer));

            }
            if (result.Count > 0)
            {
                result.RemoveAt(result.Count - 1);
                result.RemoveAt(result.Count - 1);
            }
            if (mControllerManager.LogForm != null && !mControllerManager.LogForm.IsDisposed && mControllerManager.LogForm.Visible == true)
            {
                Thread.Sleep(300);
            }
            else
            {
                Thread.Sleep(50);
            }
            return result.ToArray();
        }

        private byte[] ReadSRAMPage(int pageIndex)
        {
            List<byte> result = new List<byte>();
            List<byte> _request = new List<byte>();
            _request.AddRange(new byte[] { READ_SRAM_1_BYTE, (byte)pageIndex, READ_FLASH_MEM_2_BYTE, READ_SRAM_4_BYTE });
            writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
            if (responseBuffer != null && responseBuffer.Count == 4)
            {
                result.Add(responseBuffer[3]);
                int numOfTriplets = ((SRAM_PAGE_SIZE - 1) / 3);
                int packetSize = this._packetSize;
                int packetCount = numOfTriplets / packetSize;
                for (int p = 0; p < packetCount; p++)
                {
                    _request.Clear();
                    for (int i = 0; i < packetSize; i++)
                    {
                        _request.AddRange(new byte[] { CONT_READ_MEM_0_BYTE, CONT_READ_MEM_1_BYTE, CONT_READ_MEM_2_BYTE, CONT_READ_MEM_3_BYTE });
                    }
                    writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
                    result.AddRange(getData(responseBuffer));
                }
                _request.Clear();
                for (int i = 0; i < (numOfTriplets % packetSize) + 1; i++)
                {
                    _request.AddRange(new byte[] { CONT_READ_MEM_0_BYTE, CONT_READ_MEM_1_BYTE, CONT_READ_MEM_2_BYTE, CONT_READ_MEM_3_BYTE });
                }
                writeAndReadCommandUart(_request.ToArray(), (int)_request.Count);
                result.AddRange(getData(responseBuffer));

            }
            result.RemoveAt(result.Count - 1);
            result.RemoveAt(result.Count - 1);
            return result.ToArray();
        }

        private List<byte> getData(List<byte> responseBuffer)
        {
            List<byte> result = new List<byte>();
            for (int i = 0; i < responseBuffer.Count; i++)
            {
                if (((i % 4) == 0) && responseBuffer[i] == CONT_READ_MEM_0_BYTE)
                {
                }
                else
                {
                    result.Add(responseBuffer[i]);
                }
            }
            return result;
        }

        private bool FlashCheckStateRecursive(int additionalAttempts, int timeoutMs)
        {
            bool ret = false;
            byte rr = FlashCheckState();
            Tools._writeDebugDiagnosticMessage("STATE: " + rr);

            if ((rr & 8) > 0)
            {
                if (additionalAttempts > 0)
                {
                    Tools._writeDebugDiagnosticMessage("STATE BUSY: " + rr + "attempts remaining: " + additionalAttempts);
                    Thread.Sleep(1000);
                    ret = FlashCheckStateRecursive(additionalAttempts - 1, timeoutMs);
                }
                else
                    ret = false;
            }
            else
                ret = true;
            return ret;
        }

        internal bool FlashWriteSectorData(byte[] dataRaw, int sectorNum)
        {
            WriteSRAMPage(dataRaw, sectorNum);
            if (!FlashCheckStateRecursive(10, 1000))
                return false;

            return true;
        }

        public bool FlashWrite(bool isAsic, byte[] flashDataRaw, ZWave.Devices.IFlashSettings flashSettings, bool verify)
        {
            return FlashWrite(isAsic, flashDataRaw, flashSettings, verify, 0, FLASH_PAGES_COUNT);
        }
        public bool FlashWriteSector0(byte[] flashDataRaw)
        {
            //get sector 0 data
            byte[] sector0Data = new byte[FLASH_PAGE_SIZE];
            Array.Copy(flashDataRaw, sector0Data, sector0Data.Length);

            //area 000 - 4FF

            byte[] firstSection = new byte[0x500];
            byte[] secondSection = new byte[0x800];
            for (int i = 0; i < firstSection.Length; i++)
            {
                firstSection[i] = Constants.BLANK_VALUE;
            }
            for (int i = 0; i < secondSection.Length; i++)
            {
                secondSection[i] = Constants.BLANK_VALUE;
            }
            Array.Copy(sector0Data, firstSection, firstSection.Length);
            Array.Copy(sector0Data, 0x508, secondSection, 0x508, secondSection.Length - 0x508);

            WriteSRAMPage(firstSection, 0);
            if (!FlashCheckStateRecursive(10, 1000))
            {
                return false;
            }

            WriteSRAMPage(secondSection, 0);
            if (!FlashCheckStateRecursive(10, 1000))
            {
                return false;
            }

            return true;
        }
        public bool FlashWrite(bool isAsic, byte[] flashDataRaw, ZWave.Devices.IFlashSettings flashSettings, bool verify, int startSector, int endSector)
        {
            Tools._writeDebugDiagnosticMessage("Start", true, false);

            List<byte[]> content = new List<byte[]>();
            for (int pageIndex = 0; pageIndex < FLASH_PAGES_COUNT; pageIndex++)
            {
                byte[] page = new byte[FLASH_PAGE_SIZE];
                for (int j = 0; j < FLASH_PAGE_SIZE; j++)
                {
                    page[j] = flashDataRaw[pageIndex * FLASH_PAGE_SIZE + j];
                }
                content.Add(page);
            }
            if (content.Count < endSector)
            {
                throw new ApplicationException("Invalid end sector number");
            }
            for (int i = startSector; i < content.Count; i++)
            {
                Tools._writeDebugDiagnosticMessage("writing page:" + i);
                if (isPageNotEmpty(content[i]))
                {
                    WriteSRAMPage(content[i], i);
                    if (!FlashCheckStateRecursive(10, 1000))
                        return false;
                    if (FlashProgressChanged != null)
                    {
                        FlashProgressChanged(new ProgressChangedEventArgs(ProgressStatuses.Write, content[i].Length * (i + 1), this.FlashSize));
                    }
                    /*Issue Write Flash Sector Command*/
                    //byte[] request = new byte[] { WRITE_FLASH_ZW050X, (byte)i, 0x00, 0x00 };
                    //writeAndReadCommandUart(request, 4);
                    //Thread.Sleep(100);
                }
            }
            Tools._writeDebugDiagnosticMessage("Stop", true, false);
            return true;
        }

        #region Test Firmware
        ////////        /*Test*/

        ////////        private byte HIBYTE(short p)
        ////////        {
        ////////            return (byte)(p >> 8);
        ////////        }
        ////////        private byte LOBYTE(short p)
        ////////        {
        ////////            return (byte)((p >> 0) & 0xFF);
        ////////        }
        ////////        short pageSize = 0;
        ////////        byte i;
        ////////        int startAddr = 0;
        ////////        int stopAddr = 0;
        ////////        int currentAddr = 0;
        ////////        byte numBytes = 0;
        ////////        byte[] bytes = new byte[2];
        ////////        const int PACKET_SIZE_ZW5XX = 1024;
        ////////        private byte    /*return true if data writen correctly else false*/
        ////////WritePage(
        ////////  byte chipType,
        ////////  byte pageNo, /*The page address*/
        ////////  byte verify,
        ////////  short startAd,
        ////////  short stopAd,
        ////////  short dataLength,
        ////////  byte[] data)/*Data to be ritten to page Addr*/
        ////////        {


        ////////            //if (chipType == ZW050x) //123 WritePage
        ////////            //{
        ////////            /*Write ZW050x flash*/
        ////////            byte wrPageNo = 0;
        ////////            if ((pageNo % 2) == 0)
        ////////            {
        ////////                // 1st half
        ////////                wrPageNo = pageNo;

        ////////                currentAddr = startAd;  // 1
        ////////                startAddr = startAd;
        ////////                stopAddr = stopAd;
        ////////                numBytes = 0;

        ////////                if (currentAddr > stopAddr)
        ////////                {
        ////////                    return 0x31;
        ////////                }

        ////////                if (currentAddr > (PACKET_SIZE_ZW5XX - 1))      // 2
        ////////                {
        ////////                    return 0x31;
        ////////                }
        ////////                else
        ////////                {
        ////////                    System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                        "!@!@!@!@!@!@!@!@!@!WRITE_SRAM_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                        HIBYTE((short)currentAddr).ToString("X2"),
        ////////                        LOBYTE((short)currentAddr).ToString("X2"),
        ////////                        data[currentAddr].ToString("X2")));
        ////////                    //SPI_Exchange(WRITE_SRAM_1_BYTE);        // 3
        ////////                    //SPI_Exchange(HIBYTE(currentAddr));
        ////////                    //SPI_Exchange(LOBYTE(currentAddr));
        ////////                    //SPI_Exchange(data[currentAddr]);
        ////////                    //DelayUS(WRITE_SRAM_DURATION_US);
        ////////                    currentAddr++;

        ////////                    for (; ; )                                 // 8
        ////////                    {
        ////////                        if ((currentAddr > stopAddr) || (currentAddr > (PACKET_SIZE_ZW5XX - 1))) //4 //  4
        ////////                            break;

        ////////                        if (numBytes > 1)                               // 6
        ////////                        {
        ////////                            System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!\tCONTINUE_WRITE_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                                bytes[0].ToString("X2"),
        ////////                                bytes[1].ToString("X2"),
        ////////                                data[currentAddr].ToString("X2")));
        ////////                            //SPI_Exchange(CONTINUE_WRITE_1_BYTE);         // 7
        ////////                            //SPI_Exchange(bytes[0]);
        ////////                            //SPI_Exchange(bytes[1]);
        ////////                            //SPI_Exchange(data[currentAddr]);
        ////////                            //DelayUS(CONTINUE_WRITE_DURATION_US);
        ////////                            numBytes = 0;
        ////////                        }
        ////////                        else
        ////////                        {
        ////////                            bytes[numBytes] = data[currentAddr];   // 5
        ////////                            numBytes++;
        ////////                        }
        ////////                        currentAddr++;
        ////////                    }                              // 8

        ////////                    if (stopAddr < PACKET_SIZE_ZW5XX)        // 9
        ////////                    {
        ////////                        System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_FLASH_ZW050X: 0x{0} 0x{1} 0x{2}",
        ////////                                ((byte)(pageNo >> 1)).ToString("X2"),
        ////////                                0.ToString("X2"),
        ////////                                0.ToString("X2")));
        ////////                        /*Issue Write Write Flash Sector Command*/
        ////////                        //SPI_Exchange(WRITE_FLASH_ZW050X);         // 10
        ////////                        //SPI_Exchange(pageNo >> 1);
        ////////                        //SPI_Exchange(0x00);
        ////////                        //SPI_Exchange(0x00);
        ////////                        //DelayUS(WRITE_FLASH_ZW050X_BYTE_DURATION_MAX_US * SECTOR_SIZE_ZW050x); 

        ////////                        for (i = 0; i < numBytes; i++)
        ////////                        {
        ////////                            System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_SRAM_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                                HIBYTE((short)currentAddr).ToString("X2"),
        ////////                                LOBYTE((short)currentAddr).ToString("X2"),
        ////////                                bytes[i].ToString("X2")));
        ////////                            //SPI_Exchange(WRITE_SRAM_1_BYTE);        
        ////////                            //SPI_Exchange(HIBYTE(currentAddr));
        ////////                            //SPI_Exchange(LOBYTE(currentAddr));
        ////////                            //SPI_Exchange(bytes[i]);
        ////////                            //DelayUS(WRITE_SRAM_DURATION_US);
        ////////                            currentAddr++;

        ////////                            System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_FLASH_ZW050X: 0x{0} 0x{1} 0x{2}",
        ////////                                ((byte)(pageNo >> 1)).ToString("X2"),
        ////////                                0.ToString("X2"),
        ////////                                0.ToString("X2")));
        ////////                            /*Issue Write Write Flash Sector Command*/
        ////////                            //SPI_Exchange(WRITE_FLASH_ZW050X);
        ////////                            //SPI_Exchange(pageNo >> 1);
        ////////                            //SPI_Exchange(0x00);
        ////////                            //SPI_Exchange(0x00);
        ////////                            //DelayUS(WRITE_FLASH_ZW050X_BYTE_DURATION_MAX_US * SECTOR_SIZE_ZW050x); 
        ////////                        }
        ////////                        numBytes = 0;
        ////////                    }
        ////////                    return 0x31;       // 11
        ////////                }
        ////////            }
        ////////            else
        ////////            {
        ////////                // 2nd half

        ////////                if ((wrPageNo + 1) != pageNo)
        ////////                {
        ////////                    return 0x31; //FAIL;//invalid page number sequence
        ////////                }
        ////////                if (stopAddr < PACKET_SIZE_ZW5XX)   // 1
        ////////                {
        ////////                    return 0x31; //nothing todo
        ////////                }

        ////////                currentAddr -= PACKET_SIZE_ZW5XX;
        ////////                stopAddr -= PACKET_SIZE_ZW5XX;

        ////////                if (startAddr > (PACKET_SIZE_ZW5XX - 1))      // 2
        ////////                {
        ////////                    System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_SRAM_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                                HIBYTE((short)(currentAddr + PACKET_SIZE_ZW5XX)).ToString("X2"),
        ////////                                LOBYTE((short)(currentAddr + PACKET_SIZE_ZW5XX)).ToString("X2"),
        ////////                                data[currentAddr].ToString("X2")));
        ////////                    //SPI_Exchange(WRITE_SRAM_1_BYTE);        // 3
        ////////                    //SPI_Exchange(HIBYTE(currentAddr + PACKET_SIZE_ZW5XX));
        ////////                    //SPI_Exchange(LOBYTE(currentAddr + PACKET_SIZE_ZW5XX));
        ////////                    //SPI_Exchange(data[currentAddr]);
        ////////                    //DelayUS(WRITE_SRAM_DURATION_US);
        ////////                    currentAddr++;
        ////////                }

        ////////                for (; ; )                                 // 4
        ////////                {
        ////////                    if (currentAddr > stopAddr)        // 5
        ////////                        break;

        ////////                    if (numBytes > 1)                               // 6
        ////////                    {
        ////////                        System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!\tCONTINUE_WRITE_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                                bytes[0].ToString("X2"),
        ////////                                bytes[1].ToString("X2"),
        ////////                                data[currentAddr].ToString("X2")));
        ////////                        //SPI_Exchange(CONTINUE_WRITE_1_BYTE);         // 7
        ////////                        //SPI_Exchange(bytes[0]);
        ////////                        //SPI_Exchange(bytes[1]);
        ////////                        //SPI_Exchange(data[currentAddr]);
        ////////                        //DelayUS(CONTINUE_WRITE_DURATION_US);
        ////////                        numBytes = 0;
        ////////                    }
        ////////                    else
        ////////                    {
        ////////                        bytes[numBytes] = data[currentAddr];   // 8
        ////////                        numBytes++;
        ////////                    }
        ////////                    currentAddr++;                           //9
        ////////                }                                       // 4

        ////////                System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                        "!@!@!@!@!@!@!@!@!@!WRITE_FLASH_ZW050X: 0x{0} 0x{1} 0x{2}",
        ////////                        ((byte)(pageNo >> 1)).ToString("X2"),
        ////////                        0.ToString("X2"),
        ////////                        0.ToString("X2")));
        ////////                /*Issue Write Write Flash Sector Command*/
        ////////                //SPI_Exchange(WRITE_FLASH_ZW050X);         // 10
        ////////                //SPI_Exchange(pageNo >> 1);
        ////////                //SPI_Exchange(0x00);
        ////////                //SPI_Exchange(0x00);
        ////////                //DelayUS(WRITE_FLASH_ZW050X_BYTE_DURATION_MAX_US * SECTOR_SIZE_ZW050x);

        ////////                for (i = 0; i < numBytes; i++)
        ////////                {
        ////////                    System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_SRAM_1_BYTE: 0x{0} 0x{1} 0x{2}",
        ////////                                HIBYTE((short)(currentAddr + PACKET_SIZE_ZW5XX)).ToString("X2"),
        ////////                                LOBYTE((short)(currentAddr + PACKET_SIZE_ZW5XX)).ToString("X2"),
        ////////                                bytes[i].ToString("X2")));
        ////////                    //SPI_Exchange(WRITE_SRAM_1_BYTE);
        ////////                    //SPI_Exchange(HIBYTE(currentAddr + PACKET_SIZE_ZW5XX));
        ////////                    //SPI_Exchange(LOBYTE(currentAddr + PACKET_SIZE_ZW5XX));
        ////////                    //SPI_Exchange(bytes[i]);
        ////////                    //DelayUS(WRITE_SRAM_DURATION_US);
        ////////                    currentAddr++;

        ////////                    System.Diagnostics.Debug.WriteLine(String.Format(
        ////////                                "!@!@!@!@!@!@!@!@!@!WRITE_FLASH_ZW050X: 0x{0} 0x{1} 0x{2}",
        ////////                                ((byte)(pageNo >> 1)).ToString("X2"),
        ////////                                0.ToString("X2"),
        ////////                                0.ToString("X2")));
        ////////                    /*Issue Write Write Flash Sector Command*/
        ////////                    //SPI_Exchange(WRITE_FLASH_ZW050X);
        ////////                    //SPI_Exchange(pageNo >> 1);
        ////////                    //SPI_Exchange(0x00);
        ////////                    //SPI_Exchange(0x00);
        ////////                    //DelayUS(WRITE_FLASH_ZW050X_BYTE_DURATION_MAX_US * SECTOR_SIZE_ZW050x);
        ////////                }
        ////////                numBytes = 0;
        ////////                return 0x31;
        ////////            }
        ////////            //}


        ////////        }
        ////////        /*Test*/
        #endregion

        private void WriteSRAMPage(byte[] page, int sectorNumber)
        {
            //find first address
            short firstAddress = -1;
            short lastAddress = -1;
            short idx = 0;
            byte[] request = null;
            for (int i = 0; i < page.Length; i++)
            {
                if (page[i] != Constants.BLANK_VALUE)
                {
                    firstAddress = (short)i;
                    break;
                }
            }
            //find last address
            for (int i = page.Length - 1; i >= 0; i--)
            {
                if (page[i] != Constants.BLANK_VALUE)
                {
                    lastAddress = (short)i;
                    break;
                }
            }

            idx = firstAddress;
            byte addr1 = 0;
            byte addr2 = 0;
            if (lastAddress == -1 || firstAddress == -1)
            {
                return;
            }
            //issue Write SRAM command
            addr1 = (byte)(firstAddress >> 8);
            addr2 = (byte)(firstAddress);
            request = new byte[] { WRITE_SRAM_1_BYTE, addr1, addr2, page[idx++] };
            writeAndReadCommandUart(request, 4);

            int dataLength = lastAddress - firstAddress;
            int numberOfTriplets = (dataLength) / 3;


            //issue Continue Write SRAM command

            ////////
            int packetSize = this._packetSize;
            int packetCount = numberOfTriplets / packetSize;
            List<byte> _request = new List<byte>();
            if (packetCount == 0 && numberOfTriplets < packetSize)
            {
                for (int i = 0; i < numberOfTriplets; i++)
                {
                    _request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                            page[idx++],
                                            page[idx++],
                                            page[idx++]});

                }
                writeAndReadCommandUart(_request.ToArray(), _request.Count);
            }
            else
            {
                for (int p = 0; p < packetCount; p++)
                {
                    _request.Clear();
                    for (int i = 0; i < packetSize; i++)
                    {
                        _request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                            page[idx++],
                                            page[idx++],
                                            page[idx++]});
                    }
                    writeAndReadCommandUart(_request.ToArray(), _request.Count);
                    //Thread.Sleep(500);
                }
                _request.Clear();
                for (int i = 0; i < (numberOfTriplets % packetSize); i++)
                {
                    _request.Add(CONTINUE_WRITE_1_BYTE);

                    if (idx < page.Length)
                    {
                        _request.Add(page[idx++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                    if (idx < page.Length)
                    {
                        _request.Add(page[idx++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                    if (idx < page.Length)
                    {
                        _request.Add(page[idx++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                }
                if (_request.Count > 0)
                {
                    writeAndReadCommandUart(_request.ToArray(), _request.Count);
                }

            }



            ////////

            /*Issue Write Flash Sector Command*/
            request = new byte[] { WRITE_FLASH_ZW050X, (byte)sectorNumber, 0xFF, 0xFF };
            writeAndReadCommandUart(request, 4, false); // write flash sector command response in rare cases misses leading byte(s)
            Thread.Sleep(100);
            FlashCheckStateRecursive(10, 1000);

            int remainingBytesCount = dataLength - (numberOfTriplets * 3);

            if (remainingBytesCount == 1)
            {
                //issue Write SRAM command
                addr1 = (byte)(lastAddress >> 8);
                addr2 = (byte)(lastAddress);
                request = new byte[] { WRITE_SRAM_1_BYTE, addr1, addr2, page[lastAddress] };
                writeAndReadCommandUart(request, 4);

                /*Issue Write Flash Sector Command*/
                request = new byte[] { WRITE_FLASH_ZW050X, (byte)sectorNumber, 0xFF, 0xFF };
                writeAndReadCommandUart(request, 4, false); // write flash sector command response in rare cases misses leading byte(s)
                Thread.Sleep(100);
                FlashCheckStateRecursive(10, 1000);

            }
            else if (remainingBytesCount == 2)
            {
                if (page[lastAddress - 1] != 0xFF) // TO# 04654
                {
                    //issue Write SRAM command
                    addr1 = (byte)((lastAddress - 1) >> 8);
                    addr2 = (byte)((lastAddress - 1));
                    request = new byte[] { WRITE_SRAM_1_BYTE, addr1, addr2, page[lastAddress - 1] };
                    writeAndReadCommandUart(request, 4);
                }

                /*Issue Write Flash Sector Command*/
                request = new byte[] { WRITE_FLASH_ZW050X, (byte)sectorNumber, 0xFF, 0xFF };
                writeAndReadCommandUart(request, 4, false); // write flash sector command response in rare cases misses leading byte(s)
                Thread.Sleep(100);
                FlashCheckStateRecursive(10, 1000);


                //issue Write SRAM command
                addr1 = (byte)(lastAddress >> 8);
                addr2 = (byte)(lastAddress);
                request = new byte[] { WRITE_SRAM_1_BYTE, addr1, addr2, page[lastAddress] };
                writeAndReadCommandUart(request, 4);

                /*Issue Write Flash Sector Command*/
                request = new byte[] { WRITE_FLASH_ZW050X, (byte)sectorNumber, 0xFF, 0xFF };
                writeAndReadCommandUart(request, 4, false); // write flash sector command response in rare cases misses leading byte(s)
                Thread.Sleep(100);
                FlashCheckStateRecursive(10, 1000);
            }
        }

        public bool WriteSRAM(byte[] flashDataRaw, bool p)
        {
            if (flashDataRaw != null)
            {
                Tools._writeDebugDiagnosticMessage("Start", true, false);
                int pIndex = 0;
                byte[] request = new byte[] { WRITE_SRAM_1_BYTE, 0x00, 0x00, flashDataRaw[pIndex++] };
                writeAndReadCommandUart(request, 4);

                int numOfTriplets = ((flashDataRaw.Length - 1) / 3);
                int packetSize = this._packetSize;
                int packetCount = numOfTriplets / packetSize;
                List<byte> _request = new List<byte>();

                for (int k = 0; k < packetCount; k++)
                {
                    _request.Clear();
                    for (int i = 0; i < packetSize; i++)
                    {
                        _request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                            flashDataRaw[pIndex++],
                                            flashDataRaw[pIndex++],
                                            flashDataRaw[pIndex++]});
                    }
                    writeAndReadCommandUart(_request.ToArray(), _request.Count);
                }
                /*_request.Clear();

                List<byte[]> content = new List<byte[]>();
                for (int pageIndex = 0; pageIndex < SRAM_PAGES_COUNT; pageIndex++)
                {
                    byte[] page = new byte[SRAM_PAGE_SIZE];
                    for (int j = 0; j < SRAM_PAGE_SIZE; j++)
                    {
                        page[j] = flashDataRaw[pageIndex * SRAM_PAGE_SIZE + j];
                    }
                    content.Add(page);
                }
                for (int i = 0; i < content.Count; i++)
                {
                    if (isPageNotEmpty(content[i]))
                    {
                        WriteSRAMPage(content[i], (byte)i, 0x00);
                        if (FlashProgressChanged != null)
                        {
                            FlashProgressChanged(new ProgressChangedEventArgs(ProgressStatuses.Read, content[i].Length * (i + 1), this.SramSize));
                        }
                        //Issue Write Write Flash Sector Command
                        byte[] request = new byte[] { WRITE_FLASH_ZW050X, (byte)i, 0x00, 0x00 };
                        writeAndReadCommandUart(request, 4);
                        Thread.Sleep(50);
                    }
                }*/
                Tools._writeDebugDiagnosticMessage("Stop", true, false);

            }
            return true;
        }
        private bool isPageNotEmpty(byte[] page)
        {
            bool result = false;
            for (int byteNo = 0; byteNo < page.Length; byteNo++)
            {
                if (page[byteNo] != Constants.BLANK_VALUE)
                {
                    result = true;
                    break;
                }
            }
            return result;
        }
        private void WriteSRAMPage(byte[] page, byte addr1, byte addr2)
        {
            //write first byte

            List<byte> _page = null;

            _page = new List<byte>(page);
            for (int i = _page.Count - 1; i >= 0; i--)
            {
                if (_page[i] != Constants.BLANK_VALUE)
                {
                    break;
                }
                else
                {
                    _page.RemoveAt(i);
                }
            }
            if (_page.Count < FLASH_PAGE_SIZE)
            {
                if ((_page.Count % 3) != 0)
                {
                    int addCount = (3 - (_page.Count % 3)) + 1;
                    for (int i = 0; i < addCount; i++)
                        _page.Add(Constants.BLANK_VALUE);
                }
            }
            int pIndex = 0;
            byte[] request = new byte[] { WRITE_SRAM_1_BYTE, addr1, addr2, _page[pIndex++] };
            writeAndReadCommandUart(request, 4);
            /*
            for (int i = 0; i < ((_page.Count - 1) / 3); i++)
            {
                request = new byte[] { CONTINUE_WRITE_1_BYTE, 
                                        _page[pIndex++],
                                        _page[pIndex++],
                                        _page[pIndex++]};
                writeAndReadCommandUart(request, 4);
            }
            request = new byte[] { CONTINUE_WRITE_1_BYTE, 
                                        _page[pIndex++],
                                        0xFF,
                                        0xFF};
            writeAndReadCommandUart(request, 4);*/


            int numOfTriplets = ((_page.Count - 1) / 3);
            int packetSize = this._packetSize;
            int packetCount = numOfTriplets / packetSize;
            List<byte> _request = new List<byte>();
            if (packetCount == 0 && numOfTriplets < packetSize)
            {
                for (int i = 0; i < numOfTriplets; i++)
                {
                    _request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                            _page[pIndex++],
                                            _page[pIndex++],
                                            _page[pIndex++]});
                }
                writeAndReadCommandUart(_request.ToArray(), _request.Count);
            }
            else
            {
                for (int p = 0; p < packetCount; p++)
                {
                    _request.Clear();
                    for (int i = 0; i < packetSize; i++)
                    {
                        _request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                            _page[pIndex++],
                                            _page[pIndex++],
                                            _page[pIndex++]});
                    }
                    writeAndReadCommandUart(_request.ToArray(), _request.Count);
                }
                _request.Clear();
                for (int i = 0; i < (numOfTriplets % packetSize) + 1; i++)
                {
                    _request.Add(CONTINUE_WRITE_1_BYTE);

                    if (pIndex < _page.Count)
                    {
                        _request.Add(_page[pIndex++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                    if (pIndex < _page.Count)
                    {
                        _request.Add(_page[pIndex++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                    if (pIndex < _page.Count)
                    {
                        _request.Add(_page[pIndex++]);
                    }
                    else
                    {
                        _request.Add(Constants.BLANK_VALUE);
                    }

                    /*_request.AddRange(new byte[] { CONTINUE_WRITE_1_BYTE, 
                                        _page[pIndex++],
                                        _page[pIndex++],
                                        _page[pIndex++]});*/

                }
                if (_request.Count > 0)
                {
                    writeAndReadCommandUart(_request.ToArray(), _request.Count);
                }
            }
        }


        public void FlashRunCRCCheck()
        {
            byte[] request = new byte[] { RUN_CRC_CHK_0_BYTE, RUN_CRC_CHK_1_BYTE, RUN_CRC_CHK_2_BYTE, RUN_CRC_CHK_3_BYTE };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4 &&
                (responseBuffer[0] == RUN_CRC_CHK_0_BYTE &&
                responseBuffer[1] == RUN_CRC_CHK_1_BYTE &&
                responseBuffer[2] == RUN_CRC_CHK_2_BYTE &&
                responseBuffer[3] == RUN_CRC_CHK_3_BYTE))
            {
            }
            else
            {
                throw new Exception("Unable run CRC check");
            }
        }

        public byte FlashCheckState()
        {
            byte[] request = new byte[] { CHK_STATE_0_BYTE, CHK_STATE_1_BYTE, CHK_STATE_2_BYTE, CHK_STATE_3_BYTE };
            byte[] response = new byte[] { CHK_STATE_0_BYTE, CHK_STATE_1_BYTE, CHK_STATE_2_BYTE };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4 &&
                (responseBuffer[0] == CHK_STATE_0_BYTE &&
                responseBuffer[1] == CHK_STATE_1_BYTE &&
                responseBuffer[2] == CHK_STATE_2_BYTE))
            {
                return responseBuffer[3];
            }
            return 0x00;
        }

        public bool Compare(byte[] buffer, ZWave.Devices.IFlashSettings flashSettings, byte[] flashDataRaw, out SortedList<int, List<byte[]>> diffs)
        {
            diffs = new SortedList<int, List<byte[]>>();
            bool result = true;
            if (buffer == null || flashDataRaw == null)
                return false;

            if (buffer.Length != flashDataRaw.Length)
                return false;

            List<byte[]> hexContent = new List<byte[]>();
            for (int pageIndex = 0; pageIndex < FLASH_PAGES_COUNT; pageIndex++)
            {
                byte[] page = new byte[FLASH_PAGE_SIZE];
                for (int j = 0; j < FLASH_PAGE_SIZE; j++)
                {
                    page[j] = flashDataRaw[pageIndex * FLASH_PAGE_SIZE + j];
                }
                hexContent.Add(page);
            }
            List<byte[]> flashContent = new List<byte[]>();
            for (int pageIndex = 0; pageIndex < FLASH_PAGES_COUNT; pageIndex++)
            {
                byte[] page = new byte[FLASH_PAGE_SIZE];
                for (int j = 0; j < FLASH_PAGE_SIZE; j++)
                {
                    page[j] = buffer[pageIndex * FLASH_PAGE_SIZE + j];
                }
                flashContent.Add(page);
            }

            if (hexContent.Count == flashContent.Count)
            {
                for (int i = 0; i < hexContent.Count; i++)
                {
                    for (int j = 0; j < hexContent[i].Length; j++)
                    {
                        if ((i != hexContent.Count - 1) && (j < hexContent[i].Length - 4))//Ignore Checksum
                        {
                            if (hexContent[i][j] != flashContent[i][j])
                            {
                                if (!diffs.ContainsKey(i))
                                {
                                    List<byte[]> diffData = new List<byte[]>();
                                    diffData.Add(flashContent[i]);
                                    diffData.Add(hexContent[i]);
                                    diffs.Add(i, diffData);
                                }
                                result = false;

                            }
                        }
                    }
                }
            }
            return result;
        }

        public IFlashSettings FlashReadRfOptions()
        {
            IFlashSettings result = null;
            int pageIndex = 15;//last sector in 64K
            int offset = 0x7800;

            byte[] buffer = this.ReadPage(pageIndex);
            if (buffer != null)
            {
                result = new FlashSettings();
                result.ParseBuffer(this.ChipType, offset, buffer);
            }
            return result;
        }

        public bool SetMode(WorkingModes workingModes)
        {
            if (workingModes == WorkingModes.ExecuteOutOfSram)
            {
                byte[] request = new byte[] { ENABLE_EOOS_MODE_1_BYTE, ENABLE_EOOS_MODE_2_BYTE, ENABLE_EOOS_MODE_3_BYTE, ENABLE_EOOS_MODE_4_BYTE };
                writeAndReadCommandUart(request, 4);
                if (responseBuffer != null &&
                    responseBuffer.Count == 4 &&
                    responseBuffer[0] == ENABLE_EOOS_MODE_1_BYTE)
                {
                    return true;
                }
            }
            else
            {
                byte[] request = new byte[] { DISABLE_EOOS_MODE_1_BYTE, DISABLE_EOOS_MODE_2_BYTE, DISABLE_EOOS_MODE_3_BYTE, DISABLE_EOOS_MODE_4_BYTE };
                writeAndReadCommandUart(request, 4);
                if (responseBuffer != null &&
                    responseBuffer.Count == 4 &&
                    responseBuffer[0] == DISABLE_EOOS_MODE_1_BYTE)
                {
                    return true;
                }
            }
            return false;
        }

        public WriteRfOptionsStatuses FlashWriteRfOptions(IFlashSettings flashSettings)
        {
            WriteRfOptionsStatuses result = WriteRfOptionsStatuses.NoErrors;
            int pageIndex = 15;//last sector in 64K
            int offset = 0x7800;

            if (flashSettings != null)
            {
                byte[] buffer = this.ReadPage(pageIndex);
                if (buffer != null)
                {
                    flashSettings.StoreToBuffer(this.ChipType, offset, buffer);
                    this.ErasePage(pageIndex);
                    try
                    {
                        WriteSRAMPage(buffer, 0x00, 0x00);
                        if (FlashProgressChanged != null)
                        {
                            FlashProgressChanged(new ProgressChangedEventArgs(ProgressStatuses.Write, buffer.Length, this.FlashSize));
                        }
                        /*Issue Write Write Flash Sector Command*/
                        byte[] request = new byte[] { WRITE_FLASH_ZW050X, (byte)pageIndex, 0xFF, 0xFF };
                        writeAndReadCommandUart(request, 4, false); // write flash sector command response in rare cases misses leading byte(s)
                        Thread.Sleep(300);
                        if (!FlashCheckStateRecursive(10, 1000))
                        {
                            result = WriteRfOptionsStatuses.CantWriteAppRfSettings;
                        }
                    }
                    catch
                    {
                        result = WriteRfOptionsStatuses.CantWriteAppRfSettings;
                    }

                }
                else
                {
                    result = WriteRfOptionsStatuses.CantReadAppRfSettings;
                }
            }
            else
            {
                result = WriteRfOptionsStatuses.UndefinedRfSettings;
            }
            return result;
        }

        public void ErasePage(int pageIndex)
        {
            byte[] request = new byte[] { SECTOR_ERASE_ZW050X, (byte)pageIndex, 0xFF, 0xFF };
            byte[] response = new byte[] { SECTOR_ERASE_ZW050X, (byte)pageIndex, 0xFF, 0xFF };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4 &&
                (responseBuffer[0] == SECTOR_ERASE_ZW050X &&
                responseBuffer[1] == (byte)pageIndex &&
                responseBuffer[2] == 0xFF &&
                responseBuffer[3] == 0xFF))
            {
                Thread.Sleep(200);
                if (!FlashCheckStateRecursive(10, 1000))
                {
                    throw new Exception("Unable erase Sector: " + pageIndex.ToString());
                }
            }
            else
            {
                throw new Exception("Unable erase Sector: " + pageIndex.ToString());
            }
        }

        public bool WriteNvrByte(byte index, byte data)
        {
            if (data != 0xFF)
            {
                byte[] request = new byte[] { NVR_SET_0_BYTE, NVR_SET_1_BYTE, index, data };
                writeAndReadCommandUart(request, 4);
                if (responseBuffer != null && responseBuffer.Count == 4 && responseBuffer[2] == index && responseBuffer[3] == data)
                {
                    return true;
                }
                return false;
            }
            return true;
        }

        public byte[] ReadNvr(byte partNo)
        {
            List<byte> result = new List<byte>();

            for (int i = Constants.NVR_START_ADDRESS; i < Constants.NVR_END_ADDRESS; i++)
            {
                byte data = 0x00;
                if (ReadNvrByte((byte)i, out data, partNo))
                {
                    result.Add(data);
                }
            }
            if (result.Count > 0)
            {
                result.InsertRange(0, new byte[9]);
                return result.ToArray();
            }
            else
            {
                return null;
            }
        }

        public void Reset()
        {
            Tools._writeDebugDiagnosticMessage("!!!!!!!!Reset");
            byte[] request = new byte[] { 0xFF, 0xFF, 0xFF, 0xFF };
            writeAndReadCommandUart(request, 0);
        }
        public void ResetAndWait()
        {
            Tools._writeDebugDiagnosticMessage("!!!!!!!!ResetAndWait");
            byte[] request = new byte[] { 0xFF, 0xFF, 0xFF, 0xFF };
            writeAndReadCommandUart(request, 4);
        }

        public bool ReadNvrByte(byte index, out byte data, byte partNo)
        {
            data = 0x00;
            byte[] request = new byte[] { NVR_READ_0_BYTE, partNo, index, NVR_READ_3_BYTE };
            writeAndReadCommandUart(request, 4);
            if (responseBuffer != null && responseBuffer.Count == 4)
            {
                data = responseBuffer[3];
                return true;
            }
            return false;
        }

        //AutoResetEvent signal = new AutoResetEvent(false);
        List<byte> responseBuffer = new List<byte>();

        private void writeAndReadCommandUart(byte[] request, int bytesCount)
        {
            writeAndReadCommandUart(request, bytesCount, 0, true); // 0 -  means: use default timeout
        }

        private void writeAndReadCommandUart(byte[] request, int bytesCount, bool isThrowReadException)
        {
            writeAndReadCommandUart(request, bytesCount, 0, isThrowReadException); // 0 -  means: use default timeout
        }

        private void writeAndReadCommandUart(byte[] request, int bytesCount, int timeoutMs, bool isThrowReadException)
        {
            int ret = request.Length;
            //responseBuffer.Clear();
            if (mPort != null && mPort.IsOpen)
            {
                writeDataLow(request, ret);
                ReadData(bytesCount, timeoutMs, isThrowReadException);
            }
        }

        private void writeDataLow(byte[] request, int ret)
        {
            mPort.Write(request, 0, ret);
            Tools._writeDebugDiagnosticMessage(mPort.PortName + " >> " + Tools.ToHexString(request, " "), true, false);

            if (mControllerManager != null && mControllerManager.ZWaveManager != null &&
                request != null && request.Length > 0)
            {
                mControllerManager.ZWaveManager.AddLogPacket(
                    new ZWave.Logging.LogPacket(request, true, false, Tools.CurrentDateTime, request[0], null));
            }
        }
        public void setTimeout(int timeoutMs)
        {
            DEFAULT_TIMEOUT = timeoutMs;
        }

        private void ReadData(int count, int timeoutMs)
        {
            ReadData(count, timeoutMs, true);
        }

        private void ReadData(int count, int timeoutMs, bool IsThrowException)
        {
            int _timeoutMs = DEFAULT_TIMEOUT;
            if (timeoutMs > 0)
                _timeoutMs = timeoutMs;
            DateTime startTime = Tools.CurrentDateTime;
            responseBuffer.Clear();
            if (count > 0)
            {
                byte[] tData = new byte[1024];
                while (mPort != null && mPort.IsOpen)
                {
                    try
                    {
                        if (mPort.BytesToRead > 0)
                        {
                            #region Read
                            int bytesRead = mPort.Read(tData, 0, mPort.BytesToRead);
                            if (bytesRead > 0)
                            {
                                byte[] _tData = new byte[bytesRead];
                                Array.Copy(tData, _tData, bytesRead);

                                Tools._writeDebugDiagnosticMessage(mPort.PortName + " << " + Tools.ToHexString(_tData, " "), true, false);

                                responseBuffer.AddRange(_tData);
                                if (responseBuffer.Count >= count)
                                {
                                    if (mControllerManager != null && mControllerManager.ZWaveManager != null)
                                    {
                                        mControllerManager.ZWaveManager.AddLogPacket(
                                            new ZWave.Logging.LogPacket(responseBuffer.ToArray(), false, true, Tools.CurrentDateTime, responseBuffer[0], null));
                                    }
                                    break;
                                }
                            }
                            else
                            {
                                break;
                            }
                            #endregion Read
                        }
                        else
                        {
                            DateTime tmpTime = Tools.CurrentDateTime;
                            int totalMiliseconds = (int)((TimeSpan)(tmpTime - startTime)).TotalMilliseconds;
                            if (totalMiliseconds > _timeoutMs)
                            {
                                if (IsThrowException)
                                {
                                    Tools._writeDebugDiagnosticMessage("Read/Write operation timeout.(AutoProgDevice) " + "mPort.BytesToRead: " + mPort.BytesToRead + " ts:" + totalMiliseconds.ToString() + " " + _timeoutMs.ToString(), true, false);
                                    throw new ApplicationException("Read/Write operation timeout.");
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        if (ex is ApplicationException)
                            throw ex;
                        break;
                    }
                }
            }
        }


        #region IDisposable Members

        public void Dispose()
        {
            if (mPort != null)
            {
                if (mPort.IsOpen == true)
                {
                    try
                    {
                        mPort.ReadExisting();
                        GC.ReRegisterForFinalize(mPort.BaseStream);
                        mPort.Close();
                        mPort.Dispose();
                        mPort = null;
                        mPortInfo = null;

                    }
                    catch (Exception)
                    {
                    }
                }
            }
        }

        #endregion
    }

    public enum AutoProgDeviceTypes
    {
        UART,
        UZB_0000,
        UZB_0001,
        SD_USB_0000,
        SD_USB_0001
    }
}

