using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Controllers;
using ZWave.Programmer.Properties;
using ZWave.Programmer.UI;
using System.Globalization;
using System.IO;
using System.Diagnostics;
using ZWave.Devices;
using ZWave.SerialPortApplication.Devices;
using ZWave.Enums;
using ZWave.Framework;
using System.Security.Cryptography;
using ZWave.Programmer.Actions;

namespace ZWave.Programmer.Classes
{
    /// <summary>
    /// ProgrammerConsole class. Contains methods for parsing command line arguments.
    /// </summary>
    public class ProgrammerConsole
    {
        private ControllerManager mControllerManager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProgrammerConsole"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public ProgrammerConsole(ControllerManager controller)
        {
            mControllerManager = controller;
        }

        private void ShowCaption()
        {
            Console.WriteLine(String.Format("{0} v.{1}.{2}",
                AboutForm.AssemblyProduct,
                AboutForm.AssemblyVersionEx.Major.ToString(),
                AboutForm.AssemblyVersionEx.Minor.ToString()));
        }

        internal void ProcessCommandLine(string[] args)
        {
            ShowCaption();

            Dictionary<string, string> commands = CommandLineValidationHelper.ParseAndValidateCommandLineArgs(args);

            try
            {
                if (commands.ContainsKey("-s"))
                {
                    if (commands.Count > 1)
                    {
                        string comPort = "";
                        if (commands.ContainsKey("-c"))
                        {
                            comPort = commands["-c"];
                        }
                        else
                        {
                            comPort = commands["-s"];
                        }
                        if (string.IsNullOrEmpty(comPort))
                        {
                            CommandLineValidationHelper.ShowUsage();
                            return;
                        }
                        ProcessSerialPort(comPort);
                        if (commands.Count == 2 && commands.ContainsKey("-t"))
                        {
                            ProcessChipType(commands["-t"]);
                            mControllerManager.RunUI();
                        }
                        else
                        {
                            //ShowMessage("UART interface enabled.\nPlease keep reset button on Programmer board pressed during programming.");
                            mControllerManager.CmdLineProgInterface = 1;
                            if (commands.ContainsKey("-t"))
                            {
                                ProcessChipType(commands["-t"]);
                                ProcessCommandLine(commands);
                            }
                            else
                            {
                                if (mControllerManager.Actions.ProgrammerActions.DetectDeviceA())
                                //mControllerManager.DeviceInit();
                                {
                                    ProcessCommandLine(commands);
                                }
                            }

                        }
                    }
                }
                else if (commands.ContainsKey("-u"))
                {
                    if (commands.Count > 1)
                    {
                        string comPort = "";
                        if (commands.ContainsKey("-c"))
                        {
                            comPort = commands["-c"];
                        }
                        else
                        {
                            comPort = commands["-u"];
                        }
                        if (string.IsNullOrEmpty(comPort))
                        {
                            CommandLineValidationHelper.ShowUsage();
                            return;
                        }
                        ProcessSerialPort(comPort);
                        if (commands.Count == 2 && commands.ContainsKey("-t"))
                        {
                            ProcessChipType(commands["-t"]);
                            mControllerManager.RunUI();
                        }
                        else
                        {
                            ShowMessage("USB interface enabled.");
                            mControllerManager.CmdLineProgInterface = 1;
                            mControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW050x;
                            if (commands.ContainsKey("-t"))
                            {
                                ProcessChipType(commands["-t"]);
                                mControllerManager.DeviceInit();
                                ProcessCommandLine(commands);
                                if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                                {
                                    mControllerManager.RestoreSelectedDevice();
                                }
                            }
                            else
                            {
                                mControllerManager.DeviceInit();
                                ProcessCommandLine(commands);
                                if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                                {
                                    mControllerManager.RestoreSelectedDevice();
                                }
                            }
                        }
                    }
                }
                else if (commands.ContainsKey("-c"))
                {
                    if (commands.Count == 1)
                    {
                        ProcessSerialPort(commands["-c"]);
                        mControllerManager.RunUI();
                    }
                    else if (commands.Count > 1)
                    {
                        ProcessSerialPort(commands["-c"]);
                        if (commands.Count == 2 && commands.ContainsKey("-t"))
                        {
                            ProcessChipType(commands["-t"]);
                            mControllerManager.RunUI();
                        }
                        else
                        {
                            mControllerManager.DocumentModel.Settings.WriteOnPcbButton = false;

                            if (mControllerManager.Actions.ProgrammerActions.UpgradeLatestFirmware() <= 0 && mControllerManager.mIsRESET_NAvailable)
                            {
                                //Silicon to UART bridge
                                mControllerManager.CmdLineProgInterface = 1;
                            }

                            if (commands.ContainsKey("-t"))
                            {
                                ProcessChipType(commands["-t"]);
                                ProcessCommandLine(commands);
                            }
                            else
                            {
                                if (mControllerManager.Actions.ProgrammerActions.DetectDeviceA())
                                {
                                    ProcessCommandLine(commands);
                                }
                            }
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                ShowMessage(Resources.ErrorCantDetectDevice);
            }
        }

        private void ShowMessage(string msg)
        {
            Console.WriteLine(msg);
        }

        private void ProcessCommandLine(Dictionary<string, string> commands)
        {
            var priorityList = new string[] 
            {
                "-pks","-pkf"
            };

            foreach (var item in priorityList)
            {
                if (commands.ContainsKey(item))
                {
                    ProcessCommandArgs(item, commands[item]);
                    commands.Remove(item);
                }
            }

            foreach (KeyValuePair<string, string> cmd in commands)
            {
                if (cmd.Key != "-c" && cmd.Key != "-s" && cmd.Key != "-u" && cmd.Key != "-t")
                {
                    ProcessCommandArgs(cmd.Key, cmd.Value);
                }
            }
        }

        private void ProcessCommandArgs(string commandKey, string commandValue)
        {
            if (commandKey == "-pf")
            {
                if (mControllerManager.DocumentModel.SelectedChipType < (byte)ChipTypes.ZW050x)
                {
                    IFlashSettings flashSettings = new FlashSettings();
                    flashSettings.Frequency = (byte)CommandLineValidationHelper.GetFrequencyByName(commandValue);
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {
                        mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                    }
                }
                else
                {
                    ShowMessage("Command is not supported using ZW050x chip type.");
                }
            }
            else if (commandKey == "-p")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashProgram(commandValue, false);
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashProgram(commandValue, false, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                }

            }
            else if (commandKey == "-f")
            {
                if (mControllerManager.DocumentModel.SelectedChipType < (byte)ChipTypes.ZW050x)
                {
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ProgrammerActions.FlashWrite(commandValue, false);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {
                        mControllerManager.Actions.ProgrammerActions.FlashWrite(commandValue, false, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                    }
                }
                else
                {
                    ShowMessage("Command is not supported using ZW050x chip type.");
                }
            }
            else if (commandKey == "-r")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashRead(commandValue);
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashRead(commandValue, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                }
            }
            else if (commandKey == "-v")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashCompare(commandValue);
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashCompare(commandValue, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                }
            }
            else if (commandKey == "-e")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashErase();
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    mControllerManager.Actions.ProgrammerActions.FlashErase(mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                }

            }
            else if (commandKey == "-pe")
            {
                if (commandValue == "0")
                {
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ProgrammerActions.EEPROMErase();
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {

                        ShowMessage("EEPROM Erase is not implemented for UART/USB programming interfaces");
                    }
                }
                else
                {
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ProgrammerActions.EEPROMWrite(commandValue);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {

                        ShowMessage("EEPROM Write is not implemented for UART/USB programming interfaces");
                    }
                }
            }
            else if (commandKey == "-pr")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    mControllerManager.Actions.ProgrammerActions.EEPROMRead(commandValue);
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {

                    ShowMessage("EEPROM Read is not implemented for UART/USB programming interfaces");
                }
            }
            else if (commandKey == "-ph")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    var homeId = Tools.GetBytes(commandValue);
                    mControllerManager.Actions.ProgrammerActions.WriteHomeId(Tools.GetHexShort(homeId));
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {

                    ShowMessage("Write Home ID is not implemented for UART/USB programming interfaces");
                }
            }
            else if (commandKey == "-pks")
            {
                if (string.IsNullOrEmpty(commandValue))
                {
                    mControllerManager.DocumentModel.IsAddSecurity2Keys = true;
                }
                else
                {
                    string[] content = commandValue.Split(' ', '\t');
                    if (content.Length > 1)
                    {
                        mControllerManager.DocumentModel.PrivateS2Key = Tools.GetBytes(content[0]);
                        mControllerManager.DocumentModel.PublicS2Key = Tools.GetBytes(content[1]);
                    }
                    if (mControllerManager.DocumentModel.HasValidS2Keypair2Keys)
                    {
                        mControllerManager.DocumentModel.IsAddSecurity2Keys = true;
                    }
                    else
                        Console.WriteLine(String.Format("Can't parse keys from input '{0}'.", commandValue));
                }
            }
            else if (commandKey == "-pkf")
            {
                try
                {
                    string[] content = File.ReadAllLines(commandValue);
                    if (content.Length > 1)
                    {
                        mControllerManager.DocumentModel.PrivateS2Key = Tools.GetBytes(content[0]);
                        mControllerManager.DocumentModel.PublicS2Key = Tools.GetBytes(content[1]);
                    }
                }
                catch
                {
                }
                if (mControllerManager.DocumentModel.HasValidS2Keypair2Keys)
                {
                    mControllerManager.DocumentModel.IsAddSecurity2Keys = true;
                }
                else
                    Console.WriteLine(String.Format("Can't read keys from file '{0}'.", commandValue));
            }
            else if (commandKey == "-pkg")
            {
                mControllerManager.Actions.ProgrammerActions.GetS2Keys();
            }
            else if (commandKey == "-sr")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.SramRead(commandValue, WorkingModes.Development);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {

                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramRead(commandValue, WorkingModes.ExecuteOutOfSram);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramRead(commandValue, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);

                    }
                }
            }
            else if (commandKey == "-sw")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.SramWrite(commandValue, WorkingModes.Development);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramWrite(commandValue, WorkingModes.ExecuteOutOfSram);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramWrite(commandValue, WorkingModes.ExecuteOutOfSram, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);

                    }
                }
            }
            else if (commandKey == "-sc")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.SramCompare(commandValue, WorkingModes.Development);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {

                    ShowMessage("SRAM Compare is not implemented for UART/USB programming interfaces");
                }
            }
            else if (commandKey == "-swrd")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.SramWriteAndRunMode(commandValue, WorkingModes.Development);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {

                    ShowMessage("Development mode is not implemented for UART/USB programming interfaces");
                }
            }
            else if (commandKey == "-sweo")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.SramWriteAndRunMode(commandValue, WorkingModes.ExecuteOutOfSram);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {
                    if (mControllerManager.CmdLineProgInterface == 0)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramWriteAndRunMode(commandValue, WorkingModes.ExecuteOutOfSram);
                    }
                    else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                    {
                        mControllerManager.Actions.ZW050xFormActions.SramWriteAndRunMode(commandValue, WorkingModes.ExecuteOutOfSram, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);

                    }
                }
            }
            else if (commandKey == "-ls")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ProgrammerActions.LockBitsSet(byte.Parse(commandValue, NumberStyles.HexNumber));
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {
                    var lockBits = Tools.GetBytes(commandValue);
                    if (lockBits.Length == 9)
                    {
                        if (mControllerManager.CmdLineProgInterface == 0)
                        {
                            mControllerManager.Actions.ProgrammerActions.LockBitsSetZW050x(new List<byte>(lockBits));
                        }
                        else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                        {
                            mControllerManager.Actions.ProgrammerActions.LockBitsSetZW050x(new List<byte>(lockBits), mControllerManager.CmdLineProgInterface);
                        }
                    }
                }
            }
            else if (commandKey == "-lg")
            {
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                    {
                        Console.WriteLine(String.Format("LockBits: {0}",
                            mControllerManager.Actions.ProgrammerActions.LockBitsRead().ToString("X2")));
                    }
                    else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                    {
                        List<byte> lockBits = new List<byte>();
                        mControllerManager.Actions.ProgrammerActions.LockBitsReadZW050x(lockBits);
                        if (lockBits != null)
                        {
                            for (int i = 0; i < lockBits.Count; i++)
                            {
                                Console.WriteLine(String.Format("LockBit: {0} {1}", i, lockBits[i].ToString("X2")));

                            }
                        }
                    }
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    List<byte> lockBits = new List<byte>();
                    mControllerManager.Actions.ProgrammerActions.LockBitsReadZW050x(lockBits, mControllerManager.CmdLineProgInterface);

                    if (lockBits != null)
                    {
                        for (int i = 0; i < lockBits.Count; i++)
                        {
                            Console.WriteLine(String.Format("LockBit: {0} {1}", i, lockBits[i].ToString("X2")));

                        }
                    }
                }
            }
            else if (commandKey == "-mp")
            {
                if (commandValue == "0")
                {
                    if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                    {
                        mControllerManager.Actions.ZW040xFormActions.MtpErase();
                    }
                    else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                    {

                        ShowMessage("MTP Erase is not implemented for UART/USB programming interfaces");
                    }
                }
                else
                {
                    if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                    {
                        mControllerManager.Actions.ZW040xFormActions.MtpProgram(commandValue);
                    }
                    else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                    {

                        ShowMessage("MTP Program is not implemented for UART/USB programming interfaces");
                    }
                }
            }
            else if (commandKey == "-mr")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.MtpRead(commandValue);
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {

                    ShowMessage("MTP Read is not implemented for UART/USB programming interfaces");
                }
            }
            else if (commandKey == "-ro")
            {
                ChipTypes deviceChipType = ChipTypes.UNKNOWN;
                IFlashSettings flashSettings = null;
                if (mControllerManager.CmdLineProgInterface == 0)
                {
                    flashSettings = mControllerManager.Actions.ProgrammerActions.FlashReadOptions(out deviceChipType);
                }
                else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                {
                    flashSettings = mControllerManager.Actions.ProgrammerActions.FlashReadOptions(out deviceChipType, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);

                }
                if (flashSettings != null)
                {
                    switch (deviceChipType)
                    {
                        case (ChipTypes.ZW020x):
                        case (ChipTypes.ZW030x):
                            {
                                Console.WriteLine("");
                                Console.WriteLine(String.Format("Chip: {0}", deviceChipType.ToString()));
                                Console.WriteLine("------------------");
                                Console.WriteLine(String.Format("Normal Power:{0}", flashSettings.NormalPower.ToString("X2")));
                                Console.WriteLine(String.Format("Low Power:{0}", flashSettings.LowPower.ToString("X2")));
                            } break;
                        case (ChipTypes.ZW040x):
                        case (ChipTypes.ZW050x):
                            {
                                Console.WriteLine("");
                                Console.WriteLine(String.Format("Chip: {0}", deviceChipType.ToString()));
                                Console.WriteLine("------------------");
                                Console.WriteLine(String.Format("Normal Power (ch0):{0}", flashSettings.NormalPowerCh0.ToString("X2")));
                                Console.WriteLine(String.Format("Low Power (ch0):{0}", flashSettings.LowPowerCh0.ToString("X2")));
                                Console.WriteLine(String.Format("Normal Power (ch1):{0}", flashSettings.NormalPowerCh1.ToString("X2")));
                                Console.WriteLine(String.Format("Low Power (ch1):{0}", flashSettings.LowPowerCh1.ToString("X2")));
                                Console.WriteLine(String.Format("Normal Power (ch2):{0}", flashSettings.NormalPowerCh2.ToString("X2")));
                                Console.WriteLine(String.Format("Low Power (ch2):{0}", flashSettings.LowPowerCh2.ToString("X2")));
                            } break;

                    }
                }
            }
            else if (commandKey == "-sro")
            {
                IFlashSettings sramSettings = null;
                ChipTypes deviceChipType = ChipTypes.UNKNOWN;
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    mControllerManager.Actions.ZW040xFormActions.ReadSRAMRfOptions(ref sramSettings, ref deviceChipType);
                    if (deviceChipType == ChipTypes.ZW040x && sramSettings != null)
                    {
                        Console.WriteLine("");
                        Console.WriteLine(String.Format("Chip: {0}", deviceChipType.ToString()));
                        Console.WriteLine("------------------");
                        Console.WriteLine(String.Format("Normal Power (ch0):{0}", sramSettings.NormalPowerCh0.ToString("X2")));
                        Console.WriteLine(String.Format("Low Power (ch0):{0}", sramSettings.LowPowerCh0.ToString("X2")));
                        Console.WriteLine(String.Format("Normal Power (ch1):{0}", sramSettings.NormalPowerCh1.ToString("X2")));
                        Console.WriteLine(String.Format("Low Power (ch1):{0}", sramSettings.LowPowerCh1.ToString("X2")));
                        Console.WriteLine(String.Format("Normal Power (ch2):{0}", sramSettings.NormalPowerCh2.ToString("X2")));
                        Console.WriteLine(String.Format("Low Power (ch2):{0}", sramSettings.LowPowerCh2.ToString("X2")));
                    }
                    else
                    {
                        Console.WriteLine(String.Format("Chip: {0}. Read SRAM options not supported.", deviceChipType.ToString()));
                    }
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {
                    Console.WriteLine(String.Format("Chip: {0}. Read SRAM options not supported.", ((ChipTypes)mControllerManager.DocumentModel.SelectedChipType).ToString()));
                }
            }
            else if (commandKey == "-so")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW010x ||
                    mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW020x ||
                    mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW030x)
                {
                    var arr = Tools.GetBytes(commandValue);
                    if (arr.Length == 2)
                    {
                        byte npValue = arr[0];
                        byte lpValue = arr[1];

                        IFlashSettings flashSettings = new FlashSettings();
                        flashSettings.NormalPower = npValue;
                        flashSettings.LowPower = lpValue;
                        mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings);
                    }
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    var arr = Tools.GetBytes(commandValue);
                    if (arr.Length == 6)
                    {
                        byte np0Value = arr[0];
                        byte lp0Value = arr[1];
                        byte np1Value = arr[2];
                        byte lp1Value = arr[3];
                        byte np2Value = arr[4];
                        byte lp2Value = arr[5];

                        IFlashSettings flashSettings = new FlashSettings();
                        flashSettings.NormalPowerCh0 = np0Value;
                        flashSettings.NormalPowerCh1 = np1Value;
                        flashSettings.NormalPowerCh2 = np2Value;
                        flashSettings.LowPowerCh0 = lp0Value;
                        flashSettings.LowPowerCh1 = lp1Value;
                        flashSettings.LowPowerCh2 = lp2Value;
                        mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings);
                    }
                }
                else if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW050x)
                {
                    var arr = Tools.GetBytes(commandValue);
                    if (arr.Length == 6)
                    {
                        byte np0Value = arr[0];
                        byte lp0Value = arr[1];
                        byte np1Value = arr[2];
                        byte lp1Value = arr[3];
                        byte np2Value = arr[4];
                        byte lp2Value = arr[5];

                        IFlashSettings flashSettings = new FlashSettings();
                        flashSettings.NormalPowerCh0 = np0Value;
                        flashSettings.NormalPowerCh1 = np1Value;
                        flashSettings.NormalPowerCh2 = np2Value;
                        flashSettings.LowPowerCh0 = lp0Value;
                        flashSettings.LowPowerCh1 = lp1Value;
                        flashSettings.LowPowerCh2 = lp2Value;

                        if (mControllerManager.CmdLineProgInterface == 0)
                        {
                            mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings);
                        }
                        else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
                        {
                            mControllerManager.Actions.ProgrammerActions.FlashWriteOptions(flashSettings, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
                        }
                    }

                }

            }
            else if (commandKey == "-sso")
            {
                if (mControllerManager.DocumentModel.SelectedChipType == (byte)ChipTypes.ZW040x)
                {
                    var arr = Tools.GetBytes(commandValue);
                    if (arr.Length == 6)
                    {
                        byte npValueCh0 = 0;
                        byte lpValueCh0 = 0;
                        byte npValueCh1 = 0;
                        byte lpValueCh1 = 0;
                        byte npValueCh2 = 0;
                        byte lpValueCh2 = 0;

                        npValueCh0 = arr[0];
                        lpValueCh0 = arr[1];
                        npValueCh1 = arr[2];
                        lpValueCh1 = arr[3];
                        npValueCh2 = arr[4];
                        lpValueCh2 = arr[5];

                        IFlashSettings flashSettings = new FlashSettings();
                        flashSettings.NormalPowerCh0 = npValueCh0;
                        flashSettings.LowPowerCh0 = lpValueCh0;
                        flashSettings.NormalPowerCh1 = npValueCh1;
                        flashSettings.LowPowerCh1 = lpValueCh1;
                        flashSettings.NormalPowerCh2 = npValueCh2;
                        flashSettings.LowPowerCh2 = lpValueCh2;
                        mControllerManager.Actions.ZW040xFormActions.SramWriteOptions(flashSettings);
                    }
                }
                else
                {
                    ShowMessage("SRAM Set options is not supported.");
                }
            }
            else if (commandKey == "-nV")
            {
                byte[] nvrData = NvrReadPart0();
                if (nvrData != null)
                {
                    string hexData = HexFileHelper.WriteIntelHexFileStartingFromAddress(nvrData, 9, nvrData.Length, 0x10, 0xFF, false);
                    Console.WriteLine(hexData);
                    if (!String.IsNullOrEmpty(commandValue))
                    {
                        File.WriteAllText(commandValue, hexData);
                    }
                    ShowMessage("Read NVR data completed..");
                }
            }
            else if (commandKey == "-nv")
            {
                if (!String.IsNullOrEmpty(commandValue))
                {
                    SortedList<short, List<byte>> _hexData = HexFileHelper.ReadIntelHexData(File.ReadAllText(commandValue), Constants.BLANK_VALUE);
                    byte[] hexData = HexFileHelper.GetBytes(_hexData, Constants.NVR_END_ADDRESS, Constants.BLANK_VALUE);
                    if (hexData != null)
                    {
                        NVRData _nvr = (NVRData)hexData;
                        _nvr.CalculateCrc16();
                        if ((_nvr.CRC16[0] != hexData[NVRData.CRC16_ADDRESS]) &&
                            (_nvr.CRC16[1] != hexData[NVRData.CRC16_ADDRESS + 1]))
                        {
                            ShowMessage("NVR data contains bad CRC16 value.");
                        }
                        else
                        {
                            NvrWrite(_nvr);
                        }
                    }
                }
            }
            else if (commandKey == "-nCCAL")
            {
                byte CCALValue = Tools.GetByte(commandValue);
                byte[] nvrData = NvrReadPart0();
                NVRData nvrFormatted = (NVRData)nvrData;
                nvrFormatted.CCAL = CCALValue;
                nvrFormatted.CalculateCrc16();
                NvrWrite(nvrFormatted);
            }
        }

        private void NvrWrite(NVRData _nvr)
        {
            bool ret = false;
            if (mControllerManager.CmdLineProgInterface == 0)
            {
                ret = mControllerManager.Actions.ZW050xFormActions.NvrDataWrite(_nvr);
            }
            else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
            {
                ret = mControllerManager.Actions.ZW050xFormActions.NvrDataWrite(_nvr, mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface);
            }
            if (ret)
            {
                ShowMessage("Write NVR data completed..");
            }
            else
            {
                ShowMessage("Write NVR data failed..");
            }
        }

        private byte[] NvrReadPart0()
        {
            byte[] nvrData = null;
            if (mControllerManager.CmdLineProgInterface == 0)
            {
                var result = mControllerManager.Actions.ZW050xFormActions.NvrDataRead(false);
                if (result != null && result.Count > 0)
                    nvrData = result[0];
            }
            else if (mControllerManager.CmdLineProgInterface == 1 || mControllerManager.CmdLineProgInterface == 2)
            {
                var result = mControllerManager.Actions.ZW050xFormActions.NvrDataRead(mControllerManager.DocumentModel.PortInfo, mControllerManager.CmdLineProgInterface, false);
                if (result != null && result.Count > 0)
                    nvrData = result[0];
            }
            return nvrData;
        }

        private void ProcessSerialPort(string serialPort)
        {
            Win32PnPEntityClass serialPortInfo = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(serialPort);
            mControllerManager.DocumentModel.PortInfo = serialPortInfo;
            //Settings.Default.LastUsedDevice = serialPortInfo.DeviceID;
            //Settings.Default.Save();
        }

        private void ProcessChipType(string chipType)
        {
            foreach (byte i in Enum.GetValues(typeof(ChipTypes)))
            {
                if (chipType == Enum.GetName(typeof(ChipTypes), i))
                {
                    mControllerManager.DocumentModel.SelectedChipType = i;
                    //Settings.Default.SelectedChipType = i;
                    //Settings.Default.Save();
                    break;
                }
            }
        }
    }
}
