using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Interfaces;
using ZWave.Programmer.UI;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Models;
using System.Windows.Forms;

namespace ZWave.Programmer.Dispatchers
{
    /// <summary>
    /// MainFormDispatcher class. Bind/Unbind functions to the Main Form controls.
    /// </summary>
    public class MainFormDispatcher : IViewDispatcher
    {
        #region IViewDispatcher Members
        /// <summary>
        /// Binds the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Bind(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            MainForm form = (MainForm)view;

            //Form
            form.Load += new EventHandler(actions.MainFormActions.OnFormLoad);
            form.FormClosing += new System.Windows.Forms.FormClosingEventHandler(actions.MainFormActions.OnFormClosing);

            //View
            form.mainTabControl.Selected += new TabControlEventHandler(actions.MainFormActions.OnSelectedTabChanged);
            form.ZW010xToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnZW010xClick);
            form.ZW020xToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnZW020xClick);
            form.ZW030xToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnZW030xClick);
            form.ZW040xToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnZW040xClick);
            form.ZW050xToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnZW050xClick);
            form.LogToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnLogClick);
            form.SettingsToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnSettingsClick);
			form.DetectTargetToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnDetectTargetClick);
			form.UpgradeFirmwareToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnUpgradeFirmwareClick);
			form.UploadFirmwareToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnUploadFirmwareClick);
            form.CalibrateToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnCalibrateClick);


            form.ExitToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnExitClick);

            form.ResetZWaveModuleToolStripMenuItem.Click += new EventHandler(actions.MainFormActions.OnResetZWaveModuleClick);
            documentModel.DocumentModelStateChanged += new EventHandler<EventArgs>(actions.MainFormActions.OnDocumentModelStateChanged);

            form.KeyDown += new System.Windows.Forms.KeyEventHandler(actions.MainFormActions.OnKeyDown);
        }

        /// <summary>
        /// Drops the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Drop(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            MainForm form = (MainForm)view;

            //Form
            form.Load -= new EventHandler(actions.MainFormActions.OnFormLoad);
            form.FormClosing -= new System.Windows.Forms.FormClosingEventHandler(actions.MainFormActions.OnFormClosing);

            //View
            form.mainTabControl.Selected -= new TabControlEventHandler(actions.MainFormActions.OnSelectedTabChanged);
            form.ZW010xToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnZW010xClick);
            form.ZW020xToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnZW020xClick);
            form.ZW030xToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnZW030xClick);
            form.ZW040xToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnZW040xClick);
            form.ZW050xToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnZW050xClick);
            form.LogToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnLogClick);
            form.SettingsToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnSettingsClick);
			form.DetectTargetToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnDetectTargetClick);
			form.UpgradeFirmwareToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnUpgradeFirmwareClick);
			form.UploadFirmwareToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnUploadFirmwareClick);
            form.CalibrateToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnCalibrateClick);

            form.ExitToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnExitClick);
            form.ResetZWaveModuleToolStripMenuItem.Click -= new EventHandler(actions.MainFormActions.OnResetZWaveModuleClick);

            documentModel.DocumentModelStateChanged -= new EventHandler<EventArgs>(actions.MainFormActions.OnDocumentModelStateChanged);
            form.KeyDown -= new System.Windows.Forms.KeyEventHandler(actions.MainFormActions.OnKeyDown);
        }

        #endregion
    }
}
