using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Interfaces;
using ZWave.Programmer.UI;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Models;
using System.Windows.Forms;

namespace ZWave.Programmer.Dispatchers
{
    /// <summary>
    /// ConsoleFormDispatcher class. Bind/Unbind functions to the Console Form controls.
    /// </summary>
    public class ConsoleFormDispatcher : IViewDispatcher
    {
        #region IViewDispatcher Members
        /// <summary>
        /// Binds the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Bind(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ConsoleForm form = (ConsoleForm)view;

            //Form

            form.ClearToolStripButton.Click += new EventHandler(actions.ConsoleFormActions.OnClearClick);
            form.SaveToolStripButton.Click += new EventHandler(actions.ConsoleFormActions.OnSaveClick);
            form.CopyToolStripButton.Click += new EventHandler(actions.ConsoleFormActions.OnCopyClick);
        
        }
        /// <summary>
        /// Drops the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Drop(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ConsoleForm form = (ConsoleForm)view;

            //Form

            form.ClearToolStripButton.Click -= new EventHandler(actions.ConsoleFormActions.OnClearClick);
            form.SaveToolStripButton.Click -= new EventHandler(actions.ConsoleFormActions.OnSaveClick);
            form.CopyToolStripButton.Click -= new EventHandler(actions.ConsoleFormActions.OnCopyClick);
        }

        #endregion
    }
}
