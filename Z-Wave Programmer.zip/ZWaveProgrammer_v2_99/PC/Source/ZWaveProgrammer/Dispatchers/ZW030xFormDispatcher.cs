using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Interfaces;
using ZWave.Programmer.UI;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Models;
using System.Windows.Forms;

namespace ZWave.Programmer.Dispatchers
{
    /// <summary>
    /// ZW030xFormDispatcher class. Bind/Unbind functions to the ZW030x Form controls.
    /// </summary>
    public class ZW030xFormDispatcher : IViewDispatcher
    {
        #region IViewDispatcher Members
        /// <summary>
        /// Binds the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Bind(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ZW030xForm form = (ZW030xForm)view;

            form.ProductionButton.Click += new EventHandler(actions.ProgrammerActions.OnProductionClick);
            
            form.FlashBrowseHexFileButton.Click += new EventHandler(actions.ZW030xFormActions.OnFlashBrowseHexFileClick);
            form.EepromBrowseHexFileButton.Click += new EventHandler(actions.ZW030xFormActions.OnEEPROMBrowseHexFileClick);

            form.FlashHexFileNameTextBox.TextChanged += new EventHandler(actions.ZW030xFormActions.OnFlashHexFileNameChanged);
            form.EepromHexFileNameTextBox.TextChanged += new EventHandler(actions.ZW030xFormActions.OnEepromHexFileNameChanged);

            form.FlashEraseButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashEraseClick);
            form.FlashReadButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashReadClick);
            form.FlashWriteButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashWriteClick);
            form.FlashProgramButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashProgramClick);
            form.FlashCompareButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashCompareClick);
            form.FlashReadOptionsButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashReadOptionsClick);
            form.FlashWriteOptionsButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashWriteOptionsClick);

            form.EepromEraseButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMEraseClick);
            form.EepromReadButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMReadClick);
            form.EepromProgramButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMWriteClick);
            form.EepromCompareButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMCompareClick);
            
            form.ReadHomeIdButton.Click += new EventHandler(actions.ProgrammerActions.OnReadHomeIdClick);
            form.ChangeHomeIdButton.Click += new EventHandler(actions.ProgrammerActions.OnWriteHomeIdClick);

            form.AutoIncrementHomeIdCheckBox.CheckedChanged += new EventHandler(actions.CommonActions.OnAutoIncrementHomeIdCheckedChanged);
            documentModel.DocumentModelStateChanged += new EventHandler<EventArgs>(actions.ZW030xFormActions.OnDocumentModelStateChanged);
            form.CurrentHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.StartHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.EndHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);

			form.LockBitsReadButton.Click += new EventHandler(actions.ZW030xFormActions.OnLockBitsReadClick);
			form.LockBitsSetButton.Click += new EventHandler(actions.ZW030xFormActions.OnLockBitsSetClick);

            form.KeyDown += new System.Windows.Forms.KeyEventHandler(actions.ZW030xFormActions.OnKeyDown);
		}
        /// <summary>
        /// Drops the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Drop(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ZW030xForm form = (ZW030xForm)view;

            form.ProductionButton.Click -= new EventHandler(actions.ProgrammerActions.OnProductionClick);
            
            form.FlashBrowseHexFileButton.Click -= new EventHandler(actions.ZW030xFormActions.OnFlashBrowseHexFileClick);
            form.EepromBrowseHexFileButton.Click -= new EventHandler(actions.ZW030xFormActions.OnEEPROMBrowseHexFileClick);

            form.FlashEraseButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashEraseClick);
            form.FlashReadButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashReadClick);
            form.FlashWriteButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashWriteClick);
            form.FlashProgramButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashProgramClick);
            form.FlashCompareButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashCompareClick);
            form.FlashReadOptionsButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashReadOptionsClick);
            form.FlashWriteOptionsButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashWriteOptionsClick);

            form.EepromEraseButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMEraseClick);
            form.EepromReadButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMReadClick);
            form.EepromProgramButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMWriteClick);
            form.EepromCompareButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMCompareClick);

            form.ReadHomeIdButton.Click -= new EventHandler(actions.ProgrammerActions.OnReadHomeIdClick); 
            form.ChangeHomeIdButton.Click -= new EventHandler(actions.ProgrammerActions.OnWriteHomeIdClick);

            form.AutoIncrementHomeIdCheckBox.CheckedChanged -= new EventHandler(actions.CommonActions.OnAutoIncrementHomeIdCheckedChanged);
            documentModel.DocumentModelStateChanged -= new EventHandler<EventArgs>(actions.ZW030xFormActions.OnDocumentModelStateChanged);
            form.CurrentHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.StartHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.EndHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);

			form.LockBitsReadButton.Click -= new EventHandler(actions.ZW030xFormActions.OnLockBitsReadClick);
			form.LockBitsSetButton.Click -= new EventHandler(actions.ZW030xFormActions.OnLockBitsSetClick);

            form.KeyDown -= new System.Windows.Forms.KeyEventHandler(actions.ZW030xFormActions.OnKeyDown);
		}
        #endregion
    }
}
