using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Interfaces;
using ZWave.Programmer.UI;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Models;
using System.Windows.Forms;

namespace ZWave.Programmer.Dispatchers
{
    /// <summary>
    /// ZW050xFormDispatcher class. Bind/Unbind functions to the ZW050x Form controls.
    /// </summary>
    public class ZW050xFormDispatcher : IViewDispatcher
    {
        #region IViewDispatcher Members

        /// <summary>
        /// Binds the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Bind(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ZW050xForm form = (ZW050xForm)view;
            form.chkAddS2.CheckedChanged += new EventHandler(actions.ZW050xFormActions.OnAddS2CheckedChanged);
            form.chkGenerateS2.CheckedChanged += new EventHandler(actions.ZW050xFormActions.OnGenerateS2CheckedChanged);

            form.ProductionButton.Click += new EventHandler(actions.ProgrammerActions.OnProductionClick);

			form.SramBrowseHexFileButton.Click += new EventHandler(actions.ZW050xFormActions.OnSramBrowseHexFileClick);
			form.FlashBrowseHexFileButton.Click += new EventHandler(actions.ZW050xFormActions.OnFlashBrowseHexFileClick);
			form.EepromBrowseHexFileButton.Click += new EventHandler(actions.ZW050xFormActions.OnEEPROMBrowseHexFileClick);

            form.SramHexFileNameTextBox.TextChanged += new EventHandler(actions.ZW050xFormActions.OnSramHexFileNameChanged);
			form.FlashHexFileNameTextBox.TextChanged += new EventHandler(actions.ZW050xFormActions.OnFlashHexFileNameChanged);
			form.EepromHexFileNameTextBox.TextChanged += new EventHandler(actions.ZW050xFormActions.OnEepromHexFileNameChanged);

			form.SramReadButton.Click += new EventHandler(actions.ZW050xFormActions.OnSramReadClick);
			form.SramWriteButton.Click += new EventHandler(actions.ZW050xFormActions.OnSramWriteClick);
			form.SramCompareButton.Click += new EventHandler(actions.ZW050xFormActions.OnSramCompareClick);
			form.SramWriteAndRunModeButton.Click += new EventHandler(actions.ZW050xFormActions.OnSramWriteAndRunModeClick);

            form.FlashEraseButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashEraseClick);
			form.FlashReadButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashReadClick);
			form.CalibrateAndProgrammButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashCalibrateAndProgramClick);
            form.GetS2KeysButton.Click += new EventHandler(actions.ProgrammerActions.OnGetS2KeysClick);
            form.FlashCompareButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashCompareClick);
			form.FlashReadOptionsButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashReadOptionsClick);
			form.FlashWriteOptionsButton.Click += new EventHandler(actions.ProgrammerActions.OnFlashWriteOptionsClick);

			form.EepromEraseButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMEraseClick);
            form.EepromReadButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMReadClick);
            form.eepromReadModulesButton.Click += new EventHandler(actions.ZW050xFormActions.OnEEPROMReadModulesClick);
            form.eepromGetModuleButton.Click += new EventHandler(actions.ZW050xFormActions.OnEEPROMGetModuleClick);
            form.eepromSetModuleButton.Click += new EventHandler(actions.ZW050xFormActions.OnEEPROMSetModuleClick);
            form.EepromProgramButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMWriteClick);
			form.EepromCompareButton.Click += new EventHandler(actions.ProgrammerActions.OnEEPROMCompareClick);

			form.ReadHomeIdButton.Click += new EventHandler(actions.ProgrammerActions.OnReadHomeIdClick);
			form.ChangeHomeIdButton.Click += new EventHandler(actions.ProgrammerActions.OnWriteHomeIdClick);
			form.AutoIncrementHomeIdCheckBox.CheckedChanged += new EventHandler(actions.CommonActions.OnAutoIncrementHomeIdCheckedChanged);
            form.CurrentHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.StartHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.EndHomeIdTextBox.Validated += new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);

            form.RevTextBox.Validated += new EventHandler(actions.ZW050xFormActions.OnRevTextBoxValidated);

			form.LockBitsReadButton.Click += new EventHandler(actions.ZW050xFormActions.OnLockBitsReadClick);
			form.LockBitsSetButton.Click += new EventHandler(actions.ZW050xFormActions.OnLockBitsSetClick);
            form.ButtonSetAPM.Click += new EventHandler(actions.ZW050xFormActions.OnLockBitsSetAPMClick);

			documentModel.DocumentModelStateChanged += new EventHandler<EventArgs>(actions.ZW050xFormActions.OnDocumentModelStateChanged);

            form.KeyDown += new System.Windows.Forms.KeyEventHandler(actions.ZW050xFormActions.OnKeyDown);
            form.NvrReadButton.Click += new EventHandler(actions.ZW050xFormActions.OnNvrReadButtonClick);
            form.NvrWrteButton.Click += new EventHandler(actions.ZW050xFormActions.OnNvrWriteButtonClick);
        }

        /// <summary>
        /// Drops the functions to the specified view.
        /// </summary>
        /// <param name="view">The view.</param>
        /// <param name="actions">The actions (functions).</param>
        /// <param name="documentModel">The document model.</param>
        public void Drop(ContainerControl view, ActionCollection actions, DocumentModel documentModel)
        {
            ZW050xForm form = (ZW050xForm)view;
            form.chkAddS2.CheckedChanged -= new EventHandler(actions.ZW050xFormActions.OnAddS2CheckedChanged);
            form.chkGenerateS2.CheckedChanged -= new EventHandler(actions.ZW050xFormActions.OnGenerateS2CheckedChanged);

            form.ProductionButton.Click -= new EventHandler(actions.ProgrammerActions.OnProductionClick);

			form.SramBrowseHexFileButton.Click -= new EventHandler(actions.ZW050xFormActions.OnSramBrowseHexFileClick);
			form.FlashBrowseHexFileButton.Click -= new EventHandler(actions.ZW050xFormActions.OnFlashBrowseHexFileClick);
			form.EepromBrowseHexFileButton.Click -= new EventHandler(actions.ZW050xFormActions.OnEEPROMBrowseHexFileClick);

			form.SramHexFileNameTextBox.TextChanged -= new EventHandler(actions.ZW050xFormActions.OnSramHexFileNameChanged);
			form.FlashHexFileNameTextBox.TextChanged -= new EventHandler(actions.ZW050xFormActions.OnFlashHexFileNameChanged);
			form.EepromHexFileNameTextBox.TextChanged -= new EventHandler(actions.ZW050xFormActions.OnEepromHexFileNameChanged);

			form.SramReadButton.Click -= new EventHandler(actions.ZW050xFormActions.OnSramReadClick);
			form.SramWriteButton.Click -= new EventHandler(actions.ZW050xFormActions.OnSramWriteClick);
			form.SramCompareButton.Click -= new EventHandler(actions.ZW050xFormActions.OnSramCompareClick);
			form.SramWriteAndRunModeButton.Click -= new EventHandler(actions.ZW050xFormActions.OnSramWriteAndRunModeClick);

            form.FlashEraseButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashEraseClick);
			form.FlashReadButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashReadClick);
            form.CalibrateAndProgrammButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashCalibrateAndProgramClick);
            form.GetS2KeysButton.Click -= new EventHandler(actions.ProgrammerActions.OnGetS2KeysClick);
            form.FlashCompareButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashCompareClick);
			form.FlashReadOptionsButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashReadOptionsClick);
			form.FlashWriteOptionsButton.Click -= new EventHandler(actions.ProgrammerActions.OnFlashWriteOptionsClick);

			form.EepromEraseButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMEraseClick);
			form.EepromReadButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMReadClick);
            form.eepromReadModulesButton.Click -= new EventHandler(actions.ZW050xFormActions.OnEEPROMReadModulesClick);
            form.eepromGetModuleButton.Click -= new EventHandler(actions.ZW050xFormActions.OnEEPROMGetModuleClick);
            form.eepromSetModuleButton.Click -= new EventHandler(actions.ZW050xFormActions.OnEEPROMSetModuleClick);
            form.EepromProgramButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMWriteClick);
			form.EepromCompareButton.Click -= new EventHandler(actions.ProgrammerActions.OnEEPROMCompareClick);

			form.ReadHomeIdButton.Click -= new EventHandler(actions.ProgrammerActions.OnReadHomeIdClick);
			form.ChangeHomeIdButton.Click -= new EventHandler(actions.ProgrammerActions.OnWriteHomeIdClick);
			form.AutoIncrementHomeIdCheckBox.CheckedChanged -= new EventHandler(actions.CommonActions.OnAutoIncrementHomeIdCheckedChanged);
            form.CurrentHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.StartHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);
            form.EndHomeIdTextBox.Validated -= new EventHandler(actions.CommonActions.OnHomeIdTextBoxValidated);

            form.RevTextBox.Validated -= new EventHandler(actions.ZW050xFormActions.OnRevTextBoxValidated);

			form.LockBitsReadButton.Click -= new EventHandler(actions.ZW050xFormActions.OnLockBitsReadClick);
			form.LockBitsSetButton.Click -= new EventHandler(actions.ZW050xFormActions.OnLockBitsSetClick);
            form.ButtonSetAPM.Click -= new EventHandler(actions.ZW050xFormActions.OnLockBitsSetAPMClick);

			documentModel.DocumentModelStateChanged -= new EventHandler<EventArgs>(actions.ZW050xFormActions.OnDocumentModelStateChanged);

            form.KeyDown -= new System.Windows.Forms.KeyEventHandler(actions.ZW050xFormActions.OnKeyDown);
            form.NvrReadButton.Click -= new EventHandler(actions.ZW050xFormActions.OnNvrReadButtonClick);
            form.NvrWrteButton.Click -= new EventHandler(actions.ZW050xFormActions.OnNvrWriteButtonClick);
		}
        #endregion
    }
}
