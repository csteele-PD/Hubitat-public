using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ZWave.Programmer.Controllers;
using System.IO;
using ZWave.Framework;

namespace ZWave.Programmer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static int Main(string[] args)
        {
            Tools.CreateDebugExceptionFile("prg", Application.CommonAppDataPath, Application.UserAppDataPath);
            ControllerManager.Instance.IsConsoleMode = true;
            ControllerManager.Instance.Start(args);
            Tools.CloseDebugExceptionFile();
            return ControllerManager.ApplicationExitCode;
        }
    }
}