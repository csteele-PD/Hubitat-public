using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Controllers;
using ZWave.Programmer.UI;
using System.Windows.Forms;
using ZWave.Programmer.Properties;
using ZWave.Enums;
using System.IO;
using ZWave.Framework;
using System.Linq;

namespace ZWave.Programmer.Actions
{
    /// <summary>
    /// MainFormActions class. Contains Main Form functions.
    /// </summary>
    public class MainFormActions : BaseAction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainFormActions"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public MainFormActions(ControllerManager controller)
            : base(controller)
        {

        }
        #region Form
        /// <summary>
        /// Called when Form load.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFormLoad(object sender, EventArgs e)
        {
            LoadSettings();
            if (ControllerManager.DocumentModel.PortInfo != null && ControllerManager.DocumentModel.PortInfo.Caption.Contains("Silicon"))
            {
                ControllerManager.DoAction(new EventHandler(delegate
                {
                    ControllerManager.InitSpi();
                }), "Device initialization....", false, 0x00);
            }
        }

        /// <summary>
        /// Loads the Application settings.
        /// </summary>
        public void LoadSettings()
        {
            Win32PnPEntityClass portInfo = null;
            if (!String.IsNullOrEmpty(Settings.Default.LastUsedDevice))
            {
                try
                {
                    portInfo = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevice(Settings.Default.LastUsedDevice);
                }
                catch (System.Management.ManagementException)
                {
                    //ControllerManager.ShowMessage(mEx.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (portInfo == null)
            {
                portInfo = FindConnectedZdpBoard();
            }

            if (portInfo != null)
            {
                try
                {
                    SetPortToDocumentModel(portInfo);
                    Settings.Default.LastUsedDevice = ControllerManager.DocumentModel.PortInfo.DeviceID;
                }
                catch (Exception ex)
                {
                    ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            #region ZW010x
            if (ControllerManager.ZW010xForm != null && !ControllerManager.ZW010xForm.IsDisposed)
            {
                ControllerManager.ZW010xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW010x);
                ControllerManager.ZW010xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW010x);

                ControllerManager.ZW010xForm.AutoIncrementHomeIdCheckBox.Checked = Settings.Default.ZW010xAutoIncrementHomeId;
                ControllerManager.ZW010xForm.StartHomeIdTextBox.Text = Settings.Default.ZW010xAutoIncrementStartHomeId;
                ControllerManager.ZW010xForm.EndHomeIdTextBox.Text = Settings.Default.ZW010xAutoIncrementEndHomeId;
            }
            #endregion
            #region ZW020x
            if (ControllerManager.ZW020xForm != null && !ControllerManager.ZW020xForm.IsDisposed)
            {
                ControllerManager.ZW020xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW020x);
                ControllerManager.ZW020xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW020x);

                ControllerManager.ZW020xForm.AutoIncrementHomeIdCheckBox.Checked = Settings.Default.ZW020xAutoIncrementHomeId;
                ControllerManager.ZW020xForm.StartHomeIdTextBox.Text = Settings.Default.ZW020xAutoIncrementStartHomeId;
                ControllerManager.ZW020xForm.EndHomeIdTextBox.Text = Settings.Default.ZW020xAutoIncrementEndHomeId;
            }
            #endregion
            #region ZW030x
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {
                ControllerManager.ZW030xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW030x);
                ControllerManager.ZW030xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW030x);

                ControllerManager.ZW030xForm.AutoIncrementHomeIdCheckBox.Checked = Settings.Default.ZW030xAutoIncrementHomeId;
                ControllerManager.ZW030xForm.StartHomeIdTextBox.Text = Settings.Default.ZW030xAutoIncrementStartHomeId;
                ControllerManager.ZW030xForm.EndHomeIdTextBox.Text = Settings.Default.ZW030xAutoIncrementEndHomeId;
            }
            #endregion
            #region ZW040x
            if (ControllerManager.ZW040xForm != null && !ControllerManager.ZW040xForm.IsDisposed)
            {
                ControllerManager.ZW040xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW040x);
                ControllerManager.ZW040xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW040x);
                ControllerManager.ZW040xForm.SramHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetSramHexFileName(ChipTypes.ZW040x);
                ControllerManager.ZW040xForm.MtpHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetMtpHexFileName(ChipTypes.ZW040x);

                ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked = !Settings.Default.ZW040xAutoIncrementHomeId;		//for issuing checkbox state changed handler, which disable unneeded controls.
                ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked = Settings.Default.ZW040xAutoIncrementHomeId;
                ControllerManager.ZW040xForm.StartHomeIdTextBox.Text = Settings.Default.ZW040xAutoIncrementStartHomeId;
                ControllerManager.ZW040xForm.EndHomeIdTextBox.Text = Settings.Default.ZW040xAutoIncrementEndHomeId;

                ControllerManager.ZW040xForm.ModeDevelopmentRadioButton.Checked = (Settings.Default.ZW040xSramOperationMode == (int)WorkingModes.Development);
                ControllerManager.ZW040xForm.ModeExecOutOfSRAMRadioButton.Checked = (Settings.Default.ZW040xSramOperationMode == (int)WorkingModes.ExecuteOutOfSram);

                ControllerManager.ZW040xForm.MtpAutoEraseCheckBox.Checked = (Settings.Default.ZW040xMtpAutoErase);
            }
            #endregion
            #region ZW050x
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                ControllerManager.ZW050xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW050x);
                ControllerManager.ZW050xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW050x);
                ControllerManager.ZW050xForm.SramHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetSramHexFileName(ChipTypes.ZW050x);

                ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked = !Settings.Default.ZW050xAutoIncrementHomeId;		//for issuing checkbox state changed handler, which disable unneeded controls.
                ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked = Settings.Default.ZW050xAutoIncrementHomeId;
                ControllerManager.ZW050xForm.StartHomeIdTextBox.Text = Settings.Default.ZW050xAutoIncrementStartHomeId;
                ControllerManager.ZW050xForm.EndHomeIdTextBox.Text = Settings.Default.ZW050xAutoIncrementEndHomeId;

                ControllerManager.ZW050xForm.SetS2PrivateKey(Settings.Default.SecurityS2PrivateKey);
                ControllerManager.ZW050xForm.SetS2PublicKey(Settings.Default.SecurityS2PublicKey);
                ControllerManager.ZW050xForm.chkAddS2.Checked = Settings.Default.IsAddSecurity2Keys;
            }
            #endregion
        }

        private Win32PnPEntityClass FindConnectedZdpBoard()
        {
            Win32PnPEntityClass ret = null;
            List<Win32PnPEntityClass> ports = new List<Win32PnPEntityClass>();
            try
            {
                ports = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices();
            }
            catch (System.Management.ManagementException) { }

            ret = FindSiliconPort(ports);
            if (ret == null)
            {
                ret = FindSingleUzbPort(ports);
            }
            return ret;
        }

        private Win32PnPEntityClass FindSiliconPort(List<Win32PnPEntityClass> ports)
        {
            Win32PnPEntityClass ret = null;
            try
            {
                foreach (var port in ports)
                {
                    if (port.Caption.Contains("Silicon"))
                    {
                        ret = port;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return ret;
        }

        private Win32PnPEntityClass FindSingleUzbPort(List<Win32PnPEntityClass> ports)
        {
            Win32PnPEntityClass ret = null;
            try
            {
                if (ports != null)
                {
                    int uzbPortsCount = ports.Count(x => x.Description.ToUpper().Contains("UZB"));
                    if (uzbPortsCount == 1)
                    {
                        var port = ports.First(x => x.Description.ToUpper().Contains("UZB"));
                        ret = port;
                    }
                }
            }
            catch (Exception ex)
            {
                ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return ret;
        }

        private void SetPortToDocumentModel(Win32PnPEntityClass port)
        {
            ControllerManager.DocumentModel.PortInfo = port;
            if (Settings.Default.DetectTargetOnStartup == true)
            {
                OnDetectTargetClick(null, null);
            }
            else
            {
                ControllerManager.DocumentModel.SelectedChipType = Settings.Default.SelectedChipType;
            }
            if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.UNKNOWN)
            {
                ControllerManager.SetActiveViewByChipType((ChipTypes)ControllerManager.DocumentModel.SelectedChipType);
            }
            ControllerManager.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: " + ControllerManager.DocumentModel.PortInfo.DeviceID;
        }

        /// <summary>
        /// Called when Form closing.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFormClosing(object sender, EventArgs e)
        {
            ControllerManager.DeviceDeinit();
            SaveSettings();
        }

        /// <summary>
        /// Saves the Application settings.
        /// </summary>
        public void SaveSettings()
        {
            try
            {
                if (ControllerManager.ActiveView != null)
                {
                    Settings.Default.SelectedChipType = ControllerManager.DocumentModel.SelectedChipType;
                }
                #region ZW010x
                if (ControllerManager.ZW010xForm != null && !ControllerManager.ZW010xForm.IsDisposed)
                {
                    Settings.Default.ZW010xAutoIncrementHomeId = ControllerManager.ZW010xForm.AutoIncrementHomeIdCheckBox.Checked;
                    Settings.Default.ZW010xAutoIncrementStartHomeId = ControllerManager.ZW010xForm.StartHomeIdTextBox.Text;
                    Settings.Default.ZW010xAutoIncrementEndHomeId = ControllerManager.ZW010xForm.EndHomeIdTextBox.Text;
                }
                #endregion
                #region ZW020x
                if (ControllerManager.ZW020xForm != null && !ControllerManager.ZW020xForm.IsDisposed)
                {
                    Settings.Default.ZW020xAutoIncrementHomeId = ControllerManager.ZW020xForm.AutoIncrementHomeIdCheckBox.Checked;
                    Settings.Default.ZW020xAutoIncrementStartHomeId = ControllerManager.ZW020xForm.StartHomeIdTextBox.Text;
                    Settings.Default.ZW020xAutoIncrementEndHomeId = ControllerManager.ZW020xForm.EndHomeIdTextBox.Text;
                }
                #endregion
                #region ZW030x
                if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
                {
                    Settings.Default.ZW030xAutoIncrementHomeId = ControllerManager.ZW030xForm.AutoIncrementHomeIdCheckBox.Checked;
                    Settings.Default.ZW030xAutoIncrementStartHomeId = ControllerManager.ZW030xForm.StartHomeIdTextBox.Text;
                    Settings.Default.ZW030xAutoIncrementEndHomeId = ControllerManager.ZW030xForm.EndHomeIdTextBox.Text;
                }
                #endregion
                #region ZW040x
                if (ControllerManager.ZW040xForm != null && !ControllerManager.ZW040xForm.IsDisposed)
                {
                    Settings.Default.ZW040xAutoIncrementHomeId = ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked;
                    Settings.Default.ZW040xAutoIncrementStartHomeId = ControllerManager.ZW040xForm.StartHomeIdTextBox.Text;
                    Settings.Default.ZW040xAutoIncrementEndHomeId = ControllerManager.ZW040xForm.EndHomeIdTextBox.Text;
                    if (ControllerManager.ZW040xForm.ModeDevelopmentRadioButton.Checked)
                        Settings.Default.ZW040xSramOperationMode = (int)WorkingModes.Development;
                    else if (ControllerManager.ZW040xForm.ModeExecOutOfSRAMRadioButton.Checked)
                        Settings.Default.ZW040xSramOperationMode = (int)WorkingModes.ExecuteOutOfSram;
                    else
                        Settings.Default.ZW040xSramOperationMode = (int)WorkingModes.Development;
                    Settings.Default.ZW040xMtpAutoErase = ControllerManager.ZW040xForm.MtpAutoEraseCheckBox.Checked;
                }
                #endregion
                #region ZW050x
                if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
                {
                    Settings.Default.ZW050xAutoIncrementHomeId = ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked;
                    Settings.Default.ZW050xAutoIncrementStartHomeId = ControllerManager.ZW050xForm.StartHomeIdTextBox.Text;
                    Settings.Default.ZW050xAutoIncrementEndHomeId = ControllerManager.ZW050xForm.EndHomeIdTextBox.Text;

                    Settings.Default.SecurityS2PrivateKey = ControllerManager.ZW050xForm.GetS2PrivateKey();
                    Settings.Default.SecurityS2PublicKey = ControllerManager.ZW050xForm.GetS2PublicKey();
                    Settings.Default.IsAddSecurity2Keys = ControllerManager.ZW050xForm.chkAddS2.Checked;
                }
                #endregion
            }
            catch { }
            finally
            {
                Settings.Default.Save();
            }
        }

        #endregion

        #region View
        public void OnSelectedTabChanged(object sender, System.Windows.Forms.TabControlEventArgs e)
        {
            if (sender is TabControl && (sender as TabControl).SelectedTab != null)
            {
                ControllerManager.MainForm.CalibrateToolStripMenuItem.Enabled = false;
                ControllerManager.ActiveView = (UserControl)(sender as TabControl).SelectedTab.Controls[0];
                if (ControllerManager.ActiveView.Name == ControllerManager.ZW010xForm.Name)
                {
                    if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.ZW010x)
                        ControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW010x;
                }
                else if (ControllerManager.ActiveView.Name == ControllerManager.ZW020xForm.Name)
                {
                    if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.ZW020x)
                        ControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW020x;
                }
                else if (ControllerManager.ActiveView.Name == ControllerManager.ZW030xForm.Name)
                {
                    if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.ZW030x)
                        ControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW030x;
                }
                else if (ControllerManager.ActiveView.Name == ControllerManager.ZW040xForm.Name)
                {
                    ControllerManager.MainForm.CalibrateToolStripMenuItem.Enabled = true;
                    if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.ZW040x)
                        ControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW040x;
                }
                else if (ControllerManager.ActiveView.Name == ControllerManager.ZW050xForm.Name)
                {
                    if (ControllerManager.DocumentModel.SelectedChipType != (byte)ChipTypes.ZW050x)
                        ControllerManager.DocumentModel.SelectedChipType = (byte)ChipTypes.ZW050x;
                }
                ControllerManager.UpdateFrequencies();
            }
        }

        /// <summary>
        /// Called when ZW010x menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnZW010xClick(object sender, EventArgs e)
        {
            ShowTab(ControllerManager.ZW010xForm, "tp" + ControllerManager.ZW010xForm.Name, "ZW010x", ControllerManager.MainForm.ZW010xToolStripMenuItem);
        }
        /// <summary>
        /// Called when ZW020x menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnZW020xClick(object sender, EventArgs e)
        {
            ShowTab(ControllerManager.ZW020xForm, "tp" + ControllerManager.ZW020xForm.Name, "ZW020x", ControllerManager.MainForm.ZW020xToolStripMenuItem);
        }
        /// <summary>
        /// Called when ZW030x menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnZW030xClick(object sender, EventArgs e)
        {
            ShowTab(ControllerManager.ZW030xForm, "tp" + ControllerManager.ZW030xForm.Name, "ZW030x", ControllerManager.MainForm.ZW030xToolStripMenuItem);
        }
        /// <summary>
        /// Called when ZW040x menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnZW040xClick(object sender, EventArgs e)
        {
            ShowTab(ControllerManager.ZW040xForm, "tp" + ControllerManager.ZW040xForm.Name, "ZW040x", ControllerManager.MainForm.ZW040xToolStripMenuItem);
        }
        /// <summary>
        /// Called when ZW050x menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnZW050xClick(object sender, EventArgs e)
        {
            ShowTab(ControllerManager.ZW050xForm, "tp" + ControllerManager.ZW050xForm.Name, "ZW050x", ControllerManager.MainForm.ZW050xToolStripMenuItem);
        }

        private void ShowTab(UserControl ctrl, string key, string text, ToolStripMenuItem menu)
        {
            if (ControllerManager.MainForm.InvokeRequired)
            {
                ControllerManager.MainForm.Invoke(new EventHandler(delegate
                    {
                        ShowTab(ctrl, key, text, menu);
                    }));
            }
            else
            {
                var tabCtrl = ControllerManager.MainForm.mainTabControl;
                if (menu.Checked)
                {
                    TabPage tp;
                    if (!ControllerManager.MainForm.mainTabControl.TabPages.ContainsKey(key))
                    {
                        tp = new TabPage(text);
                        tp.UseVisualStyleBackColor = true;
                        tp.AutoScroll = true;
                        tp.Name = key;
                        tp.Controls.Add(ctrl);
                        int i;
                        for (i = 0; i < tabCtrl.TabCount; i++)
                        {
                            if (string.Compare(tabCtrl.TabPages[i].Name, tp.Name) > 0)
                                break;
                        }
                        tabCtrl.TabPages.Insert(i, tp);
                    }
                    else
                        tp = tabCtrl.TabPages[key];
                    tabCtrl.SelectedTab = null;
                    tabCtrl.SelectedTab = tp;
                }
                else
                {
                    tabCtrl.TabPages.RemoveByKey(key);
                }
            }
        }
        /// <summary>
        /// Called when Log menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnLogClick(object sender, EventArgs e)
        {
            if (ControllerManager.MainForm.LogToolStripMenuItem.Checked)
            {
                ControllerManager.LogForm.Show(ControllerManager.MainForm);
            }
            else
            {
                ControllerManager.LogForm.Hide();
            }
        }

        /// <summary>
        /// Called when Exit menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnExitClick(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        #endregion

        #region Other

        /// <summary>
        /// Called when Detect Target menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnDetectTargetClick(object sender, EventArgs e)
        {
            ControllerManager.Actions.ProgrammerActions.DetectDevice();
        }
        /// <summary>
        /// Called when Calibrate menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnCalibrateClick(object sender, EventArgs e)
        {
            ControllerManager.Actions.ProgrammerActions.CalibrateDevice();
        }

        /// <summary>
        /// Called when reset Z-Wave module menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnResetZWaveModuleClick(object sender, EventArgs e)
        {
            ControllerManager.Actions.ProgrammerActions.ResetZWaveModule();
        }
        /// <summary>
        /// Called when Upgrade Firmware menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnUpgradeFirmwareClick(object sender, EventArgs e)
        {
            ControllerManager.DoAction(new EventHandler(delegate
            {
                if (ControllerManager.Actions.ProgrammerActions.UpgradeLatestFirmware() > 0)
                {
                    ControllerManager.ShowMessage(Resources.MsgFirmwareUpgradeNotNeeded, false);
                }
            }), Resources.MsgUpgradeFirmwareProgress, false, 0x00);
        }
        /// <summary>
        /// Called when Upgrade Firmware menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnUploadFirmwareClick(object sender, EventArgs e)
        {
            string fileName = ControllerManager.Actions.CommonActions.BrowseFile();
            if (!String.IsNullOrEmpty(fileName) && File.Exists(fileName))
            {
                ControllerManager.DoAction(new EventHandler(delegate
                {
                    int version = 0;
                    int revision = 0;
                    if (ControllerManager.Actions.ProgrammerActions.UpgradeFirmware(fileName))
                    {
                        if (ControllerManager.Actions.ProgrammerActions.GetCurrentFirmwareVersion(out version, out revision))
                        {
                            ControllerManager.ShowMessage(Resources.MsgFirmwareUpgradedSuccesful, false);
                        }
                    }
                }), Resources.MsgUpgradeFirmwareProgress, false, 0x00);
            }
            else if (!String.IsNullOrEmpty(fileName))
            {
                ControllerManager.ShowMessage(String.Format("{0} does not exists.", fileName), true);
            }
        }
        /// <summary>
        /// Called when Settings menu item click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSettingsClick(object sender, EventArgs e)
        {
            ControllerManager.MainForm.Cursor = Cursors.WaitCursor;
            SettingsForm settingsForm = new SettingsForm();
            settingsForm.OnLoadInterfaces += new EventHandler(SettingsOnLoadInterfaces);
            settingsForm.CmdApply.Click += new EventHandler(SettingsApplyClick);
            settingsForm.MainTabControl.SelectedIndexChanged += new EventHandler(SettingsTabSelectedIndexChanged);
            settingsForm.SettingsPropertyGrid.SelectedObject = ControllerManager.DocumentModel.Settings;

            if (settingsForm.ShowDialog(ControllerManager.MainForm) == DialogResult.OK)
            {
                SaveSettings(settingsForm);
                ControllerManager.DeviceDeinit();

                if (ControllerManager.DocumentModel.PortInfo != null && ControllerManager.DocumentModel.PortInfo.Caption.Contains("Silicon"))
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.InitSpi();
                    }), "Device initialization....", false, 0x00);
                }
                if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
                {
                    ControllerManager.ZW050xForm.ClearData();
                }
                ControllerManager.Actions.ConsoleFormActions.OnClearClick(null, null);
                ControllerManager.Actions.LogFormActions.ClearData();
            }
            ControllerManager.UpdateFrequencies();
            ControllerManager.MainForm.Cursor = Cursors.Default;
            ControllerManager.SetProgMode = false;
        }

        private void SaveSettings(SettingsForm settingsForm)
        {
            ControllerManager.DocumentModel.PortInfo = settingsForm.SelectedPortInfo;
            ControllerManager.DocumentModel.Settings = (ProgrammerSettings)settingsForm.SettingsPropertyGrid.SelectedObject;
            ControllerManager.DocumentModel.Settings.Save();
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                Settings.Default.LastUsedDevice = ControllerManager.DocumentModel.PortInfo.DeviceID;
                ControllerManager.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: " + ControllerManager.DocumentModel.PortInfo.DeviceID;
            }
            else
            {
                Settings.Default.LastUsedDevice = "";
                ControllerManager.MainForm.SelectedSerialPortStatusLabel.Text = "Serial Port: None";
            }
            Settings.Default.Save();
        }

        void SettingsTabSelectedIndexChanged(object sender, EventArgs e)
        {
            SettingsForm settingsForm = (SettingsForm)(sender as TabControl).FindForm();
            if (settingsForm != null)
            {
                if (settingsForm.MainTabControl.SelectedIndex == 0)
                {
                    SettingsOnLoadInterfaces(settingsForm, EventArgs.Empty);
                }
            }

        }

        void SettingsApplyClick(object sender, EventArgs e)
        {
            SettingsForm settingsForm = (SettingsForm)(sender as Button).FindForm();
            if (settingsForm != null)
            {
                SaveSettings(settingsForm);
            }
        }
        private void SettingsOnLoadInterfaces(object sender, EventArgs e)
        {
            if (sender is SettingsForm)
            {
                List<Win32PnPEntityClass> interfaces = new List<Win32PnPEntityClass>();
                SettingsForm form = sender as SettingsForm;
                try
                {
                    if (!String.IsNullOrEmpty(Settings.Default.InterfaceFilter))
                    {
                        interfaces = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices(String.Format(" and Caption Like '%{0}%'", Settings.Default.InterfaceFilter));
                    }
                    else
                    {
                        interfaces = ComputerSystemHardwareHelper.GetWin32PnPEntityClassSerialPortDevices();
                    }
                }
                catch (System.Management.ManagementException)
                {
                    //ControllerManager.ShowMessage(mEx.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    ControllerManager.ShowMessage(ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                form.InterfacesListBox.Items.Clear();
                form.NoCommInterfacesLabel.Text = "";
                if (interfaces != null && interfaces.Count > 0)
                {
                    form.InterfacesListBox.Enabled = true;
                    foreach (Win32PnPEntityClass serialPortInfo in interfaces)
                    {
                        if (!String.IsNullOrEmpty(Settings.Default.LastUsedDevice) && Settings.Default.LastUsedDevice == serialPortInfo.DeviceID)
                        {
                            form.SelectedPortInfo = serialPortInfo;
                            form.InterfacesListBox.Items.Add(new InterfaceWrapper(serialPortInfo), true);
                        }
                        else
                        {
                            form.InterfacesListBox.Items.Add(new InterfaceWrapper(serialPortInfo), false);
                        }
                    }
                }
                else
                {
                    form.InterfacesListBox.Enabled = false;
                    form.NoCommInterfacesLabel.Text = Resources.MsgNoCommInterfaces;
                }
            }
        }
        #endregion

        /// <summary>
        /// Called when DocumentModel state changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnDocumentModelStateChanged(object sender, EventArgs e)
        {
        }

        public void OnKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D && e.Control) OnDetectTargetClick(null, null);

        }
    }
}
