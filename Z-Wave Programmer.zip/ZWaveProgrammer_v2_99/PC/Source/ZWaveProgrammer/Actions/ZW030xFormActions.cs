using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Controllers;
using ZWave.Enums;
using ZWave.Programmer.Properties;
using System.Windows.Forms;

namespace ZWave.Programmer.Actions
{
    /// <summary>
    /// ZW030xFormActions class. Contains ZW030x Form functions.
    /// </summary>
    public class ZW030xFormActions : BaseAction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ZW030xFormActions"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public ZW030xFormActions(ControllerManager controller)
            : base(controller)
        {

        }

        /// <summary>
        /// Called when Flash browse HEX file click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFlashBrowseHexFileClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {
                ControllerManager.DocumentModel.SetFlashHexFileName(ChipTypes.ZW030x, ControllerManager.Actions.CommonActions.BrowseFile());
                ControllerManager.ZW030xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW030x);
                ControllerManager.Actions.ProgrammerActions.UpdateUserFlashSettingsToDefault(ChipTypes.ZW030x);
            }
        }
        /// <summary>
        /// Called when EEPROM browse HEX file click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnEEPROMBrowseHexFileClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {
                ControllerManager.DocumentModel.SetEepromHexFileName(ChipTypes.ZW030x, ControllerManager.Actions.CommonActions.BrowseFile());
                ControllerManager.ZW030xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW030x);
            }
        }

        /// <summary>
        /// Called when Flash HEX file name changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFlashHexFileNameChanged(object sender, EventArgs e)
        {
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {
                //ControllerManager.DocumentModel.SetFlashHexFileName(ChipTypes.ZW030x, ControllerManager.ZW030xForm.FlashHexFileNameTextBox.Text);
            }
        }

        /// <summary>
        /// Called when EEPROM HEX file name changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnEepromHexFileNameChanged(object sender, EventArgs e)
        {
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {
                //ControllerManager.DocumentModel.SetEepromHexFileName(ChipTypes.ZW030x, ControllerManager.ZW030xForm.EepromHexFileNameTextBox.Text);
            }
        }
        /// <summary>
        /// Called when DocumentModel state changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnDocumentModelStateChanged(object sender, EventArgs e)
        {
            OnDocumentModelStateChanged();
        }

        private delegate void OnDocumentModelStateChangedDelegate();
        private void OnDocumentModelStateChanged()
        {
            if (ControllerManager.ZW030xForm != null && !ControllerManager.ZW030xForm.IsDisposed)
            {

                if (ControllerManager.ZW030xForm.InvokeRequired)
                {
                    ControllerManager.ZW030xForm.Invoke(new OnDocumentModelStateChangedDelegate(OnDocumentModelStateChanged));
                }
                else
                {
                    ControllerManager.ZW030xForm.FlashProgramButton.Enabled =
                    ControllerManager.ZW030xForm.FlashWriteButton.Enabled =
                    ControllerManager.ZW030xForm.FlashCompareButton.Enabled =
                        ControllerManager.DocumentModel.FlashHexFileSelected(ChipTypes.ZW030x);

                    ControllerManager.ZW030xForm.EepromProgramButton.Enabled =
                    ControllerManager.ZW030xForm.EepromCompareButton.Enabled =
                        ControllerManager.DocumentModel.EepromHexFileSelected(ChipTypes.ZW030x);

                }
            }
        }

		/// <summary>
		/// Called when Set Lock Bits click.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		public void OnLockBitsSetClick(object sender, EventArgs e)
		{
			ControllerManager.Actions.ProgrammerActions.OnLockBitsSet(
				ControllerManager.ZW030xForm.LockBitsDisableFlashReadCheckBox.Checked,
				ControllerManager.ZW030xForm.LockBitsBootBlockLockCheckBox.Checked,
				ControllerManager.ZW030xForm.LockBitsBootSectorSizeComboBox.SelectedIndex);
		}

		/// <summary>
		/// Called when Read Lock Bits click.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		public void OnLockBitsReadClick(object sender, EventArgs e)
		{
			bool disableFlashRead, lockBootBlock;
			int bootSectorSize;

			ControllerManager.Actions.ProgrammerActions.OnLockBitsRead(
				out disableFlashRead, out lockBootBlock, out bootSectorSize);

			ControllerManager.ZW030xForm.LockBitsDisableFlashReadCheckBox.Checked = disableFlashRead;
			ControllerManager.ZW030xForm.LockBitsBootBlockLockCheckBox.Checked = lockBootBlock;
			ControllerManager.ZW030xForm.LockBitsBootSectorSizeComboBox.SelectedIndex = bootSectorSize;
		}

        public void OnKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.O)
            {
                OnFlashBrowseHexFileClick(null, null);
            }
            if (e.Control && e.KeyCode == Keys.P)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashProgramClick(null, null);
            }
            if (e.Control && e.KeyCode == Keys.W)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashWriteClick(null, null);
            }
            if (e.Control && e.KeyCode == Keys.E)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashEraseClick(null, null);
            }
            if (e.Control && e.KeyCode == Keys.R)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashReadClick(null, null);
            }
            if (e.Control && e.KeyCode == Keys.M)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashCompareClick(null, null);
            }
            if (e.Shift && e.KeyCode == Keys.W)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashWriteOptionsClick(null, null);
            }
            if (e.Shift && e.KeyCode == Keys.R)
            {
                ControllerManager.Actions.ProgrammerActions.OnFlashReadOptionsClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.O)
            {
                OnEEPROMBrowseHexFileClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.P)
            {
                ControllerManager.Actions.ProgrammerActions.OnEEPROMWriteClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.E)
            {
                ControllerManager.Actions.ProgrammerActions.OnEEPROMEraseClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.R)
            {
                ControllerManager.Actions.ProgrammerActions.OnEEPROMReadClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.M)
            {
                ControllerManager.Actions.ProgrammerActions.OnEEPROMCompareClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.F1)
            {
                ControllerManager.Actions.ProgrammerActions.OnWriteHomeIdClick(null, null);
            }
            if (e.Alt && e.KeyCode == Keys.F2)
            {
                ControllerManager.Actions.ProgrammerActions.OnReadHomeIdClick(null, null);
            }
        }
    }
}
