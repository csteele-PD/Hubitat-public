using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Controllers;
using ZWave.Logging;
using ZWave.Framework;
using System.Windows.Forms;
using System.Threading;
using ZWave.Programmer.UI;
using System.Data;

namespace ZWave.Programmer.Actions
{
    /// <summary>
    /// LogFormActions class. Contains Log Form functions.
    /// </summary>
    public class LogFormActions : BaseAction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LogFormActions"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public LogFormActions(ControllerManager controller)
            : base(controller)
        {

        }
        #region Form
        /// <summary>
        /// Called when Form load.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFormLoad(object sender, EventArgs e)
        {
            BindData();
            ControllerManager.MainForm.LogToolStripMenuItem.Checked = true;
        }

        private void BindData()
        {
            if (_logPacketsConsumerQueue != null)
                _logPacketsConsumerQueue.Stop();
            _logPacketsConsumerQueue = new ConsumerList<LogPacket>();
            _logPacketsConsumerQueue.Start(ZWaveManager_LogPacketAdded, 300);
            ControllerManager.ZWaveManager.LogPacketAdded += new LogPacketDelegate(_logPacketsConsumerQueue.Add);
        }

        private ConsumerList<LogPacket> _logPacketsConsumerQueue;

        void ZWaveManager_LogPacketAdded(LinkedList<LogPacket> logPackets)
        {
            if (ControllerManager.LogForm != null && ControllerManager.LogForm.IsDisposed == false && ControllerManager.LogForm.Visible)
            {
                if (ControllerManager.LogForm.InvokeRequired)
                {
                    ControllerManager.LogForm.BeginInvoke(new EventHandler(delegate
                    {
                        WritePackets(logPackets);
                    }), null);
                }
                else
                {
                    WritePackets(logPackets);
                }
            }
        }
        public void ClearData()
        {
            if (ControllerManager.LogForm != null && ControllerManager.LogForm.IsDisposed == false)
            {
                ControllerManager.LogForm.logGridViewControl.Clear();
            }
        }

        private void WritePackets(LinkedList<LogPacket> logPackets)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var logPacket in logPackets)
            {
                string application = logPacket.ApplicationString.PadRight(36, ' ');
                sb.AppendFormat("{0}\t{1:HH:mm:ss.fff}\t{2}\t{3}{4}",
                    logPacket.IsPut ? ">>" : "<<",
                    logPacket.Time,
                    application,
                    Tools.GetHex(logPacket.Payload),
                    Environment.NewLine);

            }
            ControllerManager.LogForm.logGridViewControl.AddText(sb.ToString());
        }

        public void OnFormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            if (ControllerManager.LogForm.Visible)
            {
                ControllerManager.MainForm.LogToolStripMenuItem.Checked = false;
                ControllerManager.LogForm.Hide();
                e.Cancel = true;
            }
        }
        #endregion
    }
}
