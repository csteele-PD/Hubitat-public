using System;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Controllers;
using System.Windows.Forms;
using ZWave.Programmer.UI;
using ZWave.Devices;
using ZWave.Enums;
using ZWave.Framework;

namespace ZWave.Programmer.Actions
{
    /// <summary>
    /// CommonActions class. Contains common functions.
    /// </summary>
    public class CommonActions : BaseAction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommonActions"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>
        public CommonActions(ControllerManager controller)
            : base(controller)
        {

        }

        /// <summary>
        /// Browse the HEX file (Flash, EEPROM, SRAM etc.).
        /// </summary>
        /// <returns></returns>
        public string BrowseFile()
        {
            string fileName = "";
            using (OpenFileDialog dlgOpenFile = new OpenFileDialog())
            {
                dlgOpenFile.Filter = "Intel hex files (*.hex)|*.hex|All files (*.*)|*.*";
                dlgOpenFile.FilterIndex = 1;
                if (dlgOpenFile.ShowDialog() == DialogResult.OK)
                {
                    fileName = dlgOpenFile.FileName;
                }
            }
            return fileName;
        }
        internal void OnAutoIncrementHomeIdCheckedChanged(object sender, EventArgs e)
        {
            if (sender is CheckBox)
            {
                if (ControllerManager.ActiveView != null)
                {
                    if (ControllerManager.ActiveView.Name == ControllerManager.ZW010xForm.Name)
                    {
                        ControllerManager.ZW010xForm.StartHomeIdTextBox.Enabled = ControllerManager.ZW010xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW010xForm.EndHomeIdTextBox.Enabled = ControllerManager.ZW010xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW010xForm.CurrentHomeIdTextBox.Enabled = !ControllerManager.ZW010xForm.AutoIncrementHomeIdCheckBox.Checked;
                    }
                    else if (ControllerManager.ActiveView.Name == ControllerManager.ZW020xForm.Name)
                    {
                        ControllerManager.ZW020xForm.StartHomeIdTextBox.Enabled = ControllerManager.ZW020xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW020xForm.EndHomeIdTextBox.Enabled = ControllerManager.ZW020xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW020xForm.CurrentHomeIdTextBox.Enabled = !ControllerManager.ZW020xForm.AutoIncrementHomeIdCheckBox.Checked;
                    }
                    else if (ControllerManager.ActiveView.Name == ControllerManager.ZW030xForm.Name)
                    {
                        ControllerManager.ZW030xForm.StartHomeIdTextBox.Enabled = ControllerManager.ZW030xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW030xForm.EndHomeIdTextBox.Enabled = ControllerManager.ZW030xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW030xForm.CurrentHomeIdTextBox.Enabled = !ControllerManager.ZW030xForm.AutoIncrementHomeIdCheckBox.Checked;
                    }
                    else if (ControllerManager.ActiveView.Name == ControllerManager.ZW040xForm.Name)
                    {
                        ControllerManager.ZW040xForm.StartHomeIdTextBox.Enabled = ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW040xForm.EndHomeIdTextBox.Enabled = ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW040xForm.CurrentHomeIdTextBox.Enabled = !ControllerManager.ZW040xForm.AutoIncrementHomeIdCheckBox.Checked;
                    }
                    else if (ControllerManager.ActiveView.Name == ControllerManager.ZW050xForm.Name)
                    {
                        ControllerManager.ZW050xForm.StartHomeIdTextBox.Enabled = ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW050xForm.EndHomeIdTextBox.Enabled = ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked;
                        ControllerManager.ZW050xForm.CurrentHomeIdTextBox.Enabled = !ControllerManager.ZW050xForm.AutoIncrementHomeIdCheckBox.Checked;
                    }
                }
            }
        }
        public void OnHomeIdTextBoxValidated(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox txt = sender as TextBox;
                if (!String.IsNullOrEmpty(txt.Text))
                {
                    try
                    {
                        byte[] data = Tools.FromHexString(txt.Text);
                        byte[] _data = new byte[4];
                        Array.Copy(data, _data, 4);
                        txt.Text = Tools.GetHex(_data).Replace(" ", "");
                    }
                    catch
                    {
                        txt.Text = "";
                    }
                }
            }
        }
        /// <summary>
        /// Checks the device chip type compatibility.
        /// </summary>
        /// <param name="device">The device.</param>
        /// <returns></returns>
        public bool CheckDeviceChipTypeCompatibility(IProgrammableDevice device)
        {
            return ControllerManager.DocumentModel.SelectedChipType == device.ChipType;
        }
    }
}
