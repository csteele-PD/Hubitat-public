using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using ZWave.Programmer.Classes;
using ZWave.Programmer.Controllers;
using ZWave.Enums;
using ZWave.Devices;
using ZWave.Programmer.Properties;
using System.IO;
using System.Windows.Forms;
using ZWave.Programmer.UI;
using System.Globalization;
using System.Threading;
using ZWave.Framework;

namespace ZWave.Programmer.Actions
{
    /// <summary>
    /// ZW050xFormActions class. Contains ZW050x Form functions.
    /// </summary>
    public class ZW050xFormActions : BaseAction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ZW050xFormActions"/> class.
        /// </summary>
        /// <param name="controller">The controller.</param>

        bool _isWriteSucceed = true;

        public ZW050xFormActions(ControllerManager controller)
            : base(controller)
        {

        }
        #region Form

        public void MapNVRData2Form(ZW050xForm form, NVRData nvrData, byte[] nvrData2)
        {
            byte[] lotId = new byte[4];
            byte waferId = 0;
            byte[] rowId = new byte[2];
            byte[] columnId = new byte[2];
            if (nvrData2 != null && nvrData2.Length > 0x1C)
            {
                Array.Copy(nvrData2, 0x14, lotId, 0, 4);
                Array.Reverse(lotId);
                waferId = nvrData2[0x18];
                Array.Copy(nvrData2, 0x19, rowId, 0, 2);
                Array.Reverse(rowId);
                Array.Copy(nvrData2, 0x1B, columnId, 0, 2);
                Array.Reverse(columnId);
            }
            if (_isWriteSucceed)
            {
                form.Invoke(new EventHandler(delegate
                {
                    form.RevTextBox.Text = Tools.ToHexString(nvrData.REV);
                    form.CcalTextBox.Text = Tools.ToHexString(nvrData.CCAL);
                    form.PinsTextBox.Text = Tools.ToHexString(nvrData.PINS);
                    form.NvmcsTextBox.Text = Tools.ToHexString(nvrData.NVMCS);
                    form.SawcTextBox.Text = Tools.ToHexString(nvrData.SAWC, "");
                    form.SawbTextBox.Text = Tools.ToHexString(nvrData.SAWB);
                    form.NvmtTextBox.Text = Tools.ToHexString(nvrData.NVMT);
                    form.NvmsTextBox.Text = Tools.ToHexString(nvrData.NVMS, " ");
                    form.NvmpTextBox.Text = Tools.ToHexString(nvrData.NVMP, " ");
                    form.UuidTextBox.Text = Tools.ToHexString(nvrData.UUID, " ");
                    form.VidTextBox.Text = Tools.ToHexString(nvrData.VID, " ");
                    form.PidTextBox.Text = Tools.ToHexString(nvrData.PID, " ");
                    form.Txcal1TextBox.Text = Tools.ToHexString(nvrData.TXCAL1);
                    form.Txcal2TextBox.Text = Tools.ToHexString(nvrData.TXCAL2);
                    form.Crc16TextBox.Text = Tools.ToHexString(nvrData.CRC16, " ");
                    form.HwTextBox.Text = Tools.ToHexString(nvrData.HW);
                    form.TagTextBox.Text = string.Format("{0} - {1} [{2},{3}]", Tools.ToHexString(lotId, ""), waferId.ToString("X2"), Tools.ToHexString(rowId, "").Substring(1), Tools.ToHexString(columnId, "").Substring(1));
                }));
            }
        }
        public void MapForm2NVRData(ZW050xForm form, NVRData nvrData)
        {
            form.Invoke(new EventHandler(delegate
            {
                byte[] tArr = Tools.FromHexString(form.RevTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.REV = tArr[0];

                tArr = Tools.FromHexString(form.CcalTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.CCAL = tArr[0];

                tArr = Tools.FromHexString(form.PinsTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.PINS = tArr[0];

                tArr = Tools.FromHexString(form.NvmcsTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.NVMCS = tArr[0];

                tArr = Tools.FromHexString(form.SawcTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.SAWC.Length)
                    nvrData.SAWC = tArr;

                tArr = Tools.FromHexString(form.SawbTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.SAWB = tArr[0];

                tArr = Tools.FromHexString(form.NvmtTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.NVMT = tArr[0];

                tArr = Tools.FromHexString(form.NvmsTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.NVMS.Length)
                    nvrData.NVMS = tArr;

                tArr = Tools.FromHexString(form.NvmpTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.NVMP.Length)
                    nvrData.NVMP = tArr;

                tArr = Tools.FromHexString(form.UuidTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.UUID.Length)
                    nvrData.UUID = tArr;

                tArr = Tools.FromHexString(form.VidTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.VID.Length)
                    nvrData.VID = tArr;

                tArr = Tools.FromHexString(form.PidTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == nvrData.PID.Length)
                    nvrData.PID = tArr;

                tArr = Tools.FromHexString(form.Txcal1TextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.TXCAL1 = tArr[0];

                tArr = Tools.FromHexString(form.Txcal2TextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.TXCAL2 = tArr[0];

                tArr = Tools.FromHexString(form.HwTextBox.Text.Replace(" ", ""));
                if (tArr.Length > 0 && tArr.Length == 1)
                    nvrData.HW = tArr[0];

                nvrData.CalculateCrc16();
            }));
            MapNVRData2Form(form, nvrData, null);
        }

        #endregion

        public void OnAddS2CheckedChanged(object sender, EventArgs e)
        {
            ControllerManager.DocumentModel.IsAddSecurity2Keys = ControllerManager.ZW050xForm.chkAddS2.Checked;
        }

        public void OnGenerateS2CheckedChanged(object sender, EventArgs e)
        {
            ControllerManager.DocumentModel.IsGenerateSecurity2Keys = ControllerManager.ZW050xForm.chkGenerateS2.Checked;
        }

        /// <summary>
        /// Called when SRAM browse HEX file click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramBrowseHexFileClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                ControllerManager.DocumentModel.SetSramHexFileName(ChipTypes.ZW050x, ControllerManager.Actions.CommonActions.BrowseFile());
                ControllerManager.ZW050xForm.SramHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetSramHexFileName(ChipTypes.ZW050x);
            }
        }

        /// <summary>
        /// Called when SRAM HEX file name changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramHexFileNameChanged(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                //ControllerManager.DocumentModel.SetSramHexFileName(ChipTypes.ZW050x, ControllerManager.ZW050xForm.SramHexFileNameTextBox.Text);
            }
        }

        /// <summary>
        /// Called when Flash browse HEX file click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFlashBrowseHexFileClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                ControllerManager.DocumentModel.SetFlashHexFileName(ChipTypes.ZW050x, ControllerManager.Actions.CommonActions.BrowseFile());
                ControllerManager.ZW050xForm.FlashHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetFlashHexFileName(ChipTypes.ZW050x);
                ControllerManager.Actions.ProgrammerActions.UpdateUserFlashSettingsToDefault(ChipTypes.ZW050x);
            }
        }
        /// <summary>
        /// Called when EEPROM browse HEX file click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnEEPROMBrowseHexFileClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                ControllerManager.DocumentModel.SetEepromHexFileName(ChipTypes.ZW050x, ControllerManager.Actions.CommonActions.BrowseFile());
                ControllerManager.ZW050xForm.EepromHexFileNameTextBox.Text = ControllerManager.DocumentModel.GetEepromHexFileName(ChipTypes.ZW050x);
            }
        }

        /// <summary>
        /// Called when Flash HEX file name changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnFlashHexFileNameChanged(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                //ControllerManager.DocumentModel.SetFlashHexFileName(ChipTypes.ZW050x, ControllerManager.ZW050xForm.FlashHexFileNameTextBox.Text);
            }
        }

        /// <summary>
        /// Called when EEPROM HEX file name changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnEepromHexFileNameChanged(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                //ControllerManager.DocumentModel.SetEepromHexFileName(ChipTypes.ZW050x, ControllerManager.ZW050xForm.EepromHexFileNameTextBox.Text);
            }
        }

        /// <summary>
        /// Return SRAM Working Mode, selected by user
        /// </summary>
        public WorkingModes GetSelectedWorkingMode()
        {
            return WorkingModes.ExecuteOutOfSram;
        }

        #region SRAM

        /// <summary>
        /// Called when SRAM read click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramReadClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                WorkingModes workingMode = GetSelectedWorkingMode();
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        SramRead(null, workingMode);
                    }), Resources.MsgReadSramProgress, false, 0x00);
                }
                else if (progInterface == 1)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.DeviceInit();
                        SramRead(null, ControllerManager.DocumentModel.PortInfo, 1);
                        ControllerManager.RestoreSelectedDevice();
                    }), Resources.MsgReadSramProgress, false, 0x00);
                }
                else if (progInterface == 2)
                {
                    //TODO USB
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }

        /// <summary>
        /// Called when SRAM write click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramWriteClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                WorkingModes workingMode = GetSelectedWorkingMode();
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        SramWrite(null, workingMode);
                    }), Resources.MsgWriteSramProgress, false, 0x00);
                }
                else if (progInterface == 1)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.DeviceInit();
                        SramWrite(null, workingMode, ControllerManager.DocumentModel.PortInfo, progInterface);
                        ControllerManager.RestoreSelectedDevice();
                    }), Resources.MsgWriteSramProgress, false, 0x00);
                }
                else if (progInterface == 2)
                {
                    //TODO USB
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }
        /// <summary>
        /// Called when SRAM compare click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramCompareClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                WorkingModes workingMode = GetSelectedWorkingMode();

                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                {
                    SramCompare(null, workingMode);
                }), Resources.MsgCompareSramProgress, false, 0x00);

                }
                else if (progInterface == 1)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.DeviceInit();
                        SramCompare(null, workingMode, ControllerManager.DocumentModel.PortInfo, progInterface);
                        ControllerManager.RestoreSelectedDevice();
                    }), Resources.MsgCompareSramProgress, false, 0x00);

                }
                else if (progInterface == 2)
                {
                    //TODO USB
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }
        /// <summary>
        /// Called when SRAM write and run development mode click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramWriteAndRunModeClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                WorkingModes workingMode = WorkingModes.ExecuteOutOfSram;
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        SramWriteAndRunMode(null, workingMode);
                    }), Resources.MsgWriteSramProgress, false, 0x00);
                }
                else if (progInterface == 1)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.DeviceInit();
                        SramWriteAndRunMode(null, workingMode, ControllerManager.DocumentModel.PortInfo, progInterface);
                        ControllerManager.RestoreSelectedDevice();
                    }), Resources.MsgWriteSramProgress, false, 0x00);
                }
                else if (progInterface == 2)
                {
                    //TODO USB
                }



            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }
        /// <summary>
        /// Called when SRAM write and execute out of SRAM mode click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramWriteAndExecOutOfSramClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                ControllerManager.DoAction(new EventHandler(delegate
                {
                    SramWriteAndExecOutOfSram(null);
                }), Resources.MsgWriteSramProgress, false, 0x00);

            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }
        /// <summary>
        /// Called when Sram Write options click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnSramWriteOptionsClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                ControllerManager.DoAction(new EventHandler(delegate
                {
                    SramWriteOptions(null);

                }), Resources.MsgWriteSramOptionsProgress, false, 0x00);
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }


        /// <summary>
        /// Reads the SRAM.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramRead(string fileName, WorkingModes workingMode)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadSramProgress);
            int fileOffset = 0;
            int sramOffset = 0;
            byte[] sramBuffer = null;
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        device.SetBusyLedState(true);
                        switch (workingMode)
                        {
                            case WorkingModes.Development:
                                {
                                    fileOffset = (int)(device.FlashSize - Constants.SRAM_DEVMODE_SIZE);
                                    sramOffset = (int)Constants.SRAM_DEVMODE_OFFSET;
                                }
                                break;
                        }
                        if (!device.Memory.ReadSRAM())
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantReadSram, true);
                        }

                        if (device.Memory.Buffer != null)
                        {
                            sramBuffer = HexFileHelper.BlankArray(device.Memory.Buffer.Length - sramOffset, Constants.SRAM_BLANK_VALUE);
                            for (int i = 0; i < device.Memory.Buffer.Length - sramOffset; i++)
                            {
                                sramBuffer[i] = device.Memory.Buffer[sramOffset + i];
                            }
                        }

                        device.SetBusyLedState(false);
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantReadSram, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }
            if (sramBuffer != null)
            {
                if (ControllerManager.IsConsoleMode)
                {
                    try
                    {
                        if (sramBuffer.Length > 0)
                        {
                            TextWriter writer = new StreamWriter(fileName);
                            writer.Write(HexFileHelper.WriteIntelHexFile(sramBuffer, fileOffset, sramBuffer.Length, 0x10, Constants.SRAM_BLANK_VALUE, false));
                            writer.Close();
                        }
                        ControllerManager.ShowMessage("Read SRAM completed.", false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    ControllerManager.ShowConsoleInfo(HexFileHelper.WriteIntelHexFile(sramBuffer, fileOffset, sramBuffer.Length, 0x10, Constants.SRAM_BLANK_VALUE, false));
                    ControllerManager.ShowMessageInStatus("Read SRAM completed.", false);
                }
            }
        }

        public void SramRead(string fileName, Win32PnPEntityClass portInfo, int progInterface)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadSramProgress);
            if (!ControllerManager.IsConsoleMode)
            {
                ControllerManager.ClearZW050xFormData();
            }
            int fileOffset = 0;
            int sramOffset = 0;
            byte[] sramBuffer = null;
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    //device.ReadSignatureBits();
                    //if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    //{
                    byte[] buffer = device.ReadSRAM();
                    if (buffer != null)
                    {
                        sramBuffer = HexFileHelper.BlankArray(buffer.Length - sramOffset, Constants.SRAM_BLANK_VALUE);
                        for (int i = 0; i < buffer.Length - sramOffset; i++)
                        {
                            sramBuffer[i] = buffer[sramOffset + i];
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.ErrorCantReadSram, true);
                    }

                    //}
                    //else
                    //{
                    //    ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    //}
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantReadSram, true);
            }
            finally
            {
                device.Close();
            }
            if (sramBuffer != null)
            {
                if (ControllerManager.IsConsoleMode)
                {
                    try
                    {
                        if (sramBuffer.Length > 0)
                        {
                            TextWriter writer = new StreamWriter(fileName);
                            writer.Write(HexFileHelper.WriteIntelHexFile(sramBuffer, fileOffset, sramBuffer.Length, 0x10, Constants.SRAM_BLANK_VALUE, false));
                            writer.Close();
                        }
                        ControllerManager.ShowMessage("Read SRAM completed.", false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    ControllerManager.ShowConsoleInfo(HexFileHelper.WriteIntelHexFile(sramBuffer, fileOffset, sramBuffer.Length, 0x10, Constants.SRAM_BLANK_VALUE, false));
                    ControllerManager.ShowMessageInStatus("Read SRAM completed.", false);
                    if (device.Type != AutoProgDeviceTypes.UART)
                    {
                        ControllerManager.InvokeMainFormAction(() =>
                            ControllerManager.ConsoleForm.ShowSramWarning(true));
                    }
                }
            }
        }
        public bool WirteHEXToSRAM(AutoProgDevice device, string fileName, int fileOffset, int sramOffset, IFlashSettings rfSettings)
        {
            bool result = true;
            if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
            {

                string hexFileName = fileName;
                if (!String.IsNullOrEmpty(hexFileName) && File.Exists(hexFileName))
                {
                    byte[] flashDataRaw = HexFileHelper.GetBytes(HexFileHelper.ReadIntelHexFile(hexFileName, Constants.SRAM_BLANK_VALUE), (int)device.SramSize, Constants.SRAM_BLANK_VALUE);

                    if (flashDataRaw != null)
                    {
                        //Apply the SRAM RF Settings:
                        if (rfSettings != null)
                        {
                            rfSettings.StoreToBuffer(device.ChipType, fileOffset, flashDataRaw);
                        }

                        //Apply the SRAM Write Offset:
                        //if (sramWriteOffset != 0)
                        //{
                        //    int i;
                        //    for (i = (int)device.SR - 1; i >= sramWriteOffset; i--)
                        //    {
                        //        flashDataRaw[i] = flashDataRaw[i - sramWriteOffset];
                        //    }
                        //    for (; i >= 0; i--)
                        //    {
                        //        flashDataRaw[i] = Constants.SRAM_BLANK_VALUE;
                        //    }
                        //}
                        //TODO: if hex file have more than X kB of data - show error (or warning??)

                        //Erace the MTP Memory if needed, before programming SRAM.
                        // We must did this before SRAM programming, because operations with MTP can corrupt the SRAM.
                        WorkingModes wMode = GetSelectedWorkingMode();
                        //if (wMode == WorkingModes.ExecuteOutOfSram)
                        //{
                        //if (MtpAutoErase(device))
                        //{
                        //    if (!device.Memory.WriteSRAM(flashDataRaw, true))
                        //    {
                        //        ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
                        //        result = false;
                        //    }
                        //}
                        //}
                        //else
                        //{
                        if (!device.WriteSRAM(flashDataRaw, true))
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
                            result = false;
                        }
                        //}
                    }
                    //else if (rdres == HexFileHelper.ADDRESS_OUT_OF_RANGE)
                    //{
                    //    ControllerManager.ShowMessage(Resources.ErrorHexFileDataOutOfRange, true);
                    //    result = false;
                    //}
                    else
                    {
                        ControllerManager.ShowMessage(Resources.ErrorHexFileNotValid, true);
                        result = false;
                    }
                }
                else if (String.IsNullOrEmpty(hexFileName))
                {
                    ControllerManager.ShowMessage("Hex file is not selected.", true);
                    result = false;
                }
                else
                {
                    ControllerManager.ShowMessage(String.Format("{0} does not exists.", hexFileName), true);
                    result = false;
                }

            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                result = false;
            }
            if (result == false) device.Close();
            return result;
        }

        public bool WirteHEXToSRAM(IDevice device, string fileName, IFlashSettings rfSettings)
        {
            return WirteHEXToSRAM(device, fileName, 0, 0, rfSettings);
        }

        private bool WirteHEXToSRAM(IDevice device, string fileName, int fileUseFromOffset, int sramWriteOffset, IFlashSettings rfSettings)
        {
            bool result = true;
            if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
            {
                device.SetBusyLedState(true);
                string hexFileName = fileName;
                if (!String.IsNullOrEmpty(hexFileName) && File.Exists(hexFileName))
                {
                    byte[] flashDataRaw = HexFileHelper.GetBytes(HexFileHelper.ReadIntelHexFile(hexFileName, Constants.SRAM_BLANK_VALUE), device.SramSize, Constants.SRAM_BLANK_VALUE);

                    if (flashDataRaw != null)
                    {
                        //Apply the SRAM RF Settings:
                        if (rfSettings != null)
                        {
                            rfSettings.StoreToBuffer(device.ChipType, fileUseFromOffset, flashDataRaw);
                        }

                        //Apply the SRAM Write Offset:
                        if (sramWriteOffset != 0)
                        {
                            int i;
                            for (i = device.SramSize - 1; i >= sramWriteOffset; i--)
                            {
                                flashDataRaw[i] = flashDataRaw[i - sramWriteOffset];
                            }
                            for (; i >= 0; i--)
                            {
                                flashDataRaw[i] = Constants.SRAM_BLANK_VALUE;
                            }
                        }
                        //TODO: if hex file have more than X kB of data - show error (or warning??)

                        //Erace the MTP Memory if needed, before programming SRAM.
                        // We must did this before SRAM programming, because operations with MTP can corrupt the SRAM.
                        WorkingModes wMode = GetSelectedWorkingMode();
                        if (wMode == WorkingModes.ExecuteOutOfSram)
                        {
                            if (!device.Memory.WriteSRAM(flashDataRaw, true))
                            {
                                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
                                result = false;
                            }
                        }
                        else
                        {
                            if (!device.Memory.WriteSRAM(flashDataRaw, true))
                            {
                                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
                                result = false;
                            }
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.ErrorHexFileNotValid, true);
                        result = false;
                    }
                }
                else if (String.IsNullOrEmpty(hexFileName))
                {
                    ControllerManager.ShowMessage("Hex file is not selected.", true);
                    result = false;
                }
                else
                {
                    ControllerManager.ShowMessage(String.Format("{0} does not exists.", hexFileName), true);
                    result = false;
                }
                device.SetBusyLedState(false);
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                result = false;
            }
            return result;
        }
        /// <summary>
        /// Write the SRAM.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramWrite(string fileName, WorkingModes workingMode)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramProgress);
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();

                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }

                        int fileOffset = 0;
                        int sramOffset = 0;
                        IFlashSettings rfSettings = null;
                        switch (workingMode)
                        {
                            case WorkingModes.Development:
                                {
                                    fileOffset = (int)device.FlashSize - (int)Constants.SRAM_DEVMODE_SIZE;
                                    sramOffset = (int)Constants.SRAM_DEVMODE_OFFSET;
                                    if (ControllerManager.IsConsoleMode)
                                    {
                                        rfSettings = null;			//the flashSettings will be used from the .hex file
                                    }
                                    else
                                    {
                                        rfSettings = SramGetUserFlashSettings((ChipTypes)device.ChipType);
                                    }
                                }
                                break;
                        }
                        if (WirteHEXToSRAM(device, hexFileName, fileOffset, sramOffset, rfSettings))
                        {
                            ControllerManager.ShowMessageInStatus("Write SRAM completed.", false);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch (Exception)
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }
        }
        /// <summary>
        /// Write the SRAM.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramWrite(string fileName, WorkingModes workingMode, Win32PnPEntityClass portInfo, int progInterface)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramProgress);
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();

                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }

                        int fileOffset = 0;
                        int sramOffset = 0;
                        IFlashSettings rfSettings = null;
                        switch (workingMode)
                        {
                            case WorkingModes.Development:
                                {
                                    fileOffset = (int)device.FlashSize - (int)Constants.SRAM_DEVMODE_SIZE;
                                    sramOffset = (int)Constants.SRAM_DEVMODE_OFFSET;
                                    if (ControllerManager.IsConsoleMode)
                                    {
                                        rfSettings = null;			//the flashSettings will be used from the .hex file
                                    }
                                    else
                                    {
                                        rfSettings = SramGetUserFlashSettings((ChipTypes)device.ChipType);
                                    }
                                }
                                break;
                        }
                        if (WirteHEXToSRAM(device, hexFileName, fileOffset, sramOffset, rfSettings))
                        {
                            ControllerManager.ShowMessageInStatus("Write SRAM completed.", false);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch (Exception)
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
            }
            finally
            {
                device.Close();
            }
        }
        public void SramCompare(string fileName, WorkingModes workingMode, Win32PnPEntityClass portInfo, int progInterface)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadSramProgress);
            if (!ControllerManager.IsConsoleMode)
            {
                ControllerManager.ClearZW050xFormData();
            }
            bool compareResult = true;
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {

                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }
                        if (!String.IsNullOrEmpty(hexFileName) && File.Exists(hexFileName))
                        {
                            int sramOffset = 0;
                            byte[] sramDataRaw = HexFileHelper.GetBytes(HexFileHelper.ReadIntelHexFile(hexFileName, Constants.SRAM_BLANK_VALUE), (int)device.SramSize, Constants.SRAM_BLANK_VALUE);

                            bool isIdentical = false;
                            if (sramDataRaw != null)
                            {
                                byte[] buffer = device.ReadSRAM();

                                if (buffer != null)
                                {
                                    if (buffer.Length - sramOffset == sramDataRaw.Length)
                                    {
                                        SortedList<int, List<byte[]>> diffs = new SortedList<int, List<byte[]>>();
                                        isIdentical = CompareDataWithDiffs(sramDataRaw, buffer, out diffs);
                                        if (!isIdentical)
                                        {
                                            ShowPlainDataCompareResults(diffs, "SRAM");
                                        }
                                    }
                                    else
                                    {
                                        ControllerManager.ShowMessage("Selected Hex file is not equal size to SRAM content.", true);
                                        compareResult = false;
                                    }
                                }
                                else
                                {
                                    ControllerManager.ShowMessage("Couldn't read SRAM content of device.", true);
                                    compareResult = false;
                                }

                            }
                            if (compareResult)
                            {
                                if (isIdentical)
                                {
                                    ControllerManager.ShowMessage(Resources.MsgCompareSRAMSuccesful, false);
                                }
                                else
                                {
                                    ControllerManager.ShowMessage("SRAM content is different.", false);
                                }
                            }
                        }
                        else if (String.IsNullOrEmpty(hexFileName))
                        {
                            ControllerManager.ShowMessage("Hex file is not selected.", true);
                        }
                        else
                        {
                            ControllerManager.ShowMessage(String.Format("{0} does not exists.", hexFileName), true);
                        }

                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantCompareSRAM, true);
            }
            finally
            {
                device.Close();
            }
        }

        private bool CompareDataWithDiffs(byte[] sramDataRaw, byte[] buffer, out SortedList<int, List<byte[]>> diffs)
        {
            bool result = true;
            diffs = new SortedList<int, List<byte[]>>();

            if (sramDataRaw != null && buffer != null)
            {
                if (sramDataRaw.SequenceEqual(buffer))
                {
                    result = true;
                }
                else
                {
                    List<byte[]> diffData = new List<byte[]>();
                    diffData.Add(buffer); //SRAM content
                    diffData.Add(sramDataRaw); //HEX File content
                    diffs.Add(0, diffData);
                    result = false;
                }
            }
            else
            {
                result = false;
            }
            if (result)
            {
                diffs = null;
            }
            return result;
        }
        /// <summary>
        /// Compare the SRAM.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramCompare(string fileName, WorkingModes workingMode)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadSramProgress);
            if (!ControllerManager.IsConsoleMode)
            {
                ControllerManager.ClearZW050xFormData();
            }
            bool compareResult = true;
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }
                        if (!String.IsNullOrEmpty(hexFileName) && File.Exists(hexFileName))
                        {
                            int fileOffset = 0;
                            int sramOffset = 0;
                            switch (workingMode)
                            {
                                case WorkingModes.Development:
                                    {
                                        fileOffset = (int)device.FlashSize - (int)Constants.SRAM_DEVMODE_SIZE;
                                        sramOffset = (int)Constants.SRAM_DEVMODE_OFFSET;
                                    }
                                    break;
                            }

                            byte[] sramDataRaw = HexFileHelper.GetBytes(HexFileHelper.ReadIntelHexFile(hexFileName, Constants.SRAM_BLANK_VALUE), device.SramSize, Constants.SRAM_BLANK_VALUE);

                            bool isIdentical = false;
                            if (sramDataRaw != null)
                            {
                                device.SetBusyLedState(true);
                                if (device.Memory.ReadSRAM())
                                {
                                    if (device.Memory.Buffer != null)
                                    {
                                        if (device.Memory.Buffer.Length - sramOffset == sramDataRaw.Length)
                                        {
                                            SortedList<int, List<byte[]>> diffs = new SortedList<int, List<byte[]>>();
                                            isIdentical = device.Memory.Compare(sramDataRaw, out diffs);
                                            if (!isIdentical)
                                            {
                                                ShowPlainDataCompareResults(diffs, "SRAM");
                                            }
                                        }
                                        else
                                        {
                                            ControllerManager.ShowMessage("Selected Hex file is not equal size to SRAM content.", true);
                                            compareResult = false;
                                        }
                                    }
                                    else
                                    {
                                        ControllerManager.ShowMessage("SRAM was read with error.", true);
                                        compareResult = false;
                                    }
                                }
                                else
                                {
                                    ControllerManager.ShowMessage("Couldn't read SRAM content of device.", true);
                                    compareResult = false;
                                }
                                device.SetBusyLedState(false);
                            }
                            if (compareResult)
                            {
                                if (isIdentical)
                                {
                                    ControllerManager.ShowMessage(Resources.MsgCompareSRAMSuccesful, false);
                                }
                                else
                                {
                                    ControllerManager.ShowMessage("SRAM content is different.", false);
                                }
                            }

                        }
                        else if (String.IsNullOrEmpty(hexFileName))
                        {
                            ControllerManager.ShowMessage("Hex file is not selected.", true);
                        }
                        else
                        {
                            ControllerManager.ShowMessage(String.Format("{0} does not exists.", hexFileName), true);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantCompareSRAM, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }
        }

        private void ShowPlainDataCompareResults(SortedList<int, List<byte[]>> diffs, string diffTypeName)
        {
            if (diffs != null && diffs.Count == 1)
            {
                StringBuilder sb = new StringBuilder();
                foreach (KeyValuePair<int, List<byte[]>> kp in diffs)
                {
                    sb.AppendLine("Compare results\n-------------------------------------------\n");
                    sb.AppendLine("");
                    sb.AppendLine(string.Format("{0} content: ", diffTypeName));
                    string flashContent = HexFileHelper.WriteIntelHexFile(kp.Value[0], 0x10 * kp.Key, 0x10 * kp.Key + kp.Value[0].Length, 0x10, Constants.BLANK_VALUE, true);
                    string hexContent = HexFileHelper.WriteIntelHexFile(kp.Value[1], 0x10 * kp.Key, 0x10 * kp.Key + kp.Value[1].Length, 0x10, Constants.BLANK_VALUE, true);

                    string[] flashContentArr = flashContent.Split(Environment.NewLine.ToCharArray());
                    string[] hexContentArr = hexContent.Split(Environment.NewLine.ToCharArray());

                    for (int i = 0; i < flashContentArr.Length; i++)
                    {
                        if (flashContentArr[i] != hexContentArr[i])
                        {
                            string fc = "";
                            string hc = "";

                            for (int j = 1; j < flashContentArr[i].Length - 1; j += 2)
                            {
                                if (j < 9)
                                {
                                    fc += flashContentArr[i][j].ToString() + flashContentArr[i][j + 1].ToString();
                                    hc += hexContentArr[i][j].ToString() + hexContentArr[i][j + 1].ToString();
                                }
                                else if (j > flashContentArr[i].Length - 3)
                                {
                                    fc += flashContentArr[i][j].ToString() + flashContentArr[i][j + 1].ToString();
                                    hc += hexContentArr[i][j].ToString() + hexContentArr[i][j + 1].ToString();
                                }
                                else
                                {
                                    if (flashContentArr[i][j] == hexContentArr[i][j] && flashContentArr[i][j + 1] == hexContentArr[i][j + 1])
                                    {
                                        fc += "..";
                                        hc += "..";
                                    }
                                    else
                                    {
                                        fc += flashContentArr[i][j].ToString() + flashContentArr[i][j + 1].ToString();
                                        hc += hexContentArr[i][j].ToString() + hexContentArr[i][j + 1].ToString();
                                    }
                                }
                            }
                            flashContentArr[i] = ":" + fc;
                            hexContentArr[i] = ":" + hc;
                        }
                        else
                        {
                            flashContentArr[i] = "";
                            hexContentArr[i] = "";
                        }
                    }
                    for (int i = 0; i < flashContentArr.Length; i++)
                    {
                        if (!String.IsNullOrEmpty(flashContentArr[i].Trim()))
                        {
                            sb.AppendLine(flashContentArr[i]);
                        }
                    }
                    sb.AppendLine("");

                    sb.AppendLine("Source HEX file content: ");
                    for (int i = 0; i < hexContentArr.Length; i++)
                    {
                        if (!String.IsNullOrEmpty(hexContentArr[i].Trim()))
                        {
                            sb.AppendLine(hexContentArr[i]);
                        }
                    }
                    sb.AppendLine("");
                }
                ControllerManager.ShowConsoleInfo(sb.ToString());
            }
        }

        /// <summary>
        /// Write the SRAM and run specified mode.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramWriteAndRunMode(string fileName, WorkingModes workingMode, Win32PnPEntityClass portInfo, int progInterface)
        {
            switch (workingMode)
            {
                case WorkingModes.Development:
                    {
                        //SramWriteAndRunDevMode(fileName);
                    }
                    break;

                case WorkingModes.ExecuteOutOfSram:
                    {
                        SramWriteAndExecOutOfSram(fileName, portInfo, progInterface);
                    }
                    break;
            }
        }

        /// <summary>
        /// Write the SRAM and run specified mode.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="workingMode">Working mode.</param>
        public void SramWriteAndRunMode(string fileName, WorkingModes workingMode)
        {
            switch (workingMode)
            {
                case WorkingModes.Development:
                    {
                        SramWriteAndRunDevMode(fileName);
                    }
                    break;

                case WorkingModes.ExecuteOutOfSram:
                    {
                        SramWriteAndExecOutOfSram(fileName);
                    }
                    break;
            }
        }
        /// <summary>
        /// Write the SRAM and run development mode.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        private void SramWriteAndRunDevMode(string fileName)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramProgress);
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        IFlashSettings rfSettings = null;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                            rfSettings = null;			//the flashSettings will be used from the .hex file
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                            rfSettings = SramGetUserFlashSettings((ChipTypes)device.ChipType);
                        }
                        if (WirteHEXToSRAM(device, hexFileName, (int)device.FlashSize - (int)Constants.SRAM_DEVMODE_SIZE, (int)Constants.SRAM_DEVMODE_OFFSET, rfSettings))
                        {
                            if (device.SetMode(WorkingModes.Development))
                            {
                                ControllerManager.ShowMessageInStatus("Write SRAM completed. Development mode enabled.", false);
                            }
                            else
                            {
                                ControllerManager.ShowMessage(Resources.ErrorCantSetChipWorkingMode, true);
                            }
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }
        }
        private void SramWriteAndExecOutOfSram(string fileName, Win32PnPEntityClass portInfo, int progInterface)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramProgress);
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }
                        if (WirteHEXToSRAM(device, hexFileName, 0, 0, null))
                        {
                            bool result = false;
                            if (device.SetMode(WorkingModes.ExecuteOutOfSram))
                            {
                                if (device.ChipType == (byte)ChipTypes.ZW050x)
                                {
                                    Thread.Sleep(300);
                                    device.FlashCheckState(); //TODO
                                    result = true;
                                }
                                if (result)
                                    ControllerManager.ShowMessageInStatus("Write SRAM completed Execute out of SRAM enabled.", false);
                                else
                                    ControllerManager.ShowMessage(Resources.ErrorCantSetChipWorkingMode, true);
                            }
                            else
                            {
                                ControllerManager.ShowMessage(Resources.ErrorCantSetChipWorkingMode, true);
                            }
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
            }
            finally
            {
                device.Close();
            }
        }
        /// <summary>
        /// Srams the write and exec out of sram.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        private void SramWriteAndExecOutOfSram(string fileName)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramProgress);
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        string hexFileName;
                        if (ControllerManager.IsConsoleMode)
                        {
                            hexFileName = fileName;
                        }
                        else
                        {
                            hexFileName = ControllerManager.DocumentModel.GetSramHexFilePath((ChipTypes)device.ChipType);
                        }
                        if (WirteHEXToSRAM(device, hexFileName, null))
                        {
                            bool result = false;
                            if (device.SetMode(WorkingModes.ExecuteOutOfSram))
                            {
                                if (device.ChipType == (byte)ChipTypes.ZW050x)
                                {
                                    Thread.Sleep(300);
                                    device.Flash.CheckState(); //TODO
                                    result = true;
                                }
                                if (result)
                                    ControllerManager.ShowMessageInStatus("Write SRAM completed. Execute out of SRAM enabled.", false);
                                else
                                    ControllerManager.ShowMessage(Resources.ErrorCantSetChipWorkingMode, true);
                            }
                            else
                            {
                                ControllerManager.ShowMessage(Resources.ErrorCantSetChipWorkingMode, true);
                            }
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                    if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                        device.SetProgrammingMode(false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSram, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }
        }
        /// <summary>
        /// Writes the Sram options.
        /// </summary>
        /// <param name="frequency">The frequency.</param>
        /// <param name="sramSettings">The SRAM RF Options.</param>
        public void SramWriteOptions(IFlashSettings sramSettings)
        {
            WriteRfOptionsStatuses result = WriteRfOptionsStatuses.None;
            ControllerManager.ShowMessageInConsole(Resources.MsgWriteSramOptionsProgress);
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        IFlashSettings sramSettingsInHex = null;
                        if (ControllerManager.IsConsoleMode)
                        {
                            sramSettingsInHex = sramSettings;
                        }
                        else
                        {
                            sramSettingsInHex = SramGetUserFlashSettings((ChipTypes)device.ChipType);
                        }
                        result = device.Memory.WriteSRAMRfOptions(sramSettingsInHex);
                        if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                            device.SetProgrammingMode(false);
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                ControllerManager.ShowMessage(Resources.ErrorCantWriteSramOptions, true);
            }
            finally
            {
                ControllerManager.DeviceClose();
            }

            switch (result)
            {
                case WriteRfOptionsStatuses.CantReadAppRfSettings:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorCantReadAppRfSettings, true);
                    } break;
                case WriteRfOptionsStatuses.CantReadGeneralRfSettings:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorCantReadGeneralRfSettings, true);
                    } break;
                case WriteRfOptionsStatuses.CantWriteAppRfSettings:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorCantWriteAppRfSettings, true);
                    } break;
                case WriteRfOptionsStatuses.CantWriteGeneralRfSettings:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorCantWriteGeneralRfSettings, true);
                    } break;
                case WriteRfOptionsStatuses.NoErrors:
                    {
                        ControllerManager.ShowMessage(Resources.MsgWriteRfSettingsNoErrors, false);
                    } break;
                case WriteRfOptionsStatuses.None:
                    {
                        ControllerManager.ShowMessage(Resources.MsgWriteRfSettingsNone, false);
                    } break;
                case WriteRfOptionsStatuses.RfFrequencyNotSelected:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorRfFrequencyNotSelected, true);
                    } break;
                case WriteRfOptionsStatuses.UndefinedRfSettings:
                    {
                        ControllerManager.ShowMessage(Resources.ErrorUndefinedRfSettings, true);
                    } break;
            }
        }
        private IFlashSettings SramGetUserFlashSettings(ChipTypes chipType)
        {
            IFlashSettings result = null;
            if (ControllerManager.ActiveView != null)
            {
                if (chipType == ChipTypes.ZW040x && ControllerManager.ActiveView.Name == ControllerManager.ZW050xForm.Name)
                {
                    result = ControllerManager.ZWaveManager.ApplicationLayer.CreateFlashSettings();
                }
            }
            return result;
        }
        #endregion

        public void OnLockBitsSetAPMClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                List<byte> lockBits = new List<byte>();
                for (int i = 0; i < 8; i++)
                {
                    lockBits.Add(0xFF);
                }
                lockBits.Add(0xFD);
                ControllerManager.Actions.ProgrammerActions.OnLockBitsSetZW050x(lockBits);
            }
        }
        /// <summary>
        /// Called when Set Lock Bits click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnLockBitsSetClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                try
                {
                    List<byte> lockBits = new List<byte>();
                    //Lockbits
                    byte rbLockBit = 0xFF;

                    if (ControllerManager.ZW050xForm.ReadBackProtectionCheckBox.Checked)
                        rbLockBit = SetBit(rbLockBit, 0, false);
                    if (ControllerManager.ZW050xForm.Autoprog0CheckBox.Checked)
                        rbLockBit = SetBit(rbLockBit, 1, false);
                    if (ControllerManager.ZW050xForm.Autoprog1CheckBox.Checked)
                        rbLockBit = SetBit(rbLockBit, 2, false);

                    if (!String.IsNullOrEmpty(ControllerManager.ZW050xForm.ProtectSectorTextBox.Text))
                    {
                        List<byte> protectSectors = GetProtectSector(ControllerManager.ZW050xForm.ProtectSectorTextBox.Text);
                        if (protectSectors.Count > 0)
                        {
                            lockBits.AddRange(protectSectors);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            lockBits.Add(0xFF);
                        }
                    }
                    lockBits.Add(rbLockBit);
                    ControllerManager.Actions.ProgrammerActions.OnLockBitsSetZW050x(lockBits);
                }
                catch (ApplicationException aEx)
                {
                    ControllerManager.ShowMessage(aEx.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private List<byte> GetProtectSector(string protectSectorsText)
        {
            List<byte> result = new List<byte>();
            if (protectSectorsText != NO_SECTORS_PROTECTED)
            {
                for (int i = 0; i < 8; i++)
                {
                    result.Add(0xFF);
                }
                protectSectorsText = protectSectorsText.Replace(" ", "");
                string[] sArr = protectSectorsText.Split(',');
                foreach (string s in sArr)
                {
                    if (s.Contains("-"))
                    {
                        string[] _sArr = s.Split('-');
                        if (_sArr.Length == 2)
                        {
                            for (int i = int.Parse(_sArr[0]); i < int.Parse(_sArr[1]) + 1; i++)
                            {
                                if (i < 0 || i >= 64)
                                {
                                    throw new ApplicationException("Invalid LockBit value: '" + _sArr[1] + "'");
                                }
                                int bitPos = i;
                                if (bitPos > 7)
                                {
                                    bitPos = bitPos - ((bitPos / 8) * 8);
                                    result[i / 8] = SetBit(result[i / 8], (byte)bitPos, false);
                                }
                                else
                                {
                                    result[i / 8] = SetBit(result[i / 8], (byte)bitPos, false);
                                }
                            }
                        }
                    }
                    else
                    {

                        int bitValue = 0;
                        if (int.TryParse(s, out bitValue))
                        {
                            if (bitValue < 0 || bitValue >= 64)
                            {
                                throw new ApplicationException("Invalid LockBit value: '" + bitValue.ToString() + "'");
                            }
                            int bitPos = int.Parse(s);
                            if (bitPos > 7)
                            {
                                bitPos = bitPos - ((bitPos / 8) * 8);
                                result[bitValue / 8] = SetBit(result[bitValue / 8], (byte)(bitPos), false);
                            }
                            else
                            {
                                result[bitValue / 8] = SetBit(result[bitValue / 8], (byte)(bitPos), false);
                            }
                        }
                    }
                }
            }
            return result;

        }
        private byte SetBit(byte value, byte bitPosition, bool bitValue)
        {
            if (bitValue)
            {
                value |= (byte)(1 << bitPosition);
            }
            else
            {
                value &= (byte)(~(1 << bitPosition));
            }
            return value;
        }
        const string NO_SECTORS_PROTECTED = "<no sectors protected>";
        /// <summary>
        /// Called when Read Lock Bits click.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnLockBitsReadClick(object sender, EventArgs e)
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {
                List<byte> lockBits = ControllerManager.Actions.ProgrammerActions.OnLockBitsReadZW050x();
                if (lockBits.Count == 9)
                {
                    ControllerManager.ZW050xForm.ReadBackProtectionCheckBox.Checked = (lockBits[8] & (1 << 0)) == 0;
                    ControllerManager.ZW050xForm.Autoprog0CheckBox.Checked = (lockBits[8] & (1 << 1)) == 0;
                    ControllerManager.ZW050xForm.Autoprog1CheckBox.Checked = (lockBits[8] & (1 << 2)) == 0;
                    string protectSectorText = GetProtectSectorText(lockBits);
                    if (!String.IsNullOrEmpty(protectSectorText))
                    {
                        ControllerManager.ZW050xForm.ProtectSectorTextBox.Text = protectSectorText;
                    }
                    else
                    {
                        ControllerManager.ZW050xForm.ProtectSectorTextBox.Text = NO_SECTORS_PROTECTED;
                    }
                }
            }
        }

        public void OnRevTextBoxValidated(object sender, EventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox txt = sender as TextBox;
                if (!String.IsNullOrEmpty(txt.Text))
                {
                    try
                    {
                        byte[] data = Tools.FromHexString(txt.Text);
                        if (data != null && data.Length == 1)
                        {
                            if (data[0] != 0x01)
                            {
                                ControllerManager.ShowMessage("NVR layout revision (REV) should be 0x01", false);
                                txt.Text = "01";
                            }
                        }
                    }
                    catch
                    {
                        txt.Text = "01";
                    }
                }
            }
        }

        private string GetProtectSectorText(List<byte> lockBits)
        {
            List<int> protectedSectors = new List<int>();
            for (int i = 0; i < 8; i++)
            {
                byte data = lockBits[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((data & (1 << j)) == 0)
                    {
                        protectedSectors.Add(i * 8 + j);
                    }
                }
            }
            string result = "";
            int b = 0;
            for (b = 0; b < protectedSectors.Count; b++)
            {
                if (b == 0)
                {
                    result = (protectedSectors[b]).ToString();
                }
                else
                {
                    if ((protectedSectors[b] - protectedSectors[b - 1]) == 1)
                    {
                        if (!result.EndsWith("-"))
                        {
                            result += "-";
                        }
                    }
                    else
                    {
                        if (result.EndsWith("-"))
                        {
                            result += (protectedSectors[b - 1]).ToString() + ", " + (protectedSectors[b]).ToString();
                        }
                        else
                        {
                            result += ", " + (protectedSectors[b]).ToString();
                        }
                    }
                }
            }
            if (result.EndsWith("-"))
            {
                result += (protectedSectors[b - 1]).ToString();
            }

            return result;
        }


        /// <summary>
        /// Called when DocumentModel state changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        public void OnDocumentModelStateChanged(object sender, EventArgs e)
        {
            OnDocumentModelStateChanged();
        }

        private delegate void OnDocumentModelStateChangedDelegate();
        private void OnDocumentModelStateChanged()
        {
            if (ControllerManager.ZW050xForm != null && !ControllerManager.ZW050xForm.IsDisposed)
            {

                if (ControllerManager.ZW050xForm.InvokeRequired)
                {
                    ControllerManager.ZW050xForm.Invoke(new OnDocumentModelStateChangedDelegate(OnDocumentModelStateChanged));
                }
                else
                {
                    ControllerManager.ZW050xForm.chkAddS2.Checked = ControllerManager.DocumentModel.IsAddSecurity2Keys;
                    ControllerManager.ZW050xForm.chkGenerateS2.Enabled = ControllerManager.DocumentModel.IsAddSecurity2Keys;
                    ControllerManager.ZW050xForm.chkGenerateS2.Checked = ControllerManager.DocumentModel.IsGenerateSecurity2Keys;

                    ControllerManager.ZW050xForm.UpdateAvailabilityS2Keypair(ControllerManager.DocumentModel.IsAddSecurity2Keys, ControllerManager.DocumentModel.IsGenerateSecurity2Keys);

                    ControllerManager.ZW050xForm.CalibrateAndProgrammButton.Enabled =
                    ControllerManager.ZW050xForm.FlashCompareButton.Enabled =
                        ControllerManager.DocumentModel.FlashHexFileSelected(ChipTypes.ZW050x);

                    ControllerManager.ZW050xForm.EepromProgramButton.Enabled =
                    ControllerManager.ZW050xForm.EepromCompareButton.Enabled =
                        ControllerManager.DocumentModel.EepromHexFileSelected(ChipTypes.ZW050x);

                    ControllerManager.ZW050xForm.SramCompareButton.Enabled =
                    ControllerManager.ZW050xForm.SramWriteAndRunModeButton.Enabled =
                    ControllerManager.ZW050xForm.SramWriteButton.Enabled =
                        ControllerManager.DocumentModel.SramHexFileSelected(ChipTypes.ZW050x);

                    if (ControllerManager.DocumentModel != null && ControllerManager.DocumentModel.PortInfo != null)
                    {
                        if (ControllerManager.DocumentModel.PortInfo.Manufacturer.Contains("Silicon"))
                        {
                            if (ControllerManager.UseSiliconSpi)
                                ControllerManager.ZW050xForm.SetProgrammingInterface(0);
                            else
                                ControllerManager.ZW050xForm.SetProgrammingInterface(1);
                        }
                        else if (ControllerManager.DocumentModel.PortInfo.Manufacturer.Contains("Sigma") || ControllerManager.DocumentModel.PortInfo.Name.Contains("USB"))
                        {
                            ControllerManager.ZW050xForm.SetProgrammingInterface(2);
                        }
                        else
                        {
                            ControllerManager.ZW050xForm.SetProgrammingInterface(1);
                        }
                    }
                }
            }
        }

        public void OnKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.O)
            {
                OnFlashBrowseHexFileClick(null, null);
            }
            if (e.Control && e.Alt && e.KeyCode == Keys.R)
            {
                ControllerManager.Actions.ZW050xFormActions.OnSramReadClick(null, null);
            }
            if (e.Control && e.Alt && e.KeyCode == Keys.W)
            {
                ControllerManager.Actions.ZW050xFormActions.OnSramWriteClick(null, null);
            }
            if (e.Control && e.Alt && e.KeyCode == Keys.C)
            {
                ControllerManager.Actions.ZW050xFormActions.OnSramCompareClick(null, null);
            }
            if (e.Control && e.Alt && e.KeyCode == Keys.P)
            {
                ControllerManager.Actions.ZW050xFormActions.OnSramWriteAndRunModeClick(null, null);
            }
        }

        public void OnNvrWriteButtonClick(object sender, EventArgs e)
        {
            _isWriteSucceed = false;
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                NVRData nvrData = new NVRData();
                MapForm2NVRData(ControllerManager.ZW050xForm, nvrData);

                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {

                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        _isWriteSucceed = NvrDataWrite(nvrData);
                        MapForm2NVRData(ControllerManager.ZW050xForm, nvrData);
                    }), Resources.MsgWriteNvrProgress, false, 0x00);
                }
                else if (progInterface == 1)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        ControllerManager.DeviceInit();
                        _isWriteSucceed = NvrDataWrite(nvrData, ControllerManager.DocumentModel.PortInfo, progInterface);
                        MapForm2NVRData(ControllerManager.ZW050xForm, nvrData);
                        ControllerManager.RestoreSelectedDevice();
                    }), Resources.MsgWriteNvrProgress, false, 0x00);
                }
                else if (progInterface == 2)
                {
                    //TODO USB
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
            _isWriteSucceed = true;
        }

        public void NvrWrite(byte[] nvrData, IProgrammableDevice device)
        {
            try
            {
                if (nvrData != null)
                {
                    for (int i = Constants.NVR_START_ADDRESS; i < Constants.NVR_END_ADDRESS; i++)
                    {
                        device.WriteNvrByte((byte)i, nvrData[i]);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantWriteNvr, true);
                }
            }
            catch
            {

            }
            finally
            {

            }
        }

        public bool NvrDataWrite(NVRData nvrData, Win32PnPEntityClass portInfo, int progInterface)
        {
            bool ret = true;
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        if (nvrData != null)
                        {
                            byte[] buffer = device.ReadNvr(0);
                            if (IsEmpty(buffer, 0xFF))
                            {
                                device.WriteNvrByte(NVRData.REV_ADDRESS, nvrData.REV);
                                device.WriteNvrByte(NVRData.CCAL_ADDRESS, nvrData.CCAL);
                                device.WriteNvrByte(NVRData.PINS_ADDRESS, nvrData.PINS);
                                device.WriteNvrByte(NVRData.NVMCS_ADDRESS, nvrData.NVMCS);
                                for (byte i = NVRData.SAWC_ADDRESS; i < nvrData.SAWC.Length + NVRData.SAWC_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.SAWC[i - NVRData.SAWC_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.SAWB_ADDRESS, nvrData.SAWB);
                                device.WriteNvrByte(NVRData.NVMT_ADDRESS, nvrData.NVMT);

                                for (byte i = NVRData.NVMS_ADDRESS; i < nvrData.NVMS.Length + NVRData.NVMS_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.NVMS[i - NVRData.NVMS_ADDRESS]);
                                }
                                for (byte i = NVRData.NVMP_ADDRESS; i < nvrData.NVMP.Length + NVRData.NVMP_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.NVMP[i - NVRData.NVMP_ADDRESS]);
                                }
                                for (byte i = NVRData.UUID_ADDRESS; i < nvrData.UUID.Length + NVRData.UUID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.UUID[i - NVRData.UUID_ADDRESS]);
                                }
                                for (byte i = NVRData.VID_ADDRESS; i < nvrData.VID.Length + NVRData.VID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.VID[i - NVRData.VID_ADDRESS]);
                                }
                                for (byte i = NVRData.PID_ADDRESS; i < nvrData.PID.Length + NVRData.PID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PID[i - NVRData.PID_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.TXCAL1_ADDRESS, nvrData.TXCAL1);
                                device.WriteNvrByte(NVRData.TXCAL2_ADDRESS, nvrData.TXCAL2);
                                for (byte i = NVRData.PUK_ADDRESS; i < nvrData.PUK.Length + NVRData.PUK_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PUK[i - NVRData.PUK_ADDRESS]);
                                }
                                for (byte i = NVRData.PRK_ADDRESS; i < nvrData.PRK.Length + NVRData.PRK_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PRK[i - NVRData.PRK_ADDRESS]);
                                }
                                for (byte i = NVRData.PROTOCOL_DATA_ADDRESS; i < nvrData.ProtocolData.Length + NVRData.PROTOCOL_DATA_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.ProtocolData[i - NVRData.PROTOCOL_DATA_ADDRESS]);
                                }
                                for (byte i = NVRData.CRC16_ADDRESS; i < nvrData.CRC16.Length + NVRData.CRC16_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.CRC16[i - NVRData.CRC16_ADDRESS]);
                                }
                                for (byte i = NVRData.APP_DATA_ADDRESS; i < nvrData.APP_DATA.Length + NVRData.APP_DATA_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.APP_DATA[i - NVRData.APP_DATA_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.HW_ADDRESS, nvrData.HW);

                            }
                            else if (portInfo.PNPDeviceID.StartsWith(@"USB\VID_0658&PID_0280", true, CultureInfo.InvariantCulture))
                            {
                                byte[] flashData = null;
                                // check if all lockbits are 0xFF
                                byte ch = 0xFF;
                                for (int i = 0; i < 8; i++)
                                {
                                    ch &= device.ReadLockBit(i);
                                }
                                if (ch == 0xFF) // no lockbits set
                                {
                                    ControllerManager.SetProgressInfo("Reading Flash content");
                                    device.FlashProgressChanged += new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                                    flashData = device.FlashRead(ControllerManager.DocumentModel.IsAsic);
                                    device.FlashProgressChanged -= new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                                    for (int i = 0; i < 8; i++)
                                    {
                                        flashData[0x500 + i] = 0xFF; //empty usb errors area
                                    }
                                    bool isCrcOK = false;
                                    ProgrammerActions.CalculateCrc(flashData, out isCrcOK);
                                    if (!isCrcOK)
                                        flashData = null;
                                }

                                else if (File.Exists(ControllerManager.DocumentModel.GetFlashHexFilePath(ChipTypes.ZW050x)))
                                {
                                    if (ControllerManager.ShowMessage("Flash content will be programmed with selected Hex file" +
                                        Environment.NewLine +
                                        ControllerManager.DocumentModel.GetFlashHexFilePath(ChipTypes.ZW050x), MessageBoxButtons.OKCancel, MessageBoxIcon.Warning))
                                    {
                                        SortedList<short, List<byte>> tmpData = HexFileHelper.ReadIntelHexFile(ControllerManager.DocumentModel.GetFlashHexFilePath(ChipTypes.ZW050x), Constants.BLANK_VALUE);
                                        flashData = HexFileHelper.GetBytes(tmpData, device.FlashSize, Constants.BLANK_VALUE);
                                    }
                                }

                                else
                                {
                                    ControllerManager.ShowMessage("Lock bits are set. Please select HEX file on 'Flash Code Memory' tab", true);
                                }

                                if (flashData != null)
                                {
                                    bool tmp = ControllerManager.DocumentModel.IsAddSecurity2Keys;
                                    ControllerManager.DocumentModel.IsAddSecurity2Keys = false;
                                    ControllerManager.Actions.ProgrammerActions.WriteFlash500(device, true, flashData, nvrData);
                                    ControllerManager.DocumentModel.IsAddSecurity2Keys = tmp;
                                }
                            }
                            else if (ControllerManager.ShowMessage("NVR area is not empty. \nModification of NVR will erase the whole Flash Code Memory. \nDo you want to continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == true)
                            {
                                device.FlashErase(ControllerManager.DocumentModel.IsAsic);
                                NVRData.ToBuffer(nvrData, buffer);
                                for (int i = Constants.NVR_START_ADDRESS; i < Constants.NVR_END_ADDRESS; i++)
                                {
                                    device.WriteNvrByte((byte)i, buffer[i]);
                                }
                            }
                            else
                            {
                                ret = false;
                            }
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantWriteNvr, true);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {

            }
            finally
            {

                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                device.Close();
            }
            return ret;
        }

        private void OnDeviceMemoryProgressChanged(ZWave.Events.ProgressChangedEventArgs args)
        {
            ControllerManager.ChangeProgressInfo(args.ProgressStatus, args.Current, args.Total);
        }

        public bool NvrDataWrite(NVRData nvrData)
        {
            bool ret = true; //Assume everything OK to add minimum changes
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        device.SetBusyLedState(true);
                        if (nvrData != null)
                        {
                            byte[] buffer = device.ReadNvr(0);
                            if (!ControllerManager.IsConsoleMode)
                            {
                                ControllerManager.ShowConsoleInfo("");
                            }
                            if (IsEmpty(buffer, 0xFF))
                            {
                                device.WriteNvrByte(NVRData.REV_ADDRESS, nvrData.REV);
                                device.WriteNvrByte(NVRData.CCAL_ADDRESS, nvrData.CCAL);
                                device.WriteNvrByte(NVRData.PINS_ADDRESS, nvrData.PINS);
                                device.WriteNvrByte(NVRData.NVMCS_ADDRESS, nvrData.NVMCS);
                                for (byte i = NVRData.SAWC_ADDRESS; i < nvrData.SAWC.Length + NVRData.SAWC_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.SAWC[i - NVRData.SAWC_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.SAWB_ADDRESS, nvrData.SAWB);
                                device.WriteNvrByte(NVRData.NVMT_ADDRESS, nvrData.NVMT);

                                for (byte i = NVRData.NVMS_ADDRESS; i < nvrData.NVMS.Length + NVRData.NVMS_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.NVMS[i - NVRData.NVMS_ADDRESS]);
                                }
                                for (byte i = NVRData.NVMP_ADDRESS; i < nvrData.NVMP.Length + NVRData.NVMP_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.NVMP[i - NVRData.NVMP_ADDRESS]);
                                }
                                for (byte i = NVRData.UUID_ADDRESS; i < nvrData.UUID.Length + NVRData.UUID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.UUID[i - NVRData.UUID_ADDRESS]);
                                }
                                for (byte i = NVRData.VID_ADDRESS; i < nvrData.VID.Length + NVRData.VID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.VID[i - NVRData.VID_ADDRESS]);
                                }
                                for (byte i = NVRData.PID_ADDRESS; i < nvrData.PID.Length + NVRData.PID_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PID[i - NVRData.PID_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.TXCAL1_ADDRESS, nvrData.TXCAL1);
                                device.WriteNvrByte(NVRData.TXCAL2_ADDRESS, nvrData.TXCAL2);
                                for (byte i = NVRData.PUK_ADDRESS; i < nvrData.PUK.Length + NVRData.PUK_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PUK[i - NVRData.PUK_ADDRESS]);
                                }
                                for (byte i = NVRData.PRK_ADDRESS; i < nvrData.PRK.Length + NVRData.PRK_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.PRK[i - NVRData.PRK_ADDRESS]);
                                }
                                for (byte i = NVRData.PROTOCOL_DATA_ADDRESS; i < nvrData.ProtocolData.Length + NVRData.PROTOCOL_DATA_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.ProtocolData[i - NVRData.PROTOCOL_DATA_ADDRESS]);
                                }

                                for (byte i = NVRData.CRC16_ADDRESS; i < nvrData.CRC16.Length + NVRData.CRC16_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.CRC16[i - NVRData.CRC16_ADDRESS]);
                                }
                                for (byte i = NVRData.APP_DATA_ADDRESS; i < nvrData.APP_DATA.Length + NVRData.APP_DATA_ADDRESS; i++)
                                {
                                    device.WriteNvrByte(i, nvrData.APP_DATA[i - NVRData.APP_DATA_ADDRESS]);
                                }
                                device.WriteNvrByte(NVRData.HW_ADDRESS, nvrData.HW);
                            }
                            else
                            {
                                if (ControllerManager.ShowMessage("NVR area is not empty. \nModification of NVR will erase the whole Flash Code Memory. \nDo you want to continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == true)
                                {
                                    device.Flash.Erase(ControllerManager.DocumentModel.IsAsic);
                                    buffer[NVRData.REV_ADDRESS] = nvrData.REV;
                                    buffer[NVRData.CCAL_ADDRESS] = nvrData.CCAL;
                                    buffer[NVRData.PINS_ADDRESS] = nvrData.PINS;
                                    buffer[NVRData.NVMCS_ADDRESS] = nvrData.NVMCS;
                                    for (byte i = NVRData.SAWC_ADDRESS; i < nvrData.SAWC.Length + NVRData.SAWC_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.SAWC[i - NVRData.SAWC_ADDRESS];
                                    }
                                    buffer[NVRData.SAWB_ADDRESS] = nvrData.SAWB;
                                    buffer[NVRData.NVMT_ADDRESS] = nvrData.NVMT;
                                    for (byte i = NVRData.NVMS_ADDRESS; i < nvrData.NVMS.Length + NVRData.NVMS_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.NVMS[i - NVRData.NVMS_ADDRESS];
                                    }

                                    for (byte i = NVRData.NVMP_ADDRESS; i < nvrData.NVMP.Length + NVRData.NVMP_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.NVMP[i - NVRData.NVMP_ADDRESS];
                                    }

                                    for (byte i = NVRData.UUID_ADDRESS; i < nvrData.UUID.Length + NVRData.UUID_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.UUID[i - NVRData.UUID_ADDRESS];
                                    }
                                    for (byte i = NVRData.VID_ADDRESS; i < nvrData.VID.Length + NVRData.VID_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.VID[i - NVRData.VID_ADDRESS];
                                    }
                                    for (byte i = NVRData.PID_ADDRESS; i < nvrData.PID.Length + NVRData.PID_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.PID[i - NVRData.PID_ADDRESS];
                                    }

                                    buffer[NVRData.TXCAL1_ADDRESS] = nvrData.TXCAL1;
                                    buffer[NVRData.TXCAL2_ADDRESS] = nvrData.TXCAL2;
                                    for (byte i = NVRData.PUK_ADDRESS; i < nvrData.PUK.Length + NVRData.PUK_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.PUK[i - NVRData.PUK_ADDRESS];
                                    }
                                    for (byte i = NVRData.PRK_ADDRESS; i < nvrData.PRK.Length + NVRData.PRK_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.PRK[i - NVRData.PRK_ADDRESS];
                                    }
                                    for (byte i = NVRData.PROTOCOL_DATA_ADDRESS; i < nvrData.ProtocolData.Length + NVRData.PROTOCOL_DATA_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.ProtocolData[i - NVRData.PROTOCOL_DATA_ADDRESS];
                                    }

                                    for (byte i = NVRData.CRC16_ADDRESS; i < nvrData.CRC16.Length + NVRData.CRC16_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.CRC16[i - NVRData.CRC16_ADDRESS];
                                    }
                                    for (byte i = NVRData.APP_DATA_ADDRESS; i < nvrData.APP_DATA.Length + NVRData.APP_DATA_ADDRESS; i++)
                                    {
                                        buffer[i] = nvrData.APP_DATA[i - NVRData.APP_DATA_ADDRESS];
                                    }
                                    buffer[NVRData.HW_ADDRESS] = nvrData.HW;

                                    for (int i = Constants.NVR_START_ADDRESS; i < Constants.NVR_END_ADDRESS; i++)
                                    {
                                        device.WriteNvrByte((byte)i, buffer[i]);
                                    }
                                }
                                else
                                {
                                    ret = false;
                                }
                            }

                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantWriteNvr, true);
                        }
                        device.SetBusyLedState(false);
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {

            }
            finally
            {

                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                ControllerManager.DeviceClose();
            }
            return ret;
        }

        private bool IsEmpty(byte[] buffer, byte emptyValue)
        {
            bool result = true;
            for (int i = Constants.NVR_START_ADDRESS; i < Constants.NVR_END_ADDRESS; i++)
            {
                if (buffer[i] != emptyValue)
                {
                    result = false;
                    break;
                }
            }
            return result;
        }

        public void OnNvrReadButtonClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                NVRData readData = null;
                byte[] secondData = null;
                List<byte[]> resData = null;

                ControllerManager.DoAction(new EventHandler(delegate
                {
                    resData = NvrRead();
                }), Resources.MsgReadNvrProgress, false, 0x00);

                if (resData != null && resData.Count > 0)
                {
                    readData = resData[0];
                    if (resData.Count > 1)
                    {
                        secondData = resData[1];
                    }
                }
                if (readData != null)
                {
                    MapNVRData2Form(ControllerManager.ZW050xForm, readData, secondData);
                    ControllerManager.ShowMessage(Resources.MsgReadROMDone, false);
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantReadNvr, true);
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }

        public List<byte[]> NvrRead()
        {
            List<byte[]> ret = null;
            int progInterface = ControllerManager.GetProgrammingInterface();
            if (progInterface == 0)
            {
                ret = NvrDataRead(true);
            }
            else if (progInterface == 1)
            {
                ControllerManager.DeviceInit();
                ret = NvrDataRead(ControllerManager.DocumentModel.PortInfo, progInterface, true);
                ControllerManager.RestoreSelectedDevice();
            }
            else if (progInterface == 2)
            {
                //TODO USB
            }
            return ret;
        }

        public byte[] NvrRead(IProgrammableDevice device)
        {
            byte[] result = null;

            try
            {
                result = device.ReadNvr(0);
                if (result == null)
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantReadNvr, true);
                }
            }
            catch
            {

            }
            finally
            {

            }
            return result;
        }

        public List<byte[]> NvrDataRead(Win32PnPEntityClass portInfo, int progInterface, bool readWholeNvr)
        {
            List<byte[]> result = null;
            AutoProgDevice device = new AutoProgDevice(portInfo, ControllerManager);
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {

                        byte[] nvrData = device.ReadNvr(0);
                        if (nvrData != null)
                        {
                            result = new List<byte[]>();
                            result.Add(nvrData);
                            if (readWholeNvr)
                            {
                                byte[] nvrData2 = device.ReadNvr(1);
                                if (nvrData2 != null)
                                    result.Add(nvrData2);
                            }
                            if (!ControllerManager.IsConsoleMode)
                            {
                                string hexData = HexFileHelper.WriteIntelHexFileStartingFromAddress(nvrData, 9, nvrData.Length, 0x10, 0xFF, false);
                                if (result.Count > 1)
                                {
                                    //string hexData2 = HexFileHelper.WriteIntelHexFile(result[1], 0, result[1].Length, 0x10, 0xFF, false);
                                    //hexData = hexData + Environment.NewLine + hexData2;
                                }
                                ControllerManager.ShowConsoleInfo(hexData, "NVR content excluding LockBits", false);
                            }
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantReadNvr, true);
                        }

                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch (Exception)
            {

            }
            finally
            {

                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                device.Close();
            }
            return result;
        }

        public List<byte[]> NvrDataRead(bool readWholeNvr)
        {
            List<byte[]> result = null;
            var device = ControllerManager.DeviceOpen();
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        device.SetBusyLedState(true);
                        byte[] nvrData = device.ReadNvr(0);
                        if (nvrData != null)
                        {
                            result = new List<byte[]>();
                            result.Add(nvrData);
                            if (readWholeNvr)
                            {
                                byte[] nvrData2 = device.ReadNvr(1);
                                if (nvrData2 != null)
                                    result.Add(nvrData2);
                            }
                            if (!ControllerManager.IsConsoleMode)
                            {
                                string hexData = HexFileHelper.WriteIntelHexFileStartingFromAddress(nvrData, 9, nvrData.Length, 0x10, 0xFF, false);
                                if (result.Count > 1)
                                {
                                    //string hexData2 = HexFileHelper.WriteIntelHexFile(result[1], 0, result[1].Length, 0x10, 0xFF, false);
                                    //hexData = hexData + Environment.NewLine + hexData2;
                                }
                                ControllerManager.ShowConsoleInfo(hexData, "NVR content excluding LockBits", false);
                            }
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantReadNvr, true);
                        }
                        device.SetBusyLedState(false);
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {

            }
            finally
            {

                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                ControllerManager.DeviceClose();
            }
            return result;
        }

        public byte[] EEPROMReadModule(byte type)
        {
            byte[] ret = new byte[0];
            ControllerManager.ShowMessageInConsole(Resources.MsgReadEEPROMProgress);
            byte[] eepromBuffer = null;
            NVMTypes nvm_type = NVMTypes.NVMInvalid;
            var device = ControllerManager.DeviceOpen();
            ControllerManager.ChangeProgressInfo(ProgressStatuses.None, 0, 0);
            NvmData nvm = null;
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        nvm_type = device.Memory.SwitchEEPROM(true, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        if (nvm_type != NVMTypes.NVMInvalid)
                        {
                            device.SetBusyLedState(true);
                            device.Memory.ProgressChanged += new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            byte[] totalSize = device.Memory.ReadEEPROM(0, 2);
                            byte[] nvmBuffer = device.Memory.ReadEEPROM(0, (totalSize[0] << 8) + totalSize[1]);
                            nvm = nvmBuffer;
                            var module = nvm.Modules.FirstOrDefault((x) => x.TypeValue == type);
                            if (module != null)
                            {
                                ret = module.Data.ToArray();
                            }
                            else
                            {
                                ControllerManager.ShowMessage("Module not found", true);
                            }
                            device.Memory.ProgressChanged -= new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            eepromBuffer = device.Memory.Buffer;
                            device.SetBusyLedState(false);
                            device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantInitEEPROM, true);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                ControllerManager.ShowMessage(Resources.ErrorCantReadEEPROM, true);
            }
            finally
            {
                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                ControllerManager.DeviceClose();
            }



            string nvm_type_str = ProgrammerActions.NVMChipTypeToString(nvm_type);
            if (nvm != null && nvm.Modules.Count > 0)
            {
                if (ControllerManager.IsConsoleMode)
                {
                    try
                    {
                        ControllerManager.ShowMessage(nvm_type_str + Resources.MsgNVMReadFinished, false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    ControllerManager.ShowMessageInStatus(nvm_type_str + Resources.MsgNVMReadFinished, false);
                }
            }
            else
            {
                ControllerManager.ShowMessageInStatus(nvm_type_str + Resources.MsgNVMReadFinished, false);
            }
            return ret;
        }

        private void EEPROMWriteModule(byte type, byte[] data)
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadEEPROMProgress);
            byte[] eepromBuffer = null;
            NVMTypes nvm_type = NVMTypes.NVMInvalid;
            var device = ControllerManager.DeviceOpen();
            ControllerManager.ChangeProgressInfo(ProgressStatuses.None, 0, 0);
            NvmData nvm = null;
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        nvm_type = device.Memory.SwitchEEPROM(true, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        if (nvm_type != NVMTypes.NVMInvalid)
                        {
                            device.SetBusyLedState(true);
                            device.Memory.ProgressChanged += new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            byte[] totalSize = device.Memory.ReadEEPROM(0, 2);
                            byte[] nvmBuffer = device.Memory.ReadEEPROM(0, (totalSize[0] << 8) + totalSize[1]);
                            nvm = nvmBuffer;
                            var module = nvm.Modules.FirstOrDefault((x) => x.TypeValue == type);
                            if (module != null)
                            {
                                module.Data.Clear();
                                module.Data.AddRange(data);
                                nvmBuffer = nvm;
                                device.Memory.WriteEEPROM(nvmBuffer);
                            }
                            else
                            {
                                ControllerManager.ShowMessage("Module not found", true);
                            }
                            device.Memory.ProgressChanged -= new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            eepromBuffer = device.Memory.Buffer;
                            device.SetBusyLedState(false);
                            device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantInitEEPROM, true);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                ControllerManager.ShowMessage(Resources.ErrorCantReadEEPROM, true);
            }
            finally
            {
                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                ControllerManager.DeviceClose();
            }
        }

        public void OnEEPROMGetModuleClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    byte[] type = Tools.GetBytes(ControllerManager.ZW050xForm.tbNvmModuleType.Text);
                    if (type != null && type.Length == 1)
                    {
                        ControllerManager.DoAction(new EventHandler(delegate
                        {
                            byte[] res = EEPROMReadModule(type[0]);
                            ControllerManager.ZW050xForm.BeginInvoke(new Action(
                                () => ControllerManager.ZW050xForm.tbNvmModuleData.Text = Tools.GetHexShort(res)));

                        }), Resources.MsgReadEEPROMProgress, false, 0x00);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage("External NVM Read is not implemented for UART/USB programming interfaces", true);
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }

        public void OnEEPROMSetModuleClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    byte[] type = Tools.GetBytes(ControllerManager.ZW050xForm.tbNvmModuleType.Text);
                    byte[] data = Tools.GetBytes(ControllerManager.ZW050xForm.tbNvmModuleData.Text);
                    if (type != null && type.Length == 1 && data != null && data.Length > 0)
                        ControllerManager.DoAction(new EventHandler(delegate
                        {
                            EEPROMWriteModule(type[0], data);
                        }), Resources.MsgReadEEPROMProgress, false, 0x00);
                }
                else
                {
                    ControllerManager.ShowMessage("External NVM Read is not implemented for UART/USB programming interfaces", true);
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }
        }

        public void OnEEPROMReadModulesClick(object sender, EventArgs e)
        {
            if (ControllerManager.DocumentModel.PortInfo != null)
            {
                int progInterface = ControllerManager.GetProgrammingInterface();
                if (progInterface == 0)
                {
                    ControllerManager.DoAction(new EventHandler(delegate
                    {
                        EEPROMReadModules();
                    }), Resources.MsgReadEEPROMProgress, false, 0x00);
                }
                else
                {
                    ControllerManager.ShowMessage("External NVM Read is not implemented for UART/USB programming interfaces", true);
                }
            }
            else
            {
                ControllerManager.ShowMessage(Resources.MsgInterfaceNotSelected, true);
            }

        }

        internal void EEPROMReadModules()
        {
            ControllerManager.ShowMessageInConsole(Resources.MsgReadEEPROMProgress);
            byte[] eepromBuffer = null;
            NVMTypes nvm_type = NVMTypes.NVMInvalid;
            var device = ControllerManager.DeviceOpen();
            ControllerManager.ChangeProgressInfo(ProgressStatuses.None, 0, 0);
            NvmData nvm = null;
            try
            {
                if (device.SetProgrammingMode(true))
                {
                    device.ReadSignatureBits();
                    if (ControllerManager.Actions.CommonActions.CheckDeviceChipTypeCompatibility(device))
                    {
                        nvm_type = device.Memory.SwitchEEPROM(true, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        if (nvm_type != NVMTypes.NVMInvalid)
                        {
                            device.SetBusyLedState(true);
                            device.Memory.ProgressChanged += new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            byte[] totalSize = device.Memory.ReadEEPROM(0, 2);
                            byte[] nvmBuffer = device.Memory.ReadEEPROM(0, (totalSize[0] << 8) + totalSize[1]);
                            nvm = nvmBuffer;
                            device.Memory.ProgressChanged -= new ZWave.Events.ProgressChangedEventHandler(OnDeviceMemoryProgressChanged);
                            eepromBuffer = device.Memory.Buffer;
                            device.SetBusyLedState(false);
                            device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                        }
                        else
                        {
                            ControllerManager.ShowMessage(Resources.ErrorCantInitEEPROM, true);
                        }
                    }
                    else
                    {
                        ControllerManager.ShowMessage(Resources.MsgIncorrectChipType, true);
                    }
                }
                else
                {
                    ControllerManager.ShowMessage(Resources.ErrorCantSetProgrammingMode, true);
                }
            }
            catch
            {
                device.Memory.SwitchEEPROM(false, (int)ControllerManager.DocumentModel.Settings.EepromSize);
                ControllerManager.ShowMessage(Resources.ErrorCantReadEEPROM, true);
            }
            finally
            {
                if (!ControllerManager.DocumentModel.Settings.HoldDeviceInReset)
                    device.SetProgrammingMode(false);
                ControllerManager.DeviceClose();
            }
            string nvm_type_str = ProgrammerActions.NVMChipTypeToString(nvm_type);
            if (nvm != null && nvm.Modules.Count > 0)
            {
                if (ControllerManager.IsConsoleMode)
                {
                    try
                    {
                        ControllerManager.ShowMessage(nvm_type_str + Resources.MsgNVMReadFinished, false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
                else
                {
                    ControllerManager.ShowConsoleInfo(nvm.ToText());
                    ControllerManager.ShowMessageInStatus(nvm_type_str + Resources.MsgNVMReadFinished, false);
                }
            }
            else
            {
                ControllerManager.ShowConsoleInfo("No NVM Modules found");
                ControllerManager.ShowMessageInStatus(nvm_type_str + Resources.MsgNVMReadFinished, false);
            }
        }

    }
}
