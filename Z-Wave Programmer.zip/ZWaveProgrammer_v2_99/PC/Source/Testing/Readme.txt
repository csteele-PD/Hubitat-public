[Folders]
"Output" is a folder that contains test reports in html format
"Readback" is a folder that contains readback files. For example, test reads nvr memory and saves it to file "Readback\readback_nvr.hex"
"SerialAPI" is a folder with hex files that are used to program device. For example, static controller, empty nvr, and so on.
"System" is a folder with bat files that are responsible for executing tests
"TestPacks" is a folder with test packs files (txt). That files are lists of test that should be executed
"TestBatFiles" is a folder with bat files that call ZWaveProgrammer.exe and each do their specific actions. For example, SPI_e.bat file erases device flash memory using SPI interface.

[Files in root folder]
Bat files in root folder are test launchers. For example, SPI_Erase_Write_Verify.bat is a launcher for test that erases, than writes and then verifies device flash content, using SPI interface

[Test pack file explanation] (See it in folder TestPacks)
One line = one action
For example:

"TestsBatFiles\SPI_e.bat" "Erase"
"TestsBatFiles\SPI_p.bat" "Read"
"TestsBatFiles\SPI_v.bat" "Verify"

Here we can see three lines with two values in each of them. 
	First value is a path to bat file that doing it's action. SPI_e.bat is used for erasing flash memory of the device using SPI interface
	Second value is a name of action. This value will appear in test result html file. If you'll not set second value, the name of action will be same as name of the bat file that called for this action
	
	
[Test launcher .bat file explanation] Bat files in root folder

Let's see the file SPI_Erase_Write_Verify.bat
SET COMPORT=COM22
SET ZWaveProgrammerPath="C:\Program Files (x86)\Sigma Designs\Z-Wave Programmer\ZWaveProgrammer.exe"
CALL System\TestPackLauncher.bat "TestPacks\Erase_Write_Verify.txt" "Output\Erase_Write_Verify.html"

Here we can see three lines. 
First line is a defining variable COMPORT that is using later to call ZWaveProgrammer.exe (there you have to set COMPORT)
Second line is a defining path to ZWaveProgrammer.exe file. 
Third line is a call for TestPackLauncher.bat with two params: 
	1. The name of test pack file. In other words, What actions should be done
	2. The name of html file to where you want to write the results of this test