﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;

namespace HexFileReader
{
    public static class HexFileHelper
    {
        public const int SEGMENT_MAX_SIZE = 0xFFFF;

        /// <summary>
        /// Reads file line by line and returns collection of parsed lines
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static ParsedHexFile ReadFile(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException("There is not such file", filePath);

            var result = new ParsedHexFile();
            StreamReader file = null;
            try
            {
                file = new StreamReader(filePath);
                ushort segmentAddress = 0x00;
                string line;
                while ((line = file.ReadLine()) != null)
                {
                    if (ParseLine(line, result, ref segmentAddress))
                        break;
                }
            }
            catch (IncorrectFileFormatException ex)
            {
            }
            catch (Exception ex)
            {
            }
            finally
            {
                if (file != null)
                    file.Close();
            }

            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="line"></param>
        /// <param name="parsedData"></param>
        /// <param name="segmentAddress"></param>
        /// <returns>Returns true if it's end of file and file if it's not end of file</returns>
        private static bool ParseLine(string line, ParsedHexFile parsedData, ref ushort segmentAddress)
        {
            if (string.IsNullOrEmpty(line))
                return false;

            var firstSymbol = line.Substring(0, 1);
            if (firstSymbol != ":")
                throw new IncorrectFileFormatException();

            var lineBytes = StringToByteArray(line.Substring(1));

            var recordType = (HexFileRecordType)lineBytes[3];
            var recordLength = lineBytes[0];
            var data = new byte[recordLength];
            Buffer.BlockCopy(lineBytes, 4, data, 0, recordLength);

            switch (recordType)
            {
                case HexFileRecordType.ExtendedLinearAddressRecord:
                    if (data.Length < 2)
                        throw new Exception(string.Format("Incorrect linear address {0}", ByteArrayToString(data)));
                    
                    segmentAddress = CombineBytesToUShort(data[0], data[1]);
                    break;
                
                case HexFileRecordType.DataRecord:
                    HexSegment segment;
                    if (!parsedData.TryGetValue(segmentAddress, out segment))
                    {
                        segment = new HexSegment();
                        parsedData[segmentAddress] = segment;
                    }
                
                    var address = CombineBytesToUShort(lineBytes[1], lineBytes[2]);
                    segment[address] = data;

                    var segLen = address + data.Length;
                    if (segment.SegmentLength < segLen)
                        segment.SegmentLength = segLen;
                    break;
                case HexFileRecordType.EndOfFileRecord:
                    return true;
            }

            return false;
        }

        public static void WriteHexFile(string filename, byte[] array, byte lineWidth, byte emptyValue)
        {
            var hex = WriteHexFile(array, lineWidth, emptyValue);
            File.WriteAllText(filename, hex);
        }
        public static string WriteHexFile(byte[] array, byte lineWidth, byte emptyValue)
        {
            if (array == null)
                throw new ArgumentException("array mus not be null");

            var result = new StringBuilder();

            ushort currentSegmentAddress = 0x00;
            int cursorPos = 0x00;
            while (cursorPos < array.Length)
            {
                var address = (ushort)cursorPos;
                var segmentAddress = (ushort)(cursorPos >> 16);

                if (segmentAddress > currentSegmentAddress)
                {
                    //here we have to add new segment
                    currentSegmentAddress = segmentAddress;
                    result.Append(MakeStartLinearAddressRecord(segmentAddress));
                }
                
                var segmentFreeSpace = SEGMENT_MAX_SIZE - address + 1;

                var currentLineWidth = array.Length - cursorPos;
                currentLineWidth = Math.Min(currentLineWidth, lineWidth);
                currentLineWidth = Math.Min(segmentFreeSpace, currentLineWidth);

                if (segmentFreeSpace <= 0)
                    continue;

                var buf = new byte[currentLineWidth];
                Buffer.BlockCopy(array, cursorPos, buf, 0, currentLineWidth);

                result.Append(MakeRecordString(buf, emptyValue, address, segmentAddress));

                cursorPos += currentLineWidth;
            }

            result.Append(":00000001FF");

            return result.ToString();
        }

        private static string MakeStartLinearAddressRecord(ushort segmentAddress)
        {
            var segmentAddressBytes = BitConverter.GetBytes(segmentAddress);
            var checksum = CalcChecksum(segmentAddressBytes);
            var result = string.Format(":02000004{0:X4}{1:X2}\r\n", segmentAddress, checksum);
            return result;
        }

        private static string MakeRecordString(byte[] array, byte emptyValue, ushort address, ushort segmentAddress)
        {
            var result = new StringBuilder();

            var currentBuf = new List<byte>();

            for (int i = array.Length-1; i >= 0; i--)
            {
                var curValue = array[i];
                if (curValue != emptyValue)
                    currentBuf.Insert(0, curValue);
            }

            if (currentBuf.Count == 0)
                return string.Empty;

            result.AppendLine(MakeDataRecord(currentBuf, address));

            return result.ToString();
        }

        private static string MakeDataRecord(List<byte> lineBytes, ushort address)
        {
            var array = lineBytes.ToArray();
            var checksum = CalcChecksum(array);
            var byteCount = (byte) array.Length;
            const byte recordType = 0x00;
            var str = string.Format(":{0:X2}{1:X4}{2:X2}{3}{4:X2}", 
                byteCount,
                address,
                recordType,
                ByteArrayToString(array), 
                checksum);
            return str;
        }

        public static string ByteArrayToString(byte[] ba)
        {
            var hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }
        public static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();
        }

        public static int CombineBytesToInt(byte b1, byte b2)
        {
            int combined = b1 << 8 | b2;
            return combined;
        }
        public static ushort CombineBytesToUShort(byte b1, byte b2)
        {
            var combined = (ushort) (b1 << 8 | b2);
            return combined;
        }

        public static byte[] MakeArrayOfValue(int arraySize, byte value)
        {
            var result = new byte[arraySize];
            var emptyValuesBuf = new[]
            {
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
                value, value, value, value, value, value, value, value,
            };

            var i = 0;
            while (i < result.Length)
            {
                var lenToFill = result.Length - i;
                lenToFill = Math.Min(lenToFill, emptyValuesBuf.Length);
                Buffer.BlockCopy(emptyValuesBuf, 0, result, i, lenToFill);
                i += lenToFill;
            }

            return result;
        }

        public static byte[] CombineToBytesArray(HexSegment segment, byte emptyValue)
        {
            var result = MakeArrayOfValue(segment.SegmentLength, emptyValue);

            foreach (var segmentNode in segment)
            {
                var address = segmentNode.Key;
                var data = segmentNode.Value;

                Buffer.BlockCopy(data, 0, result, address, data.Length);
            }

            return result;
        }

        public static byte CalcChecksum(byte[] array)
        {
            var arraySum = array.Sum(p=>p);
            var result = (byte) (0x01 + ~(arraySum));
            return result;
        }
    }
}
