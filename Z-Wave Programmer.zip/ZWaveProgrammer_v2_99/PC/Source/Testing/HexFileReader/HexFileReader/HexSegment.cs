﻿using System.Collections.Generic;

namespace HexFileReader
{
    public class HexSegment : Dictionary<ushort, byte[]>
    {
        public int SegmentLength;
    }

    public class ParsedHexFile : Dictionary<ushort, HexSegment>
    {
        
    }
}
