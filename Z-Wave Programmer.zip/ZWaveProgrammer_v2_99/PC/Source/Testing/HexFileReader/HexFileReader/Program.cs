﻿using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

namespace HexFileReader
{
    class Program
    {
        /// <summary>
        /// Params: 
        ///     /? - help
        ///     filename - read file and print file content
        ///     filename -address -length - read file and print the part of file starting from address and -length length
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            ParseAndProcessParameters(args);
        }

        private static void ParseAndProcessParameters(string[] args)
        {
            if (args == null || args.Length == 0 || args[0] == "/?")
            {
                PrintHelp();
                return;
            }

            var firstParam = args[0];

            if (firstParam.StartsWith("-"))
            {
                //choose mode
                switch (firstParam)
                {
                    case "-r": //read file
                        try
                        {
                            ReadFile(args);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: {0}", ex.Message);
                            PrintHelp();
                        }
                        break;
                }
            }
        }

        private static void ReadFile(string[] args)
        {
            if (args.Length <= 1)
            {
                //no filename specified
                throw new Exception("No file name specified!");
            }

            //extract filename
            var filename = args[1];
            var fullPath = Path.GetFullPath(filename);
            Console.WriteLine("Full path is {0}", fullPath);
            if (!File.Exists(filename))
            {
                throw new FileNotFoundException(string.Format("{0} file doesn't exists", filename));
            }

            //extract address
            uint fullAddress = 0;
            if (args.Length > 2)
            {
                var sAddress = args[2].ToLower();
                if (sAddress.StartsWith("0x"))
                    sAddress = sAddress.Substring(2);
                if (sAddress.EndsWith("h"))
                    sAddress = sAddress.Substring(0, sAddress.Length - 1);

                if (!uint.TryParse(sAddress, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out fullAddress))
                    throw new Exception(string.Format("{0} value is incorrect for address. Type int value in HEX format", args[2]));
            }

            //extract lenght
            int lenght = -1;
            if (args.Length > 3)
            {
                var sLen = args[3].ToLower();
                if (sLen.StartsWith("0x"))
                    sLen = sLen.Substring(2);
                if (sLen.EndsWith("h"))
                    sLen = sLen.Substring(0, sLen.Length - 1);

                if (!int.TryParse(sLen, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out lenght))
                    throw new Exception(string.Format("{0} value is incorrect for data lenght. Type int value in HEX format", args[3]));
            }

            var address = (ushort)fullAddress;
            ushort segmentAddress = 0x00;

            //check segment address
            if (fullAddress > 0xFFFF)
                segmentAddress = (ushort)(fullAddress >> 16);

            ReadFile(filename, address, segmentAddress, lenght);
        }
        private static void ReadFile(string filename, ushort address, ushort segmentAddress, int lenght)
        {
            var parsedFile = HexFileHelper.ReadFile(filename);
            HexSegment segment;
            if (!parsedFile.TryGetValue(segmentAddress, out segment))
                return;

            var extractedData = HexFileHelper.CombineToBytesArray(segment, 0xFF);

            if (extractedData.Length == 0)
                return;

            if (address == -1)
                address = 0;

            if (lenght == -1)
                lenght = extractedData.Length;

            var buf = new byte[lenght];
            Buffer.BlockCopy(extractedData, address, buf, 0, lenght);

            var bytesPerLine = 0;
            var splitter = string.Empty;
            if (buf.Length > 4)
            {
                bytesPerLine = 16;
                splitter = " ";
            }
            var str = ByteArrayToString(buf, bytesPerLine, splitter);
            Console.WriteLine(str);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="array"></param>
        /// <param name="bytesPerLine">Where to split bytes. If this value == 0, there will be no splitiings</param>
        /// <param name="bytesSplitter"></param>
        /// <returns></returns>
        private static string ByteArrayToString(byte[] array, int bytesPerLine, string bytesSplitter)
        {
            if (array.Length == 0)
                return string.Empty;

            if (bytesPerLine <= 0)
                bytesPerLine = array.Length;
            bytesPerLine = Math.Min(array.Length, bytesPerLine);

            var result = new StringBuilder();

            for (int i = 0; i < array.Length; i++)
            {
                if (i > 0 && i % bytesPerLine == 0)
                    result.AppendLine();

                var str = array[i].ToString("X2");
                result.Append(str);
                result.Append(bytesSplitter);
            }

            return result.ToString();
        }

        private static void PrintHelp()
        {
            var assembly = Assembly.GetExecutingAssembly();
            const string resourceName = "HexFileReader.Help_En.txt";

            using (var stream = assembly.GetManifestResourceStream(resourceName))
                if (stream != null)
                    using (var reader = new StreamReader(stream))
                    {
                        var helpOutput = reader.ReadToEnd();
                        Console.WriteLine(helpOutput);
                    }

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        private static bool Choise(string message)
        {
            Console.WriteLine("{0} y/n", message);
            var userFeedBack = Console.ReadKey();
            Console.WriteLine();
            return userFeedBack.Key == ConsoleKey.Y;
        }
    }
}
