﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HexFileReader
{
    public class NvrAddresses
    {
        public const byte REV_ADDRESS = 0x10;
        public const byte CCAL_ADDRESS = 0x11;
        public const byte PINS_ADDRESS = 0x12;
        public const byte NVMCS_ADDRESS = 0x13;
        public const byte SAWC_ADDRESS = 0x14;
        public const byte SAWB_ADDRESS = 0x17;
        public const byte NVMT_ADDRESS = 0x18;
        public const byte NVMS_ADDRESS = 0x19;
        public const byte NVMP_ADDRESS = 0x1B;
        public const byte UUID_ADDRESS = 0x1D;
        public const byte IDVEN_ADDRESS = 0x2D;
        public const byte IDPROD_ADDRESS = 0x2F;
        public const byte TXCAL2_ADDRESS = 0x32;
        public const byte PROTOCOL_DATA_ADDRESS = 0x33;
        public const byte CRC16_ADDRESS = 0x7E;
        public const byte APP_DATA_ADDRESS = 0x80;
    }
}
