﻿using System;

namespace HexFileReader
{
    public class IncorrectFileFormatException : Exception
    {
    }
}