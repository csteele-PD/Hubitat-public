namespace HexFileReader
{
    public class HexFileDataRecord
    {
        public ushort Address;
        public byte[] Data;
        public int Length;
        public HexFileRecordType RecordType;
    }
}