﻿namespace HexFileReader
{
    public enum HexFileRecordType : byte
    {
        DataRecord = 0x00,
        EndOfFileRecord = 0x01,
        ExtendedSegmentAddressRecord = 0x02,
        ExtendedLinearAddressRecord = 0x04,
        StartLinearAddressRecord = 0x05,
    }
}