﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HexFileReader;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HexFileReaderTests
{
    [TestClass]
    public class GeneralTests
    {
        [TestMethod]
        public void ChecksumCalculation()
        {
            var lines =
            new []{
                ":10 01 00 00 C0 7A 74 01 C0 E0 C0 82 C0 83 75 7A 0A E5 FF 54 EA",
                ":10 06 08 00 F0 EA 22 C2 D5 EC 30 E7 09 B2 D5 E4 C3 9D FD E4 97"
            };
            var array = new byte[]
            {
                0x10, 0x01, 0x00, 0x00, 0xC0, 0x7A, 0x74, 0x01, 0xC0, 0xE0, 0xC0, 0x82, 0xC0, 0x83, 0x75, 0x7A, 0x0A, 0xE5,
                0xFF, 0x54
            };
            var array2 = new byte[]
            {
                0x10, 0x06, 0x08, 0x00, 0xF0, 0xEA, 0x22, 0xC2, 0xD5, 0xEC, 0x30, 0xE7, 0x09, 0xB2, 0xD5, 0xE4, 0xC3,
                0x9D, 0xFD, 0xE4
            };

            var expectedChecksum = 0xEA;
            var actualChecksum = HexFileHelper.CalcChecksum(array);
            Assert.IsTrue(expectedChecksum == actualChecksum);

            expectedChecksum = 0x97;
            actualChecksum = HexFileHelper.CalcChecksum(array2);
            Assert.IsTrue(expectedChecksum == actualChecksum);
        }

        [TestMethod]
        public void WriteFileTest()
        {
            var array = HexFileHelper.MakeArrayOfValue(0x1FFFF, 0xFF);
            
            var random = new Random();

            for (int i = 0; i < 64; i++)
            {
                if (random.Next(2) == 0)
                    array[i] = 0xFF;
                else
                    array[i] = (byte) random.Next(256);
            }

            for (int i = 0; i < 64; i++)
            {
                var j = 0xFFFF + i;
                if (random.Next(2) == 0)
                    array[j] = 0xFF;
                else
                    array[j] = (byte) random.Next(256);
            }

            var result = HexFileHelper.WriteHexFile(array, 0x10, 0xFF);
        }
    }
}
