﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ZWave.Programmer.Classes;

namespace ZWaveProgrammer.UnitTests.Models
{
    [TestFixture]
    public class HexFilesTests
    {
        [Test]
        public void PrepareAndCheckIntelHexFile()
        {
            var buffer = new byte[100];
            Random r = new Random();
            r.NextBytes(buffer);
            for (int i = 0; i < 16; i++)
            {
                int startAddress = i;
                var res = HexFileHelper.WriteIntelHexFileStartingFromAddress(buffer, startAddress, buffer.Length, 0x10, 0xFF, false);
                Console.WriteLine(res);
                var res1 = HexFileHelper.ReadIntelHexData(res, 0x00).First();
                
                Assert.IsTrue(res1.Value.Skip(startAddress).SequenceEqual(buffer.Skip(startAddress)));
            }
        }
    }
}
