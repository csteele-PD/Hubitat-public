﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using ZWave.Programmer.Classes;

namespace ZWaveProgrammer.UnitTests.Models
{
    [TestFixture]
    public class NvmDataTests
    {
        [Test]
        public void ModuleEmpty()
        {
            NvmModule module = new NvmModule();

            Assert.IsTrue(module.IsValid);
            Assert.AreEqual(7, module.Size);

            byte[] buffer = module;

            Assert.AreEqual(buffer.Length, module.Size);
            Assert.AreEqual(buffer.Length, (buffer[0] << 8) + buffer[1]);
            Assert.AreEqual(buffer.Length, (buffer[buffer.Length - 5] << 8) + buffer[buffer.Length - 4]);
        }

        [Test]
        public void ModuleRandom()
        {
            Random rnd = new Random();
            for (int i = 0; i < 1000; i++)
            {
                NvmModule module = new NvmModule();
                byte type = (byte)rnd.Next();
                ushort version = (ushort)rnd.Next();
                module.TypeValue = type;
                Assert.DoesNotThrow(() => { var aa = module.IsDefinedType; });
                module.Version = version;
                byte[] data = new byte[rnd.Next(0, 1000)];
                rnd.NextBytes(data);
                module.Data.AddRange(data);

                Assert.IsTrue(module.IsValid);
                Assert.AreEqual(data.Length + 7, module.Size);

                byte[] buffer = module;
                for (int j = 0; j < 10; j++)
                {
                    Assert.AreEqual(buffer.Length, module.Size);
                    Assert.AreEqual(buffer.Length, (buffer[0] << 8) + buffer[1]);
                    Assert.AreEqual(buffer.Length, (buffer[buffer.Length - 5] << 8) + buffer[buffer.Length - 4]);
                    Assert.AreEqual(type, buffer[buffer.Length - 3]);
                    Assert.AreEqual(version, (buffer[buffer.Length - 2] << 8) + buffer[buffer.Length - 1]);

                    NvmModule m = buffer;
                    Assert.AreEqual(type, m.TypeValue);
                    Assert.AreEqual(version, m.Version);
                    Assert.AreEqual(buffer.Length, m.Size);
                    buffer = m;
                }
            }
        }

        [Test]
        public void DataEmpty()
        {
            NvmData module = new NvmData();

            Assert.IsTrue(module.IsValid);
            Assert.AreEqual(3, module.TotalEnd);

            byte[] buffer = module;

            Assert.AreEqual(buffer.Length, module.TotalEnd);
            Assert.AreEqual(buffer.Length, (buffer[0] << 8) + buffer[1]);
        }

        [Test]
        public void DataRandom()
        {
            Random rnd = new Random();
            for (int i = 0; i < 100; i++)
            {
                NvmData nvmData = new NvmData();
                int totalSize = 3;
                int modulesCount = 0;
                for (int j = 0; j < 100; j++)
                {
                    byte[] data = new byte[rnd.Next(0, 100)];
                    rnd.NextBytes(data);
                    NvmModule module = new NvmModule() { Data = new List<byte>(data) };
                    totalSize += module.Size;
                    nvmData.Modules.Add(module);
                    modulesCount++;
                }
                Assert.Less(totalSize, ushort.MaxValue);
                Assert.IsTrue(nvmData.IsValid);
                Assert.AreEqual(totalSize, nvmData.TotalEnd);

                byte[] buffer = nvmData;
                for (int j = 0; j < 10; j++)
                {
                    Assert.AreEqual(buffer.Length, nvmData.TotalEnd);
                    Assert.AreEqual(buffer.Length, (buffer[0] << 8) + buffer[1]);

                    NvmData m = buffer;
                    Assert.AreEqual(buffer.Length, m.TotalEnd);
                    Assert.IsTrue(nvmData.IsValid);
                    Assert.AreEqual(modulesCount, m.Modules.Count);
                    buffer = m;
                }
            }
        }
    }
}
