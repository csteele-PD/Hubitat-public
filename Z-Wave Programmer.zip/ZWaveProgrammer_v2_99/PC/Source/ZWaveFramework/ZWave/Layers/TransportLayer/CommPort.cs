using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.IO;
using System.Threading;
using ZWave.Exceptions;
using ZWave.Framework;

namespace ZWave.SerialPortTransport
{
    public delegate void CommDataReceivedEventHandler(object sender, CommDataReceivedEventArgs e);
    public class CommDataReceivedEventArgs : EventArgs
    {

    }

    public class CommPort
    {
        private const int CAPACITY = 1000000;
        public event CommDataReceivedEventHandler DataReceived;
        private SerialPort port;
        private Thread workerThread;
        bool isClosing = false;
        private byte[] bufferTmp;
        private byte[] bufferStore = new byte[CAPACITY];
        public byte[] bufferWorker = new byte[CAPACITY];
        private int lengthStore = 0;
        public int lengthWorker = 0;
        private AutoResetEvent workerSignal = new AutoResetEvent(false);
        private object locker = new object();
        private string mPortName = "";
        public CommPort(string portName)
        {
            mPortName = portName;
        }

        public void Open()
        {
            if (!IsOpen)
            {
                port = new SerialPort(mPortName, 115200, Parity.None, 8, StopBits.One);
                port.WriteTimeout = 10000;
                port.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
                port.Open();
                if (port.IsOpen)
                {
                    port.ReadExisting();
                    workerThread = new Thread(DoWork);
                    workerThread.IsBackground = true;
                    workerThread.Start();
                }
            }
        }

        void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            lock (locker)
            {
                if (port.IsOpen)
                {
                    int bytesToRead = 0;
                    int len = 0;
                    try
                    {
                        while (port.BytesToRead > 0)
                        {
                            bytesToRead = port.BytesToRead;
                            len = port.Read(bufferStore, lengthStore, bytesToRead);
                            lengthStore += len;
                            if (len == 0)
                            {
                                break;
                            }
                        }
                    }
                    catch { }
                    if (lengthStore > CAPACITY)
                    {
                        throw new TransportLayerException("buffer overflow");
                    }
                }
                else
                {
                    Tools._writeDebugDiagnosticMessage("!!!!Port is Closed on DataReceived", true, true);
                }
            }
            workerSignal.Set();
        }

        public void Close()
        {
            if (port != null)
            {
                try
                {
                    port.ReadExisting();
                    port.Close();
                    port.Dispose();
                }
                catch { }
                
                port = null;
            }
            isClosing = true;
            workerSignal.Set();
            if (workerThread != null)
            {
                workerThread.Join();
            }
            workerThread = null;
        }

        public bool IsOpen
        {
            get
            {
                if (port == null)
                    return false;
                else
                    return port.IsOpen;
            }
        }

        public string PortName
        {
            get
            {
                if (port == null)
                    return "";
                else
                    return port.PortName;
            }
        }

        public int BytesToRead
        {
            get
            {
                return lengthWorker;
            }
        }

        private void DoWork()
        {
            while (!isClosing)
            {
                workerSignal.WaitOne();
                lock (locker)
                {
                    bufferTmp = bufferWorker;
                    bufferWorker = bufferStore;
                    bufferStore = bufferTmp;
                    lengthWorker = lengthStore;
                    lengthStore = 0;
                }
                OnDataReceive();
            }
        }

        public void OnDataReceive()
        {
            if (DataReceived != null)
                DataReceived(this, new CommDataReceivedEventArgs());
        }

        internal void Read(byte[] data, int startIndex, int bytesToRead)
        {
            Array.Copy(bufferWorker, startIndex, data, 0, bytesToRead);
        }

        internal void Write(byte[] buffer, int offset, int count)
        {
            lock (locker)
            {
                port.Write(buffer, offset, count);
            }
        }
    }
}
