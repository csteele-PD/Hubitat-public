using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Enums
{
    public enum ProgressStatuses
    {
        None,
        Read,
        Write
    }
}
