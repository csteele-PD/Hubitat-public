using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Enums
{
    /// <summary>
    /// Manager Status enumeration.
    /// </summary>
    public enum ManagerStatus
    {
        /// <summary>
        /// None.
        /// </summary>
        None,
        /// <summary>
        /// Initialized.
        /// </summary>
        Initialized
    }
}
