using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Events
{

    /// <summary>
    /// 
    /// </summary>
    public delegate void ProgressChangedEventHandler(ProgressChangedEventArgs args);
}
