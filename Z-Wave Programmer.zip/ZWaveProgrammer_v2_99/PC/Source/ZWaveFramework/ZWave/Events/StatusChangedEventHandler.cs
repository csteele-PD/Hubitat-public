using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Events
{
    /// <summary>
    /// Represents the method that handles a <see cref="ZWave.Devices.IDevice.ConnectionStatusChanged"/> event.
    /// </summary>
    public delegate void StatusChangedEventHandler(StatusChangedArgs args);
}
