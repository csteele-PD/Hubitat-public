using System;
using System.Collections.Generic;
using System.Text;

namespace ZWave.Events
{
    /// <summary>
    /// Represents the method that handles a <see cref="ISessionLayer.ResponseReceived"/> event.
    /// </summary>
    public delegate void ResponseReceivedEventHandler(ResponseReceivedEventArgs args);
}
