using System;
using System.Collections.Generic;
using System.Text;
using Zensys.Framework;

namespace Zensys.ZWave.Actions
{
    public class ActionHandlerResult
    {
        private ActionDataFrame mNextFrame;
        public ActionDataFrame NextFrame
        {
            get { return mNextFrame; }
            set { mNextFrame = value; }
        }

        private bool mIsHandled;
        public bool IsHandled
        {
            get { return mIsHandled; }
            set { mIsHandled = value; }
        }

        public ActionHandlerResult(bool isHandled)
        {
            IsHandled = isHandled;
        }

        public ActionHandlerResult(ActionDataFrame nextFrame)
        {
            NextFrame = nextFrame;
            IsHandled = true;
        }

        public override string ToString()
        {
            if (NextFrame != null)
                return string.Format("{0}: {1:X2} {2:X2} {3}", IsHandled, (byte)NextFrame.FrameType, (byte)NextFrame.CommandType, Tools.GetHex(NextFrame.Parameters));
            else
                return string.Format("{0}: null", IsHandled);
        }
    }
}
