using System;
using System.Collections.Generic;
using System.Text;

namespace Zensys.ZWave.Actions
{
    public enum ActionStates
    {
        None,
        Started,
        Expired,
        Failed,
        Completed
    }
}
