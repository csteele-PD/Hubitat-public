using System;
using System.Collections.Generic;
using System.Text;
using Zensys.Framework;
using Zensys.ZWave.Events;

namespace Zensys.ZWave.Actions
{
    public class ActionHandler
    {
        private ByteIndex[] mMask;
        public ByteIndex[] Mask
        {
            get { return mMask; }
            set { mMask = value; }
        }

        private ActionDelegate mAction;
        public ActionDelegate Action
        {
            get { return mAction; }
            set { mAction = value; }
        }
        
        public ActionHandler(ByteIndex[] mask, ActionDelegate action)
        {
            mMask = mask;
            mAction = action;
        }

        public bool WaitingFor(byte[] payload)
        {
            bool ret = true;
            for (int i = 0; i < mMask.Length && ret; i++)
            {
                if (i < payload.Length)
                {
                    if (mMask[i].Presence == Presence.Value)
                    {
                        if (mMask[i].MaskInData > 0)
                            ret = (payload[i] & mMask[i].MaskInData) == mMask[i].Value;
                        else
                            ret = payload[i] == mMask[i].Value;
                    }
                    else if (mMask[i].Presence == Presence.NotValue)
                    {
                        if (mMask[i].MaskInData > 0)
                            ret = !((payload[i] & mMask[i].MaskInData) == mMask[i].Value);
                        else
                            ret = !(payload[i] == mMask[i].Value);
                    }
                    else if (mMask[i].Presence == Presence.AnyValue)
                        ret = true;
                }
                else
                    ret = false;
            }
            return ret;
        }
    }

    public delegate ActionHandlerResult ActionDelegate(byte[] data);
}
