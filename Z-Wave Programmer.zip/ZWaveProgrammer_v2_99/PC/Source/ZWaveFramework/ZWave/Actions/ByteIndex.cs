using System;
using System.Collections.Generic;
using System.Text;

namespace Zensys.ZWave.Actions
{
    public enum Presence
    {
        Value,
        AnyValue,
        NotValue
    }
    [Serializable]
    public struct ByteIndex
    {
        public static ByteIndex AnyValue
        {
            get
            {
                ByteIndex bi;
                bi.mMaskInData = 0;
                bi.mPresence = Presence.AnyValue;
                bi.mValue = 0;
                return bi;
            }
        }

        public static ByteIndex NotValue
        {
            get
            {
                ByteIndex bi;
                bi.mMaskInData = 0;
                bi.mPresence = Presence.NotValue;
                bi.mValue = 0;
                return bi;
            }
        }

        public static ByteIndex Empty
        {
            get
            {
                ByteIndex bi;
                bi.mMaskInData = 0;
                bi.mPresence = Presence.Value;
                bi.mValue = 0;
                return bi;
            }
        }
        public bool IsEmpty { get { return mMaskInData == 0 && mPresence == Presence.Value && mValue == 0; } }

        private Presence mPresence;
        public Presence Presence { get { return mPresence; } set { mPresence = value; } }
        private byte mMaskInData;
        public byte MaskInData { get { return mMaskInData; } set { mMaskInData = value; } }
        private byte mValue;
        public byte Value { get { return mValue; } set { mValue = value; } }

        public ByteIndex(byte value)
        {
            mValue = value;
            mMaskInData = 0xFF;
            mPresence = Presence.Value;
        }

        public ByteIndex(byte value, Presence presence)
        {
            mValue = value;
            mMaskInData = 0xFF;
            mPresence = presence;
        }

        public ByteIndex(byte value, byte mask)
        {
            mValue = value;
            mMaskInData = mask;
            mPresence = Presence.Value;
        }

        public override int GetHashCode()
        {
            return mValue ^ mMaskInData ^ (int)mPresence;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is ByteIndex))
                return false;

            return Equals((ByteIndex)obj);
        }

        public bool Equals(ByteIndex other)
        {
            return mValue == other.mValue && mMaskInData == other.mMaskInData && mPresence == other.mPresence;
        }

        public static bool operator ==(ByteIndex index1, ByteIndex index2)
        {
            return index1.Equals(index2);
        }

        public static bool operator !=(ByteIndex index1, ByteIndex index2)
        {
            return !index1.Equals(index2);
        }

        public override string ToString()
        {
            string ret = "*_";
            switch (Presence)
            {
                case Presence.Value:
                    if (MaskInData == 0xFF)
                        ret = string.Format("{0:X2}", Value);
                    else
                        ret = string.Format("{0:X2}&{1:X2}", Value, MaskInData);
                    break;
                case Presence.AnyValue:
                    ret = "?";
                    break;
                case Presence.NotValue:
                    if (MaskInData == 0xFF)
                        ret = string.Format("!{0:X2}", Value);
                    else
                        ret = string.Format("!{0:X2}&{1:X2}", Value, MaskInData);
                    break;
            }
            return ret;
        }
    }
}
