using System;
using System.Collections.Generic;
using System.Text;

namespace Zensys.ZWave.Actions
{
    public class ActionResult
    {
        private ActionStates mState;
        public ActionStates State
        {
            get { return mState; }
            set { mState = value; }
        }

        private int mCommandTimeMs;
        public int CommandTimeMs
        {
            get { return mCommandTimeMs; }
            set { mCommandTimeMs = value; }
        }

        private int mTotalTimeMs;
        public int TotalTimeMs
        {
            get { return mTotalTimeMs; }
            set { mTotalTimeMs = value; }
        }

        private byte[] mResponseData;
        public byte[] ResponseData
        {
            get { return mResponseData; }
            set { mResponseData = value; }
        }

        public void Reset()
        {
            this.CommandTimeMs = 0;
            this.ResponseData = null;
            this.State = ActionStates.None;
            this.TotalTimeMs = 0;
        }
    }
}
