using System;
using System.Collections.Generic;
using System.Text;
using Zensys.ZWave.Enums;

namespace Zensys.ZWave.Actions
{
    public class ActionDataFrame
    {
        private FrameTypes mFrameType;
        public FrameTypes FrameType
        {
            get { return mFrameType; }
            set { mFrameType = value; }
        }

        private CommandTypes mCommandType;
        public CommandTypes CommandType
        {
            get { return mCommandType; }
            set { mCommandType = value; }
        }

        private byte[] mParameters;
        public byte[] Parameters
        {
            get { return mParameters; }
            set { mParameters = value; }
        }

        public ActionDataFrame(FrameTypes frameType, CommandTypes commandType, byte[] parameters)
        {
            FrameType = frameType;
            CommandType = commandType;
            Parameters = parameters;
        }
    }
}
