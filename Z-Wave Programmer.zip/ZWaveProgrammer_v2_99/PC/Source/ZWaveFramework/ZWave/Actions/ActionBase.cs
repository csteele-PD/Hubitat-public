using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Zensys.ZWave.Enums;
using Zensys.Framework;

namespace Zensys.ZWave.Actions
{
    public class ActionBase
    {
        private int mTimeoutMs = 20000;
        public int TimeoutMs
        {
            get { return mTimeoutMs; }
            set { mTimeoutMs = value; }
        }

        private ISessionLayer mSessionLayer;
        public ISessionLayer SessionLayer
        {
            get { return mSessionLayer; }
            set { mSessionLayer = value; }
        }

        private AutoResetEvent mCompletedSignal = new AutoResetEvent(false);
        protected AutoResetEvent CompletedSignal
        {
            get { return mCompletedSignal; }
            set { mCompletedSignal = value; }
        }

        private Action<ActionResult> mCompletedCallback;
        public Action<ActionResult> CompletedCallback
        {
            get { return mCompletedCallback; }
            set { mCompletedCallback = value; }
        }

        private ActionResult mResult = new ActionResult();
        public ActionResult Result
        {
            get { return mResult; }
            set { mResult = value; }
        }

        private List<ActionHandler> mHandlers = new List<ActionHandler>();
        public List<ActionHandler> Handlers
        {
            get { return mHandlers; }
            set { mHandlers = value; }
        }

        private DateTime mStartedAt;
        public DateTime StartedAt
        {
            get { return mStartedAt; }
            set { mStartedAt = value; }
        }

        public bool WaitForCompletedSignal(int timeoutMs)
        {
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} wait", Thread.CurrentThread.ManagedThreadId), true, true, 1);
            bool ret = CompletedSignal.WaitOne(timeoutMs);
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            return ret;
        }

        public bool WaitForCompletedSignal()
        {
            return WaitForCompletedSignal(TimeoutMs);
        }

        bool isSignalClosed = false;
        object signalLocker = new object();
        public void SetCompletedSignal()
        {
            lock (signalLocker)
            {
                if (!isSignalClosed)
                    CompletedSignal.Set();
            }
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000}", Thread.CurrentThread.ManagedThreadId), true, true, 1);
        }

        public void CloseCompletedSignal()
        {
            lock (signalLocker)
            {
                CompletedSignal.Close();
                isSignalClosed = true;
            }
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000}", Thread.CurrentThread.ManagedThreadId), true, true, 1);
        }

        public ActionHandlerResult TryHandle(byte[] data)
        {
            ActionHandlerResult ret = new ActionHandlerResult(false);
            foreach (ActionHandler item in Handlers)
            {
                if (item.WaitingFor(data))
                {
                    ret = item.Action(data);
                    break;
                }
            }
            return ret;

        }

        public virtual ActionHandlerResult Start()
        {
            Result.State = ActionStates.Started;
            StartedAt = DateTime.Now;
            ActionHandlerResult ret = new ActionHandlerResult(true);
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            return ret;
        }

        protected ActionHandlerResult SetCompleted()
        {
            Result.State = ActionStates.Completed;
            DateTime dt = Tools.CurrentDateTime;
            Result.TotalTimeMs = (int)(dt - StartedAt).TotalMilliseconds;
            ActionHandlerResult ret = new ActionHandlerResult(true);
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            SetCompletedSignal();
            if (CompletedCallback != null)
                CompletedCallback(Result);
            return ret;
        }

        protected ActionHandlerResult SetFailed()
        {
            Result.State = ActionStates.Failed;
            DateTime dt = Tools.CurrentDateTime;
            Result.TotalTimeMs = (int)(dt - StartedAt).TotalMilliseconds;
            ActionHandlerResult ret = new ActionHandlerResult(true);
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            SetCompletedSignal();
            if (CompletedCallback != null)
                CompletedCallback(Result);
            return ret;
        }



        protected ActionHandlerResult SetHandled()
        {
            ActionHandlerResult ret = new ActionHandlerResult(true);
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            return ret;
        }

        protected ActionHandlerResult SetHandled(FrameTypes frameType, CommandTypes commandType, byte[] parameters)
        {
            ActionHandlerResult ret = new ActionHandlerResult(new ActionDataFrame(frameType, commandType, parameters));
            Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            return ret;
        }

        protected ActionHandlerResult SetUnHandled()
        {
            ActionHandlerResult ret = new ActionHandlerResult(false);
            //Tools._writeDebugDiagnosticMessage(string.Format("t:{0:000} {1}", Thread.CurrentThread.ManagedThreadId, ret), true, true, 1);
            return ret;
        }
    }
}
