﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ZWave.Programmer.UI;
using ZWave.Programmer.Controllers;
using ZWave.Framework;

namespace ZWaveProgrammerUI
{
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Tools.CreateDebugExceptionFile("prg", Application.CommonAppDataPath, Application.UserAppDataPath);

            ControllerManager.Instance.IsConsoleMode = false;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            ControllerManager.Instance.MainForm = new MainForm();
            ControllerManager.Instance.ConsoleForm = ControllerManager.Instance.MainForm.ConsoleForm;
            ControllerManager.Instance.ZW010xForm = new ZW010xForm() { Name = "ZW010xForm" };
            ControllerManager.Instance.ZW020xForm = new ZW030xForm() { Name = "ZW020xForm" };

            ControllerManager.Instance.ZW030xForm = new ZW030xForm() { Name = "ZW030xForm" };
            TabPage tp = new TabPage("ZW030x");
            tp.UseVisualStyleBackColor = true;
            tp.AutoScroll = true;
            tp.Name = "tp" + ControllerManager.Instance.ZW030xForm.Name;
            tp.Controls.Add(ControllerManager.Instance.ZW030xForm);
            ControllerManager.Instance.MainForm.mainTabControl.TabPages.Add(tp);
            ControllerManager.Instance.MainForm.ZW030xToolStripMenuItem.Checked = true;

            ControllerManager.Instance.ZW040xForm = new ZW040xForm() { Name = "ZW040xForm" };
            tp = new TabPage("ZW040x");
            tp.UseVisualStyleBackColor = true; 
            tp.AutoScroll = true;
            tp.Name = "tp" + ControllerManager.Instance.ZW040xForm.Name;
            tp.Controls.Add(ControllerManager.Instance.ZW040xForm);
            ControllerManager.Instance.MainForm.mainTabControl.TabPages.Add(tp);
            ControllerManager.Instance.MainForm.ZW040xToolStripMenuItem.Checked = true;

            ControllerManager.Instance.ZW050xForm = new ZW050xForm() { Name = "ZW050xForm" };
            tp = new TabPage("ZW050x");
            tp.UseVisualStyleBackColor = true; 
            tp.AutoScroll = true;
            tp.Name = "tp" + ControllerManager.Instance.ZW050xForm.Name;
            tp.Controls.Add(ControllerManager.Instance.ZW050xForm);
            ControllerManager.Instance.MainForm.mainTabControl.TabPages.Add(tp);
            ControllerManager.Instance.MainForm.ZW050xToolStripMenuItem.Checked = true;

            ControllerManager.Instance.LogForm = new LogForm();
            Application.Run(ControllerManager.Instance.MainForm);

            Tools.CloseDebugExceptionFile();
        }
    }
}
