ATMega_ZWaveProgFW
 
Description:
ZWaveProgrammer Firmware for ATMega128 chip of ZDP02A Z-Wave Development Module.
The source code has been created for the following environment:
 - WinAVR v20071221:
     GNU Binutils 2.18 (including assembler, linker, etc.)
     Compiler Collection (GCC) 4.2.2 
     avr-libc 1.6.0
 - Z-Wave Library v2.91
 - Keil uVision PK51 v8
Project has been created in IDE:
 - Eclipse Platform v3.5 with plugins:
     AVR Eclipse Plugin
     (optional) Polarion Subversive SVN Connectors
     (optional) Eclipse Subversive - SVN Team Provider Project
Tested on:
 ZDP02A Z-Wave Development Module.
 ZDP03A Z-Wave Development Module.
  

