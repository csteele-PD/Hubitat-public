/****************************************************************************
 *
 * Copyright (c) 2001-2014
 * Sigma Designs, Inc.
 * All Rights Reserved
 *
 *---------------------------------------------------------------------------
 *
 * Description: Declaration of external NVM application interface.
 *
 * Last Changed By:  $Author: jsi $
 * Revision:         $Revision: 22797 $
 * Last Changed:     $Date: 2012-05-10 15:55:06 +0200 (to, 10 maj 2012) $
 *
 ****************************************************************************/
#ifndef _ZW_NVM_EXT_API_H_
#define _ZW_NVM_EXT_API_H_

/****************************************************************************/
/*                              INCLUDE FILES                               */
/****************************************************************************/


/****************************************************************************/
/*                              EXPORTED DATA                               */
/****************************************************************************/


/****************************************************************************/
/*                     EXPORTED TYPES and DEFINITIONS                       */
/****************************************************************************/

/**
 * Most discount FLASH chips has 4KByte as the smallest erase able unit.
 *
 * 2Mbit chips has 64 4KByte sectors
 *
 */
#define PSECTOR_SIZE_MAX 4096 /* Max handled size of physical pages. */
//#define PSECTOR_COUNT_MAX 32  /* Number of physical pages (32 x 4096 = 128KByte = 1Mbit). Used for fixed XDATA allocation */
//no room for MyProduct.control variable #define PSECTOR_COUNT_MAX 64  /* Number of physical pages (64 x 4096 = 256KByte = 2Mbit) */
//no room for MyProduct.control variable
#define PSECTOR_COUNT_MAX 1024 /* Number of physical pages (1024 x 256 = 256KByte = 2Mbit) */
/*
 * PSECTOR_COUNT is used for XDATA array variable addressing.
 * If we use the number of actual physical sectors retrieved from the chip without a limit,
 * an out-of-bounds array addressing would be the result in some cases.
 */
#define PSECTOR_COUNT (systemNVM_type.psectorCount > PSECTOR_COUNT_MAX ? PSECTOR_COUNT_MAX : systemNVM_type.psectorCount)

#define MAX_WEAR_COUNT 100000

/* ------------------------------------------------------------------------ */
/* NVM NVR specific definitions - MUST be set in NVR                        */
/* ------------------------------------------------------------------------ */

/* ------------------------------------------------------------
/* Current supported NVR NVMP settings */



/* ------------------------------------------------------------------------ */
/* NVM Definitions                                                          */
/* ------------------------------------------------------------------------ */

typedef struct _NVM_TYPE_T_
{
  BYTE manufacturerID;
  BYTE memoryType;
  BYTE memoryCapacity;
  WORD psectorSize;
  WORD psectorCount;
} NVM_TYPE_T;


/* ----- List of recognized NVM chips --------------------------------------------------------------------------------- */
/**
 * List of recognized NVM chips
 *
 * |                             | Jedec-ID                                                                | NVR configuration      |              |
 * |                             | manufacturerID | memoryType | memoryCapacity | familyCode | densityCode | NVMT | NVMS   | NVMP   | AddressBytes |
 * |-----------------------------|----------------|------------|----------------|------------|-------------|------|--------|--------|--------------|
 * | at25128a                    | 0xFF           | 0xFF       | 0xFF           |            |             | 0x01 | 0x0010 | 0x0040 | 0x02         |
 * | M25PE10VP (SGS Thomson)     | 0x20           | 0x80       | 0x11           |            |             | 0x02 | 0x0080 | 0x0100 | 0x03         |
 * | M25PE10VP (Micron)          | 0x20           | 0x80       | 0x11           |            |             | 0x02 | 0x0080 | 0x0100 | 0x03         |
 * | M25PE20VP (Micron)          | 0x20           | 0x80       | 0x12           |            |             | 0x02 | 0x0100 | 0x0100 | 0x03         |
 * | M25PE40VP (Numonyx)         | 0x20           | 0x80       | 0x13           |            |             | 0x02 | 0x0200 | 0x0100 | 0x03         |
 * | 25PE80VP  (STMicro)         | 0x20           | 0x80       | 0x14           |            |             | 0x02 | 0x0400 | 0x0100 | 0x03         |
 * | 25PE16VP  (STMicro)         | 0x20           | 0x80       | 0x15           |            |             | 0x02 | 0x0800 | 0x0100 | 0x03         |
 * | S25CM01A  (SeikoInstruments)| 0xFF           | 0xFF       | 0xFF           |            |             | 0x03 | 0x0080 | 0x0100 | 0x03         |
 * | CAT25M01  (ON Semiconductor)| 0xFF           | 0xFF       | 0xFF           |            |             | 0x03 | 0x0080 | 0x0100 | 0x03         |
 * | AT45DB021E (Adestotech)     | 0x1F           | 0x81       | 0x12           | 0x01       | 0x03        | 0x04 | 0x???? | 0x0100 | 0x03         |
 * | AT45DB041E (Adestotech)     | 0x1F           | 0x81       | 0x13           | 0x01       | 0x04        | 0x04 | 0x0200 | 0x0100 | 0x03         |
 * | AT45DB081E (Adestotech)     | 0x1F           | 0x81       | 0x14           | 0x01       | 0x05        | 0x04 | 0x???? | 0x0100 | 0x03         |
 * | AT45DB161E (Adestotech)     | 0x1F           | 0x81       | 0x15           | 0x01       | 0x06        | 0x04 | 0x???? | 0x0100 | 0x03         |
 * | AT45DB321E (Adestotech)     | 0x1F           | 0x81       | 0x16           | 0x01       | 0x07        | 0x04 | 0x???? | 0x0100 | 0x03         |
 * | AT45DB641E (Adestotech)     | 0x1F           | 0x81       | 0x17           | 0x01       | 0x08        | 0x04 | 0x???? | 0X0100 | 0x03         |
 * | AT25XE021A (Adestotech)     | 0x1F           | 0x82       | 0x12           | 0x02       | 0x03        | 0x04 | 0x???? | 0X0100 | 0x03         |
 * | SST25PF020B (Microchip)     | 0xBF           | 0x25       | 0x8C           |            |             | 0x05 | 0x0100 | 0x0002 | 0x03         |
 * | GD25Q128   (GigaDevices)    | 0xC8           | 0x40       | 0x18           |            |             | 0x06 | 0x0100 | 0x0100 | 0x03         |
 *
 */


/*
 * JEDEC STANDARD, Standard Manufacturer�s Identification Code, JEP106AQ, (Revision of JEP106AP, February 2015), MAY 2015
 */
typedef enum
{
//  Atmel = 0x1F (JEDEC)
//  Adesto Technologies = 0x43 (JEDEC)
  NVM_MANUFACTURER_AdestoTech               = 0x1F, /* Chip readout */
  NVM_MANUFACTURER_STMicroelectronics       = 0x20, /* Chip readout + JEDEC */
  NVM_MANUFACTURER_SiliconStorageTechnology = 0xBF, /* Chip readout + JEDEC */
  NVM_MANUFACTURER_GigaDevices = 0xC8, /* Chip readout + JEDEC */

  NVM_MANUFACTURER_UNKNOWN                  = 0xFF  /* EEPROM readout */
} ENVM_MANUFACTURER_T;

/*  memoryType    NVM type */
/*     0xFF        EEPROM  */
/*     0x80        FLASH   */
typedef enum
{
  NVM_TYPE_FLASH        = 0x80,  /* NVM is a FLASH */
  NVM_TYPE_FLASH_2      = 0x40,  /* NVM is a FLASH */
  NVM_TYPE_DATA_FLASH   = 0x81,  /* NVM is a DATAFLASH */
  NVM_TYPE_EEPROM       = 0xFF   /* NVM is probably an EEPROM */
} ENVM_TYPE_T;

enum NVM_DEVICES
{
//  Atmel = 0x1F (JEDEC)
//  Adesto Technologies = 0x43 (JEDEC)
  NVMInvalid               = 0x00000000, /* invalid */
  NVMUnknown               = 0x00010000,
  NVMSerialEEPROM          = 0x01000000,
  NVMSerialFlash           = 0x02000000

} ;


/* memoryCapacity       NVM size   */
/*     0x0A          128kbit(16kB) */
/*     0x10          256kbit(32kB) */
/*     0x11          1mbit(128kB)  */
/*     0x12          2mbit(256kB)  */
/*     0x13          4mbit(512kB)  */
/*     0x14          8mbit(1MB)    */
/*     0x15          16mbit(2MB)   */
/*     0x16          32mbit(4MB)   */
/*     0x17          64mbit(8MB)   */
typedef enum
{
  NVM_SIZE_16KB    = 0x0E,  /* NVM is a known type and the size of 16KByte */
  NVM_SIZE_32KB    = 0x0F,  /* NVM is a known type and the size of 32KByte */
  NVM_SIZE_64KB    = 0x10,  /* NVM is a known type and the size of 32KByte */
  NVM_SIZE_128KB   = 0x11,  /* NVM is a known type and the size of 128KByte */
  NVM_SIZE_256KB   = 0x12,  /* NVM is a known type and the size of 256KByte */
  NVM_SIZE_512KB   = 0x13,  /* NVM is a known type and the size of 512KByte */
  NVM_SIZE_1MB     = 0x14,  /* NVM is a known type and the size of 1MByte */
  NVM_SIZE_2MB     = 0x15,  /* NVM is a known type and the size of 2MByte */
  NVM_SIZE_4MB     = 0x16,  /* NVM is a known type and the size of 4MByte */
  NVM_SIZE_8MB     = 0x17,  /* NVM is a known type and the size of 8MByte */
  NVM_SIZE_16MB    = 0x18,  /* NVM is a known type and the size of 16MByte */
  NVM_SIZE_UNKNOWN = 0xFF   /* NVM is a type unknown and size could not be determined */
} ENVM_CAPACITY_T;

typedef struct  _NVM_ID_T_
{
  BYTE nvmProtocol;
  BYTE nvmManufacturerID;
  BYTE nvmTypeID;
  BYTE nvmSize;
} NVM_ID_T;




typedef struct NVM_ADDRESS_
{
  BYTE addres1byte;
  BYTE addres2byte;
	BYTE addres3byte;

} NVM_ADDRESS;

#define NVMADDRESS_2_DWORD(address) (DWORD)(((DWORD)address.addres1byte << 16)+((DWORD)address.addres2byte << 8)+(DWORD)address.addres3byte)

#define DWORD_2_NVMADDRESS(dw_addr, nvm_addr)\
         {nvm_addr.addres1byte=(BYTE)((dw_addr>>16) & 0xFF);\
         nvm_addr.addres2byte=(BYTE)((dw_addr>>8) & 0xFF);\
         nvm_addr.addres3byte=(BYTE)(dw_addr & 0xFF);}


/*========================   NVM_Get   ========================
**    Read one byte from the External NVM
**
**--------------------------------------------------------------------------*/
BYTE              /*RET External EEPROM data */
NVM_Get(
  NVM_ADDRESS offset);   /* IN offset in the External NVM */
/*=========================   NVM_Put ========================
**    Write one byte to the External EEPROM
**
** Side effects:
**    This should never be called for the discount 4KByte sector erase
**    FLASH chips.
**    Else we would need to make a distinction between the two commands
**    Byte-Program and Auto-Address-Increment-Word-Program.
**
**--------------------------------------------------------------------------*/
void            /*RET FALSE if value is identical to value in EEPROM else TRUE*/
NVM_Put(
  NVM_ADDRESS offset, /*IN offset in the External NVM */
  BYTE bData);   /*IN data to write */

/*========================   NVM_GetArray   ======================
**    Read an array of bytes from the External NVM to data buffer
**
**--------------------------------------------------------------------------*/
void            /*RET Nothing */
NVM_GetArray(
  NVM_ADDRESS offset,   /*IN offset in the External NVM */
  BYTE *buf,      /*IN destination buffer pointer */
  WORD length);   /*IN number of bytes to read */

/*==========================================================================
**    Write or Fill an array of bytes of up to 65K bytes to the External Flash
**
**--------------------------------------------------------------------------*/
void
NVM_FillArray(
  NVM_ADDRESS offset,      /*In the offset of array in the NVM to write to*/
  BYTE val,               /*The value to write to the NVM*/
  WORD length);           /*The length of the array in NVM to fill (up to 64K)*/

/*========================= NVM_PutArray  ===========================
**    Write an array of up to 64k bytes to the External NVM
**
**--------------------------------------------------------------------------*/
void           /*RET FALSE if buffer is identical to buffer in NVM else TRUE */
NVM_PutArray(
  NVM_ADDRESS offset,    /*IN offset in the External NVM */
  BYTE *buf,            /*IN source buffer pointer */
  WORD length);        /*IN number of bytes to write */

/*===============================   NVM_Init   ==============================
**   Initialse the external NVM interface
**
**    Initializes the integrated SPI controller, used for interfacing
**    to the external NVM.
**
**    Setup SPI1 in master mode, with most significant bit first,
**    clock= Fclk/16, sample at rising edge and clock low when idle
**
**--------------------------------------------------------------------------*/
NVM_ID_T                                    /* RET  Nothing        */
NVM_Init( BYTE legacyEEPROM,     /*IN true EEPROM smaller than 64k, else false*/
          volatile BYTE *port,    /*IN The chip select port address*/
          BYTE chipSel);          /*IN  chip select signal mask */

/*=========================   NVM_ErasePage ========================
**    Erase a page in the External EEPROM
**
** Side effects:
**
**--------------------------------------------------------------------------*/
void            /*RET nothing*/
NVM_ErasePage(BYTE pageNo); /*IN page number in external NVM */

#endif /* _ZW_NVM_EXT_API_H_ */

