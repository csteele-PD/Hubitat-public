/****************************************************************************
 *
 * Copyright (c) 2001-2015
 * Sigma Designs, Inc.
 * All Rights Reserved
 *
 *---------------------------------------------------------------------------
 *
 * Description: Funtions used to access the at25128a eeprom or the m25pe10
 *              flash
 *
 * Author:   Samer Seoud, Erik Friis Harck
 *
 * Last Changed By:  $Author: mvo $
 * Revision:         $Revision: 1.1 $
 * Last Changed:     $Date: 2008/08/15 07:49:56 $
 *
 ****************************************************************************/

/****************************************************************************/
/*                              INCLUDE FILES                               */
/****************************************************************************/
#include "common_defines.h"
#include <inttypes.h>
#include <ZW_typedefs.h>
#include "ports.h"
#include "ATMega_spi.h"
#include "lowlevel.h"
#include "nvm.h"


/****************************************************************************/
/*                      PRIVATE TYPES and DEFINITIONS                       */
/****************************************************************************/
/* These commands according to data sheet of M25PE40 */
/* Not all commands are impelemnted */
/* External generic commands */
#define EXT_NVM_WREN   6 /* 110 Set Write Enable Latch     */
#define EXT_NVM_WRDI   4 /* 100 Reset Write Enable Latch   */
#define EXT_NVM_RDSR   5 /* 101 Read Status Register       */
#define EXT_NVM_WRSR   1 /* 001 Write Status Register      */
#define EXT_NVM_READ   3 /* 011 Read Data from Memory Array */

/* External EEPROM commands */
#define EEPROM_WRITE  2 /* 010 Write Data to Memory Array  */

/* External serial FLASH commands */
#define EXT_FLASH_PW               0x0A /* Page program */
#define EXT_FLASH_RDID             0x9F /* Read chip ID */
#define EXT_FLASH_FAST_READ        0x0B /* Page Read */
#define EXT_FLASH_PE               0xDB /* Page Erase */
#define EXT_FLASH_DP               0xB9 /* Deep power-down */
#define EXT_FLASH_RDP              0xAB /* ReleaseDeep power-down */

/* External serial DataFLASH commands */
#define EXT_DATAFLASH_RDSR              0xD7    /* Read Status Register (the DataFlash way) */
#define EXT_DATAFLASH_READ_MODIFY_WRITE 0x58    /* Page program */

/* External serial Discount FLASH commands */
#define EXT_DISCOUNTFLASH_AUTO_ADDRESS_INCREMENT_PROGRAMMING 0xAD       /* Auto address increment programming */
#define EXT_DISCOUNTFLASH_SECTOR_ERASE                       0x20       /* 4K sector erase command */
#define EXT_DISCOUNTFLASH_PAGE_ERASE                         0x81       /* 256B sector erase command */

#define EX_GD_FLASH_PW    0x02
/* External generic status flags */
#define EXT_NVM_RDSR_WPEN       0x80    /* Write Protect Enable */
#define EXT_NVM_RDSR_BP1        0x08    /* Block Protect Bit 1 */
#define EXT_NVM_RDSR_BP0        0x04    /* Block Protect Bit 0 */
#define EXT_NVM_RDSR_WEL        0x02    /* 1 indicates the device is WRITE ENABLED. */
#define EXT_NVM_RDSR_WIP        0x01    /* 1 indicates the write cycle is in progress. */

/* external FLASH  status flags */

#define EXT_DATAFLASH_RDSR_RDY        0x80    /* 1 indicates the FLASH is ready for a new CMD. */

#define EEPROM_PAGE_SIZE 64       /* EEPROM_PAGE_MASK = 0x3F */
#define EXT_FLASH_PAGE_SIZE 256   /* EXT_FLASH_PAGE_SIZE = 0xFF */

#define SPIDELAY

/* SPI signal timing */
#define EEPROM_DELAY 12
#ifdef SPIDELAY
#define SPI_DELAY    6
#endif

#define DEEPPOWERDOWN_RISE_TIME 30

BYTE NVM_Busy( void );

/****************************************************************************/
/*                              PRIVATE DATA                                */
/****************************************************************************/

/**
 * \ref manufacturerID is not really used by this SPI NVM driver, but it is made available externally via NVM_get_id().
 */
static BYTE manufacturerID;
/**
 * \ref memoryType is used by this SPI NVM driver for selecting the correct bNVMWriteCommand and some timing.
 */
static BYTE memoryType;
/**
 * \ref memoryCapacity is not really used by this SPI NVM driver, but it is made available externally via NVM_get_id().
 */
static BYTE memoryCapacity;
/**
 * \ref familyCode is used by this SPI NVM driver for selecting the correct ??? TODO.
 */
static BYTE familyCode;
/**
 * \ref densityCode is used by this SPI NVM driver for selecting the correct ??? TODO.
 */
static BYTE densityCode;
/**
 * \ref psectorSize is not really used by this SPI NVM driver, but it is made available externally via NVM_get_id().
 */
static WORD psectorSize = 4096; /* Temporary static size of physical pages. */
/**
 * \ref psectorCount is not really used by this SPI NVM driver, but it is made available externally via NVM_get_id().
 */
static WORD psectorCount = 32;  /* Temporary staic number of physical pages (32 x 4096 = 128KByte = 1Mbit) */

/**
 * \ref NVRbNVMPageSize is used to control the buffer boundary,
 * and is set during initial call to NVM_ext_init(). If set to a nonsense value in the NVR, unpredictable results
 * will be the result.
 */
static WORD NVRbNVMPageSize;            /* declared in ZW_nvr_api.h as static BYTE NVRbNVMPageSize[NVR_NVM_PAGE_SIZE_SIZE]; */

static BYTE bNVMAddressSize;
static BYTE bNVMWriteCommand;
static BYTE bNVMEraseSectorCommand;
static BYTE bNVMReadStatusCmd ;

/**
 * \ref bNVMWriteDisableCommand is used to control termination of write/erase commands,
 * and is initialized to zero.
 * If set, write/erase commands will be terminated with this command.
 */
static BYTE bNVMWriteDisableCommand;    /* Initialized to zero */


static BOOL writeActive;  /* TRUE when an EEPROM write is active */
static BYTE bNVMstatusReadDisturbed;

static BYTE nvmProtocol = 0x02;

volatile BYTE *NVM_csPort;             /*The chip select port address*/
BYTE NVM_csMask;                       /*  chip select signal mask */

/****************************************************************************/
/*                              EXPORTED DATA                               */
/****************************************************************************/

/****************************************************************************/
/*                            PRIVATE FUNCTIONS                             */
/****************************************************************************/

/*===========================   NVM_CS_enable   ============================
**    Enable External EEPROM chip access
**
**--------------------------------------------------------------------------*/
static void   /*RET Nothing */
NVM_CS_enable(void) /*IN  Nothing */
{
  *NVM_csPort &= ~NVM_csMask;
  DELAY_10_US;

}


/*===========================   NVM_CS_disable   ===========================
**    Disable External EEPROM chip access
**
**--------------------------------------------------------------------------*/
static void   /*RET Nothing */
NVM_CS_disable(void) /*IN  Nothing */
{
#ifdef SPIDELAY
  DELAY_10_US;
#endif
  *NVM_csPort |= NVM_csMask;
  DELAY_10_US;
}

/*==========================   NVMPutArray_long   ============================
**    Write an array of up to 64 bytes to the External NVM
**
**--------------------------------------------------------------------------*/
static void           /*RET Nothing */
_NVMPutArray(
  DWORD offset,   /*IN offset in the External EEPROM */
  BYTE *buf,           /*IN destination buffer pointer */
  WORD length,         /*IN number of bytes to read */
  BYTE fillValue)           /*the value to use if the data buffer is NULL*/
{
  NVM_ADDRESS _offset;
  DWORD_2_NVMADDRESS(offset, _offset);
  while(NVM_Busy());


  writeActive = TRUE;
  NVM_CS_enable();
  /* issue write enable operation */
  SPI_Write(EXT_NVM_WREN);
  NVM_CS_disable();
  NVM_CS_enable();
  /* issue write operation */

  SPI_Write(bNVMWriteCommand);
  /* setup the write address */
  if (bNVMAddressSize != 2)
  {
    /* setup the write address HIGH byte in the 24bit address */
    SPI_Write(_offset.addres1byte);
  }
  SPI_Write(_offset.addres2byte);
  SPI_Write(_offset.addres3byte);
  /* write the data */
  while (length--)
  {

    if (NULL != buf)
    {
      SPI_Write(*buf++);
    }
    else
    {
      SPI_Write(fillValue);
    }
  }
  NVM_CS_disable();
  if (0 != bNVMWriteDisableCommand)
  {
    while(NVM_Busy());
    NVM_CS_enable();
    /* issue write disable operation */
    SPI_Write(bNVMWriteDisableCommand);
    NVM_CS_disable();
  }
  bNVMstatusReadDisturbed = TRUE;
}


static void
PutArrayFill(
  NVM_ADDRESS offset,    /*IN offset in the External NVM */
  BYTE *buf,       /*IN source buffer pointer */
  WORD length,
  BYTE fillValue  )
{
   register WORD i;
   DWORD _offset = NVMADDRESS_2_DWORD(offset);
    /* The bytes written should be alligned on memory page boundary.
       If the start address is not alligned on this boundary, then we first write
       the bytes from start addres until the end of the page */
    i = (WORD)(_offset & (NVRbNVMPageSize - 1)); /* memoryPageMask = NVRbNVMPageSize - 1 */
    if (0 != i) // address is not aligned on memory page boundary
    {
      i = (NVRbNVMPageSize - i); // the remaining of the memory page long
      if (length <= i)
      {
        i = length;
      }
      _NVMPutArray(_offset, buf, i,fillValue);
      length -= i;
      _offset += i;
      buf += (NULL != buf) ? i : 0;
    }

    while (0 != length)
    {
      if (length > NVRbNVMPageSize)
      {
        i = NVRbNVMPageSize;
      }
      else
      {
        i = length;
      }
      _NVMPutArray(_offset, buf, i, fillValue);
      length -= i;
      _offset += i;
      if (NULL != buf) buf += i;

    }
}

/*===========================   NVM_read_id   ==============================
**    Get External NVM ID
**
**--------------------------------------------------------------------------*/
static void           /*RET Nothing */
NVM_read_id( void ) /* IN Nothing */
{
  register BYTE spiNVMbusy;
  register BYTE spiNVMstatus1;
  register BYTE spiNVMstatus2;
  spiNVMbusy = TRUE;
  /* Wait for SPI device to be ready */
  while(spiNVMbusy)
  {
    /* Probe for device status the old SPI FLASH way */
    NVM_CS_enable();
    SPI_Write(EXT_NVM_RDSR);
    spiNVMbusy = SPI_Read();
    NVM_CS_disable();
    /* Probe for device status the new SPI DATAFLASH way */
    NVM_CS_enable();
    SPI_Write(EXT_DATAFLASH_RDSR);
     spiNVMstatus1 = SPI_Read();
     spiNVMstatus2 = SPI_Read();
    NVM_CS_disable();
    spiNVMbusy &= EXT_NVM_RDSR_WIP;     /* write is done                */
    if ((spiNVMstatus1 != 0xFF) && (spiNVMstatus2 != 0xFF) && (spiNVMstatus1 & EXT_DATAFLASH_RDSR_RDY)) spiNVMbusy = FALSE; /* Device is ready */
  }
  NVM_CS_enable();
  /* issue write disable operation if the chip was left in some active state (discount flash chips) */
  SPI_Write(EXT_NVM_WRDI);
  NVM_CS_disable();
  NVM_CS_enable();
  /* issue read ID operation */
  SPI_Write(EXT_FLASH_RDID);
  /* read the manufacturer ID */
  manufacturerID = SPI_Read();
  /* read the Memory type */
  memoryType = SPI_Read();
  /* read the Memory capacity */
  memoryCapacity = SPI_Read();
  NVM_CS_disable();

  switch (manufacturerID)               /* See the above list of recognized NVM chips for manufacturerID */
  {
    case NVM_MANUFACTURER_AdestoTech:
      densityCode = memoryType & 0x1F;
      familyCode = memoryType >> 5;
      memoryCapacity = densityCode + 0x0F; /* Convert Density Code into memoryCapacity (bit 0..4 of Device ID (Byte 1) from datasheet) */
      memoryType = familyCode | NVM_TYPE_FLASH; /* Include Family Code into memoryType (bit 5..7 of Device ID (Byte 1) from datasheet) */
      break;

    default:
      break;
  }

}


/*========================   NVM_clearStatusReg   ===========================
**    Clear block protection bits
**
**--------------------------------------------------------------------------*/
static
void NVM_clearStatusReg(void)
{
  while(NVM_Busy());
  writeActive = TRUE;
  /* issue write enable operation */
  NVM_CS_enable();
  SPI_Write(EXT_NVM_WREN);
  NVM_CS_disable();
  NVM_CS_enable();
  SPI_Write(EXT_NVM_WRSR);
  SPI_Write(/* not EXT_NVM_RDSR_WPEN    Clear Status Register Write Protect */
                /* not EXT_NVM_RDSR_BP1     Clear BlockProtect1                 */
                /* not EXT_NVM_RDSR_BP0     Clear BlockProtect0                 */
                EXT_NVM_RDSR_WEL |
                EXT_NVM_RDSR_WIP);
  NVM_CS_disable();
}
/****************************************************************************/
/*                           EXPORTED FUNCTIONS                             */
/****************************************************************************/

/*===============================   NVM_ext_init   ==============================
**   Initialse the external NVM interface
**
**    Initializes the integrated SPI controller, used for interfacing
**    to the external NVM.
**
**    Setup SPI1 in master mode, with most significant bit first,
**    clock= Fclk/16, sample at rising edge and clock low when idle
**
**--------------------------------------------------------------------------*/
NVM_ID_T                                    /* RET  Nothing        */
NVM_Init( BYTE legacyEEPROM,     /*IN true EEPROM smaller than 64k, else false*/
  volatile BYTE *port,    /*IN The chip select port address*/
  BYTE chipSel)           /*IN  chip select signal mask */
{
  register BYTE tmp;

  NVRbNVMPageSize = 32;
  if (legacyEEPROM)
  {
    bNVMAddressSize = 2;
  }
  else
  {
    bNVMAddressSize = 3;
  }

  NVM_ID_T nvmIDType;
  NVM_csPort = port;
  NVM_csMask = chipSel;

  /* set chip select pins as Output, disabled */
  /* Make sure we're in NORMAL SPI mode */
  NVM_CS_disable();

  /* Setup SPIx in master mode, with most significant bit first, */
  /* sample at rising edge and clock low when idle */
  SPI_Init(&PORTD, &PIND, (1<<MOSI), (1<<MISO), (1<<SCK));
  /* For now we only handle deep powerdown for Flash based NVM */
  /* - Currently only FLASH based NVM supports the feature - NVR must be correctly set to 0x02 */
  NVM_CS_enable();
  SPI_Write(EXT_FLASH_RDP);
  NVM_CS_disable();
 /* Make sure we wait enough for chip to exit Deep powerdown */
  for (tmp = DEEPPOWERDOWN_RISE_TIME; tmp > 0; tmp--);

  /* Try to read the ID from the serial memory chip */
  NVM_read_id();
  if (manufacturerID == 0xFF && memoryType == 0xFF && memoryCapacity == 0xFF)
    nvmProtocol = 0x01;
  /* When insufficient identification of NVM chip, assume default values, for: */
  bNVMWriteCommand = EEPROM_WRITE;      /* Use EEPROM_WRITE (0x02) for all dumb SPI chips */
  bNVMReadStatusCmd = EXT_NVM_RDSR;
  bNVMWriteDisableCommand = 0;

  switch (manufacturerID)               /* See the above list of recognized NVM chips for manufacturerID */
  {
    case NVM_MANUFACTURER_AdestoTech:
      switch (familyCode)               /* See the above list of recognized NVM chips for memoryType */
      {
        case 0x01:                      /* SPI DataFlash type */
           /* Switch physical page size in chip from 264 --> 256 bytes/page */
          NVM_CS_enable();
          SPI_Write(EXT_DATAFLASH_RDSR);
          tmp = SPI_Read();
          NVM_CS_disable();
          if (!(0x01 & tmp))      /* Avoid unnecessary wear on page size configuration bit */
          {
            NVM_CS_enable();
            SPI_Write(0x3D);
            SPI_Write(0x2A);
            SPI_Write(0x80);
            SPI_Write(0xA6);
            NVM_CS_disable();

          }
          bNVMWriteCommand = EXT_DATAFLASH_READ_MODIFY_WRITE;
          /* Because we know, the following 2 parameters for the driver will overrule, what he has set in the NVR */
          bNVMAddressSize = 3;          /* If ReadID returns valid memoryType, then we know */
          NVRbNVMPageSize = 0x0100;     /* If ReadID returns valid memoryType, then we know */
          bNVMReadStatusCmd = EXT_DATAFLASH_RDSR;
          break;
        case 0x02:                      /* SPI Discount Flash type. 256 Byte page erase capability. */
          bNVMEraseSectorCommand = EXT_DISCOUNTFLASH_PAGE_ERASE;
          /* Because we know, the following 2 parameters for the driver will overrule, what he has set in the NVR */
          bNVMAddressSize = 3;          /* If ReadID returns valid memoryType, then we know */
          NVRbNVMPageSize = 0x0100;     /* If ReadID returns valid memoryType, then we know */
          psectorSize = 256;            /* Size of physical sectors */
          psectorCount = 1024;          /* Number of physical pages (1024 x 256 = 256KByte = 2Mbit) */
          break;
        default:
          break;
      }
      break;
    case NVM_MANUFACTURER_SiliconStorageTechnology: /* Silicon Storage Technology (Microchip) */
      switch (memoryType)               /* See the above list of recognized NVM chips for memoryType */
      {
        case 0x25:                      /* SPI Discount 4K sector erase able Flash type */
          bNVMWriteCommand = EXT_DISCOUNTFLASH_AUTO_ADDRESS_INCREMENT_PROGRAMMING;
          bNVMEraseSectorCommand = EXT_DISCOUNTFLASH_SECTOR_ERASE;
          bNVMWriteDisableCommand = EXT_NVM_WRDI;
          /* Because we know, the following 2 parameters for the driver will overrule, what he has set in the NVR */
          bNVMAddressSize = 3;          /* If ReadID returns valid memoryType, then we know */
          NVRbNVMPageSize = 0x0002;     /* If ReadID returns valid memoryType, then we know */
          psectorSize = 4096;           /* Size of physical sectors */
                                        /* Test program only utilize part of the NVM chip. Verification XDATA RAM is limited. */
          psectorCount = 32;            /* Number of physical pages (32 x 4096 = 128KByte = 1Mbit) */

          break;
        default:
          break;
      }
      break;
    default:
      switch (memoryType)               /* See the above list of recognized NVM chips for memoryType */
      {

        case NVM_TYPE_FLASH:                      /* Old SPI Flash type */
          if (0x11 == memoryCapacity)  /*we have to be back compatible with the old formate of ATmel firmware*/
            memoryCapacity = 0x10;  /*1 Mbit*/
          else if (0x12 == memoryCapacity)
            memoryCapacity = 0x20; /*2 Mbit*/
          else if (0x13 == memoryCapacity)
            memoryCapacity = 0x40; /*4 MBit*/


          bNVMWriteCommand = EXT_FLASH_PW;  /* Page write (byte-in-page) */
          /* Because we know, the following 2 parameters for the driver will overrule, what he has set in the NVR */
          bNVMAddressSize = 3;          /* If ReadID returns valid memoryType, then we know */
          NVRbNVMPageSize = 0x0100;     /* If ReadID returns valid memoryType, then we know */
           break;
        case NVM_TYPE_FLASH_2:
          bNVMWriteCommand = EX_GD_FLASH_PW;
          /* Because we know, the following 2 parameters for the driver will overrule, what he has set in the NVR */
          bNVMAddressSize = 3;          /* If ReadID returns valid memoryType, then we know */
          NVRbNVMPageSize = 0x0100;     /* If ReadID returns valid memoryType, then we know */
          break;
        default:
          break;
      }
      break;
  }



  NVM_clearStatusReg();
  nvmIDType.nvmProtocol = nvmProtocol;
  nvmIDType.nvmManufacturerID = manufacturerID;
  nvmIDType.nvmTypeID = memoryType;
  nvmIDType.nvmSize = memoryCapacity;
  return nvmIDType;

}


/*============================   NVM_Busy   ===============================
**    Get External NVM write status
**
**--------------------------------------------------------------------------*/
BYTE               /*RET TRUE if External EEPROM write in progress */
NVM_Busy( void ) /* IN Nothing */
{
  register BYTE status;
  if (writeActive)
  {
    NVM_CS_enable();
    SPI_Write(bNVMReadStatusCmd);
    status = SPI_Read();
    NVM_CS_disable();
    if (EXT_NVM_RDSR == bNVMReadStatusCmd)
    {
       if (!(EXT_NVM_RDSR_WIP & status))
        writeActive = FALSE;
    }
    else
    {
      if (EXT_DATAFLASH_RDSR_RDY & status)
        writeActive = FALSE;
    }
  }
  return (writeActive);
}

/*========================   NVM_Get   ========================
**    Read one byte from the External NVM
**
**--------------------------------------------------------------------------*/
BYTE              /*RET External EEPROM data */
NVM_Get(
  NVM_ADDRESS offset)   /* IN offset in the External NVM */
{
  register BYTE bData;
  while(NVM_Busy());
  NVM_CS_enable();
  /* issue read operation */
  SPI_Write(EXT_NVM_READ);
  /* setup the read address */
  if (bNVMAddressSize != 2)
  {
    SPI_Write(offset.addres1byte);
  }
  SPI_Write(offset.addres2byte);
  SPI_Write(offset.addres1byte);
  /* read the data */
  bData = SPI_Read();
  NVM_CS_disable();

  return(bData);
}

void
_NVM_Put(
  NVM_ADDRESS offset, /*IN offset in the External NVM */
  BYTE bData)   /*IN data to write */
{
    while(NVM_Busy());
    writeActive = TRUE;
    NVM_CS_enable();
    /* issue write enable operation */
    SPI_Write(EXT_NVM_WREN);
    NVM_CS_disable();
    NVM_CS_enable();
    /* issue write operation */
    SPI_Write(bNVMWriteCommand);
    if (bNVMAddressSize != 2)
    {
      SPI_Write(offset.addres1byte);
    }
    /* setup the write address */
    SPI_Write(offset.addres2byte);
    SPI_Write(offset.addres3byte);
    /* write the data */
    SPI_Write(bData);
    NVM_CS_disable();
    bNVMstatusReadDisturbed = TRUE;
}

/*=========================   NVM_ErasePage ========================
**    Erase a page in the External EEPROM
**
** Side effects:
**
**--------------------------------------------------------------------------*/
void            /*RET nothing*/
NVM_ErasePage(BYTE pageNo) /*IN page number in external NVM */
{
  while(NVM_Busy());
  writeActive = TRUE;
  NVM_CS_enable();
  /* issue write enable operation */
  SPI_Write(EXT_NVM_WREN);
  NVM_CS_disable();
  NVM_CS_enable();
  /* issue oage erase operation */
  SPI_Write(EXT_DISCOUNTFLASH_PAGE_ERASE);
  /* send a dummy byte */
  SPI_Write(0x00);
  /* send oage number */
  SPI_Write(pageNo);
  /* send a dummy byte */
  SPI_Write(0x00);
  NVM_CS_disable();
}


/*=========================   NVM_Put ========================
**    Write one byte to the External EEPROM
**
** Side effects:
**    This should never be called for the discount 4KByte sector erase
**    FLASH chips.
**    Else we would need to make a distinction between the two commands
**    Byte-Program and Auto-Address-Increment-Word-Program.
**
**--------------------------------------------------------------------------*/
void            /*RET FALSE if value is identical to value in EEPROM else TRUE*/
NVM_Put(
  NVM_ADDRESS offset, /*IN offset in the External NVM */
  BYTE bData)   /*IN data to write */
{
  _NVM_Put(offset, 0xFF);
  _NVM_Put(offset, bData);
}


/*========================   NVM_GetArray   ======================
**    Read an array of bytes from the External NVM to data buffer
**
**--------------------------------------------------------------------------*/
void            /*RET Nothing */
NVM_GetArray(
  NVM_ADDRESS offset,   /*IN offset in the External NVM */
  BYTE *buf,      /*IN destination buffer pointer */
  WORD length)    /*IN number of bytes to read */
{
  while(NVM_Busy());

  NVM_CS_enable();
  /* issue read operation */
  SPI_Write(EXT_NVM_READ);
  /* setup the read address */
  if (bNVMAddressSize != 2)
  {
    SPI_Write(offset.addres1byte);
  }
  SPI_Write(offset.addres2byte);
  SPI_Write(offset.addres3byte);
  /* read the data */
  while (length--)
  {
    *buf = SPI_Read();
    buf++;
  }
  NVM_CS_disable();

}


/*==========================================================================
**    Write or Fill an array of bytes of up to 65K bytes to the External Flash
**
**--------------------------------------------------------------------------*/
void
NVM_FillArray(
  NVM_ADDRESS offset,      /*In the offset of array in the NVM to write to*/
  BYTE val,               /*The value to write to the NVM*/
  WORD length)            /*The length of the array in NVM to fill (up to 64K)*/
{
  PutArrayFill(offset, NULL, length, val);
}

/*========================= NVM_PutArray  ===========================
**    Write an array of up to 64k bytes to the External NVM
**
**--------------------------------------------------------------------------*/
void           /*RET FALSE if buffer is identical to buffer in NVM else TRUE */
NVM_PutArray(
  NVM_ADDRESS offset,    /*IN offset in the External NVM */
  BYTE *buf,       /*IN source buffer pointer */
  WORD length)
{
  if (nvmProtocol == 2)
    PutArrayFill(offset, NULL, length, 0xFF);

  PutArrayFill(offset, buf, length, 0);
}

/*========================   NVM_ext_read_status   ===========================
**    Read one byte from the External NVM
**
**--------------------------------------------------------------------------*/
BYTE                        /* RET External NVM status */
NVM_ext_read_status(void)   /* IN  none */
{
  return bNVMstatusReadDisturbed;
}

/*========================   NVM_ext_clear_status   ==========================
**    Clear status for the External NVM
**
**--------------------------------------------------------------------------*/
void                        /* RET none */
NVM_ext_clear_status(void)  /* IN  none */
{
  bNVMstatusReadDisturbed = FALSE;
}
