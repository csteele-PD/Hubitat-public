/*
 *
 * HubConnect Remote Client for Hubitat
 *
 * Copyright 2019-2020 Steve White, Retail Media Concepts LLC.
 *
 * HubConnect for Hubitat is a software package created and licensed by Retail Media Concepts LLC.
 * HubConnect, along with associated elements, including but not limited to online and/or electronic documentation are
 * protected by international laws and treaties governing intellectual property rights.
 *
 * This software has been licensed to you. All rights are reserved. You may use and/or modify the software.
 * You may not sublicense or distribute this software or any modifications to third parties in any way.
 *
 * By downloading, installing, and/or executing this software you hereby agree to the terms and conditions set forth in the HubConnect license agreement.
 * <https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html>
 *
 * Hubitat is the trademark and intellectual property of Hubitat, Inc. Retail Media Concepts LLC has no formal or informal affiliations or relationships with Hubitat.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License Agreement
 * for the specific language governing permissions and limitations under the License.
 *
 */
Map getAppVersion() {[platform: "Hubitat", major: 2, minor: 0, build: 0]}

import groovy.transform.Field
import groovy.json.JsonOutput

definition(
	name: "HubConnect Remote Client",
	namespace: "shackrat",
	author: "Steve White",
	description: "Synchronizes devices and events across hubs..",
	category: "My Apps",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	videoLink: "https://hubconnect.hubitatcommunity.com/HubConnect_Install_Videos/HubConnect_Remote_Install/",
	documentationLink: "https://hubconnect.to/knowledgebase/1/HubConnect-2.0-Beta",
	singleInstance: true
)


// Preference pages
preferences
{
	page(name: "mainPage")
	page(name: "aboutPage")
	page(name: "connectPage")
	page(name: "devicePage")
	page(name: "customDevicePage")
	page(name: "dynamicDevicePage")
	page(name: "uninstallPage")
	page(name: "resetPage")
	page(name: "resyncAllDevicesPage")
}


// Map containing driver and attribute definitions for each device class
@Field static Map<String, Map> NATIVE_DEVICES =
[
	"arlocamera":		[driver: "Arlo Camera", displayName: "Arlo Pro Cameras", platform: "SmartThings", selector: "arloProCameras", capability: "device.ArloProCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arloqcamera":		[driver: "Arlo Camera", displayName: "Arlo Q Cameras", platform: "SmartThings", selector: "arloQCameras", capability: "device.ArloQCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arlogocamera":		[driver: "Arlo Camera", displayName: "Arlo Go Cameras", platform: "SmartThings", selector: "arloGoCameras", capability: "device.ArloGoCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arrival":			[driver: "Arrival Sensor", selector: "smartThingsArrival", capability: "presenceSensor", prefGroup: "presence", type: "attr", attr: ["presence", "battery", "tone"]],
	"audioVolume":		[driver: "AVR", selector: "audioVolume", capability: "audioVolume", prefGroup: "audio", type: "attr", attr: ["switch", "mediaInputSource", "mute", "volume"]],
	"bulb":				[driver: "Bulb", selector: "genericBulbs", capability: "changeLevel", prefGroup: "lighting", type: "attr", attr: ["switch", "level"]],
	"button":			[driver: "Button", selector: "genericButtons", capability: "pushableButton", prefGroup: "other", type: "attr", attr: ["numberOfButtons", "pushed", "held", "doubleTapped", "button", "temperature", "battery"]],
	"contact":			[driver: "Contact Sensor", selector: "genericContacts", capability: "contactSensor", prefGroup: "sensors", type: "attr", attr: ["contact", "temperature", "battery"]],
	"dimmer":			[driver: "Dimmer", selector: "genericDimmers", capability: "switchLevel", prefGroup: "lighting", type: "attr", attr: ["switch", "level"]],
	"domemotion":		[driver: "DomeMotion Sensor", selector: "domeMotions", capability: "motionSensor", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "illuminance", "battery"]],
	"energy":			[driver: "Energy Meter", selector: "energyMeters", capability: "energyMeter", prefGroup: "power", type: "attr", attr: ["energy"]],
	"energyplug":		[driver: "DomeAeon Plug", selector: "energyPlugs", capability: "energyMeter", prefGroup: "lighting", type: "attr", attr: ["switch", "power", "voltage", "current", "energy", "acceleration"]],
	"fancontrol":		[driver: "Fan Controller", selector: "fanControl", capability: "fanControl", prefGroup: "fans", type: "attr", attr: ["speed"]],
	"fanspeed":			[driver: "FanSpeed Controller", selector: "fanSpeedControl", capability: "fanControl", prefGroup: "fans", type: "attr", attr: ["speed"]],
	"garagedoor":		[driver: "Garage Door", selector: "garageDoors", capability: "garageDoorControl", prefGroup: "other", type: "attr", attr: ["door", "contact"]],
	"irissmartplug":	[driver: "Iris SmartPlug", selector: "smartPlugs", capability: "switch", prefGroup: "shackrat", type: "synth", attr: ["switch", "power", "voltage", "ACFrequency"]],
	"irisv3motion":		[driver: "Iris IL071 Motion Sensor", selector: "irisV3Motions", capability: "motionSensor", prefGroup: "shackrat", type: "synth", attr: ["motion", "temperature", "humidity", "battery"]],
	"keypad":			[driver: "Keypad", selector: "genericKeypads", capability: "securityKeypad", prefGroup: "safety", type: "attr", attr: ["motion", "temperature", "battery", "tamper", "alarm", "lastCodeName"]],
	"lock":				[driver: "Lock", selector: "genericLocks", capability: "lock", prefGroup: "safety", type: "attr", attr: ["lock", "lockCodes", "lastCodeName", "codeChanged", "codeLength", "maxCodes", "battery"]],
	"mobileApp":		[driver: "Mobile App", selector: "mobileApp", capability: "notification", prefGroup: "presence", type: "attr", attr: ["presence", "notificationText"]],
	"moisture":			[driver: "Moisture Sensor", selector: "genericMoistures", capability: "waterSensor", prefGroup: "safety", type: "attr", attr: ["water", "temperature", "battery"]],
	"motion":			[driver: "Motion Sensor", selector: "genericMotions", capability: "motionSensor", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "battery"]],
	"motionswitch":		[driver: "Motion Switch", selector: "genericMotionSwitches", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch", "motion"]],
	"multipurpose":		[driver: "Multipurpose Sensor", selector: "genericMultipurposes", capability: "accelerationSensor", prefGroup: "sensors", type: "attr", attr: ["contact", "temperature", "battery", "acceleration", "threeAxis"]],
	"netatmowxbase":	[driver: "Netatmo Community Basestation", selector: "netatmoWxBasetations", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "pressure", "carbonDioxide", "soundPressureLevel", "sound", "min_temp", "max_temp", "temp_trend", "pressure_trend"]],
	"netatmowxmodule":	[driver: "Netatmo Community Additional Module", selector: "netatmoWxModule", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "carbonDioxide", "min_temp", "max_temp", "temp_trend", "battery"]],
	"netatmowxoutdoor":	[driver: "Netatmo Community Outdoor Module", selector: "netatmoWxOutdoor", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "min_temp", "max_temp", "temp_trend", "battery"]],
	"netatmowxrain":	[driver: "Netatmo Community Rain", selector: "netatmoWxRain", capability: "sensor", prefGroup: "netatmowx", type: "synth", attr: ["rain", "rainSumHour", "rainSumDay", "units", "battery"]],
	"netatmowxwind":	[driver: "Netatmo Community Wind", selector: "netatmoWxWind", capability: "sensor", prefGroup: "netatmowx", type: "synth", attr: ["WindStrength", "WindAngle", "GustStrength", "GustAngle", "max_wind_str", "date_max_wind_str", "units", "battery"]],
	"omnipurpose":		[driver: "Omnipurpose Sensor", selector: "genericOmnipurposes", capability: "relativeHumidityMeasurement", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "humidity", "illuminance", "ultravioletIndex", "tamper", "battery"]],
	"pocketsocket":		[driver: "Pocket Socket", selector: "pocketSockets", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch", "power"]],
	"power":			[driver: "Power Meter", selector: "powerMeters", capability: "powerMeter", prefGroup: "power", type: "attr", attr: ["power"]],
	"presence":			[driver: "Presence Sensor", selector: "genericPresences", capability: "presenceSensor", prefGroup: "presence", type: "attr", attr: ["presence", "battery"]],
	"ringdoorbell":		[driver: "Ring Doorbell", selector: "ringDoorbellPros", capability: "device.RingDoorbellPro", prefGroup: "smartthings", type: "attr", attr: ["numberOfButtons", "pushed", "motion"]],
	"rgbbulb":			[driver: "RGB Bulb", selector: "genericRGBs", capability: "colorControl", prefGroup: "lighting", type: "attr", attr: ["switch", "level", "hue", "saturation", "RGB", "color", "colorMode", "colorTemperature"]],
	"rgbwbulb":			[driver: "RGBW Bulb", selector: "genericRGBW", capability: "colorMode", prefGroup: "lighting", type: "attr", attr: ["switch", "level", "hue", "saturation", "RGB(w)", "color", "colorMode", "colorTemperature"]],
	"shock":			[driver: "Shock Sensor", selector: "genericShocks", capability: "shockSensor", prefGroup: "sensors", type: "attr", attr: ["shock", "battery"]],
	"siren":			[driver: "Siren", selector: "genericSirens", capability: "alarm", prefGroup: "safety", type: "attr", attr: ["switch", "alarm", "battery"]],
	"smartsmoke":		[driver: "Smart SmokeCO", selector: "smartSmokeCO", capability: "device.HaloSmokeAlarm", prefGroup: "safety", type: "attr", attr: ["smoke", "carbonMonoxide", "battery", "temperature", "humidity", "switch", "level", "hue", "saturation", "pressure"]],
	"smoke":			[driver: "SmokeCO", selector: "genericSmokeCO", capability: "smokeDetector", prefGroup: "safety", type: "attr", attr: ["smoke", "carbonMonoxide", "battery"]],
	"speaker":			[driver: "Speaker", selector: "genericSpeakers", capability: "musicPlayer", prefGroup: "audio", type: "attr", attr: ["level", "mute", "volume", "status", "trackData", "trackDescription"]],
	"speechSynthesis":	[driver: "SpeechSynthesis", selector: "speechSynth", capability: "speechSynthesis", prefGroup: "other", type: "attr", attr: ["mute", "version", "volume"]],
	"switch":			[driver: "Switch", selector: "genericSwitches", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch"]],
	"thermostat":		[driver: "Thermostat", selector: "genericThermostats", capability: "thermostat", prefGroup: "climate", type: "attr", attr: ["coolingSetpoint", "heatingSetpoint", "schedule", "supportedThermostatFanModes", "supportedThermostatModes", "temperature", "thermostatFanMode", "thermostatMode", "thermostatOperatingState", "thermostatSetpoint"]],
	"windowshade":		[driver: "Window Shade", selector: "windowShades", capability: "windowShade", prefGroup: "other", type: "attr", attr: ["switch", "position", "windowShade"]],
	"valve":			[driver: "Valve", selector: "genericValves", capability: "valve", prefGroup: "other", type: "attr", attr: ["valve"]],
	"v_acceleration":	[driver: "Virtual Acceleration Sensor", selector: "virtualAcceleration", capability: "accelerationSensor", prefGroup: "virtual", type: "synth", attr: ["acceleration"]],
	"v_audiovolume":	[driver: "Virtual audioVolume", selector: "virtualAudioVolume", capability: "audioVolume", prefGroup: "virtual", type: "synth", attr: ["volume", "mute"]],
	"v_co_detector":	[driver: "Virtual CO Detector", selector: "virtualCO", capability: "carbonMonoxideDetector", prefGroup: "virtual", type: "synth", attr: ["carbonMonoxide"]],
	"v_contact":		[driver: "Virtual Contact Sensor", selector: "virtualContact", capability: "contactSensor", prefGroup: "virtual", type: "synth", attr: ["contact"]],
	"v_humidity":		[driver: "Virtual Virtual Humidity Sensor", selector: "virtualHumidity", capability: "relativeHumidityMeasurement", prefGroup: "virtual", type: "synth", attr: ["humidity"]],
	"v_illuminance":	[driver: "Virtual Illuminance Sensor", selector: "virtualIlluminance", capability: "illuminanceMeasurement", prefGroup: "virtual", type: "synth", attr: ["illuminance"]],
	"v_moisture":		[driver: "Virtual Moisture Sensor", selector: "virtualMoisture", capability: "waterSensor", prefGroup: "virtual", type: "synth", attr: ["water"]],
	"v_motion":			[driver: "Virtual Motion Sensor", selector: "virtualMotion", capability: "motionSensor", prefGroup: "virtual", type: "synth", attr: ["motion"]],
	"v_multi":			[driver: "Virtual Multi Sensor", selector: "virtualMulti", capability: "accelerationSensor", prefGroup: "virtual", type: "synth", attr: ["acceleration", "contact", "temperature"]],
	"v_omni":			[driver: "Virtual Omni Sensor", selector: "virtualOmni", capability: "carbonDioxideMeasurement", prefGroup: "virtual", type: "synth", attr: ["acceleration", "carbonDioxide", "carbonMonoxide", "contact", "energy", "humidity", "illuminance", "power", "presence", "smoke", "temperature", "water"]],
	"v_presence":		[driver: "Virtual Presence Sensor", selector: "virtualPresence", capability: "presenceSensor", prefGroup: "virtual", type: "synth", attr: ["presence"]],
	"v_smoke_detector":	[driver: "Virtual Smoke Detector", selector: "virtualSmoke", capability: "smokeDetector", prefGroup: "virtual", type: "synth", attr: ["smoke"]],
	"v_temperature":	[driver: "Virtual Temperature Sensor", selector: "virtualTemperature", capability: "temperatureMeasurement", prefGroup: "virtual", type: "synth", attr: ["temperature"]],
	"vc_globalvar":		[driver: "RM Global Variable Connector", platform: "Hubitat", selector: "virtualGlobVar", capability: "*", prefGroup: "virtual", synthetic: true, attr: ["sensor"]],
	"zwaverepeater":	[driver: "Iris Z-Wave Repeater", selector: "zwaveRepeaters", capability: "device.IrisZ-WaveRepeater", prefGroup: "shackrat", type: "synth", attr: ["status", "lastRefresh", "deviceMSR", "deviceVersion", "deviceZWaveLibType", "deviceZWaveVersion", "lastMsgRcvd"]],

	// HubConnect Apps
	"automatic":		[driver: "Automatic Vehicle", selector: "automaticVehicles", capability: "presenceSensor", prefGroup: "hcautomatic", type: "hcapp", attr: ["presence"]],
	"NAMain":			[driver: "Netatmo Basestation", selector: "hcnetatmowxBasetations", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "pressure", "carbonDioxide", "soundPressureLevel", "sound", "lowTemperature", "highTemperature", "temperatureTrend", "pressureTrend"]],
	"NAModule1":		[driver: "Netatmo Outdoor Module", selector: "hcnetatmowxOutdoor", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "lowTemperature", "highTemperature", "temperatureTrend", "battery"]],
	"NAModule2":		[driver: "Netatmo Wind", selector: "hcnetatmowxWind", capability: "sensor", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["WindStrength", "WindAngle", "GustStrength", "GustAngle", "max_wind_str", "date_max_wind_str", "units", "battery"]],
	"NAModule3":		[driver: "Netatmo Rain", selector: "hcnetatmowxRain", capability: "sensor", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["rain", "rainSumHour", "rainSumDay", "units", "battery"]],
	"NAModule4":		[driver: "Netatmo Additional Module", selector: "hcnetatmowxModule", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "carbonDioxide", "lowTemperature", "highTemperature", "temperatureTrend", "battery"]]
]

// Map containing device group definitions
@Field static Map<String, Map> DEVICE_GROUPS =
[
	"audio":		[title: "Audio Devices", description: "Speakers, AV Receivers"],
	"climate":		[title: "Climate Devices", description: "Thermostats & Weather Stations"],
	"fans":			[title: "Fans", description: "Celing Fans & Devices", parent: "switches"],
	"lighting":		[title: "Lighting Devices", description: "Bulbs, Dimmers, RGB/RGBW Lights, and Switches", parent: "switches"],
	"hcautomatic":	[title: "HubConnect Automatic Client", description: "HubConnect Automatic Driving Tracker Integration", parent: "hcapps"],
	"hcapps":		[title: "HubConnect Apps", description: "HubConnect Integrated Apps (Automatic, Netatmo)"],
	"hcnetatmowx":	[title: "HubConnect Netatmo Client", description: "HubConnect Netatmo Weather Station Client", parent: "hcapps"],
	"netatmowx":	[title: "Netatmo Weather Station (Community)", description: "Netatmo Weather Station Community Integration", parent: "climate"],
	"other":		[title: "Other Devices", description: "Presence, Button, Valves, Garage Doors, SpeechSynthesis, Window Shades"],
	"power":		[title: "Power & Energy Meters", description: "Power Meters & Energy Meters", parent: "switches"],
	"presence":		[title: "Presence Sensors & Apps", description: "Arrival Sensors, Presence Sensors, and Mobile Apps", parent: "sensors"],
	"safety":		[title: "Safety & Security", description: "Locks, Keypads, Smoke & Carbon Monoxide, Leak, Sirens"],
	"sensors":		[title: "Sensors", description: "Contact, Mobile App, Motion, Multipurpose, Omnipurpose, Presence, Shock"],
	"shackrat":		[title: "Shackrat's Drivers", description: "Iris V3 Motion, Iris Smart Plug, Z-Wave Repeaters"],
	"switches":		[title: "Lighting, Fans, & Switches", description: "Switches, Dimmers, Bulbs, Power & Energy Meters"],
	"virtual":		[title: "Virtual Devices", description: "Hubitat Virtual Devices, GV Connector"]
]


// Map containing commands to HSM states
@Field static Map<String, List> HSM_COMMAND_STATES =
[
	armAway: 		["armedAway", "armingAway"],
	armHome: 		["armedHome", "armingHome"],
	armNight: 		["armedNight", "armingNight"],
	disarm: 		["disarmed"],
	disarmAll:		["allDisarmed"],
	armAll: 		["armedAway", "armingAway", "armedHome", "armingHome", "armedNight", "armingNight"],
	armRules: 		[],
	disarmRules: 	[],
	cancelAlerts: 	[]
]


// Mapping to receive events
mappings
{
	// Client mappings
    path("/event/:deviceId/:deviceCommand/:commandParams")
	{
		action: [GET: "remoteDeviceCommand"]
	}
    path("/modes/get")
	{
		action: [GET: "getAllModes"]
	}
    path("/modes/set/:name")
	{
		action: [GET: "remoteModeChange"]
	}
    path("/hsm/get")
	{
		action: [GET: "getAllHSMStates"]
	}
    path("/hsm/set/:name")
	{
		action: [GET: "remoteHSMChange"]
	}
    path("/hsm/alert/:text")
	{
		action: [GET: "hsmReceiveAlert"]
	}

	// System endpoints
	path("/system/setCommStatus/:status")
	{
		action: [GET: "systemSetCommStatus"]
	}
    path("/system/setCommType/:type")
	{
		action: [GET: "systemSetCommType"]
	}
    path("/system/setConnectString/:connectKey")
	{
		action: [GET: "systemSetConnectKey"]
	}
	path("/system/drivers/save")
	{
		action: [POST: "systemSaveCustomDrivers"]
	}
    path("/system/versions/get")
	{
		action: [GET: "systemGetVersions"]
	}
    path("/system/initialize")
	{
		action: [GET: "systemRemoteInitialize"]
	}
    path("/system/update")
	{
		action: [GET: "systemRemoteUpdate"]
	}
    path("/system/tsreport/get")
	{
		action: [GET: "systemGetTSReport"]
	}
    path("/system/disconnect")
	{
		action: [GET: "systemRemoteDisconnect"]
	}

	// Device endpoints
    path("/devices/save")
	{
		action: [POST: "devicesSaveAll"]
	}
    path("/device/:deviceId/event/:event")
	{
		action: [GET: "deviceSendEvent"]
	}
	path("/device/:deviceId/sync/:type")
	{
		action: [GET: "getDeviceSync"]
	}
}


/*
	getDeviceSync

	Purpose:	Retrieves the current attribute and device name/label.

	URL Format: GET /device/:deviceId/sync/:type

	API:		https://hubconnect.to/knowledgebase/7/getDeviceSync.html
*/
def getDeviceSync() {getDeviceSync(params)}
def getDeviceSync(Map params)
{
	if (enableDebug) log.info "Received device update request from server: [${params.deviceId}, type ${params.type}]"

	com.hubitat.app.DeviceWrapper device = getDevice(params)
	if (device != null)
	{
		def currentAttributes = getAttributeMap(device, params.type)
		String label = device.label ?: device.name
		jsonResponse([status: "success", name: "${device.name}", label: "${label}", currentValues: currentAttributes])
	}
}


/*
	getDevice

	Purpose: Helper function to retreive a device from all groups of devices.
*/
com.hubitat.app.DeviceWrapper getDevice(Map params)
{
	com.hubitat.app.DeviceWrapper foundDevice = (com.hubitat.app.DeviceWrapper) null

	NATIVE_DEVICES.each
	{
	  groupname, device ->
		if (foundDevice != null) return
		foundDevice = settings."${device.selector}"?.find{it.id == params.deviceId}
	}

	// Custom devices drivers
	if (foundDevice == null)
	{
		state.customDrivers?.each
		{
	 	  groupname, device ->
			if (foundDevice != null) return
			foundDevice = settings."custom_${groupname}".find{it.id == params.deviceId}
		}
	}
	foundDevice
}


/*
	remoteDeviceCommand

	Purpose: 	Executes a command on a device located on this hub.

	Parameters: params - (Map)

	URL Format:	GET /event/:deviceId/:deviceCommand/:commandParams

	API:		https://hubconnect.to/knowledgebase/6/remoteDeviceCommand.html
*/
def remoteDeviceCommand() {remoteDeviceCommand(params)}
def remoteDeviceCommand(Map params)
{
    List commandParams = (state.connectionType == "socket" && useProxy) ? params.commandParams : (params.commandParams != "null" ? parseJson(URLDecoder.decode(params.commandParams)) : [])

	// Get the device
	com.hubitat.app.DeviceWrapper device = getDevice(params)
	if (device == null)
	{
		log.error "Could not locate a device with an id of ${params.deviceId}"
		return jsonResponse([status: "error"])
	}

	// DeleteSync: Uninstalling?
	if (params.deviceCommand == "uninstalled")
	{
		def driverDef = NATIVE_DEVICES.findResults{groupname, driver -> settings?."${driver.selector}"?.findResults{ if (it.id == "${device.id}") return driver.selector }?.join() }?.join() ?:
			 state.customDrivers.each.findResults{groupname, driver -> settings?."custom_${groupname}"?.findResults{ if (it.id == "${device.id}") return driver.selector }?.join() }?.join()

		if (driverDef)
		{
			// "de-select" the device
			def newSetting = settings?."${driverDef}"?.findResults{if (it.id != "${device.id}") return it.id}
			app.updateSetting("${driverDef}", [type: "capability", value: newSetting])
			if (enableDebug) log.info "Received device delete requet from client: [\"${device.label ?: device.name}]\"..  Sharing of this device has been disabled on this hub."
		}

		// Update subscriptions & device ID filter
		subscribeLocalEvents()
		updateDeviceIDList()

		return jsonResponse([status: "success"])
	}

	if (enableDebug) log.info "Received command from server: [\"${device.label ?: device.name}\": ${params.deviceCommand}]"

	// Make sure the physical device supports the command
	if (!device.hasCommand(params.deviceCommand))
	{
		log.warn "The device [${device.label ?: device.name}] does not support the command ${params.deviceCommand}."
		return jsonResponse([status: "error"])
	}

	// Execute the command
	device."${params.deviceCommand}"(*commandParams)

	jsonResponse([status: "success"])
}


/*
	remoteModeChange

	Purpose:	Executes a mode change on this hub.

	URL Format: GET /modes/set/:name

	API:		https://hubconnect.to/knowledgebase/9/remoteModeChange.html
*/
def remoteModeChange() {remoteModeChange(params)}
def remoteModeChange(Map params)
{
	String modeName = (state.connectionType == "socket") ? params.value : (params?.name ? URLDecoder.decode(params?.name) : "")
	clientName = clientName ?: thisClientName // no reason for a Null clientName

	// Send mode status event to the remote hub device to update even if it's not defined on this hub
	hubDevice.sendEvent([name: "modeState", value: modeName])

    if (!receiveModes)
    {
		log.warn "Ignoring mode change event... Mode changes are disabled on this hub."
        jsonResponse([status: "error"])
        return
    }

	if (location.modes?.find{it.name == modeName})
	{
		if (enableDebug) log.debug "Received mode event from ${clientName}: ${modeName}"
		if (location.mode != modeName) setLocationMode(modeName)
		jsonResponse([status: "complete"])
	}
	else
	{
		log.error "Received mode event from ${clientName}: ${modeName} does not exist!"
		jsonResponse([status: "error"])
    }
}


/*
	remoteHSMChange

	Purpose:	Executes a SHM setArm command on this hub.

	URL Format: GET /hsm/set/:name

	API:		https://hubconnect.to/knowledgebase/11/remoteHSMChange.html
*/
def remoteHSMChange() {remoteHSMChange(params)}
def remoteHSMChange(Map params)
{
	String hsmState = (state.connectionType == "socket") ? params.value : (params?.value ? URLDecoder.decode(params?.value) : "")

	// Send HSM status event to the remote hub device to update even if it's not configured on this hub
	hubDevice.sendEvent([name: "hsmState", value: hsmState])

	if (!receiveHSM)
	{
		log.warn "Ignoring HSM change event... HSM changes are disabled on this hub."
	    jsonResponse([status: "error"])
	    return
	}
	
	if (HSM_COMMAND_STATES.find{cmd, state -> cmd == hsmState})
	{
		if (enableDebug) log.debug "Received HSM event from server: ${hsmState}"
		if (HSM_COMMAND_STATES.find{cmd, state -> cmd == hsmState && state.find {it == location.hsmStatus}})
		{
			if (enableDebug) log.debug "HSM is already in the requested state...  Skipping."
			return
		}
	
		sendLocationEvent(name: "hsmSetArm", value: hsmState, data: app.id)
		atomicState.lastHSMChange = hsmState
		jsonResponse([status: "complete"])
	}
	else if (HSM_COMMAND_STATES.find{cmd, state -> state.find {it == hsmState}})
	{
		if (logDebug) log.info "Received HSM event from server: server is in the ${hsmState} state."
	}
	else
	{
		log.error "Received HSM event from server: ${hsmState} does not exist!"
		jsonResponse([status: "error"])
	}
}


/*
	hsmReceiveAlert

	Purpose: 	Receives and forwards HSM alert events from the server hub.

	URL Format: GET /hsm/alert/:text

	API:		https://hubconnect.to/knowledgebase/12/hsmReceiveAlert.html
*/
def hsmReceiveAlert() {hsmReceiveAlert(params)}
def hsmReceiveAlert(Map params)
{
	if (!receiveHSM) return
    String hsmAlertText = params?.text ? URLDecoder.decode(params?.text) : ""

	sendEvent(app, hsmAlertText)
	jsonResponse([status: "success"])
}


/*
	subscribeLocalEvents

	Purpose: Subscribes to all device events for all attribute returned by getSupportedAttributes()

	Notes: 	Thank god this isn't SmartThings, or this would time out after about 10 subscriptions!
*/
private void subscribeLocalEvents()
{
	unsubscribe()

	if (state.connectionType == "socket")
	{
		log.info "Skipping event subscriptions...  Using event socket to send events to server."
		return
	}

	log.info "Subscribing to events.."

	NATIVE_DEVICES.each
	{
	  groupname, device ->
		def selectedDevices = settings."${device.selector}"
		if (selectedDevices?.size()) getSupportedAttributes(groupname).each { subscribe(selectedDevices, it, realtimeEventHandler) }
	}

	// Special handling for Smart Plugs & Power Meters - Kinda Kludgy
	if (!sp_EnablePower && smartPlugs?.size()) unsubscribe(smartPlugs, "power", realtimeEventHandler)
	if (!sp_EnableVolts && smartPlugs?.size()) unsubscribe(smartPlugs, "voltage", realtimeEventHandler)
	if (!pm_EnableVolts && powerMeters?.size()) unsubscribe(powerMeters, "voltage", realtimeEventHandler)

	// Custom defined drivers
	state.customDrivers?.each
	{
	  groupname, driver ->
		if (settings."custom_${groupname}"?.size()) getSupportedAttributes(groupname).each { subscribe(settings."custom_${groupname}", it, realtimeEventHandler) }
	}
}


/*
	realtimeEventHandler

	Purpose: Event handler for all local device events.

	URL Format: GET /device/localDeviceId/event/name/value/unit

	Notes: Handles everything from this hub!
*/
void realtimeEventHandler(evt)
{
	if (state.commDisabled) return

	Map event =
	[
		name:			evt.name,
		value:			evt.value,
		unit:			evt.unit,
		displayName:	evt.displayName ?: (evt.device.label ?: evt.device.name),
		data:			evt.data
	]

	def data = URLEncoder.encode(JsonOutput.toJson(event), "UTF-8")

	if (enableDebug) log.debug "Sending event to server: ${evt.device.label ?: evt.device.name} [${evt.name}: ${evt.value} ${evt.unit}]"
	sendGetCommand("/device/${evt.deviceId}/event/${data}")
}


/*
	updateDeviceIDList

	Purpose: Helper function to update the list of device ID's and push them to the remote hub device.
*/
void updateDeviceIDList()
{
	// Build a lookup table
	String[] parts = []
	state.deviceIdList = new HashSet<>()
	childDevices.each
	{
		parts = it.deviceNetworkId.split(":")
		if (parts?.size() > 1) state.deviceIdList << (localConnectionType != "socket" ? parts[1].toString() : parts[1].toInteger())
	}
    hubDevice?.updateDeviceIdList(state.deviceIdList)
}


/*
	getAttributeMap

	Purpose: Returns a map of current attribute values for (device) with the device class (deviceClass).

	Notes: Calls getSupportedAttributes() to obtain list of attributes.
*/
List getAttributeMap(com.hubitat.app.DeviceWrapper device, String deviceClass)
{
	def deviceAttributes = getSupportedAttributes(deviceClass)
	List currentAttributes = []
	deviceAttributes.each
	{
		if (device.supportedAttributes.find{attr -> attr.toString() == it})  // Filter only attributes the device supports
			currentAttributes << [name: "${it}", value: device.currentValue("${it}"), unit: it == "temperature" ? "°"+getTemperatureScale() : it == "power" ? "W" :  it == "voltage" ? "V" : it == "battery" ? "%" : ""]
	}
	return currentAttributes
}


/*
	getSupportedAttributes

	Purpose: Returns a list of supported attribute values for the device class (deviceClass).

	Notes: Called from getAttributeMap().
*/
private getSupportedAttributes(String deviceClass)
{
	if (NATIVE_DEVICES.find{it.key == deviceClass}) return NATIVE_DEVICES[deviceClass].attr
	if (state.customDrivers.find{it.key == deviceClass}) return state.customDrivers[deviceClass].attr
	return null
}


/*
	realtimeModeChangeHandler

	URL Format: GET /modes/set/modeName

	Purpose: Event handler for mode change events on the controller hub (this one).
*/
void realtimeModeChangeHandler(evt)
{
	if (state.commDisabled || !pushModes) return

	String newMode = evt.value
	if (enableDebug) log.debug "Sending mode change event to server: ${newMode}"
	sendGetCommand("/modes/set/${URLEncoder.encode(newMode)}")
}


/*
	pushCurrentMode

	Purpose: Pushes the current mode out to server hub.

	URL Format: /modes/set/modeName

	Notes: Called by system start event to make sure the correct mode is pushed to all remote hubs.
*/
void pushCurrentMode()
{
	if (state.commDisabledb || !pushModes) return
	sendGetCommand("/modes/set/${URLEncoder.encode(location.mode)}")
}


/*
	realtimeHSMChangeHandler

	URL Format: GET /hsm/set/hsmStateName

	Purpose: Event handler for HSM state change events on the controller hub (this one).
*/
void realtimeHSMChangeHandler(evt)
{
	if (state.commDisabled || !pushHSM) return

	if (evt?.data?.toInteger() != app.id && atomicState.lastHSMChange != evt.value)
	{
		if (enableDebug) log.debug "Sending HSM state change event to Server: ${evt.value}"
		sendGetCommand("/hsm/set/${URLEncoder.encode(evt.value)}")
		atomicState.lastHSMChange = evt.value
	}
	else if (enableDebug) log.info "Filtering duplicate HSM state change event."
}


/*
	deviceToServer

	Purpose: Sends all of the devices selected (& current attribute values) from this hub to the controller hub.

	URL Format: POST /devices/save

	Notes: Makes a single POST request for each group of devices.
*/
void saveDevicesToServer()
{
	if (devicesChanged == false) return

	// Fetch all devices and attributes for each device group and send them to the master.
	List idList = []
	List devices = []
	NATIVE_DEVICES.each
	{
	  groupname, device ->

		devices = []
		settings."${device.selector}".each
		{
			devices << [id: it.id, label: it.label ?: it.name, attr: getAttributeMap(it, groupname)]
			idList << it.id
		}
		if (devices != [])
		{
			if (enableDebug) log.info "Sending devices to server: ${groupname} - ${devices}"
			sendPostCommand("/devices/save", [deviceclass: groupname, devices: devices])
		}
	}

	// Custom defined device drivers
	state.customDrivers.each
	{
	  groupname, driver ->

		devices = []
		settings?."custom_${groupname}"?.each
		{
			devices << [id: it.id, label: it.label ?: it.name, attr: getAttributeMap(it, groupname)]
			idList << it.id
		}
		if (devices != [])
		{
			if (enableDebug) log.info "Sending custom devices to remote: ${groupname} - ${devices}"
			sendPostCommand("/devices/save", [deviceclass: groupname, devices: devices])
		}
	}
	if (cleanupDevices) sendPostCommand("/devices/save", [cleanupDevices: idList])
	state.saveDevices = false
}


/*
	sendDeviceEvent

	Purpose: Send an event to a client device.

	URL format: GET /event/:deviceId/:deviceCommand/:commandParams

	Notes: CALLED FROM CHILD DEVICE
*/
void sendDeviceEvent(String deviceId, String deviceCommand, List commandParams=[])
{
	if (state.commDisabled) return
	String[] dniParts = deviceId.split(":")

	// HubConnect server
	if (state.connectionType == "socket" && useProxy)
	{
		log.info "Sending ${deviceCommand} command to HubConnect Server."
		hubDevice.hcsSendMessage([
			source:			"COMMAND",
			deviceId:		dniParts[1],
			deviceCommand:	deviceCommand,
			commandParams:	commandParams
		])
		return
	}

	String paramsEncoded = commandParams ? URLEncoder.encode(new groovy.json.JsonBuilder(commandParams).toString()) : null
	sendGetCommand("/event/${dniParts[1]}/${deviceCommand}/${paramsEncoded}")
}


/*
	deviceSendEvent

	Purpose:	Receives and forwards events received from a physical device located on a remote hub.

	URL Format: GET /device/:deviceId/event/:event

	API:		https://hubconnect.to/knowledgebase/22/deviceSendEvent.html
*/
def deviceSendEvent() {deviceSendEvent(params)}
def deviceSendEvent(Map params)
{
	String eventraw = params.event ? URLDecoder.decode(params.event) : (String) null
	if (eventraw == null) return

	Map event = parseJson(new String(eventraw))
	String data = event?.data ?: ""
	String unit = event?.unit ?: ""

	// We can do this faster if we don't need info on the device
	if (state.deviceIdList.contains(params.deviceId))
	{
		sendEvent("${serverIP}:${params.deviceId}", (Map) [name: (String) event.name, value: (String) event.value, unit: (String) unit, descriptionText: "${event?.displayName} ${event.name} is ${event.value} ${unit}", isStateChange: true, data: data])
		if (enableDebug) log.info "Received event from server/${event.displayName}: [${event.name}, ${event.value} ${unit}]"
		return jsonResponse([status: "complete"])
	}

	if (enableDebug) log.warn "Ignoring Received event from server: Device Not Found!"
	jsonResponse([status: "error"])
}


/*
	wsSendEvent

	Purpose: Handler for events received from physical devices through the websocket interface.

	Notes: 	This is only called by the hub device for events received through its local websocket.
			Also, this does not warn when a device cannot be found as websockets get ALL events so we rely on an internal filter for this.
*/
void wsSendEvent(Object event)
{
	// We can do this faster if we don't need info on the device, so defer that for logging
	sendEvent("${serverIP}:${event.deviceId}", (Map) [name: (String) event.name, value: (String) event.value, unit: (String) event.unit, descriptionText: (String) event.descriptionText, isStateChange: (Boolean) event.isStateChange])
	if (enableDebug) log.info "Received websocket event from server/${event.displayName}: [${event.name}, ${event.value} ${event.unit}]"
}


/*
	devicesSaveAll

	Purpose:	Creates virtual shadow devices and connects them the remote hub.

	URL Format: POST /devices/save

	API:		https://hubconnect.to/knowledgebase/21/devicesSaveAll.html
*/
def devicesSaveAll() {devicesSaveAll(params)}
def devicesSaveAll(Map params)
{
	// Device cleanup?
	if (request?.JSON?.cleanupDevices != null)
	{
		childDevices.each
		{
		  child ->
			if (child.deviceNetworkId != state.hubDeviceDNI && request.JSON.cleanupDevices.find{"${serverIP}:${it}" == child.deviceNetworkId} == null)
			{
				if (enableDebug) log.info "Deleting device ${child.label} as it is no longer shared with this hub."
				deleteChildDevice(child.deviceNetworkId)
			}
		}
	}

	// Find the device class
	else if (!request?.JSON?.deviceclass || !request?.JSON?.devices)
	{
		return jsonResponse([status: "error"])
	}

	if (NATIVE_DEVICES.find {it.key == request.JSON.deviceclass})
	{
		// Create the devices
		request.JSON.devices.each { createLinkedChildDevice(it, "HubConnect ${NATIVE_DEVICES[request.JSON.deviceclass].driver}") }
	}
	else if (state.customDrivers.find {it.key == request.JSON.deviceclass})
	{
		// Get the custom device type and create the devices
		request.JSON.devices.each { createLinkedChildDevice(it, "${state.customDrivers[request.JSON.deviceclass].driver}") }
	}

	// Update the device filter
	updateDeviceIDList()

	jsonResponse([status: "complete"])
}


/*
	createLinkedChildDevice

	Purpose: Helper function to create child devices.

	Notes: 	Called from devicesSaveAll()
*/
private createLinkedChildDevice(Map dev, String driverType)
{
	com.hubitat.app.DeviceWrapper childDevice = getChildDevice("${serverIP}:${dev.id}")
	if (childDevice)
	{
		// Device exists
		if (enableDebug) log.trace "${driverType} ${dev.label} (${childDevice.deviceNetworkId}) exists... Skipping creation.."
		return
	}
	else
	{
		if (enableDebug) log.trace "Creating Device ${driverType} - ${dev.label}... ${serverIP}:${dev.id}..."
		try
		{
			childDevice = addChildDevice("shackrat", driverType, "${serverIP}:${dev.id}", null, [name: dev.label, label: dev.label])
		}
		catch (errorException)
		{
			log.error "... Uunable to create device ${dev.label}: ${errorException}."
			childDevice = null
		}
	}

	// Set the value of the primary attributes
	if (childDevice)
	{
		dev.attr.each
		{
	 	 attribute ->
			childDevice.sendEvent([name: attribute.name, value: attribute.value, unit: attribute.unit])
		}
	}
}


/*
	syncDevice

	Purpose: Sync device details with the physcial device by requeting an update of all attribute values from the remote hub.

	Notes: CALLED FROM CHILD DEVICE
*/
void syncDevice(String deviceNetworkId, String deviceType)
{
	String[] dniParts = deviceNetworkId.split(":")
	com.hubitat.app.DeviceWrapper childDevice = getChildDevice(deviceNetworkId)
	if (childDevice)
	{
		if (enableDebug) log.debug "Requesting device sync from server: ${childDevice.label}"

		def data = httpGetWithReturn("/device/${dniParts[1]}/sync/${deviceType}")
		if (data?.status == "success")
		{
			childDevice.setLabel(data.label)

			data?.currentValues.each
			{
			  attr ->
				childDevice.sendEvent([name: attr.name, value: attr.value, unit: attr.unit, descriptionText: "Sync: ${childDevice.displayName} ${attr.name} is ${attr.value} ${attr.unit}", isStateChange: true])
			}
		}
	}
}


/*
	httpGetWithReturn

	Purpose: Helper function to format GET requests with the proper oAuth token.

	Notes: 	Command is absolute and must begin with '/'
			Returns JSON Map if successful.
*/
def httpGetWithReturn(String command)
{
	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		timeout: 10
	]

	try
	{
		httpGet(requestParams)
		{
	  	  response ->
			if (response?.status == 200)
			{
				return response.data
			}
			else
			{
				log.warn "httpGet() request failed with status ${response?.status}"
				return [status: "error", message: "httpGet() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpGet() failed with error ${e.message}"
		return [status: "error", message: e.message]
	}
}


/*
	sendGetCommand

	Purpose: Helper function to format GET requests with the proper oAuth token.

	Notes: 	Executes async http request and does not return data.
*/
def sendGetCommand(String command)
{
	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		timeout: 5
	]

	try
	{
		asynchttpGet((enableDebug ? "asyncHTTPHandler" : null), requestParams)
	}
	catch (Exception e)
	{
		log.error "asynchttpGet() failed with error ${e.message}"
	}
}


/*
	asyncHTTPHandler

	Purpose: Helper function to handle returned data from asyncHttpGet.

	Notes: 	Does not return data, only logs errors when debugging is enabled.
*/
void asyncHTTPHandler(response, data)
{
	if (response?.status != 200)
	{
		log.error "asynchttpGet() request failed with error ${response?.status}"
	}
}


/*
	sendPostCommand

	Purpose: Helper function to format POST requests with the proper oAuth token.

	Notes: 	Returns JSON Map if successful.
*/
def sendPostCommand(String command, data)
{
	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		body: data,
		timeout: 20
	]

	try
	{
		httpPostJson(requestParams)
		{
	  	  response ->
			if (response?.status == 200)
			{
				return response.data
			}
			else
			{
				log.error "httpPostJson() request failed with error ${response?.status}"
				return [status: "error", message: "httpPostJson() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpPostJson() failed with error ${e.message}"
		return [status: "error", message: e.message]
	}
}


/*
	appHealth

	Purpose: Checks in with the controller hub every 1 minute.

	URL Format: /ping

	Notes: 	Hubs are considered in a warning state after missing 2 pings (2 minutes).
			Hubs are considered offline after missing 5 pings (5 minutes).
			When a hub is offline, the virtual hub device presence state will be set to "not present".
*/
void appHealth()
{
	if (useProxy) hubDevice.hcsSendMessage([source: "SYSTEM", name: "appHealth", value: now()])
	else sendGetCommand("/ping")
}


/*
	systemSetCommStatus

	Purpose:	Enable or disable bi-directional communications between hubs.

	URL Format:	GET /system/setCommStatus/:status

	API: 		https://hubconnect.to/knowledgebase/13/systemSetCommStatus.html
*/
def systemSetCommStatus() {systemSetCommStatus(params)}
def systemSetCommStatus(Map params)
{
	log.info "Received setCommStatus command from server: disabled ${params.status}]"
	state.commDisabled = params.status == "false" ? false : true

	getHubDevice()?.(state.commDisabled ? "off" : "on")()
	jsonResponse([status: "success", switch: params.status == "false" ? "on" : "off"])
}


/*
	setCommStatus

	Purpose: Event handler which disables events communications between hubs.

	Notes: 	This is useful to stop the remote hub from listening to the server web socket.
			Called by Remote Hub Device
*/
void setCommStatus(Boolean status)
{
	log.info "Received setCommStatus command from virtual hub device: disabled ${status}]"
	log.info "Master bi-directional communciation status can only be set from the server hub."
	state.commDisabled = status
}


/*
	getAllModes

	Purpose: 	Returns a list of all configured modes on this hub.

	URL Format: GET /modes/get

	API:		https://hubconnect.to/knowledgebase/8/getAllModes.html
*/
def getAllModes()
{
	jsonResponse(modes: location.modes, active: location.mode)
}


/*
	getAllHSMStates

	Purpose:	Returns a list of all configured HSM States and the active state on this hub.

	URL Format: GET /hsm/get

	API:		https://hubconnect.to/knowledgebase/10/getAllHSMStates.html
*/
def getAllHSMStates()
{
	jsonResponse(hsmSetArm: ["armAway", "armHome", "armNight", "disarm", "armRules", "disarmRules", "disarmAll", "armAll", "cancelAlerts"], hsmStatus: location.hsmStatus)
}


/*
	systemSaveCustomDrivers

	Purpose:	Saves the custom driver definitions from the server hub.

	URL Format:	GET /system/drivers/save

	API: 		https://hubconnect.to/knowledgebase/16/systemSaveCustomDrivers.html
*/
def systemSaveCustomDrivers()
{
	if (request?.JSON?.find{it.key == "customdrivers"})
	{
		// Clean up from deleted drivers
		state.customDrivers.each
		{
	  	  key, driver ->
			if (request?.JSON?.customdrivers?.findAll{it.key == key}.size() == 0)
			{
				if (enableDebug) log.debug "Unsubscribing from events and removing device selector for ${key}"
				unsubscribe(settings."custom_${key}")
				app.removeSetting("custom_${key}")
			}
		}
		state.customDrivers = request.JSON.customdrivers
		state.customDriverDBVersion = request?.JSON?.customdriverdbversion
		jsonResponse([status: "success"])
	}
	else
	{
		jsonResponse([status: "error"])
	}
}


/*
	installed

	Purpose: Standard install function.

	Notes: Doesn't do much.
*/
void installed()
{
	log.info "${app.name} Installed"

	state.saveDevices = false
	state.installedVersion = appVersion

	if (!state?.customDrivers)
	{
		state.customDrivers = (Map) [:]
		state.customDriverDBVersion = 0
	}

	initialize()
}


/*
	updated

	Purpose: Standard update function.

	Notes: Still doesn't do much.
*/
void updated()
{
	log.info "${app.name} Updated"

	if (!state?.customDrivers)
	{
		state.customDrivers = (Map) [:]
		state.customDriverDBVersion = 0
	}
	state.proxyIP = state.proxyIP ?: ""
	state.proxyPort = state.proxyPort ?: ""

	if (state?.hubDeviceDNI == null) state.hubDeviceDNI = "serverhub-${serverIP}"

	// Clean up ghost hub devices
	childDevices.findAll{it.typeName == "HubConnect Remote Hub" && it.deviceNetworkId != state.hubDeviceDNI}.each{deleteChildDevice(it.deviceNetworkId)}

	initialize()

	state.installedVersion = appVersion
}


/*
	systemRemoteUpdate

	Purpose:	Processes the software update following the installation of new code.

	URL Format:	GET /system/update

	API: 		https://hubconnect.to/knowledgebase/19/systemRemoteUpdate.html
*/
def systemRemoteUpdate()
{
	updated()
	jsonResponse([status: "success"])
}


/*
	uninstalled

	Purpose: Standard uninstall function.

	Notes: Tries to clean up just in case Hubitat misses something.
*/
void uninstalled()
{
	// Remove virtual hub device
	deleteChildDevice(state.hubDeviceDNI)

	// Remove all devices if not explicity told to keep.
	if (removeDevices) childDevices.each { deleteChildDevice(it.deviceNetworkId) }

	log.info "HubConnect remote client has been uninstalled."
}


/*
	initialize

	Purpose: Initialize the server instance.

	Notes:Gets things ready to go!
*/
void initialize()
{
	log.info "${app.name} Initialized"
	unschedule()
	unsubscribe()

   	state.commDisabled = false

	// Build a lookup table & update device IPs if necessary
	List parts = []
	state.deviceIdList = new HashSet<>()
	childDevices.each
	{
		parts = it.deviceNetworkId.split(":")
		if (parts?.size() > 1)
		{
			state.deviceIdList << (state.connectionType != "socket" ? parts[1].toString() : parts[1].toInteger())
			if (updateDeviceIPs) it.deviceNetworkId = "${serverIP}:${parts[1]}"
		}
	}
	app.updateSetting("updateDeviceIPs", [type: "bool", value: false])

	String[] connURI = state?.clientURI?.split(":")
	String serverPort = connURI?.size() > 2 ? connURI[2] : "80"

	String hubDeviceDNI = "serverhub-${serverIP}"

	// Fetch the hub device, update DNI if necessary
	com.hubitat.app.DeviceWrapper hubDevice = getHubDevice()
	if (hubDevice)
	{
		// Changing DNI?
		if (hubDeviceDNI != state.hubDeviceDNI)
		{
			if (logDebug) log.info "Changing HubDevice DNI from ${state.hubDeviceDNI} to ${hubDeviceDNI}"
			hubDevice.deviceNetworkId = state.hubDeviceDNI = hubDeviceDNI
		}
		hubDevice.setConnectionType(state.connectionType, serverIP, serverPort, state?.proxyIP, state.proxyPort?.toString(), state.useProxy)
		hubDevice.updateDeviceIdList(state.deviceIdList)
	}
	else if (state?.clientToken)
	{
		state.hubDeviceDNI = hubDeviceDNI
		hubDevice = createHubChildDevice()
		if (hubDevice == null)
		{
			// Failed to create device
			log.error "HubConnect could not be initialized.  A server hub device with a DNI of [${hubDeviceDNI}] was found.  Please manually remove this device before using HubConnect."
			state.hubDeviceDNI = null
			return
		}
		hubDevice.setConnectionType(state.connectionType, serverIP, serverPort, state?.proxyIP, state.proxyPort?.toString(), state.useProxy)
		hubDevice.updateDeviceIdList(state.deviceIdList)
	}

	if (isConnected)
	{
		saveDevicesToServer()
		subscribeLocalEvents()
		if (pushModes && state.connectionType == "http") subscribe(location, "mode", realtimeModeChangeHandler)
		if (pushHSM && state.connectionType == "http") subscribe(location, "hsmSetArm", realtimeHSMChangeHandler)
		runEvery1Minute("appHealth")
	}

	atomicState.remove("rsStatus")
	atomicState.remove("rsProgress")

	state.saveDevices = false
	app.updateLabel("${ thisClientName ? thisClientName.replaceAll(/[^0-9a-zA-Z&_ ]/, "") + "${ isConnected ? '<span style=\"color:green\"> Online</span>' : '<span style=\"color:red\"> Offline</span>' }" : 'HubConnect Remote Client' }")
}


/*
	systemRemoteInitialize

	Purpose:	Reinitializes the remote client & remote hub device on this hub.

	URL Format:	GET /system/initialize

	API:		https://hubconnect.to/knowledgebase/18/systemRemoteInitialize.html
*/
def systemRemoteInitialize()
{
	initialize()
	jsonResponse([status: "success"])
}


/*
	createHubChildDevice

	Purpose: Create child device for the server hub so up/down status can be managed with rules.

	Notes: 	Called from initialize()
*/
private com.hubitat.app.DeviceWrapper createHubChildDevice()
{
	String deviceNetworkId = state.hubDeviceDNI
	String serverHubName = "Server Hub"

	com.hubitat.app.DeviceWrapper hubDevice = getHubDevice()
	if (hubDevice != null)
	{
		// Hub exists
		log.error "Remote hub device exists... Skipping creation.."
		hubDevice = null
	}
	else
	{
		if (enableDebug) log.trace "Creating remote hub Device ${serverHubName}... ${deviceNetworkId}..."

		try
		{
			hubDevice = addChildDevice("shackrat", "HubConnect Remote Hub", deviceNetworkId, null, [name: "HubConnect Hub", label: serverHubName])
		}
		catch (errorException)
		{
			log.error "Unable to create the Remote Hub device: ${errorException}.   Support Data: [id: \"${deviceNetworkId}\", name: \"HubConnect Hub\", label: \"${serverHubName}\"]"
			hubDevice = (com.hubitat.app.DeviceWrapper) null
		}

		// Set the value of the primary attributes
		if (hubDevice != null) sendEvent("${deviceNetworkId}", [name: "presence", value: "present"])
	}

	hubDevice
}


/*
	jsonResponse

	Purpose: Helper function to render JSON responses
*/
def jsonResponse(Map respMap)
{
	render contentType: 'application/json', data: JsonOutput.toJson(respMap)
}


/*
	getDevicePageStatus

	Purpose: Helper function to set flags for configured devices.
*/
def getDevicePageStatus()
{
	Map status = [:]
	NATIVE_DEVICES.each
	{
	  groupname, device ->
		status["${device.prefGroup}"] = (status["${device.prefGroup}"] ?: 0) + ((Integer) settings?."${device.selector}"?.size() ?: 0)
	}

	// Custom defined device drivers
	state.customDrivers.each
	{
	  groupname, driver ->
		status["custom"] = (status["custom"] ?: 0) + ((Integer) settings?."custom_${groupname}"?.size() ?: 0)
	}

	status["all"] = status.collect{it.value}.sum()
	status
}


/*
	deviceCategoryStatus

	Purpose: Helper function to set flags for configured devices on a category page.
*/
Integer deviceCategoryStatus(String page)
{
	(DEVICE_GROUPS.findResults{groupname, group -> if (page == group.parent) devicePageStatus."${groupname}"}.sum() ?: 0) + ((Integer) devicePageStatus."${page}" ?: 0)
}


/*
	mainPage

	Purpose: Displays the main (landing) page.

	Notes: 	Not very exciting.
*/
def mainPage()
{
	if (settings?.serverIP == null && state?.installedVersion == null) return connectPage()
	if (isConnected && state.installedVersion != null && state.installedVersion != appVersion) return upgradePage()
	app.updateSetting("removeDevices", [type: "bool", value: false])
	dynamicPage(name: "mainPage", title: "${app.label}${state.commDisabled ? " <span style=\"color:orange\"> [Paused]</span>" : ""}", uninstall: (hubDevice == null && !state.connected) ? true : false, install: true)
	{
		section(menuHeader("Connect"))
		{
			href "connectPage", title: "Connect to Server Hub...", description: "", state: isConnected ? "complete" : null
			if (isConnected) href "devicePage", title: "Select devices to synchronize to Server hub...", description: "", state: devicePageStatus.all ? "complete" : null
		}
		if (isConnected)
		{
			section(menuHeader("Modes"))
			{
				if (state.connectionType == "http" || state.connectionType == "hubaction")
				{
					paragraph "Synchronize mode changes on this remote hub to the Server Hub."
					input "pushModes", "bool", title: "Send mode changes to the Server Hub?", defaultValue: false
				}
				paragraph "Synchronize mode changes from the Server hub to this remote hub."
				input "receiveModes", "bool", title: "Receive mode changes from the Server Hub?", description: "", defaultValue: false
			}
			section(menuHeader("Hubitat Safety Monitor (HSM)"))
			{
				if (state.connectionType == "http" || state.connectionType == "hubaction")
				{
					paragraph "Synchronize HSM status on this remote hub to the Server Hub."
					input "pushHSM", "bool", title: "Send HSM changes to the Server Hub?", defaultValue: false
				}
				paragraph "Synchronize HSM status from the Server Hub to this remote hub."
				input "receiveHSM", "bool", title: "Receive HSM changes from the Server Hub?", description: "", defaultValue: false
			}
		}
		section(menuHeader("Admin"))
		{
			if (childDevices?.size() > 1) href "resyncAllDevicesPage", title: "Device Resynchronization", description: "Refreshes all attributes for all devices.", state: null
			input "enableDebug", "bool", title: "Enable debug output?", required: false, defaultValue: false
			href "uninstallPage", title: "${isConnected ? "Disconnect Server Hub &amp; " : ""}Remove this instance...", description: "", state: null
		}
		section()
		{
			href "aboutPage", title: "Help Support HubConnect!", description: "HubConnect is provided free of charge for the benefit the Hubitat community.  If you find HubConnect to be a valuable tool, please help support the project."
			paragraph "<span style=\"font-size:.8em\">Remote Client v${appVersion.major}.${appVersion.minor}.${appVersion.build} ${appCopyright}</span>"
		}
	}
}


/*
	upgradePage

	Purpose: Displays the splash page to force users to initialize the app after an upgrade.
*/
def upgradePage()
{
	dynamicPage(name: "upgradePage", uninstall: false, install: true)
	{
		section("New Version Detected!")
		{
			paragraph "<b style=\"color:green\">This HubConnect Remote Client has an upgrade that has been installed...</b> <br /> Please click [Done] to complete the installation."
		}
	}
}


/*
	systemSetConnectKey

	Purpose:	Sets the connection parameters from the connection key.

	URL Format: GET

	API:		https://hubconnect.to/knowledgebase/15/systemSetConnectKey.html
*/
def systemSetConnectKey()
{
	connectPage()
}


/*
	connectPage

	Purpose: Displays the local & remote oAuth links.

	Notes: 	Really should create a proper token exchange someday.
*/
def connectPage()
{
	if (!state?.accessToken)
	{
		state.accessToken = createAccessToken()
	}

	String responseText = ""

	if (serverKey)
	{
		String rawKey = ""

		// Remote key update
		if (params?.connectKey)
		{
			rawKey = params?.connectKey
			app.updateSetting("serverKey", [type: "text", value: params.connectKey])
		}
		else rawKey = serverKey

		def accessData
		try
		{
			accessData = parseJson(new String(rawKey.decodeBase64()))
		}
		catch (errorException)
		{
			log.error "Error reading connection key: ${errorException}."
			responseText = "Error: Corrupt or invalid connection key"
			state.connected = false
            accessData = null
		}
		if (accessData && accessData?.token && accessData?.type != "smartthings")
		{
			// Set the coordinator hub details
			state.clientURI = accessData.uri
			state.clientToken = accessData.token
			state.clientType = accessData.type
			state.connectionType = accessData.connectionType
			state.proxyIP = accessData.proxyIP
			state.proxyPort = accessData.proxyPort
			state.useProxy = accessData.useProxy

			app.updateSetting("serverIP", [type: "text", value: accessData.serverIP])
			if (settings?.thisClientName == null) app.updateSetting("thisClientName", [type: "text", value: accessData.name])

			// Send our connect string to the coordinator
			String connectKey = new groovy.json.JsonBuilder([uri: (state.clientType == "local" ? getFullLocalApiServerUrl() : getFullApiServerUrl()), name: location.name, type: state.clientType, token: state.accessToken, mac: location.hubs[0].name, customDriverDBVersion: state.customDriverDBVersion]).toString().bytes.encodeBase64()
			def response = httpGetWithReturn("/connect/${connectKey}")
			if ("${response.status}" == "success")
			{
				state.connected = true
			}
			else
			{
				state.connected = false
				responseText = "<div style=\"color: red\">Error: ${response?.message}</div>"
			}
		}
		else if (accessData?.type == "smartthings") responseText = "<div style=\"color: red\">Error: Connection key is not for this platform</div>"
	}

	// Reset connection data if handshake failed
	if (serverKey == null || disconnectHub || state.connected == false)
	{
		resetHubConnection()
	}

	// Remote key update
	if (params?.connectKey)
	{
		runIn(3, initialize)
		return jsonResponse([connected: state.connected, responseText: responseText])
	}

	dynamicPage(name: "connectPage", uninstall: (hubDevice == null && !state.connected) ? true : false, install: false, nextPage: state?.installedVersion == null ? null : "mainPage")
	{
		section(menuHeader("Server Details"))
		{
			input "serverKey", "text", title: "Paste the server hub's connection key here:", required: false, defaultValue: null, submitOnChange: true
			if (serverKey) input "serverIP", "text", title: "Local LAN IP Address of the Server Hub:", required: false, defaultValue: null, submitOnChange: true
		}
		if ((serverKey && serverIP) || state.connected )
		{
			section(menuHeader("Remote Details"))
			{
				input "thisClientName", "text", title: "Friendly Name of this Remote Hub <i>Optional</i>:", required: false, defaultValue: null, submitOnChange: false
				if (serverIP && state.connected) input "updateDeviceIPs", "bool", title: "Update child devices with new IP address?", defaultValue: false
			}
		}
		section()
		{
			if (state.connected)
			{
				if (state?.lastError)
				{
					paragraph "<b style=\"color:red\">${state.lastError}</b>"
					state.remove("lastError")
				}
				paragraph "<b style=\"color:green\">Connected!</b>"
				if (state?.installedVersion == null)
				{
					paragraph "Please click [Install] to complete installation."
					input "completeInstall", "button", title: "Install", required: true, submitOnChange: true
				}
				else input "disconnectHub", "bool", title: "Disconnect Server Hub...", description: "This will erase the connection key.", required: false, submitOnChange: true
			}
			else
			{
				paragraph "<b style=\"color:red\">Not Connected</b>${responseText}"
				if (response?.status == null) input "disconnectHub", "bool", title: "Reset Connection to Server Hub...", description: "This will erase the connection key.", required: false, submitOnChange: true
			}
		}
	}
}


/*
	systemSetCommType

	Purpose:	Sets communications to [http/socket/proxy].

	URL Format: GET /system/setCommType/:type

	API:		https://hubconnect.to/knowledgebase/14/systemSetCommType.html
*/
def systemSetCommType()
{
	jsonResponse([status: systemSetCommType(params) ? "success" : "error"])
}
Boolean systemSetCommType(Map params)
{
	if (params?.type == null) return
	if (params.type == "socket")
	{
		state.connectionType = "socket"
		state.useProxy = false
	}
	else if (params.type == "proxy")
	{
		if (state?.proxyIP?.length() > 0 && state?.proxyPort > 0)
		{
			state.connectionType = "socket"
			state.useProxy = true
		}
	}
	else if (params.type == "http")
	{
		state.connectionType = "http"
	}
	else
	{
		log.error("systemSetCommType: Unknown connection type.")
		return false
	}

	if (enableDebug) log.info "Switching connection type to ${params.type}"

	// Schedule
	runIn(1, initialize)
	return true
}


/*
	uninstallPage

	Purpose: Displays options for removing an instance.

	Notes: 	Really should create a proper token exchange someday.
*/
def uninstallPage()
{
	dynamicPage(name: "uninstallPage", title: "Uninstall HubConnect Remote", uninstall: true, install: false)
	{
		section(menuHeader("Warning!"))
		{
			paragraph "It is strongly recommended to back up your hub before proceeding. This action cannot be undone!\n\nClick the [Remove] button below to disconnect and remove this remote."
		}
		section(menuHeader("Options"))
		{
			input "removeDevices", "bool", title: "Remove virtual HubConnect shadow devices on this hub?", required: false, defaultValue: false, submitOnChange: true
		}
		section(menuHeader("Factory Reset"))
		{
			href "resetPage", title: "Factory Reset..", description: "Perform a factory reset of this remote.", state: null
		}
		section()
		{
			href "mainPage", title: "Cancel and return to the main menu..", description: "", state: null
		}
	}
}


/*
	resetPage

	Purpose:	Prompts a user to "factory reset" this app.

	Notes:		DO NOT USE unless directed by support
*/
def resetPage()
{
	dynamicPage(name: "resetPage", title: "Factory Reset HubConnect Remote", uninstall: false, install: true)
	{
		if (settings?.serverIP == null && state?.installedVersion == null)
		{
			section()
			{
				paragraph "Reset is complete; please check the logs for details."
				href "mainPage", title: "Return to the main menu..", description: "", state: null
			}
		}
		else
		{
			section(menuHeader("Warning!"))
			{
				paragraph "Please DO NOT reset unless directed to by support!!"
				paragraph "It is strongly recommended to back up your hub before proceeding. This action cannot be undone!"
			}
			section(menuHeader("Factory Reset"))
			{
				input "resetConfirmText", "text", title: "Please confirm", description: "Please enter the word \"reset\" (without quotes) to confirm.", required: false
				input "resetToFactoryDefaults", "button", title: "RESET TO DEFAULTS"
			}
		}
		section()
		{
			href "mainPage", title: "Cancel and return to the main menu..", description: "", state: null
		}
	}
}


/*
	devicePage

	Purpose: Displays the page where devices are selected to be linked to the controller hub.

	Notes: 	Really could stand to be better organized.
*/
def devicePage()
{
	Integer totalNativeDevices = 0
	String requiredDrivers = ""
	NATIVE_DEVICES.each
	{devicegroup, device ->
		if (settings."${device.selector}"?.size())
		{
			totalNativeDevices += settings."${device.selector}"?.size()
			requiredDrivers += "<li><a href=\"https://raw.githubusercontent.com/HubitatCommunity/HubConnect/master/UniversalDrivers/HubConnect-${device.driver.replace(" ","-")}.groovy\">HubConnect ${device.driver}</a></li>"
		}
	}

	Integer totalCustomDevices = 0
	state.customDrivers?.each
	{devicegroup, device ->
		totalCustomDevices += settings."custom_${devicegroup}"?.size() ?: 0
	}

	def quickNavOpts = NATIVE_DEVICES.findResults {devicegroup, driver ->
		if (!driver?.platform || driver?.platform == appVersion.platform)  ["${devicegroup}": driver.displayName ?: driver.driver]
	}

	Integer totalDevices = totalNativeDevices + totalCustomDevices

	// Changes in the quick select list?
	if (devicesChanged) state.saveDevices = true
	state.quickSelectState = null

	dynamicPage(name: "devicePage", uninstall: false, install: false, nextPage: "mainPage")
	{
		section(menuHeader("Quick Select"))
		{
			input "quickSelect", "enum", options: quickNavOpts, title: "Device Types", description: "Select the type of device to connect.", required: false, submitOnChange: true
			if (quickSelect)
			{
				def selector = renderDeviceSelector(NATIVE_DEVICES.find{devicegroup, device -> devicegroup == quickSelect}?.value)
				app.updateSetting("quickSelect", [type: "enum", value: ""])
				state.quickSelectState = [name: selector, devices: settings?."${selector}".collect{it.id}]
			}
		}

		section(menuHeader("Device Categories  (${totalDevices} connected)"))
		{
			DEVICE_GROUPS.each
			{
			  groupname, group ->
				if (!group?.parent) href "dynamicDevicePage", title: group.title, description: group.description, state: deviceCategoryStatus(groupname) ? "complete" : null, params: [prefGroup: groupname, title: group.title]
			}
			href "customDevicePage", title: "Custom Devices", description: "Devices with user-defined drivers.", state: devicePageStatus.custom ? "complete" : null
		}
		if (state.saveDevices)
		{
			section()
			{
				paragraph "<b style=\"color:red\">Changes to remote devices will be saved on exit.</b>"
				input "cleanupDevices", "bool", title: "Remove unused devices on the ${getConnectedInstanceType()} hub?", required: false, defaultValue: true
			}
		}
		if (requiredDrivers?.size())
		{
			section(menuHeader("Required Drivers"))
			{
				paragraph "Please make sure the following native drivers are installed on the ${getConnectedInstanceType()} hub before clicking \"Done\": <ul>${requiredDrivers}</ul>"
			}
		}
	}
}


/*
	dynamicDevicePage

	Purpose: Displays a device selection page.
*/
def dynamicDevicePage(Map params)
{
	state.saveDevices = true

	dynamicPage(name: "dynamicDevicePage", title: params.title, uninstall: false, install: false, nextPage: "devicePage")
	{
		if (DEVICE_GROUPS.find{key, val -> val?.parent == params.prefGroup})
		{
			section(menuHeader("Device Categories"))
			{
				DEVICE_GROUPS.each
				{
				  groupname, group ->
					if (group?.parent == params.prefGroup) href "dynamicDevicePage", title: group.title, description: group.description, state: devicePageStatus."${groupname}" ? "complete" : null, params: [prefGroup: groupname, title: group.title]
				}
			}
		}
		NATIVE_DEVICES.each
		{
		  groupname, device ->
			if (device.prefGroup == params.prefGroup)
			{
				if (device?.platform && device?.platform != appVersion.platform) return
				section(menuHeader("Select ${device.driver} Devices (${settings?."${device.selector}"?.size() ?: "0"} connected)"))
				{
					renderDeviceSelector(device)

					// Customizations
					if (groupname == "irissmartplug")
					{
						input "sp_EnablePower", "bool", title: "Enable power meter reporting?", required: false, defaultValue: true
						input "sp_EnableVolts", "bool", title: "Enable voltage reporting?", required: false, defaultValue: true
					}
					else if (groupname == "power")
					{
						input "pm_EnableVolts", "bool", title: "Enable voltage reporting?", required: false, defaultValue: true
					}
				}
			}
		}
	}
}


/*
	customDevicePage

	Purpose: Displays the page where custom (user-defined) devices are selected to be linked to the controller hub.

	Notes: 	First attempt at remotely defined device definitions.
*/
def customDevicePage()
{
	state.saveDevices = true

	dynamicPage(name: "customDevicePage", uninstall: false, install: false)
	{
		state.customDrivers.each
		{
		  groupname, driver ->
			def customSel = settings."custom_${groupname}"
			section(menuHeader("${driver.driver} Devices (${customSel?.size() ?: "0"} connected)"))
			{
				input "custom_${groupname}", "capability.${driver.selector.substring(driver.selector.lastIndexOf("_") + 1)}", title: "${driver.driver} Devices (${driver.attr}):", required: false, multiple: true, defaultValue: null
			}
		}
	}
}


/*
	aboutPage

	Purpose: Displays the about page with credits.
*/
def aboutPage()
{
	dynamicPage(name: "aboutPage", title: "HubConnect v${appVersion.major}.${appVersion.minor}", uninstall: false, install: false)
	{
		section()
		{
			paragraph "HubConnect is provided free for personal and non-commercial use.  Countless hours went into the development and testing of this project.  If you like it and would like to see it succeed, or see more apps like this in the future, please consider making a small donation to the cause."
			href "donate", style:"embedded", title: "Please consider making a \$20 or \$40 donation to show your support!", image: "http://irisusers.com/hubitat/hubconnect/donate-icon.png", url: "https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=T63P46UYH2TJC&source=url"
		}
		section()
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
			paragraph "<span style=\"font-size:.8em\">Remote Client v${appVersion.major}.${appVersion.minor}.${appVersion.build} ${appCopyright}</span>"
		}
	}
}


/*
	resyncAllDevicesPage

	Purpose: Landing page to confirm action to sync() all devices.
*/
def resyncAllDevicesPage()
{
	if (atomicState?.rsStatus == "start")
	{
		runIn(1, "resyncAllDevices")
		atomicState.rsStatus = "starting"
		atomicState.rsProgress = 0
	}
	if (atomicState?.rsStatus == "starting" || atomicState?.rsStatus == "running")
	{
		return waitPage("HubConnect is re-syncing devices; this may take several minutes...\n\nStatus: ${atomicState?.rsStatus?.capitalize()} &nbsp; ${atomicState.rsProgress}/${childDevices?.size()} complete.")
	}

	dynamicPage(name: "resyncAllDevicesPage", uninstall: false, install: false)
	{
		section(menuHeader("Re-synchronize Device Attributes"))
		{
			if (!atomicState?.rsStatus)
			{
				paragraph "There are ${childDevices?.size()} HubConnected devices on this hub that will be resynchronized...  This may take several minutes."
				paragraph "This process is resource intensive; it is not recommended to perform any other tasks on your Hubitat sytem while the resync runs."
				input "rsRunButton", "button", title: "Resync Devices"
			}
			else
			{
				paragraph "<b style=\"color:green\">Device re-syncing is complete.</b>\n${atomicState.rsProgress} devices have been processed."
				atomicState.remove("rsStatus")
				atomicState.remove("rsProgress")
			}
		}
	}

}


/*
	resyncAllDevices

	Purpose: Simply calls sync() on all devices.
*/
void resyncAllDevices()
{
	atomicState.rsStatus = "running"
 	childDevices?.each
	{
	  device ->
		if (device.hasCommand("sync")) device.sync()
		atomicState.rsProgress++
	}
	atomicState.rsStatus = "complete"
}


/*
	waitPage

	Purpose: Displays a please wait splash page to get around Hubitat UI caching.
*/
def waitPage(String dialogMessage = "HubConnect is reconfiguring...")
{
	dynamicPage(name: "waitPage", uninstall: false, install: false, refreshInterval: 1)
	{
		section(menuHeader("Please wait..."))
		{
			paragraph dialogMessage
		}
	}
}


/*
	appButtonHandler

	Purpose: Handles button events for various pages.
*/
void appButtonHandler(String btnPressed)
{
	switch(btnPressed)
	{
		// Complete installation by calling the installed() method manually
		case "completeInstall":
			installed()
			if (hubDevice == null)
			{
				state.lastError = "Remote hub device has not been created. Please check the logs for further information."

				// Disable the remote until the error is fixed
				resetHubConnection(true)
			}
			break

		case "rsRunButton":
			atomicState.rsStatus = "start"
			break

		case "resetToFactoryDefaults":
			if (settings.resetConfirmText == "reset") resetToFactoryDefaults()
			break

		default:
			break
	}
}


/*
	systemGetVersions

	Purpose:	Returns a list of all versions including this remote client and any active/installed drivers on this hub.

	URL Format: GET /system/versions/get

	API			https://hubconnect.to/knowledgebase/17/systemGetVersions.html
*/
def systemGetVersions()
{
	// Get hub app & drivers
	Map remoteDrivers = (Map) [:]
	getChildDevices()?.each
	{
	   device ->
		if (remoteDrivers[device.typeName] == null) remoteDrivers[device.typeName] = device.getDriverVersion()
	}
	jsonResponse([apps: [[appName: app.name, appVersion: appVersion]], drivers: remoteDrivers])
}


/*
	systemRemoteDisconnect

	Purpose:	Accepts a command from the server to disconnect.

	URL Format: GET /system/disconnect

	API:		https://hubconnect.to/knowledgebase/25/systemRemoteDisconnect.html
*/
def systemRemoteDisconnect()
{
	resetHubConnection()

	app.updateSetting("serverKey", [type: "string", value: ""])
	app.updateSetting("disconnectHub", [type: "bool", value: false])
	initialize()
	jsonResponse([status: "success"])
}


/*
	resetHubConnection

	Purpose: Resets the connection to the server hub.
*/
def resetHubConnection(Boolean removeHub = false)
{
	log.info "Resetting connection settings and disconnecting from server hub."

	state.remove("clientURI")
	state.remove("clientToken")
	state.remove("clientType")
	state.remove("connectionType")
	state.remove("proxyIP")
	state.remove("proxyPort")
	state.remove("useProxy")
	state.connected = false

	hubDevice?.off()

	// Remove virtual hub device
	if (removeHub)
	{
		log.info "Removing remote hub device with DNI [${deviceNetworkId}]"
		deleteChildDevice(deviceNetworkId)
	}

	if (disconnectHub)
	{
		app.updateSetting("serverIP", [type: "string", value: ""])
		app.updateSetting("serverKey", [type: "string", value: ""])
		app.updateSetting("disconnectHub", [type: "bool", value: false])
	}
}


/*
	resetToFactoryDefaults

	Purpose: 	Resets everything to a freshly-installed state.

	Notes:		This will disconnect this hub.  Do not use ubnless directed to by support.
*/
void resetToFactoryDefaults()
{
	log.warn "!!! HubConnect resetToFactoryDefaults() Called !!!"
	log.warn "** Resetting all settings and app storage to defaults; device selections and child devices will be preserved. **"
	log.warn "** This hub will be disconnected... **"

	// Destroy state
	log.info ">> Clearing state..."
	state.clear()

	// Destroy atomicState
	log.info ">> Clearing atomicState..."
	atomicState.each{k, v -> atomicState."${k}" = null}

	// Destroy all settings except for device selection
	log.info ">> Clearing settings..."
	settings.each
	{
	  k, v ->
		log.debug "checking: ${k}"

		if (settings?."${k}" != null && k.startsWith("custom_") == false && NATIVE_DEVICES.find{groupname, driver -> k == driver.selector} == null)
		{
			log.info ">>>> Remove setting: ${k}"
			app.removeSetting(k)
		}
	}

	// Remove all Hub Devices
	log.info ">> Removing all hub devices..."
	childDevices.findAll{it.typeName == "HubConnect Remote Hub"}.each{deleteChildDevice(it.deviceNetworkId)}

	log.warn "!!! HubConnect resetToFactoryDefaults() COMPLETE !!!"
}


/*
	renderDeviceSelector

	Purpose: Renders the DeviceMatch device selection dropdown.

	Returns: Name of the rendered selector
*/
private String renderDeviceSelector(Map device)
{
	if (device == null) return
	String capability =
		(device.type == "attr") ? (device.capability.contains("device.") ? device.capability : "capability.${device.capability}")
		: (device.type == "hcapp") ? "device." + device.driver.replace(" ", "")
			: (!settings?."syn_${device.selector}" || settings."syn_${device.selector}" == "attribute") ? "capability.${device.capability}"
			: (settings."syn_${device.selector}" == "physical") ? "device." + device.driver.replace(" ", "")
			: "device.HubConnect" + device.driver.replace(" ", "")

	input "${device.selector}", "${capability}", title: "${device.driver} Device(s) ${device.attr}:", required: false, multiple: true, defaultValue: null
	if (device.type=="synth") input "syn_${device.selector}", "enum", title: "DeviceMatch Selection Type? ${settings."${device.selector}"?.size() ? " (Changing may affect the availability of previously selected devices)" : ""}", options: [physical: "Device Driver", synthetic: "HubConnect Driver", attribute: "Primary Attribute"], required: false, defaultValue: (capability.startsWith("device") ? "physical" : "attribute"), submitOnChange: true
	device.selector
}


/*
	systemGetTSReport

	Purpose:	Returns a full report on the current app including configuration and current status of this client.

	URL Format:	GET /system/tsreport/get

	API:		https://hubconnect.to/knowledgebase/20/systemGetTSReport.html
*/
def systemGetTSReport()
{
	jsonResponse([
		app: [
			appId: app.id,
			appVersion: getAppVersion().toString(),
			installedVersion: state.installedVersion
		],
		prefs: [
			thisClientName: thisClientName,
			serverKey: serverKey,
			pushModes: pushModes,
			pushHSM: pushHSM,
			enableDebug: enableDebug,
		],
		state: [
			clientURI: state?.clientURI,
			connectionType: state?.connectionType,
			customDrivers: state.customDrivers,
			commDisabled: state.commDisabled
		],
		devices: [
			incomingDevices: getChildDevices()?.size() - (hubDevice != null ? 1 : 0),
			deviceIdList: state.deviceIdList
		],
		hub: [
			deviceStatus: hubDevice == null ? "Not Installed" : "Installed",
			connectionType: hubDevice?.currentValue("connectionType"),
			eventSocketStatus: hubDevice?.currentValue("eventSocketStatus"),
			hsmStatus: hubDevice?.currentValue("hsmState"),
			modeStatus: hubDevice?.currentValue("modeState"),
			presence: hubDevice?.currentValue("presence"),
			switch: hubDevice?.currentValue("switch"),
			version: hubDevice?.currentValue("version"),
			subscribedDevices: hubDevice?.getState()?.subscribedDevices,
			connectionAttempts: hubDevice?.getState()?.connectionAttempts,
			refreshSocket: hubDevice?.getPref("refreshSocket"),
			refreshHour: hubDevice?.getPref("refreshHour"),
			refreshMinute: hubDevice?.getPref("refreshMinute"),
			hardwareID: location?.hubs[0]?.data?.hardwareID,
			firmwareVersion: location?.hubs[0]?.firmwareVersionString,
			localIP: location?.hubs[0]?.data?.localIP
		]
	])
}
String menuHeader(titleText){"<div style=\"width:102%;background-color:#696969;color:white;padding:4px;font-weight: bold;box-shadow: 1px 2px 2px #bababa;margin-left: -10px\">${titleText}</div>"}
com.hubitat.app.DeviceWrapper getHubDevice() { getChildDevice(state.hubDeviceDNI) }
Boolean getUseProxy() {state.useProxy}
def getDevicesChanged() {state.saveDevices || (state?.quickSelectState && state?.quickSelectState.devices != (settings?."${state?.quickSelectState?.name}"?.collect{it.id} ?: []))}
Boolean getIsConnected(){(state?.clientURI?.size() > 0 && state?.clientToken?.size() > 0) ? true : false}
String getConnectedInstanceType() {"Server"}
String getAppCopyright(){"&copy; 2019-2020 Steve White, Retail Media Concepts LLC <a href=\"https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html\" target=\"_blank\">HubConnect License Agreement</a>"}
