/**
 * HubConnect Remote Hub
 *
 * Copyright 2019-2020 Steve White, Retail Media Concepts LLC.
 *
 * HubConnect for Hubitat is a software package created and licensed by Retail Media Concepts LLC.
 * HubConnect, along with associated elements, including but not limited to online and/or electronic documentation are
 * protected by international laws and treaties governing intellectual property rights.
 *
 * This software has been licensed to you. All rights are reserved. You may use and/or modify the software.
 * You may not sublicense or distribute this software or any modifications to third parties in any way.
 *
 * By downloading, installing, and/or executing this software you hereby agree to the terms and conditions set forth in the HubConnect license agreement.
 * <https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html>
 *
 * Hubitat is the trademark and intellectual property of Hubitat, Inc. Retail Media Concepts LLC has no formal or informal affiliations or relationships with Hubitat.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License Agreement
 * for the specific language governing permissions and limitations under the License.
 *
 */
Map getDriverVersion() {[platform: "Hubitat", major: 2, minor:0, build: 0]}

import groovy.json.JsonOutput

metadata
{
	definition(name: "HubConnect Remote Hub", namespace: "shackrat", author: "Steve White", importUrl: "")
	{
		capability "Presence Sensor"
		capability "Switch"
		capability "Initialize"

		attribute "eventSocketStatus", "string"
		attribute "eventSocketSource", "string"
		attribute "connectionType", "string"
		attribute "version", "string"
		attribute "hsmState", "enum", ["armedAway", "armingAway",  "armedHome", "armingHome", "armedNight", "armingNight", "disarmed", "allDisarmed"]
		attribute "modeState", "string"

		attribute "proxyEventsReceived", "number"
		attribute "proxyEventsSent", "number"
		attribute "proxyEventsFiltered", "number"
		attribute "proxyEventsDuplicate", "number"
		attribute "proxyEventsUnknown", "number"
		attribute "proxyLoadRxPerSecond", "number"
		attribute "proxyLoadTxPerSecond", "number"
		attribute "proxyLatencyMS", "number"
		attribute "proxyJitterMS", "number"

		command "pushCurrentMode"
		command "toggleSocket"

		preferences
		{
			input(name: "refreshSocket", type: "bool", title: "Re-connect webscocket daily at...", required: true)
			input(name: "refreshHour", type: "number", title: "... hour (0-23)", range: "0...23", defaultValue: 3, required: false)
			input(name: "refreshMinute", type: "number", title: "... minute (0-59)", range: "0...59", defaultValue: 0, required: false)
		}
	}
}


/*
	installed

	Doesn't do much other than call initialize().
*/
void installed()
{
	sendEvent([name: "switch", value: "off"])
	state.connectionType = "http"
	state.useProxy = false
	initialize()
}


/*
	updated

	Doesn't do much other than call initialize().
*/
void updated()
{
	initialize()
	if (state.connectionType == null) state.connectionType = "http"

	unschedule()
	if (state.connectionType == "socket" && refreshSocket) schedule("0 ${refreshMinute} ${refreshHour} * * ?", initialize)
}


/*
	initialize

	Doesn't do much other than call refresh().
*/
void initialize()
{
	log.trace "Initialize virtual Hub device..."

	// Make sure we're not an orphaned device
	if (checkParent() == false) return

	state.connectionAttempts = 0

	if (state.connectionType == "socket")
	{
		// Disconnect if already connected
		interfaces.webSocket.close()

		// Connect to the remote hubs event socket
		String connIP = state.useProxy ? getDataValue("proxyIP") : getDataValue("remoteIP")
		String connPort = state.useProxy ? getDataValue("proxyPort") : getDataValue("remotePort")
		try
		{
			log.info "Attempting websocket connection to ${device.label ?: device.name} (${state.connectionAttempts})"
			interfaces.webSocket.connect("ws://${connIP}:${connPort}/eventsocket")
		}
		catch(errorException)
		{
			log.error "Websocket connect to remote hub failed: ${errorException.message}"
    	}
	}
	sendEvent([name: "connectionType", value: state.connectionType])
	sendEvent([name: "version", value: "v${driverVersion.major}.${driverVersion.minor}.${driverVersion.build}"])
}


/*
	uninstalled

	Reports to the remote that this device is being uninstalled.
*/
void uninstalled()
{
	// Disable communications & close websocket (if open)
	parent?.setCommStatus(true)
	interfaces.webSocket.close()
}


/*
	webSocketStatus

	Called by the websocket to the remote Hubitat hub.
*/
void webSocketStatus(String socketStatus)
{
	if (socketStatus.startsWith("status: open"))
	{
		// Make sure we're not an orphaned device
		if (checkParent() == false) return

		log.info "Connected to ${device.label ?: device.name}"
		state.connectionAttempts = 0
		sendEvent([name: "eventSocketStatus", value: "connected"])
		sendEvent([name: "eventSocketSource", value: (state.useProxy ? "proxy" : "hubitat")])
		sendEvent([name: "switch", value: "on"])
		sendEvent([name: "presence", value: "present"])
		if (state.useProxy)
		{
			interfaces.webSocket.sendMessage(JsonOutput.toJson([source: "FILTER", deviceIdList: state.subscribedDevices]))
		}
		return
    }
	else if (socketStatus.startsWith("status: closing"))
	{
		log.info "Closing connection to ${device.label ?: device.name}"
		sendEvent([name: "eventSocketStatus", value: "closed"])
		sendEvent([name: "eventSocketSource", value: "none"])
		if (state.connectionType == "socket")
		{
			sendEvent([name: "switch", value: "off"])
			sendEvent([name: "presence", value: "not present"])
		}
		return
	}
	else if (socketStatus.startsWith("failure:"))
	{
		log.warn "Connection to ${device.label ?: device.name} has failed with error [${socketStatus}].  Attempting to reconnect..."
		sendEvent([name: "eventSocketStatus", value: "error"])
		sendEvent([name: "presence", value: "not present"])
    }
	else
	{
		log.warn "Connection to ${device.label ?: device.name} has been lost due to an unknown error.  Attempting to reconnect..."
    }

	state.connectionAttempts = state.connectionAttempts + 1
	runIn(10, "initialize")
}


/*
	setConnectionType

	Called by Server Instance or Remote Client to set the connection type.
*/
void setConnectionType(String connType, String remoteIP, String remotePort, String proxyIP, String proxyPort, Boolean useProxy)
{
	state.connectionType = connType
	state.useProxy = useProxy
	updateDataValue("remoteIP", remoteIP)
	updateDataValue("remotePort", remotePort)
	updateDataValue("proxyIP", proxyIP)
	updateDataValue("proxyPort", proxyPort)

	// Switch connections
	if (connType == "http" || connType == "hubaction")
	{
		if (device.currentEventSocketStatus == "connected") interfaces.webSocket.close()
		sendEvent([name: "eventSocketSource", value: "none"])
		sendEvent([name: "connectionType", value: connType])
	}
	else if (connType == "socket")
	{
		if (device.currentEventSocketStatus == "connected")
		{
			interfaces.webSocket.close()
			pauseExecution(1000)
		}
		initialize()
	}

	log.info "Switching connection to ${device.label ?: device.name} to ${connType}"
}


/*
	parse

	In a virtual world this should never be called.
*/
def parse(String description)
{
	Object eventData = (Object) null
	try
	{
		eventData = (Object) parseJson(description)
	}
	catch(errorException)
	{
		log.error "Failed to parse event data: ${errorException}"
		return
    }

	if (eventData.source == "DEVICE")
	{
		if (state.subscribedDevices.contains((int) eventData.deviceId))
		{
			eventData.isStateChange = (eventData.name == "pushed" || eventData.name ==  "held" || eventData.name == "doubleTapped" || eventData.name ==  "released") ? true : false
			parent.wsSendEvent(eventData)
		}
	}
	else if (eventData.source == "COMMAND")
	{
        parent.remoteDeviceCommand(eventData)
	}
	else if (eventData.source == "LOCATION")
	{
		if (eventData.name == "mode") parent.remoteModeChange(eventData)
		if (eventData.name == "hsmSetArm" || eventData.name == "hsmStatus") parent.remoteHSMChange(eventData)
	}
	else if (eventData.source == "PROXY")
	{
		sendEvent([name: "proxyEventsReceived", value: eventData.data.received]);
		sendEvent([name: "proxyEventsSent", value: eventData.data.sent]);
		sendEvent([name: "proxyEventsFiltered", value: eventData.data.filtered]);
		sendEvent([name: "proxyEventsDuplicate", value: eventData.data.duplicate]);
		sendEvent([name: "proxyEventsUnknown", value: eventData.data.unknown]);
		sendEvent([name: "proxyLoadRxPerSecond", value: eventData.data.rxs]);
		sendEvent([name: "proxyLoadTxPerSecond", value: eventData.data.txs]);
		sendEvent([name: "proxyJitterMS", value: eventData.data.jitter]);
		sendEvent([name: "proxyLatencyMS", value: eventData.data.latency]);
	}
	else if (eventData.source == "SYSTEM")
	{
		if (eventData.name == "appHealth")
		{
			parent.registerPing()
		}
		else if (eventData.name == "tsReportResults")
		{
			parent.registerServerTSReport(eventData.data)
		}
	}
	else if (eventData.source == "PING")
	{
		hcsSendMessage(eventData)
	}
}


/*
	on

	Enable communications from the remote hub.
*/
void on()
{
	// Make sure we're not an orphaned device
	if (checkParent() == false) return

	parent.setCommStatus(false)
	if (state.connectionType == "socket")
	{
		sendEvent([name: "eventSocketStatus", value: "connecting"])
	}
	else
	{
		sendEvent([name: "presence", value: "present"])
		sendEvent([name: "switch", value: "on"])
	}
	initialize()
}


/*
	off

	Disable communications from the remote hub.
*/
void off()
{
	// Make sure we're not an orphaned device
	if (checkParent() == false) return

	parent.setCommStatus(true)
	if (state.connectionType == "socket")
	{
		interfaces.webSocket.close()
	}
	else
	{
		sendEvent([name: "presence", value: "not present"])
		sendEvent([name: "switch", value: "off"])
	}
}


/*
	toggleSocket

	Toggles between the proxy server (if configured) and Hubitat websocket.
*/
void toggleSocket()
{
	if (state.connectionType != "socket") return
	interfaces.webSocket.close()

	if (state.useProxy) parent.systemSetCommType([type: "socket"])
	else parent.systemSetCommType([type: "proxy"])
}


/*
	pushCurrentMode

	Pushes the current mode of the server hub to the remote hub.
*/
void pushCurrentMode()
{
	// Make sure we're not an orphaned device
	if (checkParent() == false) return

	parent.pushCurrentMode()
}


/*
	updateDeviceIdList

	Updates the list of deviceIds that this hub should listen for.
*/
void updateDeviceIdList(deviceIdList)
{
    state.subscribedDevices = deviceIdList

	// Pushing the device list to the proxy server?
	if (state.useProxy && device.currentEventSocketStatus == "connected")
	{
		interfaces.webSocket.sendMessage(JsonOutput.toJson([source: "FILTER", deviceIdList: deviceIdList]))
	}
}


/*
	hcsSendMessage

	Purpose: Sends an event or device command through the websocket interface.

	Notes: 	This is only called by the parent app.
*/
void hcsSendMessage(Object data)
{
	// Send the data object as a JSON string
	interfaces.webSocket.sendMessage(JsonOutput.toJson(data))
}


/*
	checkParent

	Checks to make sure the device is associated with a HubConnect parent app.
*/
private Boolean checkParent()
{
	// Make sure we're not an orphan
	if (parent == null)
	{
		log.error "This HubConnect Remote Hub is no longer associated with HubConnect and is being disabled.  Please remove it from this hub."
		if (state?.connectionType == "socket")
		{
			interfaces.webSocket.close()
		}
		subscribedDevices = []
		state.connectionType = "DEVICE DISCONNECTED.  Please DELETE!"
		sendEvent([name: "eventSocketStatus", value: "disassociated"])
		sendEvent([name: "switch", value: "off"])
		sendEvent([name: "modeState", value: "invalid"])
		device.setDeviceNetworkId("hubconnect-orphan-${now()}")
		device.setLabel("HubConnect Disabled Hub")
		return false
	}
	return true
}
def getPref(setting) {return settings."${setting}"}
