/**
 * HubConnect Server for Hubitat
 *
 * Copyright 2019-2020 Steve White, Retail Media Concepts LLC.
 *
 * HubConnect for Hubitat is a software package created and licensed by Retail Media Concepts LLC.
 * HubConnect, along with associated elements, including but not limited to online and/or electronic documentation are
 * protected by international laws and treaties governing intellectual property rights.
 *
 * This software has been licensed to you. All rights are reserved. You may use and/or modify the software.
 * You may not sublicense or distribute this software or any modifications to third parties in any way.
 *
 * By downloading, installing, and/or executing this software you hereby agree to the terms and conditions set forth in the HubConnect license agreement.
 * <https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html>
 *
 * Hubitat is the trademark and intellectual property of Hubitat, Inc. Retail Media Concepts LLC has no formal or informal affiliations or relationships with Hubitat.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License Agreement
 * for the specific language governing permissions and limitations under the License.
 *
 */
Map getAppVersion() {[platform: "Hubitat", major: 2, minor: 0, build: 0]}

import groovy.transform.Field
import groovy.json.JsonOutput

definition(
	name: "HubConnect Server for Hubitat",
	namespace: "shackrat",
	author: "Steve White",
	description: "Synchronizes devices and events across hubs..",
	category: "My Apps",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches@2x.png",
	videoLink: "https://hubconnect.hubitatcommunity.com/HubConnect_Install_Videos/HubConnect_Server_Install/",
	documentationLink: "https://hubconnect.to/knowledgebase/1/HubConnect-2.0-Beta",
	singleInstance: true
)

// Preference pages
preferences
{
	page(name: "mainPage")
	page(name: "aboutPage")
	page(name: "customDriverPage")
	page(name: "createCustomDriver")
	page(name: "editCustomDriver")
	page(name: "customDriverManifestPage")
	page(name: "customDriverImportPage")
	page(name: "utilitesPage")
	page(name: "reportsPage")
	page(name: "modeReportPage")
	page(name: "versionReportLoadingPage")
	page(name: "versionReportPage")
	page(name: "hubUtilitiesPage")
	page(name: "tsReportPage")
	page(name: "diagnosticReportPage")
	page(name: "stubDriverPage")
	page(name: "supportPage")
	page(name: "uninstallPage")
	page(name: "restartPage")
	page(name: "resetCustomDriverPage")
	page(name: "deviceReportPage")
	page(name: "hctMyTicketsPage")
	page(name: "hctConnectPage")
}


// Map containing driver and attribute definitions for each device class
@Field static Map<String, String> ATTRIBUTE_TO_SELECTOR =
[
	"alarm":					"alarm",
	"audioVolume":				"audioVolume",
	"battery":					"battery",
	"button":					"button",
	"bulb":						"bulb",
	"carbonMonoxide":			"carbonMonoxideDetector",
	"colorMode":				"colorMode",
	"colorTemperature":			"colorTemperature",
	"contact":					"contactSensor",
	"coolingSetpoint":			"thermostatCoolingSetpoint",
	"door":						"garageDoorControl",
	"doubleTapped":				"doubleTapableButton",
	"energy":					"energyMeter",
	"heatingSetpoint":			"thermostatHeatingSetpoint",
	"held":						"holdableButton",
	"humidity":					"relativeHumidityMeasurement",
	"illuminance":				"illuminanceMeasurement",
	"level":					"switchLevel",
	"lock":						"lock",
	"motion":					"motionSensor",
	"power":					"powerMeter",
	"powerSource":				"powerSource",
	"pushed":					"pushableButton",
	"presence":					"presenceSensor",
	"refresh":					"refresh",
	"securityKeypad":			"securityKeypad",
	"shock":					"shockSensor",
	"sleepSensor":				"sleepSensor",
	"smoke":					"smokeDetector",
	"speechSynthesis":			"speechSynthesis",
	"speed":					"fanControl",
	"switch":					"switch",
	"temperature":				"temperatureMeasurement",
	"thermostat":				"thermostat",
	"thermostatFanMode":		"thermostatFanMode",
	"thermostatMode":			"thermostatMode",
	"thermostatOperatingState": "thermostatOperatingState",
	"thermostatSchedule":		"thermostatSchedule",
	"thermostatSetpoint":		"thermostatSetpoint",
	"threeAxis":				"threeAxis",
	"touch":					"touchSensor",
	"ultravioletIndex":			"ultravioletIndex",
	"valve":					"valve",
	"voltage":					"voltageMeasurement",
	"water":					"waterSensor",
	"windowshade":				"windowShade"
]


@Field static Map<String, Map> ATTRIBUTE_TO_COMMAND =
[
	"door":			["open": [], "close": []],
	"level":		["on": [], "off": [], "setLevel": ["level"]],
	"lock":			["lock": [], "unlock": []],
	"lockCodes":	["setCodeLength": ["length"], "deleteCode": ["codeNumber"], "setCode": ["codeNumber", "code", "name = null"], "getCodes": []],
	"speed":		["setSpeed": ["fanSpeed"]],
	"switch":		["on": [], "off": []]
]


// Mapping to receive events
mappings
{
	// V2 Server Mappings
	path("/oauth/callback")
	{
		action: [GET: "hctOAuthCallback"]
	}
}


/*
	mainPage

	Purpose: Displays the main (landing) page.

	Notes: 	Not very exciting.
*/
def mainPage()
{
	if (state.serverInstalled && state.installedVersion != appVersion) return upgradePage()

	// Initialize UI
	state.hubConnectToOpenTickets = null
	app.updateSetting("hubconnectto_tsrTicketSubject", [type: "string", value: ""])
	app.updateSetting("hubconnectto_tsrTicketMessage", [type: "string", value: ""])

	dynamicPage(name: "mainPage", title: app.label, uninstall: false, install: true)
	{
		if (state?.serverInstalled == null || state.serverInstalled == false)
		{
			section("<b style=\"color:green\">HubConnect Installed!</b>")
			{
				paragraph "Click <i>Done</i> to save then return to the HubConnect app to connect a remote hub."
			}
			return
		}

		section(menuHeader("Connected Hubs"))
		{
			app(name: "hubClients", appName: "HubConnect Server Instance", namespace: "shackrat", title: "Connect a Hub...", multiple: true)
		}
		section(menuHeader("Custom Drivers"))
		{
			href "customDriverPage", title: "Manage Custom Drivers", required: false
		}
		section(menuHeader("Communications"))
		{
			input "haltComms", "bool", title: "Suspend all communications between this server and all remote hubs?  (Resets at reboot)", required: false, defaultValue: false
		}
		section(menuHeader("Utilities &amp; Reports"))
		{
			href "utilitesPage", title: "HubConnect Utilites", required: false
			href "reportsPage", title: "HubConnect Reports", required: false
		}
		section(menuHeader("Support"))
		{
			href "supportPage", title: "Technical Support", description: "Get help with HubConnect, download code, or read the docs."
			if (state.hubconnectToSession) href "hctMyTicketsPage", title: "Active Support Tickets", description: "View your list of open support tickets."
			href "aboutPage", title: "Help Support HubConnect!", description: "HubConnect is provided free of charge for the benefit the Hubitat community.  If you find HubConnect to be a valuable tool, please help support the project."
			paragraph "<span style=\"font-size:.8em\">Server Container v${appVersion.major}.${appVersion.minor}.${appVersion.build} ${appCopyright}</span>"
		}
	}
}


/*
	deviceReportPage

	Purpose: Shows status of all devices on this hub

	Notes: 	Not very exciting.
*/
def deviceReportPage()
{
	if (settings?.allDevices && atomicState?.drStatus == "start")
	{
		runIn(1, "generateDeviceReport")
		atomicState.drStatus = "starting"
		atomicState.drProgress = 0
	}
	if (atomicState?.drStatus == "starting" || atomicState?.drStatus == "running")
	{
		atomicState.drProgress++
		return
		("HubConnect is generating the device report; this may take several minutes...\n\nStatus: ${atomicState?.drStatus?.capitalize()} &nbsp;${"=".multiply(atomicState.drProgress)} &gt;")
	}

	dynamicPage(name: "deviceReportPage", title: "HubConnect Device Report", uninstall: false, install: false)
	{
		if (settings?.allDevices && atomicState?.drStatus == "complete")
		{
			section(menuHeader("Device Report for: ${app.label}"))
			{
				paragraph "${state.deviceReportHTML}</tbody></table>"
				paragraph "<table><tr><td>Legend: </td><td class=\"in\">incoming</td><td>&nbsp;</td><td class=\"ot\">outgoing</td></tr></table>"
			}
			state.remove("deviceReportHTML")
			atomicState.remove("drStatus")
			atomicState.remove("drProgress")
		}
		else
		{
			section(menuHeader("Device Report"))
			{
				paragraph "Before HubConnect can run the device report, we need to know a little more about the devices on the server hub."
				paragraph "Please select the devices you want to appear in the report.  It is recommended to select all devices in the Report Configuraiton Options section."
				if (settings?.allDevices) input "drRunButton", "button", title: "Run Device Report", submitOnChange: true
			}
			section(menuHeader("Report Configuration Options"))
			{
				paragraph "You can use this handy <a href=\"http://hubconnect.hubitatcommunity.com/colorPick.html\" type=\"_blank\">Color Picker</a> to generate color codes."
				input "drInColor", "text", title: "Incoming Device Color", description: "Enter a CSS color code.", required: false, defaultValue: "red", submitOnChange: true
				input "drOutColor", "text", title: "Outgoing Device Color", description: "Enter a CSS color code.", required: false, defaultValue: "green", submitOnChange: true
				input "allDevices", "capability.*", title: "Select Devices", description: "Select devices to appear on the device report.  Selecting ALL is recommended.", multiple: true, submitOnChange: true
			}
		}
	}
}


/*
	deviceReportPage

	Purpose: Helper function to generate the HTML for the device usage report.
*/
def generateDeviceReport()
{
	atomicState?.drStatus = "running"
	String html =
"""
<script type="text/javascript">
\$(document).ready(function(){
	\$(".mdl-card").width("90%")
});
</script>
"""
	def hub = location.hubs[0]
	String serverIP = hub.getDataValue('localIP')

	html += "<style>.in{background-color:${drInColor}}.ot{background-color:${drOutColor}}.ns{background-color:#cccccc}</style><table style=\"width:100%;\" id=\"hcdr\"><tr><th>ID</th><th>Name</th>"
	List serverInstanceData = []

	// Collect all devices from remotes
	childApps.each
	{
	  child ->
		serverInstanceData << [id: child.id, label: child.label, outgoingDevices: child.getSelectedDeviceIds(), incomingDevices: child.getChildDevices()?.collect{it.id}]
		html += "<th>${child.label}</th>"
	}
	html += "</tr><tbody>"

	def d = settings?.allDevices?.sort{it.label ?: it.name}
	d.each
	{
	  dev ->
		html += "<tr><td><a href=\"/device/edit/${dev.id}\">${dev.id}</a></td><td>${dev.label ?: dev.name}</td>"

		// Compile outgoing device data
		serverInstanceData.each
		{
		  inst ->

			if (inst.outgoingDevices.find{it == dev.id.toString()}) html += "<td class=\"ot\"></td>"
			else if (inst.incomingDevices.find{it == dev.id.toString()}) html += "<td class=\"in\"></td>"
			else html += "<td class=\"ns\"></td>"
		}
		html += "</tr>"
	}
	state.deviceReportHTML = html
	atomicState.drStatus = "complete"
}


/*
	upgradePage

	Purpose: Displays the splash page to force users to initialize the app after an upgrade.
*/
def upgradePage(String installType = "Server")
{
	dynamicPage(name: "upgradePage", uninstall: false, install: true)
	{
		section(menuHeader("New Version Detected!"))
		{
			paragraph "<b style=\"color:green\">HubConnect ${installType} has detected an upgrade that has been installed...</b> <br /> Please click [Done] to complete the installation on the server and all remotes."
		}
	}
}


/*
	customDriverPage

	Purpose: Displays the page where shackrat's custom device drivers (SmartPlug, Z-Wave Repeater) are selected to be linked to the controller hub.

	Notes: 	First attempt at organization.
*/
def customDriverPage()
{
	resetDriverForm()
	dynamicPage(name: "customDriverPage", uninstall: false, install: false, nextPage: "mainPage")
	{
		section(menuHeader("Currently Installed Custom Drivers"))
		{
			state.customDrivers.each
			{
			  groupname, driver ->
				href "editCustomDriver", title: "${driver.driver} (${groupname})", description: "${driver.attr}", params: [groupname: groupname]
			}

			href "createCustomDriver", title: "Add Driver", description: "Define a custom driver type."
		}
		section(menuHeader("Import/Export"))
		{
			href "customDriverImportPage", title: "Import Driver(s)", description: "Import a custom driver manifest."
			href "customDriverManifestPage", title: "Export Driver(s)", description: "Export a custom driver manifest."
		}
		section(menuHeader("Navigation"))
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	editCustomDriver

	Purpose: Loads the custom driver details into preferences so they can be edited in the UI.

	Notes: 	This requires a page refresh in order to work properly.  Hubitat cache issue??
*/
def editCustomDriver(params = [:])
{
	if (params?.groupname)
	{
		def dtMap = state?.customDrivers[params.groupname]
		if (dtMap)
		{
			app.updateSetting("newDev_AttributeGroup", [type: "string", value: params.groupname])
			app.updateSetting("newDev_DriverName", [type: "string", value: dtMap.driver])
			state.cdFields = 0
			dtMap.attr.eachWithIndex
			{
			  attr, idx ->
				app.updateSetting("attr_${idx+1}", [type: idx == 0 ? "enum" : "string", value: attr])
				state.cdFields++
			}
		}
		params.editgroup = params.groupname
		params.groupname = null
		dynamicPage(name: "editCustomDriver", uninstall: false, install: false, refreshInterval: 1)
		{
			section("Loading, please wait..."){}
		}
	}
	else driverPage("editCustomDriver", params?.editgroup)
}


/*
	createCustomDriver

	Purpose: Displays a blank custom driver form.
*/
def createCustomDriver()
{
	driverPage("createCustomDriver")
}


/*
	driverPage

	Purpose: Displays the page where shackrat's custom device drivers (SmartPlug, Z-Wave Repeater) are selected to be linked to the controller hub.

	Notes: 	First attempt at organization.
*/
def driverPage(pageName, groupName = null)
{
	if (groupName) atomicState.cdEditGroup = groupName

	if (atomicState?.cdSaveStatus == "start")
	{
		runIn(1, "saveCustomDrivers")
		atomicState.cdSaveStatus = "starting"
	}
	if (atomicState?.cdSaveStatus == "starting" || atomicState?.cdSaveStatus == "running")
	{
		return waitPage("Please wait while custom drivers are saved...")
	}
	else if (atomicState?.cdSaveStatus == "complete") return saveCustomDriverPage([update: atomicState.cdEditGroup])

	// Make sure groupname contains only alphanumeric chars
	if (newDev_AttributeGroup?.findAll("[^A-Za-z0-9]"))
		app.updateSetting("newDev_AttributeGroup", [type: "string", value: newDev_AttributeGroup.replaceAll("[^A-Za-z0-9]", "")])

	dynamicPage(name: pageName, uninstall: false, install: false, nextPage: null)
	{
		section(menuHeader("Configure Driver"))
		{
			if (groupName) paragraph "Attribute Class Name (letters & numbers only, others will be removed):<br />${groupName}"
			else
			{
				input "newDev_AttributeGroup", "text", title: "Attribute Class Name (letters & numbers only):", required: true, defaultValue: null, submitOnChange: true, state: (state.customDrivers.find{it.key == newDev_AttributeGroup}) ? "error" : null
				if (state.customDrivers.find{it.key == newDev_AttributeGroup}) paragraph "Another driver with this class name already exists!"
			}
			if (groupName || (newDev_AttributeGroup?.length() > 0 && !state.customDrivers.find{it.key == newDev_AttributeGroup}))
				input "newDev_DriverName", "text", title: "Device Driver Name:", required: true, defaultValue: "HubConnect <replace with your name>", submitOnChange: true
		}
		if (settings.newDev_AttributeGroup?.size() > 0 && settings.newDev_DriverName?.size() > 0)
		{
			section(menuHeader("Supported Attributes"))
			{
				input "attr_1", "enum", title: "Attribute 1 (This will act as the primary capability for selecting devices):", required: true, multiple: false, options: ATTRIBUTE_TO_SELECTOR, defaultValue: null, submitOnChange: true
				if (attr_1?.size())
				{
					(state.cdFields-1).times
					{
						input "attr_"+(it+2), "string", title: "Attribute ${it+2}:", required: false, multiple: false, defaultValue: null, submitOnChange: true
					}
				}
				input "addField", "button", title: "Add Input", submitOnChange: true
			}
			if (attr_1?.size())
			{
				section(menuHeader("Actions"))
				{
					input "saveDriver", "button", title: "Save Driver", submitOnChange: true, style: "float:left;"
					if (groupName != null) input "deleteDriver", "button", title: "Delete Driver", submitOnChange: true, style: "float:right;margin-top:-52px"
				}
				if (groupName != null)
				{
					section(menuHeader("HubConnect Driver Builder (BETA)"))
					{
						href "stubDriverPage", title: "Create Hubitat Driver", description: "Create a driver to use with this custom device.",  params: [groupname: groupName]
					}
				}
			}
		}
	}
}


/*
	saveCustomDriverPage

	Purpose: Displays a confirmation page when a custom driver has been saved or deleted.
*/
def saveCustomDriverPage(params)
{
	String action = (atomicState.cdLastAction == "save" ? "saved" : "deleted")
	String resultHtml = state?.cdSaveResult?.sort()?.collect{"<li>${it.key} - ${it.value?.status?.capitalize()} ${it.value?.message ?: ""}</li>"}.join()

	atomicState.remove("cdSaveStatus")
	atomicState.remove("cdEditGroup")
	atomicState.remove("cdLastAction")
	state.remove("cdSaveResult")

	dynamicPage(name: "saveCustomDriverPage", uninstall: false, install: false, nextPage: null)
	{
		section(menuHeader("Driver ${action.capitalize()}!"))
		{
			paragraph "The driver definition has been ${action}. Synchronization results:"
			paragraph "<ul>${resultHtml}</ul>"

		}
		section()
		{
			if (action == "saved") href "stubDriverPage", title: "Create Stub Driver", description: "Create a stub driver for this device...", params: [groupname: params.update]
			href "customDriverPage", title: "Custom Drivers", description: "Manage Custom Drivers"
		}
	}
}


/*
	deleteCustomDriver

	Purpose:	Deletes the custom driver that's loaded in the form.
*/
def deleteCustomDriver(String groupName)
{
	state?.customDrivers?.remove(groupName)
	resetDriverForm()
}


/*
	saveCustomDriver

	Purpose:	Saves the custom driver form to storage.
*/
def saveCustomDriver(updateGroup = null)
{
	def deviceClass = updateGroup ?: newDev_AttributeGroup

	if (deviceClass.size() && newDev_DriverName?.size() && attr_1?.size())
	{
		def attr = []
		50.times
		{
			if (settings."attr_${it+1}"?.size())
			{
				attr << settings."attr_${it+1}"
			}
		}

		def selector = ATTRIBUTE_TO_SELECTOR.find{it.key == attr_1}?.value
		def randString = Long.toUnsignedString(new Random().nextLong(), 16).toUpperCase()
		state.customDrivers[deviceClass] =
		[
			driver: newDev_DriverName,
			selector: state.customDrivers[deviceClass]?.selector != null && (state.customDrivers[deviceClass]?.selector.substring(state.customDrivers[deviceClass]?.selector.lastIndexOf("_") + 1)) == selector ? state.customDrivers[deviceClass]?.selector : "${randString}_${selector}",
			attr: attr
		]
		resetDriverForm()
	}

	state.customDriverDBVersion = now()
}


/*
	saveCustomDrivers

	Purpose: Saves custom defined drivers to each child app instance.

	Notes: Calls like-named method in child app
*/
void saveCustomDrivers()
{
	if (enableDebug) log.debug "Saving custom drivers to instances and remotes..."
	atomicState.cdSaveStatus = "running"
	state.cdSaveResult = [:]
	childApps.each
	{
	  child ->
		state.cdSaveResult["${child.label}"] = child.saveCustomDrivers(state.customDrivers, state.customDriverDBVersion)
	}
	atomicState.cdSaveStatus = "complete"

	if (enableDebug) log.debug "Saving custom drivers is complete."
}


/*
	customDriverManifestPage

	Purpose: Creates a custom driver manifest file to export custom drivers for use on other HubConnect installations.
*/
def customDriverManifestPage()
{
	dynamicPage(name: "customDriverManifestPage", uninstall: false, install: false, nextPage: "mainPage")
	{
		if (state?.customDriverManifest == null)
		{
			section(menuHeader("Select Custom Drivers"))
			{
				paragraph "Creating a manifest allows one or more drivers to be imported automatically."
				Map customDriverOptions = (Map) [:]
				state.customDrivers.each
				{
				  groupname, driver ->
					customDriverOptions << ["${groupname}": driver.driver]
				}
				if (customDriverOptions.size() > 0)
				{
					input "manifestName", "string", title: "Manifest Name:", description: "A friendly name that users will see when importing this manifest.",  required: true, submitOnChange: true, defaultValue: null
					input "manifestAuthor", "string", title: "Author:", description: "Optional.  The name you wish to associate with this manifest.",  required: false, defaultValue: null
					input "manifestDrivers", "enum", title: "Select Custom Driver to Export:", options: customDriverOptions, multiple: true, required: false, submitOnChange: true
					if (manifestDrivers?.size() > 0) input "generateManifest", "button", title: "Create Manifest", submitOnChange: true
				}
				else paragraph "There are no custom drivers to export at this time."
			}
		}
		else
		{
			section(menuHeader("Manifest Code: ${state.customDriverManifest.name}"))
			{
				paragraph "To save, copy and paste this manifest into your favorite text editor."
				paragraph """
<textarea rows="20" style="width:100%; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New, monospace;" onclick="this.select()" onclick="this.focus()">
${JsonOutput.prettyPrint(JsonOutput.toJson(state.customDriverManifest))}
</textarea>
				"""
			}
			state.customDriverManifest = null
			app.updateSetting("manifestName", [type: "string", value: ""])
			app.updateSetting("manifestAuthor", [type: "string", value: ""])
			app.updateSetting("manifestDrivers", [type: "enum", value: ""])
		}
		section(menuHeader("Navigation"))
		{
			href "customDriverPage", title: "Custom Drivers", description: "Return to Manage Custom Drivers"
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	customDriverImportPage

	Purpose: Imports a custom driver manifest from other HubConnect installations.
*/
def customDriverImportPage()
{
	// Parse the manifest
	if (state.manifest == null && manifestCode?.size() > 0)
	{
		try
		{
			state.manifest = parseJson(manifestCode)
		}
		catch (Exception e)
		{
			log.error "Error parsing manifest: ${e.message}"
			state.manifest = [:]
			app.updateSetting("manifestCode", [type: "string", value: ""])
		}
	}
	dynamicPage(name: "customDriverImportPage", uninstall: false, install: false, nextPage: "mainPage")
	{
		// Ask for a manifest
		if (manifestCode == null && state.manifest == null)
		{
			section(menuHeader("Import Manifest from URL"))
			{
				paragraph "HubConnect will be ask you to confirm changes after the manifest has been retrieved."
				input "manifestURL", "string", title: "Manifest URL:", description: "Manifest file must have a.json extension to import.", required: false, defaultValue: null, submitOnChange: true
				input "importManifestURL", "button", title: "Import from URL", submitOnChange: true
			}
			section(menuHeader("Import Manifest from Code"))
			{
				paragraph "HubConnect will ask you to confirm before changes are saved."
				input "manifestCode", "string", title: "Manifest Code:", description: "Paste the manifest code here.",  required: false, defaultValue: null
				input "importManifest", "button", title: "Import from Code", submitOnChange: true
			}
		}

		// Parse the manifest
		if (state?.manifest?.size() > 0)
		{
			section(menuHeader("Manifest Details"))
			{
				paragraph "Name: ${state.manifest.name}\nAuthor: ${state.manifest.author}\nDrivers: ${state.manifest.exported}"
				String existsORinstalled = state.manifest.importResult ? " <b style=\"color:green\">Driver Installed!</b>" : " <b style=\"color:red\">Driver exists and will be overwritten!</b>"
				String html = ""
				state.manifest.drivers.each
				{
				  groupname, driver ->
					html += "<li>${driver.driver} (${groupname})" + (state.customDrivers.find{it.key == groupname} ? existsORinstalled : "") + "</li>"
				}
				paragraph "<ul>" + html + "</ul>"

				if (state.manifest?.importResult)
				{
					paragraph "These drivers have been successfully imported!"
					state.remove("manifest")
					app.removeSetting("manifestCode")
					app.removeSetting("manifestURL")
				}
				else
				{
					input "confirmManifestImport", "button", title: "Save Drivers", submitOnChange: true
					input "cancelManifestImport", "button", title: "Cancel Import", submitOnChange: true
				}
			}
		}
		section(menuHeader("Navigation"))
		{
			href "customDriverPage", title: "Custom Drivers", description: "Return to Manage Custom Drivers"
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	resetDriverForm

	Purpose: Clears out all preferences so the UI page displays as if it were new.
*/
void resetDriverForm()
{
	app.updateSetting("newDev_AttributeGroup", [type: "string", value: ""])
	app.updateSetting("newDev_DriverName", [type: "string", value: ""])
	app.updateSetting("attr_1", [type: "enum", value: ""])
	50.times
	{
		app.removeSetting("attr_${it+2}")
	}

	// Driver builder
	app.updateSetting("hdbCapability_actuator", [type: "bool", value: false])
	app.updateSetting("hdbCapability_battery", [type: "bool", value: false])
	app.updateSetting("hdbCapability_initialize", [type: "bool", value: false])
	app.updateSetting("hdbCapability_refresh", [type: "bool", value: false])
	app.updateSetting("hdbCapability_lockCodes", [type: "bool", value: false])
	app.updateSetting("hdbCapability_sensor", [type: "bool", value: false])
	app.updateSetting("hdbAttribute_lastCodeName", [type: "bool", value: false])
	app.removeSetting("hdbAuthor_name")
	app.removeSetting("hdbAuthor_copyright")
	state.cdFields = 1
}


/*
	installed

	Purpose: Standard install function.

	Notes: Doesn't do much.
*/
void installed()
{
	log.info "${app.name} Installed"

	initializeCustomDriverStorage()

	state.serverInstalled = true
	state.installedVersion = appVersion

	initialize()
}


/*
	updated

	Purpose: Standard update function.

	Notes: Still doesn't do much.
*/
void updated()
{
	log.info "${app.name} Updated"

	initializeCustomDriverStorage()

	if (state?.serverInstalled == null)
	{
		state.serverInstalled = true
	}

	unsubscribe()
	initialize()

	// Upgrade the system if necessary
	if (state.installedVersion != appVersion)
	{
		log.info "An upgrade has been detected...  Updating the HubConnect system..."
		childApps.each
		{
		  child ->
			log.info "Running updated() on ${child.label}..."
			child.updated()
		}
	}

	state.installedVersion = appVersion
}


/*
	uninstalled

	Purpose: Standard uninstall function.

	Notes: Tries to clean up just in case Hubitat misses something.
*/
void uninstalled()
{
	log.info "HubConnect server has been uninstalled."

	childApps.each
	{
	  child ->
		child.updateSetting("removeDevices", [type: "bool", value: true])
		child.uninstalled() // Just in case
		app.deleteChildApp(child.id)
	}
}


/*
	initialize

	Purpose: Initialize the server.

	Notes: Subscribes to the systemStart event to synchronize modes.
*/
void initialize()
{
	log.info "${app.name} Initialized"

	childApps.each
	{
	  child ->
		log.debug "Found server instance: ${child.label}"
	}

	// Cleanup infrequently used state vars
	state.remove("versionReport")
	state.remove("versionReportStatus")
	state.remove("customDriverManifest")
	state.remove("currentVersions")
	state.remove("restartStatus")
	state.remove("lastTSRTicket")
	state.remove("hubConnectToOpenTickets")
	state.remove("utilityStatus")

	state.remove("deviceReportHTML")
	atomicState.remove("drStatus")
	atomicState.remove("drProgress")

	state.remove("tsRreport")
	atomicState.remove("tsStatus")
	atomicState.remove("tsProgress")

	state.remove("cdFields")
	atomicState.remove("cdSaveStatus")
	atomicState.remove("cdEditGroup")
	atomicState.remove("cdLastAction")

	app.removeSetting("manifestCode")
	app.removeSetting("manifestURL")
	state.remove("manifest")

	subscribe(location, "systemStart", systemStartEventHandler)
}


/*
	initializeCustomDriverStorage

	Purpose: Helper function to initialize or reset custom driver storage.
*/
void initializeCustomDriverStorage(Boolean reset = false)
{
	if (!state?.customDrivers || reset)
	{
		state.customDrivers = [:]
		state.customDriverDBVersion = now()
		saveCustomDrivers() // Push changes to hubs
	}
	else if (!state?.customDriverDBVersion) state.customDriverDBVersion = now()
}


/*
	systemStartEventHandler

	Purpose: Event handler for the systemStart event.

	Notes: May do some cleanup in the future, but for now just schedules a mode sync.
*/
void systemStartEventHandler(evt)
{
	app.updateSetting("haltComms",[type: "bool", value: false])
	childApps.each
	{
	  child ->
		child.setCommStatus(false)
		log.debug "System Start: Restoring communications to remote instance: ${child.label}..."
	}

	// Push out a mode sync in 20 seconds, after other automations have a chance to determine the correct mode
	runIn(20, "pushSystemMode")
}


/*
	pushSystemMode

	Purpose: Pushes the current system mode to all remote hubs.

	Notes: Calls pushCurrentMode() in each server instance.
*/
void pushSystemMode()
{
	log.debug "System Start: Synchronizing modes across all hubs..."
	childApps.each
	{
	  child ->
		child.pushCurrentMode()
	}
}


/*
	hsmSetState

	Purpose: Sets the HSM state for each child instance to <state>.

	Notes: Calls realtimeHSMChangeHandler with a "fake" event.
*/
void setHSMState(String hsmState, appId)
{
	log.debug "Setting HSM state across all hubs to ${hsmState}..."
	childApps.each
	{
	  child ->
		if (child.id != appId) child.realtimeHSMChangeHandler([value: hsmState, data: 0])
	}
}


/*
	hsmSendAlert

	Purpose: Pushes an HSM alert to all remotes.

	Notes: Calls pushCurrentMode() in each server instance.
*/
void hsmSendAlert(String hsmAlertText, appId)
{
	log.debug "Sending HSM alert state across all hubs to ${hsmState}..."
	childApps.each
	{
	  child ->
		if (child.id != appId) child.realtimeHSMChangeHandler([value: hsmState, data: 0])
	}
}


/*
	remoteHubControl

	Purpose: Helper function to power off/reboot the remote hub.

	Notes: Supported remote commands: reboot, shutdown
*/
void remoteHubControl(child, String command)
{
	String port = child.remoteType == "homebridge" ? ":20009" : ""
	Map requestParams =
	[
		uri:  "http://${child.clientIP}${port}/hub/${command}",
		requestContentType: "text/html",
		body: []
	]

	httpPost(requestParams)
	{
	  response ->
		if (response?.status != 200)
		{
			log.error "httpPost() request failed with error ${response?.status}"
		}
	}
}


/*
	utilitiesPage

	Purpose: Displays a menu of utilities.
*/
def utilitesPage(params)
{
	if (params?.debug != null)
	{
		childApps.each
		{
		  child ->
			child.updateSetting("enableDebug", [type: "bool", value: params.debug])
			log.debug "${params.debug ? "Enabling" : "Disabling"} debug logging on ${child.label}"
		}
	}
	dynamicPage(name: "utilitesPage", title: "HubConnect Utilites", uninstall: false, install: false)
	{
		section(menuHeader("Utilites"))
		{
			href "hubUtilitiesPage", title: "Remote Hub Utilities", description: "Shutdown/reboot hubs on the same LAN..."
			href "resetCustomDriverPage", title: "Reset Custom Drivers", description: "Reset and re-initialize the custom defined device driver system..."
			href "restartPage", title: "Restart HubConnect", description: "Restart all HubConnect drivers and services..."
		}
	   	section(menuHeader("Master Debug Control"))
	   	{
	   		if (params?.debug != null) paragraph "Debug has been ${params.debug ? "enabled" : "disabled"} for all hubs."
	   		href "utilitesPage", title: "Enable debug logging for all instances?", description: "Click to enable", params: [debug: true]
	   		href "utilitesPage", title: "Disable debug logging for all instances?", description: "Click to disable",  params: [debug: false]
	   	}
	   	section(menuHeader("Uninstall HubConnect"))
	   	{
			href "uninstallPage", title: "Uninstall HubConnect from this hub.", description: "", state: null
		}
		section()
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
		state.utilityStatus = ""
		params = [:]
	}
}


/*
	resetCustomDriverPage

	Purpose: Confirms reset of custom drivers.
*/
def resetCustomDriverPage()
{
	dynamicPage(name: "resetCustomDriverPage", title: "Reset Custom Drivers", uninstall: false, install: false)
	{
		if (state.utilityStatus != "") section(menuHeader("Reset Status")) { paragraph "${state.utilityStatus}" }
		else
		{
			section(menuHeader("Reset Custom Drivers"))
			{
				paragraph "This will DELETE all custom driver definitions from all hubs.\nIt will NOT remove any virtual devices that have been shared."
				input "resetCustomDrivers", "button", title: "Reset Custom Drivers", submitOnChange: false
			}
		}
		section()
		{
			href "utilitesPage", title: "Utilities", description: "Return to Utilities menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
		state.utilityStatus = ""
	}
}


/*
	reportsPage

	Purpose: Displays a menu of reports.
*/
def reportsPage(Map params)
{
	atomicState.versionReportStatus = null
	dynamicPage(name: "reportsPage", title: "HubConnect Reports", uninstall: false, install: false)
	{
		section(menuHeader("Reports"))
		{
			href "deviceReportPage", title: "Device Usage Report", description: "A grid of all devices on this hub and their usage in HubConnect...", required: false
			href "modeReportPage", title: "System Mode Report", description: "Lists all modes configured on each remote hub..."
			href "versionReportLoadingPage", title: "App & Driver Version Report", description: "Displays all app and driver versions configured on each hub...  (May be slow to load)"
			href "tsReportPage", title: "Technical Support Report", description: "Export HubConnect configuration data for technical support."
		}
		section()
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	modeReportPage

	Purpose: Displays a report of configured system modes.
*/
def modeReportPage()
{
	// Query all children for modes
	Map allModes = (Map) [:]

	allModes[0] = [label: "Server Hub", modes: location.modes.collect{it?.name}.sort().join(", "), active: location.mode, pushModes: "-", receiveModes: "-"]
	childApps.each
	{
	  child ->
		Object remoteModes = [:]
		if (child.getAppHealthStatus() == "online")
		{
			remoteModes = child.getAllRemoteModes()
			allModes[child.id] = [label: child.label, modes: remoteModes?.status == "error" ? ["<span style=\"color:red\">error</span>"] : remoteModes?.modes.collect{it?.name}.sort().join(", "), active: remoteModes?.active, pushModes: child.pushModes, receiveModes: child.receiveModes]
		}
		else allModes[child.id] = [label: child.label, modes: "", active: false, pushModes: child.pushModes, receiveModes: child.receiveModes]
	}

	dynamicPage(name: "modeReportPage", title: "System Mode Report", uninstall: false, install: false)
	{
		section(menuHeader("Modes"))
		{
			String html = "<table style=\"width:100%\"><thead><tr><th>Hub</th><th>Active</th><th>TX</th><th>RX</th><th>Configured Modes</th></tr></thead><tbody>"
			allModes.each
			{
			  k, v->
				html += "<tr><td>${v?.label}</td><td>${v?.active}</td><td>${v.pushModes}</td><td>${v.receiveModes}</td><td>${v?.modes}</td></tr>"
			}
			paragraph "${html}</tbody></table>"
			paragraph "TX = Send Mode Change to Remote"
			paragraph "RX = Receive Mode Change from Remote"
		}
		section(menuHeader("Navigation"))
		{
			href "reportsPage", title: "Reports", description: "Return to Reports menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	getVersionReportData

	Purpose: Queries all hubs for current app & driver version data.
*/
def getVersionReportData()
{
	// Get the latest available versions
	versionCheck()

	// Server hub apps & drivers
	Map serverDrivers = (Map) [:]
	childApps.each
	{
  	  child ->
		child.getChildDevices()?.each
		{
		  device ->
			if (serverDrivers[device.typeName] == null) serverDrivers[device.typeName] = device.getDriverVersion()
		}
	}

	Map allHubs = (Map) [:]
	allHubs[0] = [name: "Server Hub", report: [apps: [[appName: app.label, appVersion: appVersion], [appName: childApps?.first()?.name, appVersion: childApps?.first()?.getAppVersion()]], drivers: serverDrivers]]

	// Remote hubs apps & drivers
	childApps.each
	{
	  child ->
		if (child.getAppHealthStatus() == "online")
		{
			atomicState.versionReportStatus = "Gathering report data for ${child.label}..."

			Object report = (Object) child.getAllVersions()
   			if (report != null && (report.apps != "" || report.drivers != ""))
			{
				allHubs[child.id] = [name: child.label, report: report]
			}
		}
		else allHubs[child.id] = [name: child.label, report: [drivers:[], apps: []]]
	}
	state.versionReport = allHubs
	atomicState.versionReportStatus = "Checking for latest versions..."

	// This is to allow another 5 seconds for the version check to complete...  It should never be needed!
	Integer lp = 0
	while (atomicState.currentVersions == null)
	{
		pauseExecution(1000)
		if (++lp > 5) break
	}

	atomicState.versionReportStatus = "Rendering..."
}


/*
	versionReportLoadingPage

	Purpose: Displays loading page while data is pulled from hubs.
*/
def versionReportLoadingPage()
{
	if (atomicState.versionReportStatus == null)
	{
		atomicState.versionReportStatus = "Gathering report data for for Server Hub..."
		runIn(1, "getVersionReportData")
	}
	else if (atomicState.versionReportStatus == "Rendering...") return versionReportPage()

	dynamicPage(name: "versionReportLoadingPage", title: "Loading system version report...", uninstall: false, install: false, refreshInterval: 1)
	{
		section()
		{
			paragraph "${atomicState.versionReportStatus}"
		}
	}
}


/*
	versionReportPage

	Purpose: Displays a report of app & driver versions.
*/
def versionReportPage()
{
	atomicState.versionReportStatus = null
	dynamicPage(name: "versionReportPage", title: "System Version Report", uninstall: false, install: false)
	{
		state.versionReport.each
		{
		  k, v ->
			section(menuHeader("${v?.name}"))
			{
				if (v?.report == null)
				{
					paragraph "Hub is not reachable or remote client is not reporting version information."
					return
				}
				String html = "<table style=\"width:100%\"><thead><tr><th style=\"width:46%\">Component</th><th style=\"width:10%\">Type</th><th style=\"width:16%\">Platform</th><th style=\"width:14%\">Installed</th><th style=\"width:14%\">Latest</th></tr></thead><tbody>"
				v?.report?.apps?.sort()?.each
				{
					def latest = (it?.appVersion?.platform != null && state?.currentVersions != null) ? atomicState.currentVersions?.(it.appVersion.platform.toLowerCase())?.app?.(it.appName) : [:]
					String latestVersion = latest ?  "<span style=\"color:${isNewer(latest, it?.appVersion) ? "red" : "green"}\">${latest.major}.${latest.minor}.${latest.build}</span>" : ""
					String currentVersion = latest ?  "<span style=\"color:${isNewer(latest, it?.appVersion) ? "red" : "black"}\">${it?.appVersion?.major}.${it?.appVersion?.minor}.${it?.appVersion?.build}</span>" : ""
					html += "<tr><td>${it?.appName}</td><td>app</td><td>${it?.appVersion?.platform}</td><td>${currentVersion}</td><td>${latestVersion}</td></tr>"
				}
				v?.report?.drivers?.sort()?.each
				{
				  dk, dv ->
					def latest = (dv?.platform != null && state?.currentVersions != null) ? atomicState?.currentVersions?.(dv?.platform?.toLowerCase())?.driver?.(dk?.toString()) : [:]
					String latestVersion = latest ?  "<span style=\"color:${isNewer(latest, dv) ? "red" : "green"}\">${latest.major}.${latest?.minor}.${latest?.build}</span>" : ""
					String currentVersion = latest ?  "<span style=\"color:${isNewer(latest, dv) ? "red" : "black"}\">${dv?.major}.${dv?.minor}.${dv?.build}</span>" : ""
					html += "<tr><td>${dk}</td><td>driver</td><td>${dv?.platform}</td><td>${currentVersion}</td><td>${latestVersion}</td></tr>"
				}
				paragraph "${html}</tbody></table>"
			}
		}
		section()
		{
			paragraph "Note: The version report can only report on drivers that are currently in use by HubConnect devices."
			href "versionReportLoadingPage", title: "Refresh", description: "Refresh this report with the latest data...  (May be slow to load)"
		}
		section()
		{
			href "reportsPage", title: "Utilities", description: "Return to Reports menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
		state.remove("versionReport")
	}
}


/*
	restartPage

	Purpose: Restarts HubConnect services.
*/
def restartPage()
{
	dynamicPage(name: "restartPage", title: "Restart HubConnect Services", uninstall: false, install: false)
	{
		if (state.utilityStatus != "") section(menuHeader("Restart Status")) { paragraph "${state.utilityStatus}" }
		else
		{
			section(menuHeader("Restart All Services"))
			{
				input "restartAllServices", "button", title: "Restart All", submitOnChange: false
			}
			section(menuHeader("Restart Services on Select Hubs"))
			{
				childApps.each
				{
			  	  child ->
					if (child.getState()?.connectStatus == "offline")
					{
						paragraph "${child.label} is offline and cannot be controlled."
					}
					else if (child.remoteType != "homebridge")
					{
						input "restart_${child.id}", "button", title: "${child.label}", submitOnChange: false, params: [t: now()]
					}
					else paragraph "${child.label} cannot be remotely restarted."
				}
			}
		}
		section(menuHeader("Navigation"))
		{
			href "utilitesPage", title: "Utilities", description: "Return to Utilities menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
		state.utilityStatus = ""
	}
}


/*
	hubUtilitiesPage

	Purpose: Reboots a remote hub that is on the same LAN.
*/
def hubUtilitiesPage()
{
	// Rebooting or shutting down a hub?
	childApps.each
	{
	  child ->
		if (settings."reboot_${child.id}" == true)
		{
			log.warn "Sending the reboot command to ${child.label}."
			app.updateSetting("reboot_${child.id}",[type: "bool", value: false])
			remoteHubControl(child, "reboot")
		}
		else if (settings."shutdown_${child.id}" == true)
		{
			log.warn "Sending the shutdown command to ${child.label}."
			app.updateSetting("shutdown_${child.id}",[type: "bool", value: false])
			remoteHubControl(child, "shutdown")
		}
	}

	dynamicPage(name: "hubUtilitiesPage", title: "Remote Hub Utilities", uninstall: false, install: false)
	{
		section()
		{
			paragraph "<b>All commands take effect immediately!</b>"
		}

		childApps.each
		{
		  child ->
			section(menuHeader("${child.label}"))
			{
				if (child.remoteType == "local" || child.remoteType == "homebridge")
				{
					input "reboot_${child.id}", "bool", title: "Reboot this hub?", required: false, defaultValue: false, submitOnChange: true
					if (child.remoteType == "local") input "shutdown_${child.id}", "bool", title: "Shutdown this hub?", required: false, defaultValue: false, submitOnChange: true
				}
				else paragraph "This is a remote hub and cannot be controlled."
			}
		}
		section(menuHeader("Navigation"))
		{
			href "utilitesPage", title: "Utilities", description: "Return to Utilities menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	tsReportPage

	Purpose: Landing Page for diagnosticReportPage.
*/
def tsReportPage()
{
	// Report already running?
	if (atomicState?.tsStatus) return diagnosticReportPage()

	// Get all open tickets if connected
	if (state.hubconnectToSession && state.hubConnectToOpenTickets == null)
	{
		Map ticketQuery = hubconnectToAPI([action: "GetTickets"])
		if (ticketQuery.result == "success" && ticketQuery.numreturned > 0)
		{
			state.hubConnectToOpenTickets = [:]
			ticketQuery.tickets?.ticket?.each { state.hubConnectToOpenTickets << ["${it.id}": it.subject] }
		}
	}

	dynamicPage(name: "tsReportPage", title: "Technical Support Report", uninstall: false, install: false)
	{
		section(menuHeader("Generate a Report"))
		{
			paragraph "This report will contain specific technical information about your HubConnect installation."
			if (state?.hubconnectToSession)
			{
				input "hubconnectto_tsrTicket", "bool", title: "Open a support ticket and send this report to HubConnect support?", required: false, defaultValue: false, submitOnChange: true
			}
			else app.updateSetting("hubconnectto_tsrTicket",[type: "bool", value: false])

			if (hubconnectto_tsrTicket)
			{
				if (state.hubConnectToOpenTickets?.size() > 0) input "hubconnectto_useTicket", "enum", title: "Select an Existing Ticket", options: state.hubConnectToOpenTickets, required: false, submitOnChange: true
				if (hubconnectto_useTicket == null) input "hubconnectto_tsrTicketSubject", "text", title: "Subject", description: "Enter a brief summary of this request...", required: true, submitOnChange: true
				if (hubconnectto_useTicket != null || hubconnectto_tsrTicketSubject != null)
				{
					input "hubconnectto_tsrTicketMessage", "text", title: "Message", description: "Enter a message to HubConnect support...", required: true, submitOnChange: true
					if (hubconnectto_tsrTicketMessage) input "tsRunButton", "button", title: "Run Technical Support Report", submitOnChange: true
				}
			}
			else input "tsRunButton", "button", title: "Run Technical Support Report", submitOnChange: true
		}
		section(menuHeader("Navigation"))
		{
			href "reportsPage", title: "Utilities", description: "Return to Reports menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	diagnosticReportPage

	Purpose: Displays the diagnostic data for support.
*/
def diagnosticReportPage()
{
	if (atomicState?.tsStatus == "start")
	{
		runIn(1, "generateDiagnosticReport")
		atomicState.tsStatus = "starting"
		atomicState.tsProgress = 0
	}
	if (atomicState?.tsStatus == "starting" || atomicState?.tsStatus == "running")
	{
		atomicState.tsProgress++
		return waitPage("HubConnect is generating the technical support report; this may take several minutes...\n\nStatus: ${atomicState?.tsStatus?.capitalize()} &nbsp;${"=".multiply(atomicState.tsProgress)} &gt;")
	}

	// Send this report to HubConnect.to
	Map ticketResponse = (Map) [:]
	if (state?.hubconnectToSession && hubconnectto_tsrTicket)
	{
		ticketResponse = hubconnectToOpenTSR(hubconnectto_tsrTicketSubject, hubconnectto_tsrTicketMessage, state.tsRreport)
	}

	dynamicPage(name: "diagnosticReportPage", title: "Technical Support Report", uninstall: false, install: false)
	{
		if (ticketResponse?.result == "success")
		{
			section(menuHeader("Your HubConnect Report..."))
			{
				paragraph "<b style=\"color:green\">Support ticket #<a href=\"https://hubconnect.to/viewticket.php?tid=${ticketResponse.tid}&c=${ticketResponse.c}\">${ticketResponse.tid}</a> has been opened!</b>"
			}
		}
		section(menuHeader("Your HubConnect Report..."))
		{
			paragraph "This report contains specific technical information about your HubConnect installation.\nPlease share via e-mail or private message (PM) only. Do not post this report to a public forum!"
			paragraph state.tsRreport

			// Clean up immediately
			state.remove("tsRreport")
			atomicState.remove("tsStatus")
			atomicState.remove("tsProgress")
		}
		section(menuHeader("Navigation"))
		{
			href "reportsPage", title: "Reports", description: "Return to Reports menu..."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	generateDiagnosticReport

	Purpose: Creates diagnostic data report for support.
*/
def generateDiagnosticReport()
{
	log.trace "Technical Support Report is Running..."

	atomicState?.tsStatus = "running"
	String textAreaOpen = (String) """
<textarea rows="20" style="width:100%; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New, monospace;" onclick="this.select()" onclick="this.focus()">
"""

	String hcTopology = (String) """
HubConnect Technical System Report
Created on ${new Date(now()).format("MM-dd-yyyy HH:mm Z", location.timeZone)}

${"=".multiply(32)} HubConnect Server ${"=".multiply(33)}
appId: ${app.id}
appVersion: ${appVersion.toString()}
installedVersion: ${state?.installedVersion}
remoteClients: ${childApps?.size()}

---------- Hub ----------
hardwareID: ${location?.hubs[0]?.data?.hardwareID}
firmwareVersion: ${location?.hubs[0]?.firmwareVersionString}
localIP: ${location?.hubs[0]?.data?.localIP}

-------- Topology -------

HubConnect Server
"""
	String tsReport = (String) """

--------- Modes ---------
activeMode: ${location.mode}
definedModes: ${location.modes}

---------- HSM ----------
activeState: ${location.hsmStatus ?: "Not Installed"}
definedStates: [armAway, armHome, armNight, disarm, armRules, disarmRules, disarmAll, armAll, cancelAlerts]

${"=".multiply(80)}

"""
	childApps.each
	{
	  child ->

		log.trace "Generating TSR for ${child.label}"
		String hubName = child.label.replaceAll("<(.|\n)*?>|(Online|Offline|Warning)", '')

		def modeReport = child.getAllRemoteModes()
		pauseExecution(1000) 	// ST needs requests to be spaced out

		def hsmReport = child.getAllRemoteHSMStates()
		pauseExecution(1000)	// ST needs requests to be spaced out

		Map remoteTSR = child.getRemoteTSReport()
		com.hubitat.app.DeviceWrapper remoteHub = child.getHubDevice()

		// Query the first child using the HubConnect server for a TSR
		if (child.useProxy && atomicState.proxyTSR == null)
		{
			child.getHubDevice()?.hcsSendMessage([source: "SYSTEM", name: "getTSReport"])
			atomicState.proxyTSR = "loading"
		}

		hcTopology += "\t|\n\t+---${hubName}(${child?.localConnectionType ?: "http"})\n"
		tsReport +=
"""
${"=".multiply(35-(hubName.length()/2))} ${hubName} (Instance) ${"=".multiply(35-(hubName.length()/2))}
appId: ${child.id}
appVersion: ${child.getAppVersion()?.toString()}
installedVersion: ${child.getState()?.installedVersion}

-------- Prefs ----------
pushModes: ${child?.pushModes}
receiveModes: ${child?.receiveModes}
pushHSM: ${child?.pushHSM}
receiveHSM: ${child?.receiveHSM}
enableDebug: ${child?.enableDebug}

-------- Status ---------
appHealth: ${child.getState()?.connectStatus}
commDisabled: ${child.getState()?.commDisabled}

-------- Comms ----------
remoteType: ${child?.remoteType}
localConnectionType: ${child?.localConnectionType}
clientURI: ${child.getState()?.clientURI}
connectionKey: ${child.getConnectString()}

-------- Inbound Devices --------
incomingDevices: ${child.getChildDevices()?.size()-1}
deviceIdList: ${child.getState()?.deviceIdList}

------ Virtual Hub ------
-Attributes-
deviceStatus: ${remoteHub == null ? "Not Installed" : "Installed"}
connectionType: ${remoteHub?.currentValue("connectionType")}
eventSocketStatus: ${remoteHub?.currentValue("eventSocketStatus")}
hsmStatus: ${remoteHub?.currentValue("hsmStatus")}
modeStatus: ${remoteHub?.currentValue("modeStatus")}
presence: ${remoteHub?.currentValue("presence")}
switch: ${remoteHub?.currentValue("switch")}
version: ${remoteHub?.currentValue("version")}

-State-
subscribedDevices: ${remoteHub?.getState()?.subscribedDevices}
connectionAttempts: ${remoteHub?.getState()?.connectionAttempts}

-Preferences-
refreshSocket: ${remoteHub?.getPref("refreshSocket")}
refreshHour: ${remoteHub?.getPref("refreshHour")}
refreshMinute: ${remoteHub?.getPref("refreshMinute")}

---- Custom Drivers -----
customDrivers: ${remoteHub?.getState()?.customDrivers?.toString()}

${"=".multiply(80)}


${"=".multiply(35-(hubName.length()/2))} ${hubName} (Remote) ${"=".multiply(35-(hubName.length()/2))}
appId: ${remoteTSR?.app?.appId}
appVersion: ${remoteTSR?.app?.appVersion}
installedVersion: ${remoteTSR?.app?.installedVersion}

---------- Hub ----------
hardwareID: ${remoteTSR?.hub?.hardwareID}
firmwareVersion: ${remoteTSR?.hub?.firmwareVersion}
localIP: ${remoteTSR?.hub?.localIP}

-------- Prefs ----------
pushModes: ${remoteTSR?.prefs?.pushModes}
pushHSM: ${remoteTSR?.prefs?.pushHSM}
enableDebug: ${remoteTSR?.prefs?.enableDebug}

-------- Status ---------
commDisabled: ${remoteTSR?.state?.commDisabled}

-------- Comms ----------
connectionType: ${remoteTSR?.state?.connectionType}
clientURI: ${remoteTSR?.state?.clientURI}
serverKey: ${remoteTSR?.prefs?.serverKey}

-------- Incoming Devices --------
incomingDevices: ${remoteTSR?.devices?.incomingDevices}
deviceIdList: ${remoteTSR?.devices?.deviceIdList}

--------- Modes ---------
activeMode: ${modeReport?.active}
definedModes: ${modeReport?.modes?.name?.toString()}

---------- HSM ----------
activeState: ${hsmReport?.hsmStatus ?: "Not Installed"}
definedStates: ${hsmReport?.hsmSetArm}

------ Virtual Hub ------
-Attributes-
deviceStatus: ${remoteTSR?.hub?.deviceStatus}
connectionType: ${remoteTSR?.hub?.connectionType}
eventSocketStatus: ${remoteTSR?.hub?.eventSocketStatus}
hsmStatus: ${remoteTSR?.hub?.hsmStatus}
modeStatus: ${remoteTSR?.hub?.modeStatus}
presence: ${remoteTSR?.hub?.presence}
switch: ${remoteTSR?.hub?.switch}
version: ${remoteTSR?.hub?.version}

-State-
subscribedDevices: ${remoteTSR?.hub?.subscribedDevices}
connectionAttempts: ${remoteTSR?.hub?.connectionAttempts}

-Preferences-
refreshSocket: ${remoteTSR?.hub?.refreshSocket}
refreshHour: ${remoteTSR?.hub?.refreshHour}
refreshMinute: ${remoteTSR?.hub?.refreshMinute}

---- Custom Drivers -----
customDrivers: ${remoteTSR?.state?.customDrivers}

${"=".multiply(80)}
"""
	}

	// Proxy report
	String proxyTsReport = ""
	if (atomicState?.proxyTSR)
	{
		proxyTsReport =
"""
${"=".multiply(31)} HubConnect Server ${"=".multiply(31)}
appVersion: ${atomicState?.proxyTSR?.appVersion}

---- Config ----
${atomicState.proxyTSR?.config ?  JsonOutput.prettyPrint(JsonOutput.toJson(atomicState.proxyTSR.config)) : ""}

${"=".multiply(80)}
"""
		atomicState.remove("proxyTSR")
	}

	state.tsRreport = textAreaOpen + hcTopology + tsReport + proxyTsReport + "</textarea>"
	atomicState.tsStatus = "complete"

	log.trace "Technical Support Report is Complete..."
}


/*
	stubDriverPage

	Purpose: Displays a stub driver for a custom driver.
*/
def stubDriverPage(Map params)
{
	Map dtMap = state?.customDrivers[(params?.groupname ?: state.dbGroup)]
	String attributes = (String) ""
	if (dtMap != null)
	{
		dtMap.attr.eachWithIndex
		{
		  attr, idx ->
			if (idx > 0 && attr != null) attributes += "\t\tattribute \"${attr.toString()}\", \"string\"\n"
		}
		state.dbGroup = (params?.groupname ?: state.dbGroup)
	}

	String commands = ""
	ATTRIBUTE_TO_COMMAND.find{attr -> attr.key == dtMap.attr[0]}.each
	{
	   command ->
		command.value.each{cmd ->
			commands += (String) "\n/*\n\t${cmd.key.toString().replaceAll("\\(.*?\\)","")}\n*/\ndef ${cmd.key}(${cmd.value.join(', ')})\n{\n\t// The server will update status\n\tparent.sendDeviceEvent(device.deviceNetworkId, \"${cmd.key.toString()}\"" + ((cmd.value.size() > 0) ? ", ${cmd.value.toString().replaceAll(" = null", "")}" : "") + ")\n}\n\n"
		}
	}
	String extraCapabilities = "" +
		(hdbCapability_actuator ? "\t\tcapability \"Actuator\"\n" : "") +
		(hdbCapability_battery ? "\t\tcapability \"Battery\"\n" : "") +
		(hdbCapability_initialize ? "\t\tcapability \"Initialize\"\n" : "") +
		(hdbCapability_refresh ? "\t\tcapability \"Refresh\"\n" : "") +
		(hdbCapability_lockCodes ? "\t\tcapability \"Lock Codes\"\n" : "") +
		(hdbCapability_sensor ? "\t\tcapability \"Sensor\"\n" : "")

	String extraAttributes =  "" +
		(hdbAttribute_lastCodeName ? "\t\tattribute \"lastCodeName\", \"string\"\n" : "")

	dynamicPage(name: "stubDriverPage", title: "HubConnect Driver Builder (BETA)", uninstall: false, install: false, nextPage: "customDriverPage")
	{
		if (params?.groupname == null && dtMap == null)
		{
			section()
			{
				paragraph "Error: The custom driver could not be located!"
			}
		}
		else
		{
			section(menuHeader("Driver Code"))
			{
				paragraph "Create a new driver on each hub where this device will be used, paste the code into the editor, then click save..."
				paragraph "" +
"""
<textarea rows="20" wrap="off" style="width:100%; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New, monospace;" onclick="this.select()" onclick="this.focus()">
/*
 *	${hdbAuthor_copyright ?: "Copyright 2019-2020"} ${hdbAuthor_name ?: "Steve White, Retail Media Concepts LLC"}.
 *
 *	Licensed under the Apache License, Version 2.0 (the "License"); you may not
 *	use this file except in compliance with the License. You may obtain a copy
 *	of the License at:
 *
 *		http://www.apache.org/licenses/LICENSE-2.0
 *
 *	Unless required by applicable law or agreed to in writing, software
 *	distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 *	WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 *	License for the specific language governing permissions and limitations
 *	under the License.
 *
 */
def getDriverVersion() {[platform: "Universal", major: 2, minor: 0, build: 0]}

metadata
{
	definition(name: "${dtMap.driver}", namespace: "shackrat", author: "Steve White")
	{
		capability "${ATTRIBUTE_TO_SELECTOR.find{it.key == dtMap.attr[0]}.value.capitalize()}"
${extraCapabilities}

		// Autogenerated attributes
${attributes}
		attribute "version", "string"
${extraAttributes}
		command "sync"
	}
}


/*
	installed
*/
def installed()
{
	initialize()
}


/*
	updated
*/
def updated()
{
	initialize()
}


/*
	initialize
*/
def initialize()
{
	refresh()
}


/*
	uninstalled

	Reports to the remote that this device is being uninstalled.
*/
def uninstalled()
{
	// Report
	parent?.sendDeviceEvent(device.deviceNetworkId, "uninstalled")
}


/*
	refresh
*/
def refresh()
{
	// The server will update status
	parent.sendDeviceEvent(device.deviceNetworkId, "refresh")
}

${commands}
/*
	sync
*/
def sync()
{
	// The server will respond with updated status and details
	parent.syncDevice(device.deviceNetworkId, "${(params?.groupname ?: state.dbGroup)}")
	sendEvent([name: "version", value: "v\${driverVersion.major}.\${driverVersion.minor}.\${driverVersion.build}"])
}
</textarea>
"""
				paragraph "Disclaimer: This driver builder is considered to be a beta-level feature.\nThe code generated may not work in all instances."
				paragraph "Please help improve this tool by <a href=\"https://community.hubitat.com/t/release-hubconnect-share-devices-across-multiple-hubs-even-smartthings/12028/1601\" target=\"_blank\">reporting</a> any issues with the code generated."
			}
			section(menuHeader("Customize Driver Code"))
			{
				input "hdbCapability_actuator", "bool", title: "Add Actuator capability?", required: false, defaultValue: false, submitOnChange: true
				input "hdbCapability_battery", "bool", title: "Add Battery capability?", required: false, defaultValue: false, submitOnChange: true
				input "hdbCapability_initialize", "bool", title: "Add Initialize capability?", required: false, defaultValue: false, submitOnChange: true
				input "hdbCapability_refresh", "bool", title: "Add Refresh capability?", required: false, defaultValue: false, submitOnChange: true
				input "hdbCapability_sensor", "bool", title: "Add Sensor capability?", required: false, defaultValue: false, submitOnChange: true
				if (dtMap?.attr[0] == "lock") input "hdbCapability_lockCodes", "bool", title: "Add Lock Codes capability?", required: false, defaultValue: false, submitOnChange: true
				if (dtMap?.attr[0] == "lock") input "hdbAttribute_lastCodeName", "bool", title: "Add lastCodeName attribute?", required: false, defaultValue: false, submitOnChange: true
			}
			section(menuHeader("Author Information (Optional)"))
			{
				input "hdbAuthor_name", "text", title: "Author Name", required: false, submitOnChange: true
				input "hdbAuthor_copyright", "text", title: "Copyright", required: false, submitOnChange: true
			}
			section(menuHeader("Navigation"))
			{
				href "customDriverPage", title: "Custom Drivers", description: "Manage Custom Drivers"
				href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
			}
		}
	}
}


/*
	supportPage

	Purpose: Displays the technical support page.
*/
def supportPage()
{
	dynamicPage(name: "supportPage", title: "HubConnect v${appVersion.major}.${appVersion.minor} Technical Support", uninstall: false, install: false)
	{
		section(menuHeader("Get Help"))
		{
			href "hctConnectPage", title: "HubConnect.to Support Website", description: state?.hubconnectToSession ? "Connected to HubConnect.to" : "Connect to the HubConnect Official Support Website", state: state?.hubconnectToSession ? "complete" : null
			href "hubitat", style:"external", title: "Get help with HubConnect!", description: "Post a question in the discussion thread at the Hubitat community. (hubitat.com)", url: "https://community.hubitat.com/t/release-hubconnect-share-devices-across-multiple-hubs-even-smartthings/"
		}
		section(menuHeader("Documentation"))
		{
			href "install", style:"external", title: "HubConnect Installation Instructions", description: "Read the installation instructions (github.com).", url: "https://github.com/HubitatCommunity/HubConnect/blob/master/HubConnect%20Installation%20Instructions.pdf"
			href "upgrade", style:"external", title: "HubConnect v1.5 Upgrade Instructions", description: "Read the upgrade instructions (github.com).", url: "https://github.com/HubitatCommunity/HubConnect/blob/master/HubConnect%20v1.5%20Upgrade%20Instructions.pdf"
		}
		section(menuHeader("How-to Videos by @csteele"))
		{
			href "client", style:"external", title: "HubConnect Server Installation", description: "Watch the step-by-step installation of the HubConnect server app (hubitatcommunity.com).", url: "http://hubconnect.hubitatcommunity.com/HubConnect_Install_Videos/HubConnect_Server_Install/index.html"
			href "server", style:"external", title: "HubConnect Remote Client Installation", description: "Watch the step-by-step installation of the HubConnect server app (hubitatcommunity.com).", url: "http://hubconnect.hubitatcommunity.com/HubConnect_Install_Videos/HubConnect_Remote_Install/index.html"
		}
		section(menuHeader("Technical Stuff"))
		{
			href "attributes", style:"external", title: "HubConnect Supported Attributes", description: "A list of supported attributes by device type (github.com).", url: "https://github.com/HubitatCommunity/HubConnect/blob/master/HubConnect%20Attributes.pdf"
			href "importurls", style:"external", title: "HubConnect Code URLs", description: "A list of HubConnect source code URL's (hubitatcommunity.com).", url: "http://hubconnect.hubitatcommunity.com/import.php"
		}
		section()
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	hubconnectToOpenTSR

	Purpose: Sends a technical support report to the HubConnect.to website.
*/
def hubconnectToOpenTSR(String subject, String message, String tsReport)
{
	if (state?.hubconnectToSession == null) return [result: "Not logged in"]
	Integer useTicket = settings?.hubconnectto_useTicket ?: 0
	Map requestParams =
	[
		action: useTicket ? "AddTicketReply" : "OpenTicket",
		subject: subject?.length() > 5 ? subject : "HubConnect Technical Support Report",
		message: message
	]

	if (useTicket > 0) requestParams << [ticketid: useTicket]
	if (tsReport.length() > 10)
	{
		requestParams <<
		[
			attachments: JsonOutput.toJson([[name: "HubConnect_TSR.txt", data: tsReport.bytes.encodeBase64().toString()]]).toString().bytes.encodeBase64()
		]
	}

	// Open the ticket or add the reply
	def ticketData = hubconnectToAPI(requestParams)
	if (ticketData?.result == "success") state.lastTSRTicket = ticketData
	else state.lastTSRTicket = null
}


/*
	hubconnectToAPI

	Purpose: Makes an HTTP POST call to the HubConnect.to website.
*/
def hubconnectToAPI(data)
{
	state.hubConnectToOpenTickets = null
	Map requestParams =
	[
		uri:  "http://hubconnect.to/api.php",
		body:
		[
			access_token: state.hubconnectToSession.access_token,
			id: state.hubconnectToSession.client,
			uid: state.hubconnectToSession.uid,
			responsetype: "json"
		] + data,
		timeout: 10
	]

	Map result = (Map) [:]
	try
	{
		httpPost(requestParams)
		{
		  response ->

			if (response?.status == 200)
			{
				result = response.data
			}
			else
			{
				log.error "httpPost() request failed with error ${response?.status}"
				result = [result: "error", message: "http error ${response?.status}."]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpPostJson() failed with error ${e.message}"
		return [status: "error", message: e.message]
	}
	result
}


/*
	hctConnectPage

	Purpose: Displays the HubConnect website connect page.

*/
def hctConnectPage()
{
	if (state.localAccessToken == null)
	{
		try
		{
			state.localAccessToken = createAccessToken()
		}
		catch (errorException)
		{
			log.error "oAuth is disabled for this app.  Please enable it in the apps source code page."
		}
	}

	if (state.localAccessToken != null) state.oAuthState = UUID.randomUUID().toString()

	// Build the oAuth Request
	Map oauthRequestParams =
	[
		client_id: "HUBCONNECT-APPS.qMWrEiYEVA5J1XlC1oJyDA==",
		response_type: "code",
		scope: "openid profile email",
		state: state.oAuthState,
		redirect_uri: getFullApiServerUrl() + "/oauth/callback?access_token=${state.localAccessToken}"
	]
	def oAuthQS = queryString(oauthRequestParams)

	dynamicPage(name: "hctConnectPage", title: "HubConnect Technical Support Registration", uninstall: false, install: false)
	{
		section(menuHeader("HubConnect Support"))
		{
			paragraph "HubConnect.to is the official technical support website for HubConnect.  It offers personalized, one-on-one technical support for users of the HubConnect software."
			href "attributes", style:"external", title: "HubConnect.to Website", description: "The official support website for HubConnect (hubconnect.to).", url: "https://hubconnect.to"
		}
		section(menuHeader("Get Connected!"))
		{
			paragraph "Connecting this server to the HubConnect website allows for the automatic submission of technical support reports from within the HubConnect app. This means no more copying and pasting into forum posts!"
			if (state.localAccessToken == null)
			{
				paragraph "<b style=\"color:red\">Error: oAuth is disabled!  Please enable oAuth in the app's source code page to continue.</b>"
			}
			else
			{
				if (state.hubconnectToSession == null)
				{
					href "getAuth", style:"external", title: "Connect", description: "Connect to the HubConnect Server", url: "https://hubconnect.to/oauth/authorize.php?${oAuthQS}"
					href "registerPage", title: "Don't have an account?", description: "Register for your HubConnect.to account.", url: "https://hubconnect.to/register.php"
				}
				else
				{
					paragraph "<b style=\"color:green\">You are connected to HubConnect.to support!</b>"
					input "logOff", "button", title: "Disconnect", submitOnChange: true
				}
			}
		}
		section()
		{
			href "supportPage", title: "Technical Support", description: "Return to the technical support menu."
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	hctOAuthCallback

	Purpose: Receives the callback following a request for authorization.

	URL Format: (GET) /oauth/callback

	Notes: Called from HTTP request from the HubConnect.to website.
*/
def hctOAuthCallback()
{
	// Match the security token (random UUID) before accepting the callback
	if (params.state == state.oAuthState)
	{
		// Build the oAuth Response
		// Scope defines the capabilities that this Remote Client supports
		Map oauthResponseParams =
		[
			grant_type: "authorization_code",
			client_id: "HUBCONNECT-APPS.qMWrEiYEVA5J1XlC1oJyDA==",
			client_secret: "OlPuSa+0L9tfuM6LXaoBnJAAEeYcTHY/MgaRPm3AGQtf+zk5sl2oEPr1s2ZXIv3fRMV2NANCRFCGIDM3XpBm0A==",
			code: params.code,
			redirect_uri: getFullApiServerUrl() + "/oauth/callback?access_token=${state.localAccessToken}"
		]

		Map requestParams =
		[
			uri:  "https://hubconnect.to/oauth/token.php",
			contentType: "application/json",
			body: oauthResponseParams,
			timeout: 15
		]

		// Complete the handshake by requesting the access token
		try
		{
			httpPost(requestParams)
			{
			  response ->
				if (response?.status == 200 && response.data)
				{
					state.hubconnectToSession =
					[
						access_token:	response.data.access_token, // A token that can be sent to the API.
						id_token:		response.data.id_token,		// JWT that contains identity information.
						expires_in:		response.data.expires_in, 	// The remaining lifetime of the access token.
						token_type:		response.data.token_type,
						code: 			params.code
					]
				}
				else
				{
					log.error "httpPostJson() request failed with error ${response?.status}"

					// Force a new token to be generated on failure
					state.localAccessToken = null
				}
			}
		}
		catch (Exception e)
		{
			log.error "httpPostJson() failed with error ${e.message}"

			// Force a new token to be generated on failure
			state.localAccessToken = null
		}

		// Finally, get the users UID to store for future use
		if (state.localAccessToken)
		{
			// Get the UID
			requestParams =
			[
				uri:  "https://hubconnect.to/api.php",
				contentType: "application/json",
				body:
				[
					action: "getUID",
					access_token: state.hubconnectToSession.access_token
				],
				timeout: 10
			]

			try
			{
				httpPost(requestParams)
				{
				  response ->
					if (response?.status == 200 && response.data)
					{
						if (response.data.result == "success")
						{
							state.hubconnectToSession.client = response.data.client
							state.hubconnectToSession.uid = response.data.uid
						}
					}
					else
					{
						log.error "httpPost() request failed with error ${response?.status}"
					}
				}
			}
			catch (Exception e)
			{
				log.error "httpPost() UID failed with error ${e.message}"
			}
			if (state.hubconnectToSession.uid) htmlDialog("Successfully connected to your HubConnect.to support account!")
			else htmlDialog("Could not locate your HubConnect.to account!")
		}
		else
		{
			htmlDialog("ERROR: Could not connect HubConnect.to support account!")
		}
	}
}


/*
	htmlDialog

	Purpose: Displays a lightweight html webpage.
*/
def htmlDialog(String dialogMessage)
{
	// Generate a lightweight HTML page
	render contentType: "text/html", data: """
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Menu</title>
    <meta name="theme-color" content="#ffffff">
    <style>
		* {box-sizing: border-box}
        @font-face {
          font-family: 'hubitat';
          src:  url('/ui2/css/fonts/hubitat.eot?roox2j');
          src:  url('/ui2/css/fonts/hubitat.eot?roox2j#iefix') format('embedded-opentype'),
            url('/ui2/css/fonts/hubitat.woff2?roox2j') format('woff2'),
            url('/ui2/css/fonts/hubitat.ttf?roox2j') format('truetype'),
            url('/ui2/css/fonts/hubitat.woff?roox2j') format('woff'),
            url('/ui2/css/fonts/hubitat.svg?roox2j#hubitat') format('svg');
          font-weight: normal;
          font-style: normal;
          font-display: block;
        }
		.dialogMsg {
			width: 100%;
			padding: 50px;
			text-align: center;
			font-size: 1.2em;
		}
		.dialogMsg img {vertical-align: middle;}
		.dialogMsg input {font-size:1.2em}
    </style>
</head>
<body>
	<div class="dialogMsg">
		<img src="https://cdn.shopify.com/s/files/1/2575/8806/t/20/assets/logo-image-file.png" alt="Hubitat logo" />
	</div>
	<div class="dialogMsg">
		${dialogMessage}
	</div>
	<div class="dialogMsg">
		<form action="javascript:window.close()" method="get">
			<input type="submit" name="submit" value="Close Window" />
		</form>
	</div>
</body>
</html>
"""
}


/*
	hctMyTicketsPage

	Purpose: Displays the HubConnect.to support tickets page.
*/
def hctMyTicketsPage()
{
	dynamicPage(name: "hctMyTicketsPage", title: "My Support Tickets", uninstall: false, install: false)
	{
		if (state.hubconnectToSession == null)
		{
			section(menuHeader("HubConnect.to"))
			{
				paragraph "HubConnect offers personalized, one-on-one technical support for users of the HubConnect software.\nRegistering allows for the submission support tickets from within HubConnect server."
				href "hctConnectPage", title: "Connect to HubConnect.to", description: "Connect this HubConnect Server to our support website."
			}
		}
		else
		{
			section(menuHeader("My Tickets"))
			{
				// Get all open tickets
				def ticketQuery = hubconnectToAPI([action: "GetTickets"])
				if (ticketQuery.result == "success" && ticketQuery.numreturned > 0)
				{
					ticketQuery.tickets?.ticket?.each
					{
					 href "mainPage", title: "${it.subject} (${it.status})", description: "Last reply on ${it.lastreply}.", url: "https://hubconnect.to/viewticket.php?tid=${it.tid}&c=${it.c}", state: it.status == "Answered" ? "complete" : null
					}
				}
			}

		}
		section()
		{
			href "hubconnectto", style:"external", title: "HubConnect.to", description: "Visit the HubConnect website.", url: "http://hubconnect.to/"
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
		}
	}
}


/*
	aboutPage

	Purpose: Displays the about page with credits.
*/
def aboutPage()
{
	dynamicPage(name: "aboutPage", title: "HubConnect v${appVersion.major}.${appVersion.minor}", uninstall: false, install: false)
	{
		section()
		{
			paragraph "HubConnect is provided free for personal and non-commercial use.  Countless hours went into the development and testing of this project.  If you like it and would like to see it succeed, or see more apps like this in the future, please consider making a small donation to the cause."
			href "donate", style:"embedded", title: "Please consider making a \$20 or \$40 donation to show your support!", image: "http://irisusers.com/hubitat/hubconnect/donate-icon.png", url: "https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=T63P46UYH2TJC&source=url"
		}
		section()
		{
			href "mainPage", title: "Home", description: "Return to HubConnect main menu..."
			paragraph "<span style=\"font-size:.8em\">Server Container  v${appVersion.major}.${appVersion.minor}.${appVersion.build} ${appCopyright}</span>"
		}
	}
}


/*
	uninstallPage

	Purpose: Displays options for removing an instance.

	Notes: 	Really should create a proper token exchange someday.
*/
def uninstallPage()
{
	dynamicPage(name: "uninstallPage", title: "Uninstall HubConnect", uninstall: true, install: false)
	{
		section(menuHeader("Warning!"))
		{
			paragraph "It is strongly recommended to back up your hub before proceeding.\n\nThis will remove ALL HubConnect instances and devices from this hub!!!\n\nThis action cannot be undone!\n\nClick the [Remove] button below completely remove HubConnect."
		}
		section(menuHeader("Options"))
		{
			input "removeDevices", "bool", title: "Remove virtual HubConnect shadow devices on this hub?", required: false, defaultValue: true, submitOnChange: true
		}
		section()
		{
			href "mainPage", title: "Cancel and return to the main menu..", description: "", state: null
		}
	}
}


/*
	appButtonHandler

	Purpose: Handles button events for various pages.
*/
def appButtonHandler(String btnPressed)
{
	switch(btnPressed)
	{
		// Restart all hub services
		case "restartAllServices":
			childApps.each
			{
		  	  child ->
				if (child.getState()?.connectStatus != "offline" && child.remoteType != "homebridge")
				{
					log.warn "Re-initializing ${child.label}..."
					child.initialize()
					if (child.remoteInitialize()?.status == "success")
						state.utilityStatus += "${child.label} reinitialized\n"
					else state.utilityStatus += "ERROR: ${child.label} could not be reinitialized\n"
				}
				else log.warn "Could not restart services on ${child.label} because the hub is offline or does not support the command..."
			}
			break

		case "resetCustomDrivers":
			initializeCustomDriverStorage(true)
			log.info "Custom driver system has been reset."
			state.utilityStatus = "Custom driver definitions have been reset!"
			break;

		case "addField":
			if (state.cdFields++ > 50) state.cdFields = 50
			break

		// Disconnect from HubConnect.to
		case "logOff":
			state.localAccessToken = null
			state.hubconnectToSession = null
			break;

		// Custom manifest creation
		case "generateManifest":
			state.customDriverManifest =
			[
				name: manifestName,
				author: manifestAuthor,
				exported: manifestDrivers.size(),
				drivers: [:]
			]
			manifestDrivers.each
			{
			  groupname ->
				state.customDriverManifest.drivers << state.customDrivers.find{it.key == groupname}
			}
			break

		// Load a manifest file from a website
		case "importManifestURL":
			try
			{
				httpGet([uri:  settings.manifestURL, timeout: 10])
				{
				  response ->
					if (response?.status == 200) state.manifest = response.data
					else log.warn "httpGet() request failed with status ${response?.status}"
				}
			}
			catch (Exception e)
			{
				log.error "httpGet() failed with error ${e.message}"
			}
			break

		// Save the drivers imported from the manifest
		case "confirmManifestImport":
			state.customDrivers.putAll(state.manifest.drivers)
			state.manifest.importResult = "imported"
			break

		// Cancel import
		case "cancelManifestImport":
			app.removeSetting("manifestCode")
			app.removeSetting("manifestURL")
			state.remove("manifest")
			break

		// Device report RUN button
		case "drRunButton":
			atomicState.drStatus = "start"
			break

		// TS report RUN button
		case "tsRunButton":
			atomicState.tsStatus = "start"
			break

		// Save custom driver
		case "saveDriver":
			if (atomicState?.cdEditGroup) saveCustomDriver(atomicState.cdEditGroup)
			else
			{
				saveCustomDriver()
				atomicState.cdEditGroup = newDev_AttributeGroup
			}
			atomicState.cdLastAction = "save"
			atomicState.cdSaveStatus = "start"
			break

		// Delete custom driver
		case "deleteDriver":
			if (atomicState?.cdEditGroup) deleteCustomDriver(atomicState.cdEditGroup)

			atomicState.cdLastAction = "delete"
			atomicState.cdSaveStatus = "start"
			break
	}


	// Individual hub service restarts
	if (btnPressed.startsWith("restart_"))
	{
		def appId = btnPressed.replace("restart_", "")
		def child = childApps?.find{it.id == Integer.parseInt(appId)}
		if (child != null)
		{
			log.warn "Re-initializing ${child.label}..."
			child.initialize()
			if (child.remoteInitialize()?.status == "success")
				state.utilityStatus += "${child.label} reinitialized\n"
			else state.utilityStatus += "ERROR: ${child.label} could not be reinitialized\n"
		}
	}
}


/*
	httpGetWithReturn

	Purpose: Helper function to format GET requests with the proper oAuth token.

	Notes: 	Command is absolute and must begin with '/'
			Returns JSON Map if successful.
*/
def httpGetWithReturn(command)
{
	Map requestParams =
	[
		uri:  command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		timeout: 10
	]

	try
	{
		httpGet(requestParams)
		{
	  	  response ->
			if (response?.status == 200)
			{
				return response.data
			}
			else
			{
				log.warn "httpGet() request failed with status ${response?.status}"
				return [status: "error", message: "httpGet() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpGet() failed with error ${e.message}"
		return [status: "error", message: e.message]
	}
}


/*
	registerServerTSReport

	Purpose: Saves a TSR received from the server to state.
*/
def registerServerTSReport(Map eventData)
{
	atomicState.proxyTSR = eventData
}


/*
	checkIP

	Purpose: Checks to see if the IP is in use by another connection.
*/
def checkIP(String ipAddress)
{
	def child = getChildApps().each{}.find{it?.getPref("clientIP") == ipAddress && it.getPref("remoteType") != "homebridge"}
	return [name: child.label, id: child.id] ?: (location?.hubs[0]?.data?.localIP == ipAddress) ? [name: "Server Hub", id: 0] : null
}


/*
	waitPage

	Purpose: Displays a please wait splash page to get around Hubitat UI caching.
*/
def waitPage(String dialogMessage = "HubConnect is reconfiguring...")
{
	dynamicPage(name: "waitPage", uninstall: false, install: false, refreshInterval: 1)
	{
		section(menuHeader("Please wait..."))
		{
			paragraph dialogMessage
		}
	}
}


/*
	versionCheck

	Purpose: Fetches the latest available module versions.
*/
def versionCheck()
{
	atomicState.currentVersions = null
	String token = URLEncoder.encode(location.hubs[0].toString())

	Map requestParams =
	[
		uri: "http://irisusers.com/hubitat/hubconnect/latest.php?s=${token}",
		requestContentType: 'application/json',
		contentType: 'application/json',
		timeout: 10
	]

	try
	{
		asynchttpGet("versionCheckResponse", requestParams)
	}
	catch (Exception e)
	{
		log.error "asynchttpGet() failed with error ${e.message}"
	}
}


/*
	versionCheckResponse

	Purpose: Stores the retreived version information to state.
*/
void versionCheckResponse(response, data)
{
	if (response?.status == 200 && response.json.versions != null)
	{
		atomicState.currentVersions = response.json.versions
	}
}


/*
	ssdpDiscoverHubs

	Purpose:	Initiates the discovery of Hubitat hubs.  (ST hubs do not respond to discovery messages)
*/
void ssdpDiscoverHubs()
{
	if (logDebug) log.debug "Initiating hub discovery..."

	atomicState.hubDiscoveryStatus = "running"
	atomicState.discoveredHubs = [:]

	subscribe(location, "ssdpTerm.urn:Hubitat:device:hub:1", ssdpDiscoveryHandler)
	sendHubCommand(new hubitat.device.HubAction("lan discovery urn:Hubitat:device:hub:1", hubitat.device.Protocol.LAN))

	runIn(5, "ssdpStopHubDiscovery")
}


/*
	ssdpStopHubDiscovery

	Purpose:	Stops the SSDP search for Hubiat hubs by unsubscribing to location events.
*/
void ssdpStopHubDiscovery()
{
	atomicState.hubDiscoveryStatus = "complete"
	unsubscribe(location, "ssdpTerm.urn:Hubitat:device:hub:1")
}


/*
	ssdpDiscoverHubs

	Purpose:	Processes hub discovery events
*/
@Field static java.util.concurrent.Semaphore mutex = new java.util.concurrent.Semaphore(1)
def ssdpDiscoveryHandler(event)
{
	// Tokenize the lan message, then parse it into a Map.
	String[] parsedData = event.description.toString().split(", ")
    Map<String, String> ssdpData = (Map) [:]
    parsedData.each
    {
		String[] parts = it.split(":")
        if (parts?.size() < 2) return // Shouldn't happen
		ssdpData["${parts[0]}"] = parts[1]
    }

    if (ssdpData.ssdpPath == "/api/hubitat.xml")
    {
		// Implement a mutex so as to not stomp on atomicState
		mutex.acquire()
    	Map discoveredHubs = (Map) atomicState.discoveredHubs
   		if (ssdpData.mac != null) discoveredHubs["${ssdpData.networkAddress}"] = [name: ssdpData.ssdpNTS, mac: ssdpData.mac]
		atomicState.discoveredHubs = discoveredHubs
		mutex.release()
    }
}


/*
	getDiscoveredHubs

	Purpose:	Returns the results of the last hub discovery.
*/
Map getDiscoveredHubs()
{
	while (atomicState.hubDiscoveryStatus == "running") pauseExecution(250)
	state.discoveredHubs
}


/*
	Hub Discovery Helper Methods
*/
private Boolean isHubDiscoveryRunning() { (atomicState.hubDiscoveryStatus == "running" ? true : false) }
private String convertHexToIP(hex) { return [convertHexToInt(hex[0..1]),convertHexToInt(hex[2..3]),convertHexToInt(hex[4..5]),convertHexToInt(hex[6..7])].join(".")}
private Integer convertHexToInt(hex) { return Integer.parseInt(hex,16) }
private List getAllConnectedHubs() { getChildApps().collect{it?.getPref("clientIP")} }


String menuHeader(titleText){"<div style=\"width:102%;background-color:#696969;color:white;padding:4px;font-weight: bold;box-shadow: 1px 2px 2px #bababa;margin-left: -10px\">${titleText}</div>"}
String queryString(Map m) { m.collect { k, v -> "${k}=${URLEncoder.encode(v.toString())}" }.sort().join("&") }
Boolean isNewer(latest, installed) { (latest.major.toInteger() > installed.major ||  (latest.major.toInteger() == installed.major && latest.minor.toInteger() > installed.minor) || (latest.major.toInteger() == installed.major && latest.minor.toInteger() == installed.minor && latest.build.toInteger() > installed.build)) ? true : false }
String getAppCopyright(){"&copy; 2019-2020 Steve White, Retail Media Concepts LLC <a href=\"https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html\" target=\"_blank\">HubConnect License Agreement</a>"}
