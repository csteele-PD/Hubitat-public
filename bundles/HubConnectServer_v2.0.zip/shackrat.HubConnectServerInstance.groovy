/**
 * HubConnect Server Instance
 *
 * Copyright 2019-2020 Steve White, Retail Media Concepts LLC.
 *
 * HubConnect for Hubitat is a software package created and licensed by Retail Media Concepts LLC.
 * HubConnect, along with associated elements, including but not limited to online and/or electronic documentation are
 * protected by international laws and treaties governing intellectual property rights.
 *
 * This software has been licensed to you. All rights are reserved. You may use and/or modify the software.
 * You may not sublicense or distribute this software or any modifications to third parties in any way.
 *
 * By downloading, installing, and/or executing this software you hereby agree to the terms and conditions set forth in the HubConnect license agreement.
 * <https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html>
 *
 * Hubitat is the trademark and intellectual property of Hubitat, Inc. Retail Media Concepts LLC has no formal or informal affiliations or relationships with Hubitat.
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License Agreement
 * for the specific language governing permissions and limitations under the License.
 *
 */
Map getAppVersion() {[platform: "Hubitat", major: 2, minor: 0, build: 0]}

import groovy.transform.Field
import groovy.json.JsonOutput

definition(
	name: "HubConnect Server Instance",
	namespace: "shackrat",
	author: "Steve White",
	description: "Synchronizes devices and events across multiple hubs..",
	category: "My Apps",
	parent: "shackrat:HubConnect Server for Hubitat",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/App-BigButtonsAndSwitches@2x.png",
	videoLink: "https://hubconnect.hubitatcommunity.com/HubConnect_Install_Videos/HubConnect_Server_Install/",
	documentationLink: "https://hubconnect.to/knowledgebase/1/HubConnect-2.0-Beta"
)


// Preference pages
preferences
{
	page(name: "mainPage")
	page(name: "connectPage")
	page(name: "devicePage")
	page(name: "customDevicePage")
	page(name: "dynamicDevicePage")
	page(name: "uninstallPage")
	page(name: "resyncAllDevicesPage")
	page(name: "hubSearchPage")
	page(name: "resetPage")
}


// Map containing driver and attribute definitions for each device class
@Field static Map<String, Map> NATIVE_DEVICES =
[
	"arlocamera":		[driver: "Arlo Camera", displayName: "Arlo Pro Cameras", platform: "SmartThings", selector: "arloProCameras", capability: "device.ArloProCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arloqcamera":		[driver: "Arlo Camera", displayName: "Arlo Q Cameras", platform: "SmartThings", selector: "arloQCameras", capability: "device.ArloQCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arlogocamera":		[driver: "Arlo Camera", displayName: "Arlo Go Cameras", platform: "SmartThings", selector: "arloGoCameras", capability: "device.ArloGoCamera", prefGroup: "smartthings", type: "attr", attr: ["switch", "motion", "sound", "rssi", "battery"]],
	"arrival":			[driver: "Arrival Sensor", selector: "smartThingsArrival", capability: "presenceSensor", prefGroup: "presence", type: "attr", attr: ["presence", "battery", "tone"]],
	"audioVolume":		[driver: "AVR", selector: "audioVolume", capability: "audioVolume", prefGroup: "audio", type: "attr", attr: ["switch", "mediaInputSource", "mute", "volume"]],
	"bulb":				[driver: "Bulb", selector: "genericBulbs", capability: "changeLevel", prefGroup: "lighting", type: "attr", attr: ["switch", "level"]],
	"button":			[driver: "Button", selector: "genericButtons", capability: "pushableButton", prefGroup: "other", type: "attr", attr: ["numberOfButtons", "pushed", "held", "doubleTapped", "button", "temperature", "battery"]],
	"contact":			[driver: "Contact Sensor", selector: "genericContacts", capability: "contactSensor", prefGroup: "sensors", type: "attr", attr: ["contact", "temperature", "battery"]],
	"dimmer":			[driver: "Dimmer", selector: "genericDimmers", capability: "switchLevel", prefGroup: "lighting", type: "attr", attr: ["switch", "level"]],
	"domemotion":		[driver: "DomeMotion Sensor", selector: "domeMotions", capability: "motionSensor", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "illuminance", "battery"]],
	"energy":			[driver: "Energy Meter", selector: "energyMeters", capability: "energyMeter", prefGroup: "power", type: "attr", attr: ["energy"]],
	"energyplug":		[driver: "DomeAeon Plug", selector: "energyPlugs", capability: "energyMeter", prefGroup: "lighting", type: "attr", attr: ["switch", "power", "voltage", "current", "energy", "acceleration"]],
	"fancontrol":		[driver: "Fan Controller", selector: "fanControl", capability: "fanControl", prefGroup: "fans", type: "attr", attr: ["speed"]],
	"fanspeed":			[driver: "FanSpeed Controller", selector: "fanSpeedControl", capability: "fanControl", prefGroup: "fans", type: "attr", attr: ["speed"]],
	"garagedoor":		[driver: "Garage Door", selector: "garageDoors", capability: "garageDoorControl", prefGroup: "other", type: "attr", attr: ["door", "contact"]],
	"irissmartplug":	[driver: "Iris SmartPlug", selector: "smartPlugs", capability: "switch", prefGroup: "shackrat", type: "synth", attr: ["switch", "power", "voltage", "ACFrequency"]],
	"irisv3motion":		[driver: "Iris IL071 Motion Sensor", selector: "irisV3Motions", capability: "motionSensor", prefGroup: "shackrat", type: "synth", attr: ["motion", "temperature", "humidity", "battery"]],
	"keypad":			[driver: "Keypad", selector: "genericKeypads", capability: "securityKeypad", prefGroup: "safety", type: "attr", attr: ["motion", "temperature", "battery", "tamper", "alarm", "lastCodeName"]],
	"lock":				[driver: "Lock", selector: "genericLocks", capability: "lock", prefGroup: "safety", type: "attr", attr: ["lock", "lockCodes", "lastCodeName", "codeChanged", "codeLength", "maxCodes", "battery"]],
	"mobileApp":		[driver: "Mobile App", selector: "mobileApp", capability: "notification", prefGroup: "presence", type: "attr", attr: ["presence", "notificationText"]],
	"moisture":			[driver: "Moisture Sensor", selector: "genericMoistures", capability: "waterSensor", prefGroup: "safety", type: "attr", attr: ["water", "temperature", "battery"]],
	"motion":			[driver: "Motion Sensor", selector: "genericMotions", capability: "motionSensor", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "battery"]],
	"motionswitch":		[driver: "Motion Switch", selector: "genericMotionSwitches", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch", "motion"]],
	"multipurpose":		[driver: "Multipurpose Sensor", selector: "genericMultipurposes", capability: "accelerationSensor", prefGroup: "sensors", type: "attr", attr: ["contact", "temperature", "battery", "acceleration", "threeAxis"]],
	"netatmowxbase":	[driver: "Netatmo Community Basestation", selector: "netatmoWxBasetations", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "pressure", "carbonDioxide", "soundPressureLevel", "sound", "min_temp", "max_temp", "temp_trend", "pressure_trend"]],
	"netatmowxmodule":	[driver: "Netatmo Community Additional Module", selector: "netatmoWxModule", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "carbonDioxide", "min_temp", "max_temp", "temp_trend", "battery"]],
	"netatmowxoutdoor":	[driver: "Netatmo Community Outdoor Module", selector: "netatmoWxOutdoor", capability: "relativeHumidityMeasurement", prefGroup: "netatmowx", type: "synth", attr: ["temperature", "humidity", "min_temp", "max_temp", "temp_trend", "battery"]],
	"netatmowxrain":	[driver: "Netatmo Community Rain", selector: "netatmoWxRain", capability: "sensor", prefGroup: "netatmowx", type: "synth", attr: ["rain", "rainSumHour", "rainSumDay", "units", "battery"]],
	"netatmowxwind":	[driver: "Netatmo Community Wind", selector: "netatmoWxWind", capability: "sensor", prefGroup: "netatmowx", type: "synth", attr: ["WindStrength", "WindAngle", "GustStrength", "GustAngle", "max_wind_str", "date_max_wind_str", "units", "battery"]],
	"omnipurpose":		[driver: "Omnipurpose Sensor", selector: "genericOmnipurposes", capability: "relativeHumidityMeasurement", prefGroup: "sensors", type: "attr", attr: ["motion", "temperature", "humidity", "illuminance", "ultravioletIndex", "tamper", "battery"]],
	"pocketsocket":		[driver: "Pocket Socket", selector: "pocketSockets", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch", "power"]],
	"power":			[driver: "Power Meter", selector: "powerMeters", capability: "powerMeter", prefGroup: "power", type: "attr", attr: ["power"]],
	"presence":			[driver: "Presence Sensor", selector: "genericPresences", capability: "presenceSensor", prefGroup: "presence", type: "attr", attr: ["presence", "battery"]],
	"ringdoorbell":		[driver: "Ring Doorbell", selector: "ringDoorbellPros", capability: "device.RingDoorbellPro", prefGroup: "smartthings", type: "attr", attr: ["numberOfButtons", "pushed", "motion"]],
	"rgbbulb":			[driver: "RGB Bulb", selector: "genericRGBs", capability: "colorControl", prefGroup: "lighting", type: "attr", attr: ["switch", "level", "hue", "saturation", "RGB", "color", "colorMode", "colorTemperature"]],
	"rgbwbulb":			[driver: "RGBW Bulb", selector: "genericRGBW", capability: "colorMode", prefGroup: "lighting", type: "attr", attr: ["switch", "level", "hue", "saturation", "RGB(w)", "color", "colorMode", "colorTemperature"]],
	"shock":			[driver: "Shock Sensor", selector: "genericShocks", capability: "shockSensor", prefGroup: "sensors", type: "attr", attr: ["shock", "battery"]],
	"siren":			[driver: "Siren", selector: "genericSirens", capability: "alarm", prefGroup: "safety", type: "attr", attr: ["switch", "alarm", "battery"]],
	"smartsmoke":		[driver: "Smart SmokeCO", selector: "smartSmokeCO", capability: "device.HaloSmokeAlarm", prefGroup: "safety", type: "attr", attr: ["smoke", "carbonMonoxide", "battery", "temperature", "humidity", "switch", "level", "hue", "saturation", "pressure"]],
	"smoke":			[driver: "SmokeCO", selector: "genericSmokeCO", capability: "smokeDetector", prefGroup: "safety", type: "attr", attr: ["smoke", "carbonMonoxide", "battery"]],
	"speaker":			[driver: "Speaker", selector: "genericSpeakers", capability: "musicPlayer", prefGroup: "audio", type: "attr", attr: ["level", "mute", "volume", "status", "trackData", "trackDescription"]],
	"speechSynthesis":	[driver: "SpeechSynthesis", selector: "speechSynth", capability: "speechSynthesis", prefGroup: "other", type: "attr", attr: ["mute", "version", "volume"]],
	"switch":			[driver: "Switch", selector: "genericSwitches", capability: "switch", prefGroup: "lighting", type: "attr", attr: ["switch"]],
	"thermostat":		[driver: "Thermostat", selector: "genericThermostats", capability: "thermostat", prefGroup: "climate", type: "attr", attr: ["coolingSetpoint", "heatingSetpoint", "schedule", "supportedThermostatFanModes", "supportedThermostatModes", "temperature", "thermostatFanMode", "thermostatMode", "thermostatOperatingState", "thermostatSetpoint"]],
	"windowshade":		[driver: "Window Shade", selector: "windowShades", capability: "windowShade", prefGroup: "other", type: "attr", attr: ["switch", "position", "windowShade"]],
	"valve":			[driver: "Valve", selector: "genericValves", capability: "valve", prefGroup: "other", type: "attr", attr: ["valve"]],
	"v_acceleration":	[driver: "Virtual Acceleration Sensor", selector: "virtualAcceleration", capability: "accelerationSensor", prefGroup: "virtual", type: "synth", attr: ["acceleration"]],
	"v_audiovolume":	[driver: "Virtual audioVolume", selector: "virtualAudioVolume", capability: "audioVolume", prefGroup: "virtual", type: "synth", attr: ["volume", "mute"]],
	"v_co_detector":	[driver: "Virtual CO Detector", selector: "virtualCO", capability: "carbonMonoxideDetector", prefGroup: "virtual", type: "synth", attr: ["carbonMonoxide"]],
	"v_contact":		[driver: "Virtual Contact Sensor", selector: "virtualContact", capability: "contactSensor", prefGroup: "virtual", type: "synth", attr: ["contact"]],
	"v_humidity":		[driver: "Virtual Virtual Humidity Sensor", selector: "virtualHumidity", capability: "relativeHumidityMeasurement", prefGroup: "virtual", type: "synth", attr: ["humidity"]],
	"v_illuminance":	[driver: "Virtual Illuminance Sensor", selector: "virtualIlluminance", capability: "illuminanceMeasurement", prefGroup: "virtual", type: "synth", attr: ["illuminance"]],
	"v_moisture":		[driver: "Virtual Moisture Sensor", selector: "virtualMoisture", capability: "waterSensor", prefGroup: "virtual", type: "synth", attr: ["water"]],
	"v_motion":			[driver: "Virtual Motion Sensor", selector: "virtualMotion", capability: "motionSensor", prefGroup: "virtual", type: "synth", attr: ["motion"]],
	"v_multi":			[driver: "Virtual Multi Sensor", selector: "virtualMulti", capability: "accelerationSensor", prefGroup: "virtual", type: "synth", attr: ["acceleration", "contact", "temperature"]],
	"v_omni":			[driver: "Virtual Omni Sensor", selector: "virtualOmni", capability: "carbonDioxideMeasurement", prefGroup: "virtual", type: "synth", attr: ["acceleration", "carbonDioxide", "carbonMonoxide", "contact", "energy", "humidity", "illuminance", "power", "presence", "smoke", "temperature", "water"]],
	"v_presence":		[driver: "Virtual Presence Sensor", selector: "virtualPresence", capability: "presenceSensor", prefGroup: "virtual", type: "synth", attr: ["presence"]],
	"v_smoke_detector":	[driver: "Virtual Smoke Detector", selector: "virtualSmoke", capability: "smokeDetector", prefGroup: "virtual", type: "synth", attr: ["smoke"]],
	"v_temperature":	[driver: "Virtual Temperature Sensor", selector: "virtualTemperature", capability: "temperatureMeasurement", prefGroup: "virtual", type: "synth", attr: ["temperature"]],
	"vc_globalvar":		[driver: "RM Global Variable Connector", platform: "Hubitat", selector: "virtualGlobVar", capability: "*", prefGroup: "virtual", synthetic: true, attr: ["sensor"]],
	"zwaverepeater":	[driver: "Iris Z-Wave Repeater", selector: "zwaveRepeaters", capability: "device.IrisZ-WaveRepeater", prefGroup: "shackrat", type: "synth", attr: ["status", "lastRefresh", "deviceMSR", "deviceVersion", "deviceZWaveLibType", "deviceZWaveVersion", "lastMsgRcvd"]],

	// HubConnect Apps
	"automatic":		[driver: "Automatic Vehicle", selector: "automaticVehicles", capability: "presenceSensor", prefGroup: "hcautomatic", type: "hcapp", attr: ["presence"]],
	"NAMain":			[driver: "Netatmo Basestation", selector: "hcnetatmowxBasetations", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "pressure", "carbonDioxide", "soundPressureLevel", "sound", "lowTemperature", "highTemperature", "temperatureTrend", "pressureTrend"]],
	"NAModule1":		[driver: "Netatmo Outdoor Module", selector: "hcnetatmowxOutdoor", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "lowTemperature", "highTemperature", "temperatureTrend", "battery"]],
	"NAModule2":		[driver: "Netatmo Wind", selector: "hcnetatmowxWind", capability: "sensor", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["WindStrength", "WindAngle", "GustStrength", "GustAngle", "max_wind_str", "date_max_wind_str", "units", "battery"]],
	"NAModule3":		[driver: "Netatmo Rain", selector: "hcnetatmowxRain", capability: "sensor", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["rain", "rainSumHour", "rainSumDay", "units", "battery"]],
	"NAModule4":		[driver: "Netatmo Additional Module", selector: "hcnetatmowxModule", capability: "relativeHumidityMeasurement", prefGroup: "hcnetatmowx", type: "hcapp", attr: ["temperature", "humidity", "carbonDioxide", "lowTemperature", "highTemperature", "temperatureTrend", "battery"]]
]

/*
types

attr = Attribute only (Devices are selected by primary attribute only)
synth = Synthetic by "driver name" for local devices, or "hubconnect driver name" for remote devices.  (As a fallback, user can select by attribute)
hcapp = HubConnect App.  Same driver local & remote (Devices are selected by driver only)

*/

// Map containing device group definitions
@Field static Map<String, Map> DEVICE_GROUPS =
[
	"audio":		[title: "Audio Devices", description: "Speakers, AV Receivers"],
	"climate":		[title: "Climate Devices", description: "Thermostats & Weather Stations"],
	"fans":			[title: "Fans", description: "Ceiling Fans & Devices", parent: "switches"],
	"lighting":		[title: "Lighting Devices", description: "Bulbs, Dimmers, RGB/RGBW Lights, and Switches", parent: "switches"],
	"hcautomatic":	[title: "HubConnect Automatic Client", description: "HubConnect Automatic Driving Tracker Integration", parent: "hcapps"],
	"hcapps":		[title: "HubConnect Apps", description: "HubConnect Integrated Apps (Automatic, Netatmo)"],
	"hcnetatmowx":	[title: "HubConnect Netatmo Client", description: "HubConnect Netatmo Weather Station Client", parent: "hcapps"],
	"netatmowx":	[title: "Netatmo Weather Station (Community)", description: "Netatmo Weather Station Community Integration", parent: "climate"],
	"other":		[title: "Other Devices", description: "Presence, Button, Valves, Garage Doors, SpeechSynthesis, Window Shades"],
	"power":		[title: "Power & Energy Meters", description: "Power Meters & Energy Meters", parent: "switches"],
	"presence":		[title: "Presence Sensors & Apps", description: "Arrival Sensors, Presence Sensors, and Mobile Apps", parent: "sensors"],
	"safety":		[title: "Safety & Security", description: "Locks, Keypads, Smoke & Carbon Monoxide, Leak, Sirens"],
	"sensors":		[title: "Sensors", description: "Contact, Mobile App, Motion, Multipurpose, Omnipurpose, Presence, Shock"],
	"shackrat":		[title: "Shackrat's Drivers", description: "Iris V3 Motion, Iris Smart Plug, Z-Wave Repeaters"],
	"switches":		[title: "Lighting, Fans, & Switches", description: "Switches, Dimmers, Bulbs, Power & Energy Meters"],
	"virtual":		[title: "Virtual Devices", description: "Hubitat Virtual Devices, GV Connector"]
]


// Map containing commands to HSM states
@Field static Map<String, List> HSM_COMMAND_STATES =
[
	armAway: 		["armedAway", "armingAway"],
	armHome: 		["armedHome", "armingHome"],
	armNight: 		["armedNight", "armingNight"],
	disarm: 		["disarmed"],
	disarmAll:		["allDisarmed"],
	armAll: 		["armedAway", "armingAway", "armedHome", "armingHome", "armedNight", "armingNight"],
	armRules: 		[],
	disarmRules: 	[],
	cancelAlerts: 	[]
]


// Mapping to receive events
mappings
{
	// Client mappings
    path("/event/:deviceId/:deviceCommand/:commandParams")
	{
		action: [GET: "remoteDeviceCommand"]
	}
    path("/modes/get")
	{
		action: [GET: "getAllModes"]
	}
	path("/modes/set/:name")
	{
		action: [GET: "remoteModeChange"]
	}
    path("/hsm/get")
	{
		action: [GET: "getAllHSMStates"]
	}
    path("/hsm/set/:name")
	{
		action: [GET: "remoteHSMChange"]
	}
    path("/hsm/alert/:text")
	{
		action: [GET: "hsmReceiveAlert"]
	}

	// Server Mappings
    path("/devices/get")
	{
		action: [GET: "getAllDevices"]
	}
    path("/ping")
	{
		action: [GET: "registerPing"]
	}
    path("/connect/:data")
	{
		action: [GET: "connectRemoteHub"]
	}

	// Device endpoints
    path("/devices/save")
	{
		action: [POST: "devicesSaveAll"]
	}
    path("/device/:deviceId/event/:event")
	{
		action: [GET: "deviceSendEvent"]
	}
    path("/device/:deviceId/sync/:type")
	{
		action: [GET: "getDeviceSync"]
	}

	// SmartThings-specific endpoints
    path("/smartthings/callback/httpget")
	{
		action: [POST: "smartthingsHTTPGetCallback"]
	}
    path("/smartthings/callback/httppost")
	{
		action: [POST: "smartthingsHTTPPostCallback"]
	}
}


/*
	syncDevice

	Purpose: Sync virtual device on this hub with the physcial (remote) device by requesting an update of all attribute values.

	URL Format: GET /device/:deviceId/sync/:type

	Notes: CALLED FROM CHILD DEVICE DRIVER
*/
void syncDevice(String deviceNetworkId, String deviceType)
{
	String[] dniParts = deviceNetworkId.split(":")
	com.hubitat.app.DeviceWrapper childDevice = getChildDevice(deviceNetworkId)
	if (childDevice != null)
	{
		if (enableDebug) log.debug "Requesting device sync from ${clientName}: ${childDevice.label}"

		def data = httpGetWithReturn("/device/${dniParts[1]}/sync/${deviceType}")
		if (data?.status == "success")
		{
			childDevice.setLabel(data.label)

			data?.currentValues.each
			{
			  attr ->
				childDevice.sendEvent([name: attr.name, value: attr.value, unit: attr.unit, descriptionText: "Sync: ${childDevice.displayName} ${attr.name} is ${attr.value} ${attr.unit}", isStateChange: true])
			}
		}
	}
}


/*
	sendDeviceEvent

	Purpose: Send an event to a client device.

	URL format: GET /event/:deviceId/:deviceCommand/:commandParams

	Notes: CALLED FROM CHILD DEVICE
*/
void sendDeviceEvent(String deviceId, String deviceCommand, List commandParams=[])
{
	if (state.commDisabled) return
	String[] dniParts = deviceId.split(":")

	// HubConnect server
	if (localConnectionType == "socket" && useProxy)
	{
		log.info "Sending ${deviceCommand} command to HubConnect Server."
		hubDevice.hcsSendMessage([
			source:			"COMMAND",
			deviceId:		dniParts[1],
			deviceCommand:	deviceCommand,
			commandParams:	commandParams
		])
		return
	}

	String paramsEncoded = commandParams ? URLEncoder.encode(new groovy.json.JsonBuilder(commandParams).toString()) : null
	sendGetCommand("/event/${dniParts[1]}/${deviceCommand}/${paramsEncoded}")
}


/*
	deviceSendEvent

	Purpose:	Receives and forwards events received from a physical device located on a remote hub.

	URL Format: GET /device/:deviceId/event/:event

	API:		https://hubconnect.to/knowledgebase/22/deviceSendEvent.html

*/
def deviceSendEvent() {deviceSendEvent(params)}
def deviceSendEvent(Map params)
{
	String eventraw = params.event ? URLDecoder.decode(params.event) : (String) null
	if (eventraw == null) return

	Map event = parseJson(eventraw)
	String data = (String) event?.data ?: ""
	String unit = (String) event?.unit ?: ""

	// We can do this faster if we don't need info on the device
	if (state.deviceIdList.contains(params.deviceId))
	{
		sendEvent("${clientIP}:${params.deviceId}", (Map) [name: (String) event.name, value: (String) event.value, unit: (String) unit, descriptionText: "${event?.displayName} ${event.name} is ${event.value} ${unit}", isStateChange: true, data: data])
		if (enableDebug) log.info "Received event from ${clientName}/${event.displayName}: [${event.name}, ${event.value} ${unit}]"
		return jsonResponse([status: "complete"])
	}

	if (enableDebug) log.warn "Ignoring Received event from ${clientName}: Device Not Found!"
	jsonResponse([status: "error"])
}


/*
	wsSendEvent

	Purpose: Handler for events received from physical devices through the websocket interface.

	Notes: 	This is only called by the hub device for events received through its local websocket.
			Also, this does not warn when a device cannot be found as websockets get ALL events so we rely on an internal filter for this.
*/
void wsSendEvent(Object event)
{
	// We can do this faster if we don't need info on the device, so defer that for logging
	sendEvent("${clientIP}:${event.deviceId}", (Map) [name: (String) event.name, value: (String) event.value, unit: (String) event.unit, descriptionText: (String) event.descriptionText, isStateChange: (Boolean) event.isStateChange])
	if (enableDebug) log.info "Received event from ${clientName}/${event.displayName}: [${event.name}, ${event.value} ${event.unit}]"
}


/*
	realtimeModeChangeHandler

	URL Format: GET /modes/set/modeName

	Purpose: Event handler for mode change events on the controller hub (this one).
*/
void realtimeModeChangeHandler(evt)
{
	if (state.commDisabled || !pushModes) return

	if (enableDebug) log.debug "Sending mode change event to ${clientName}: ${evt.value}"
	sendGetCommand("/modes/set/${URLEncoder.encode(evt.value)}")

	getHubDevice()?.sendEvent(name: "modeState", value: evt.value)
}


/*
	realtimeHSMChangeHandler

	URL Format: GET /hsm/set/hsmStateName

	Purpose: Event handler for HSM state change events on the controller hub (this one).
*/
void realtimeHSMChangeHandler(evt)
{
	if (state.commDisabled || !pushHSM) return
	String newState = evt.value

	if (evt?.data?.toInteger() != app.id && atomicState.lastHSMChange != evt.value)
	{
		if (enableDebug) log.debug "Sending HSM state change event to ${clientName}: ${newState}"
		sendGetCommand("/hsm/set/${URLEncoder.encode(newState)}")
		atomicState.lastHSMChange = evt.value
	}
	else if (enableDebug) log.info "Filtering duplicate HSM state change event."
}


/*
	realtimeHSMStatusHandler

	Purpose: Updates virtual hub device with correct HSM status.
*/
void realtimeHSMStatusHandler(evt)
{
	getHubDevice()?.sendEvent(name: "hsmState", value: evt.value)
}


/*
	hsmSendAlert

	URL Format: GET /hsm/set/hsmStateName

	Purpose: Event handler for HSM state change events on the controller hub (this one).
*/
void hsmSendAlert(String hsmAlertText)
{
	if (state.commDisabled || !pushHSM) return

	if (enableDebug) log.debug "Sending HSM alert change event to ${clientName}: ${hsmAlertText}"
	sendGetCommand("/hsm/alert/${URLEncoder.encode(hsmAlertText)}")
}


/*
	devicesSaveAll

	Purpose:	Creates virtual shadow devices and connects them the remote hub.

	URL Format: POST /devices/save

	API:		https://hubconnect.to/knowledgebase/21/devicesSaveAll.html
*/
def devicesSaveAll()
{
	// Device cleanup?
	if (request?.JSON?.cleanupDevices != null)
	{
		childDevices.each
		{
		  child ->
			if (child.deviceNetworkId != state.hubDeviceDNI && request.JSON.cleanupDevices.find{"${clientIP}:${it}" == child.deviceNetworkId} == null)
			{
				if (enableDebug) log.info "Deleting device ${child.label} as it is no longer shared with this hub."
				deleteChildDevice(child.deviceNetworkId)
			}
		}
	}

	// Find the device class
	else if (!request?.JSON?.deviceclass || !request?.JSON?.devices)
	{
		return jsonResponse([status: "error"])
	}

	if (NATIVE_DEVICES.find {it.key == request.JSON.deviceclass})
	{
		// Create the devices
		request.JSON.devices.each { createLinkedChildDevice(it, "HubConnect ${NATIVE_DEVICES[request.JSON.deviceclass].driver}") }
	}
	else if (state.customDrivers.find {it.key == request.JSON.deviceclass})
	{
		// Get the custom device type and create the devices
		request.JSON.devices.each { createLinkedChildDevice(it, "${state.customDrivers[request.JSON.deviceclass].driver}") }
	}

	// Update the device filter
	updateDeviceIDList()

	jsonResponse([status: "complete"])
}


/*
	createLinkedChildDevice

	Purpose: Helper function to create child devices.

	Notes: 	Called from devicesSaveAll()
*/
private createLinkedChildDevice(Map dev, String driverType)
{
	com.hubitat.app.DeviceWrapper childDevice = getChildDevice("${clientIP}:${dev.id}")
	if (childDevice != null)
	{
		// Device exists
		if (enableDebug) log.trace "${driverType} ${dev.label} (${childDevice.deviceNetworkId}) exists... Skipping creation.."
		return
	}
	else
	{
		if (enableDebug) log.trace "Creating Device ${driverType} - ${dev.label}... ${clientIP}:${dev.id}..."
		try
		{
			childDevice = addChildDevice("shackrat", driverType, "${clientIP}:${dev.id}", null, [name: dev.label, label: dev.label])
		}
		catch (errorException)
		{
			log.error "... Uunable to create device ${dev.label}: ${errorException}."
			childDevice = null
		}
	}

	// Set the value of the primary attributes
	if (childDevice != null)
	{
		dev.attr.each
		{
	 	 attribute ->
			childDevice.sendEvent([name: attribute.name, value: attribute.value, unit: attribute.unit])
		}
	}
}


/*
	createHubChildDevice

	Purpose: Create child device for the remote hub so up/down status can be managed with rules.

	Notes: 	Called from initialize()
*/
private com.hubitat.app.DeviceWrapper createHubChildDevice()
{
	String deviceNetworkId = state.hubDeviceDNI

	com.hubitat.app.DeviceWrapper hubDevice = getHubDevice()
	if (hubDevice != null)
	{
		// Hub exists
		log.info "Hub device exists... Skipping creation.."
	}
	else
	{
		if (enableDebug) log.trace "Creating hub Device ${clientName}... ${deviceNetworkId}..."

		try
		{
			hubDevice = addChildDevice("shackrat", "HubConnect Remote Hub", deviceNetworkId, null, [name: "HubConnect Hub", label: clientName])
		}
		catch (errorException)
		{
			state.lastError = "Unable to create the Hub monitoring device: ${errorException}.   Support Data: [id: \"${deviceNetworkId}\", name: \"HubConnect Hub\", label: \"${clientName}\"]"
			log.error state.lastError
			hubDevice = (com.hubitat.app.DeviceWrapper) null
		}

		// Set the value of the primary attributes
		if (hubDevice != null) sendEvent(deviceNetworkId, [name: "presence", value: "present"])
	}

	hubDevice
}


/*
	getDeviceSync

	Purpose:	Retrieves the current attribute and device name/label.

	URL Format: GET /device/:deviceId/sync/:type

	API:		https://hubconnect.to/knowledgebase/7/getDeviceSync.html
*/
def getDeviceSync() {getDeviceSync(params)}
def getDeviceSync(Map params)
{
	log.info "Received device update request from client: [${params.deviceId}, type ${params.type}]"

	com.hubitat.app.DeviceWrapper device = getDevice(params)
	if (device != null)
	{
		def currentAttributes = getAttributeMap(device, params.type)
		String label = device.label ?: device.name
		jsonResponse([status: "success", name: "${device.name}", label: "${label}", currentValues: currentAttributes])
	}
}


/*
	getDevice

	Purpose: Helper function to retreive a specific device from all selected devices.
*/
com.hubitat.app.DeviceWrapper getDevice(Map params)
{
	com.hubitat.app.DeviceWrapper foundDevice = (com.hubitat.app.DeviceWrapper) null

	NATIVE_DEVICES.each
	{
	  groupname, device ->
		if (foundDevice != null) return
		foundDevice = settings."${device.selector}"?.find{it.id == params.deviceId}
	}

	// Custom devices drivers
	if (foundDevice == null)
	{
		state.customDrivers?.each
		{
	 	  groupname, device ->
			if (foundDevice != null) return
			foundDevice = settings."custom_${groupname}".find{it.id == params.deviceId}
		}
	}
	return foundDevice
}


/*
	remoteDeviceCommand

	Purpose: 	Executes a command on a device located on this hub.

	Parameters: params - (Map)

	URL Format:	GET /event/:deviceId/:deviceCommand/:commandParams

	API:		https://hubconnect.to/knowledgebase/6/remoteDeviceCommand.html
*/
def remoteDeviceCommand() {remoteDeviceCommand(params)}
def remoteDeviceCommand(Map params)
{
    List commandParams = (localConnectionType == "socket" && useProxy) ? params.commandParams : (params.commandParams != "null" ? parseJson(URLDecoder.decode(params.commandParams)) : [])

	// Get the device
	com.hubitat.app.DeviceWrapper device = getDevice(params)
	if (device == null)
	{
		log.error "Could not locate a device with an id of ${params.deviceId}"
		return jsonResponse([status: "error"])
	}

	// DeleteSync: Uninstalling?
	if (params.deviceCommand == "uninstalled")
	{
		def driverDef = NATIVE_DEVICES.findResults{groupname, driver -> settings?."${driver.selector}"?.findResults{ if (it.id == "${device.id}") return driver.selector }?.join() }?.join() ?:
			 state.customDrivers.each.findResults{groupname, driver -> settings?."custom_${groupname}"?.findResults{ if (it.id == "${device.id}") return driver.selector }?.join() }?.join()

		if (driverDef)
		{
			// "de-select" the device
			def newSetting = settings?."${driverDef}"?.findResults{if (it.id != "${device.id}") return it.id}
			app.updateSetting("${driverDef}", [type: "capability", value: newSetting])
			if (enableDebug) log.info "Received device delete requet from client: [\"${device.label ?: device.name}]\"..  Sharing of this device has been disabled on this hub."
		}

		// Update subscriptions & device ID filter
		subscribeLocalEvents()
		updateDeviceIDList()

		return jsonResponse([status: "success"])
	}

	if (enableDebug) log.info "Received command from client: [\"${device.label ?: device.name}\": ${params.deviceCommand}]"

	// Make sure the physical device supports the command
	if (!device.hasCommand(params.deviceCommand))
	{
		log.warn "The device [${device.label ?: device.name}] does not support the command ${params.deviceCommand}."
		return jsonResponse([status: "error"])
	}

	// Execute the command
	device."${params.deviceCommand}"(*commandParams)

	jsonResponse([status: "success"])
}


/*
	remoteModeChange

	Purpose:	Executes a mode change on this hub.

	URL Format: GET /modes/set/:name

	API:		https://hubconnect.to/knowledgebase/9/remoteModeChange.html

*/
def remoteModeChange(){remoteModeChange(params)}
def remoteModeChange(Map params)
{
	String modeName = (localConnectionType == "socket") ? params.value : (params?.name ? URLDecoder.decode(params?.name) : "")

	// Send mode status event to the remote hub device to update even if it's not defined on this hub
	hubDevice.sendEvent([name: "modeState", value: modeName])

    if (!receiveModes)
    {
		log.warn "Ignoring mode change event... Mode changes are disabled on this hub."
        jsonResponse([status: "error"])
        return
    }

    if (location.modes?.find{it.name == modeName})
	{
		if (enableDebug) log.debug "Received mode event from ${clientName}: ${modeName}"
		if (location.mode != modeName) setLocationMode(modeName)
		jsonResponse([status: "complete"])
	}
	else
	{
		log.error "Received mode event from ${clientName}: ${modeName} does not exist!"
		jsonResponse([status: "error"])
    }
}


/*
	remoteHSMChange

	Purpose:	Executes a SHM setArm command on this hub.

	URL Format: GET /hsm/set/:name

	API:		https://hubconnect.to/knowledgebase/11/remoteHSMChange.html
*/
def remoteHSMChange(){remoteHSMChange(params)}
def remoteHSMChange(Map params)
{
	String hsmState = (localConnectionType == "socket") ? params.value : (params?.value ? URLDecoder.decode(params?.value) : "")

	// Send HSM status event to the remote hub device to update even if it's not configured on this hub
	hubDevice.sendEvent([name: "hsmState", value: hsmState])

	if (!receiveHSM)
    {
		log.warn "Ignoring HSM change event... HSM changes are disabled on this hub."
        jsonResponse([status: "error"])
        return
    }

	if (HSM_COMMAND_STATES.find{cmd, state -> cmd == hsmState})
	{
		if (enableDebug) log.debug "Received HSM event from remote: ${hsmState}"
		if (location.hsmStatus != null || location.hsmStatus != "")
		{
			if (HSM_COMMAND_STATES.find{cmd, state -> cmd == hsmState && state.find {it == location.hsmStatus}})
			{
				if (enableDebug) log.debug "HSM is already in the requested state...  Skipping."
				return
			}
			sendLocationEvent(name: "hsmSetArm", value: hsmState, data: app.id)
		}
		else
		{
			if (HSM_COMMAND_STATES.find{cmd, state -> cmd == hsmState && state.find {it == atomicState.lastHSMChange}})
			{
				if (enableDebug) log.debug "HSM is already in the requested state...  Skipping."
				return
			}
			parent.hsmSetState(hsmState, app.id)
		}
		atomicState.lastHSMChange = hsmState
		jsonResponse([status: "complete"])
	}
	else if (HSM_COMMAND_STATES.find{cmd, state -> state.find {it == hsmState}})
	{
		if (logDebug) log.info "Received HSM event from server: server is in the ${hsmState} state."
	}
	else
	{
		log.error "Received HSM event from server: ${hsmState} does not exist!"
		jsonResponse([status: "error"])
    }
}


/*
	hsmReceiveAlert

	Purpose: 	Receives and forwards HSM alert events from the server hub.

	URL Format: GET /hsm/alert/:text

	API:		https://hubconnect.to/knowledgebase/12/hsmReceiveAlert.html
*/
def hsmReceiveAlert(){hsmReceiveAlert(params)}
def hsmReceiveAlert(Map params)
{
	if (!receiveHSM) return
    def hsmAlertText = params?.text ? URLDecoder.decode(params?.text) : ""

	parent.hsmSendAlert(hsmAlertText, appId)
}


/*
	subscribeLocalEvents

	Purpose: Subscribes to all device events for all attribute returned by getSupportedAttributes()

	Notes: 	Thank god this isn't SmartThings, or this would time out after about 10 subscriptions!

*/
private void subscribeLocalEvents()
{
	unsubscribe()

	if (localConnectionType == "socket")
	{
		log.info "Skipping event subscriptions...  Using event socket to send events to server."
		return
	}

	log.info "Subscribing to events.."

	NATIVE_DEVICES.each
	{
	  groupname, device ->
		def selectedDevices = settings."${device.selector}"
		if (selectedDevices?.size()) getSupportedAttributes(groupname).each { subscribe(selectedDevices, it, realtimeEventHandler) }
	}

	// Special handling for Smart Plugs & Power Meters - Kinda Kludgy
	if (!sp_EnablePower && smartPlugs?.size()) unsubscribe(smartPlugs, "power", realtimeEventHandler)
	if (!sp_EnableVolts && smartPlugs?.size()) unsubscribe(smartPlugs, "voltage", realtimeEventHandler)
	if (!pm_EnableVolts && powerMeters?.size()) unsubscribe(powerMeters, "voltage", realtimeEventHandler)

	// Custom defined drivers
	state.customDrivers?.each
	{
	  groupname, driver ->
		if (settings."custom_${groupname}"?.size()) getSupportedAttributes(groupname).each { subscribe(settings."custom_${groupname}", it, realtimeEventHandler) }
	}
}


/*
	updateDeviceIDList

	Purpose: Helper function to update the list of device ID's and push them to the remote hub device.
*/
private void updateDeviceIDList()
{
	// Build a lookup table
	String[] parts = []
	state.deviceIdList = new HashSet<>()
	childDevices.each
	{
		parts = it.deviceNetworkId.split(":")
		if (parts?.size() > 1) state.deviceIdList << (localConnectionType != "socket" ? parts[1].toString() : parts[1].toInteger())
	}
	hubDevice?.updateDeviceIdList(state.deviceIdList)
}


/*
	realtimeEventHandler

	Purpose: Event handler for all local device events.

	URL Format: GET /device/:deviceId/sync/:type

	Notes: Send local events to the remote hub. (Filters out urlencoded Degree symbols for ST)
*/
void realtimeEventHandler(evt)
{
	if (state.commDisabled) return

	Map event =
	[
		name:			evt.name,
		value:			evt.value,
		unit:			remoteType != "smartthings" ? evt.unit : evt.unit?.replace("°", "")?.replace("%", ""),
		displayName:	evt.device.label ?: evt.device.name,
		data:			evt.data
	]

	if (remoteType == "smartthings") event.displayName = event.displayName.replace("/", "!@!").replace("’", "!#!")  // Another ST kludge
	def data = URLEncoder.encode(JsonOutput.toJson(event), "UTF-8")

	if (enableDebug) log.debug "Sending event to ${clientName}: ${evt.device.label ?: evt.device.name} [${event.name}: ${event.value} ${event.unit}]"
	sendGetCommand("/device/${evt.deviceId}/event/${data}")
}


/*
	getAttributeMap

	Purpose: Returns a map of current attribute values for (device) with the device class (deviceClass).

	Notes: Calls getSupportedAttributes() to obtain list of attributes.
*/
List getAttributeMap(com.hubitat.app.DeviceWrapper device, String deviceClass)
{
	def deviceAttributes = getSupportedAttributes(deviceClass)
	List currentAttributes = []
	deviceAttributes.each
	{
		if (device.supportedAttributes.find{attr -> attr.toString() == it})  // Filter only attributes the device supports
			currentAttributes << [name: (String) "${it}", value: device.currentValue("${it}"), unit: it == "temperature" ? "°"+getTemperatureScale() : it == "power" ? "W" :  it == "voltage" ? "V" : it == "battery" ? "%" : ""]
	}
	return currentAttributes
}


/*
	getCommandMap

	Purpose: Returns a map of support commands for (device)

	Note: This applies to the device as it exists on this hub.
		  Virtual devices may expose commands that the physical device does not support.
*/
private Map getCommandMap(com.hubitat.app.DeviceWrapper device)
{
    return device.supportedCommands.collectEntries { command-> [ (command?.name): (command?.arguments) ] }
}


/*
	getSupportedAttributes

	Purpose: Returns a list of supported attribute values for the device class (deviceClass).

	Notes: Called from getAttributeMap().
*/
private getSupportedAttributes(String deviceClass)
{
	if (NATIVE_DEVICES.find{it.key == deviceClass}) return NATIVE_DEVICES[deviceClass].attr
	if (state.customDrivers.find{it.key == deviceClass}) return state.customDrivers[deviceClass].attr
	return null
}


/*
	saveDevicesToClient

	Purpose: Sends all of the devices selected (& current attribute values) from this hub to the client (remote) hub.

	URL Format: POST /devices/save

	Notes: Makes a single POST request for each group of devices.
*/
void saveDevicesToClient()
{
	if (devicesChanged == false) return

	// Fetch all devices and attributes for each device group and send them to the master.
	List idList = []
	NATIVE_DEVICES.each
	{
	  groupname, device ->

		List devices = []
		settings."${device.selector}".each
		{
			devices << [id: it.id, label: it.label ?: it.name, attr: getAttributeMap(it, groupname)]
			idList << it.id
		}
		if (devices != [])
		{
			if (enableDebug) "Sending devices to remote: ${groupname} - ${devices}"
			sendPostCommand("/devices/save", [deviceclass: groupname, devices: devices])
		}
	}

	// Custom defined device drivers
	state.customDrivers.each
	{
	  groupname, driver ->

		List devices = []
		settings?."custom_${groupname}"?.each
		{
			devices << [id: it.id, label: it.label ?: it.name, attr: getAttributeMap(it, groupname)]
			idList << it.id
		}
		if (devices != [])
		{
			if (enableDebug) log.info "Sending custom devices to remote: ${groupname} - ${devices}"
			sendPostCommand("/devices/save", [deviceclass: groupname, devices: devices])
		}
	}
	if (cleanupDevices) sendPostCommand("/devices/save", [cleanupDevices: idList])

	state.saveDevices = false
}


/*
	httpGetWithReturn

	Purpose: Helper function to format GET requests with the proper oAuth token.

	Notes: 	Command is absolute and must begin with '/'
			Returns JSON Map if successful.
*/
def httpGetWithReturn(String command)
{
	// SmartThings HubActions need a content-length of 0 or the request will hang until it times out.
	if (localConnectionType == "hubaction")
	{
		if (enableDebug) log.trace "Sending httpGet [${command}]to SmartThings hub ..."
		atomicState.smartThingsGET = null

		def result = null
		Integer retries = 0

		while (result == null)
		{
			result = hubactionHttpRequest(command)
			if (result.status != "202" && retries < 5)
			{
				retries++
				if (enableDebug) log.trace "httpGet to SmartThings hub timed out; retrying ${retries}/5..."
				pauseExecution(1000)
				result = null
			}
		}

		// ST only respons with accepted, so we have to wait for a callback POST
		if (result.status == "202")
		{
			Integer timeOut = 0
			while (atomicState.smartThingsGET == null && timeOut < 40) // Timeout after 20 seconds
			{
				 pauseExecution(500)
				++timeOut
				if (enableDebug) log.trace "Waiting for http callback response from SmartThings hub... ${timeOut}/40"
			}
			if (timeOut == 30)
			{
				if (enableDebug) log.error "Timeout waiting for response from SmartThings hub to return data."
				result = [status: "error", message: "Timeout waiting for response from SmartThings hub"]
			}
			if (timeOut < 40) result = parseJson(atomicState.smartThingsGET?.data) ///
			atomicState.smartThingsGET = null
		}
		return result
	}

	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		timeout: 15
	]

	def result
	try
	{
		httpGet(requestParams)
		{
	  	  response ->

			if (response?.status == 200)
			{
				result = response.data
			}
			else
			{
				log.warn "httpGet() request failed with status ${response?.status}"
				result =  [status: "error", message: "httpGet() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpGet() failed with error ${e.message}"
		result =  [status: "error", message: e.message]
	}

	result
}


/*
	hubactionHttpRequest

	Purpose: Helper function to handle httpGet/httoPost requests for direct requests to SmartThings hub.

	Notes: 	Command is absolute and must begin with '/'
			Returns JSON Map if successful.
*/
private Map hubactionHttpRequest(String command, String method = "httpGet", data = [:])
{
	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			HOST: "${clientIP}:${state.clientPort}"
		],
		timeout: (method == "httpPost" ? 5 : 2)
	]

	if (method == "httpPost") requestParams <<  [body: data]
	else requestParams.headers << ["Content-Length": 0]

	Map result
	try
	{
		"${method}"(requestParams)
		{
	  	  response ->

			// ST only responds with accepted, so we have to wait for a callback POST
			if (response?.status == 202)
			{
				result = [status: "202"]
			}
			else
			{
				result =  [status: "error", message: "${method}() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		result =  [status: "error", message: e.message]
	}

	result
}


/*
	smartthingsHTTPGetCallback

	Purpose:	httpGetWithReturn callback function for SmartThings HubAction communication.
*/
void smartthingsHTTPGetCallback()
{
	atomicState.smartThingsGET = request?.JSON
}


/*
	sendGetCommand

	Purpose: Helper function to format GET requests with the proper oAuth token.

	Notes: 	Executes async http request and does not return data.
*/
def sendGetCommand(String command)
{
	// SmartThings HubActions need a content-length of 0 or the request will hang until it times out.
	if (localConnectionType == "hubaction")
	{
		return httpGetWithReturn(command)
	}

	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		timeout: 5
	]

	try
	{
		asynchttpGet((enableDebug ? "asyncHTTPHandler" : null), requestParams)
	}
	catch (Exception e)
	{
		log.error "asynchttpGet() failed with error ${e.message}"
	}
}


/*
	asyncHTTPHandler

	Purpose: Helper function to handle returned data from asyncHttpGet.

	Notes: 	Does not return data, only logs errors when debugging is enabled.
*/
void asyncHTTPHandler(response, data)
{
	if (response?.status != 200 && response?.status != 202) // ST HubActions return 202
	{
		log.error "asynchttpGet() request failed with error ${response?.status}"
	}
}


/*
	sendPostCommand

	Purpose: Helper function to format POST requests with the proper oAuth token.

	Notes: 	Returns JSON Map if successful.
*/
def sendPostCommand(String command, data)
{
	// SmartThings HubActions need a content-length of 0 or the request will hang until it times out.
	if (localConnectionType == "hubaction")
	{
		if (enableDebug) log.trace "Sending httpPost [${command}]to SmartThings hub ..."
		atomicState.smartThingsPOST = null

		def result = null
		Integer retries = 0

		while (result == null)
		{
			result = hubactionHttpRequest(command, "httpPost", data)
			if (result.status != "202" && retries < 5)
			{
				retries++
				if (enableDebug) log.trace "httpPost to SmartThings hub timed out; retrying ${retries}/5..."
				pauseExecution(1000)
				result = null
			}
		}

		// ST only respons with accepted, so we have to wait for a callback POST
		if (result.status == "202")
		{
			Integer timeOut = 0
			while (atomicState.smartThingsPOST == null && timeOut < 40) // Timeout after 20 seconds
			{
				 pauseExecution(500)
				++timeOut
				if (enableDebug) log.trace "Waiting for http callback response from SmartThings hub... ${timeOut}/40"
			}
			if (timeOut == 30)
			{
				if (enableDebug) log.error "Timeout waiting for response from SmartThings hub to return data."
				result = [status: "error", message: "Timeout waiting for response from SmartThings hub"]
			}
			else result = parseJson(atomicState.smartThingsPOST?.data)
			atomicState.smartThingsPOST = null
		}
		return result
	}

	Map requestParams =
	[
		uri:  state.clientURI + command,
		requestContentType: "application/json",
		headers:
		[
			Authorization: "Bearer ${state.clientToken}"
		],
		body: data,
		timeout: 20
	]

	def result
	try
	{
		httpPost(requestParams)
		{
	  	  response ->
			if (response?.status == 200)
			{
				result = response.data
			}
			else
			{
				log.error "httpPost() request failed with error ${response?.status}"
				result = [status: "error", message: "httpPost() request failed with status code ${response?.status}"]
			}
		}
	}
	catch (Exception e)
	{
		log.error "httpPost() failed with error ${e.message}"
		result = [status: "error", message: e.message]
	}
	result
}


/*
	smartthingsHTTPPostCallback

	Purpose:	sendPostCommand callback function for SmartThings HubAction communication.
*/
void smartthingsHTTPPostCallback()
{
	atomicState.smartThingsPOST = request?.JSON
}


/*
	getDevicePageStatus

	Purpose: Helper function to set flags for configured devices.
*/
Map getDevicePageStatus()
{
	Map status = (Map) [:]
	NATIVE_DEVICES.each
	{
	  groupname, device ->
		status["${device.prefGroup}"] = (status["${device.prefGroup}"] ?: 0) + ((Integer) settings?."${device.selector}"?.size() ?: 0)
	}

	// Custom defined device drivers
	state.customDrivers.each
	{
	  groupname, driver ->
		status["custom"] = (status["custom"] ?: 0) + ((Integer) settings?."custom_${groupname}"?.size() ?: 0)
	}

	status["all"] = status.collect{it.value}.sum()
	status
}


/*
	deviceCategoryStatus

	Purpose: Helper function to set flags for configured devices on a category page.
*/
Integer deviceCategoryStatus(String page)
{
	(DEVICE_GROUPS.findResults{groupname, group -> if (page == group.parent) devicePageStatus."${groupname}"}.sum() ?: 0) + ((Integer) devicePageStatus."${page}" ?: 0)
}


/*
	mainPage

	Purpose: Displays the main (landing) page.

	Notes: 	Not very exciting.
*/
def mainPage()
{
	if (state?.clientURI == null && state.installedVersion == null && !isConfigured)
	{
		parent.ssdpDiscoverHubs()
		return connectPage()
	}
	app.updateSetting("removeDevices", [type: "bool", value: false])
	if (settings?.clientName && app.label == "")
	{
		app.updateLabel(clientName)
	}

	if (state?.clientURI != null && state.installedVersion != null && state.installedVersion != appVersion) return parent.upgradePage("Server Instance")

	dynamicPage(name: "mainPage", title: app.label, uninstall: false, install: true)
	{
		section(menuHeader("Connect"))
		{
			href "connectPage", title: "Connect to Remote Hub...", description: "", state: state?.clientURI ? "complete" : null
			if (state?.clientURI) href "devicePage", title: "Connect local devices to Remote Hub...", description: "", state: devicePageStatus.all ? "complete" : null
		}
		if (isConfigured)
		{
			section(menuHeader("Modes"))
			{
				if (localConnectionType == "http" || localConnectionType == "hubaction")
				{
					paragraph "Synchronize mode changes on the server to this remote (client) hub."
					input "pushModes", "bool", title: "Send mode changes to Remote Hub?", defaultValue: false
				}
				paragraph "Synchronize mode changes from this remote (client) hub to the Server hub."
				input "receiveModes", "bool", title: "Receive mode changes from Remote Hub?", description: "", defaultValue: false
			}
			section(menuHeader("Hubitat Safety Monitor (HSM)"))
			{
				if (localConnectionType == "http" || localConnectionType == "hubaction")
				{
					paragraph "Synchronize HSM status on the server to this remote (client) hub."
					input "pushHSM", "bool", title: "Send HSM changes to Remote Hub?", defaultValue: false
				}
				paragraph "Synchronize HSM status from this remote (client) hub to the Server hub."
				input "receiveHSM", "bool", title: "Receive HSM changes from Remote Hub?", description: "", defaultValue: false
			}
		}
		section(menuHeader("Admin"))
		{
			if (childDevices?.size() > 1) href "resyncAllDevicesPage", title: "Device Resynchronization", description: "Refreshes all attributes for all devices.", state: null
			input "enableDebug", "bool", title: "Enable debug output?", required: false, defaultValue: false
			href "uninstallPage", title: "${state?.clientURI ? "Disconnect Server Hub &amp; " : ""}Remove this instance...", description: "", state: null
		}
		section()
		{
			paragraph "<span style=\"font-size:.8em\">Server Instance v${appVersion.major}.${appVersion.minor}.${appVersion.build} ${appCopyright}</span>"
		}
	}
}


/*
	hubSearchPage

	Purpose: Displays a please wait splash page to get around Hubitat UI caching.
*/
def hubSearchPage()
{
	if (!parent.isHubDiscoveryRunning()) return connectPage()
	dynamicPage(name: "hubSearchPage", uninstall: false, install: false, refreshInterval: 1)
	{
		section(menuHeader("Please wait..."))
		{
			paragraph "HubConnect is searching for hubs...."
		}
	}
}


/*
	connectPage

	Purpose: Displays the local & remote oAuth links.

	Notes: 	Really should create a proper token exchange someday.
*/
def connectPage()
{
	if (!state?.accessToken)
	{
		createAccessToken()
	}

	// Hub discovery active?
	if (parent.isHubDiscoveryRunning()) return hubSearchPage()

	// Populate clientIP from dropdown
	if (clientIPSelected && clientIPSelected != "0") app.updateSetting("clientIP", [type: "string", value: clientIPSelected])

	// Validate IP
	if (clientIP && state?.clientURI == null)
	{
		def ipCheck = parent.checkIP(clientIP)
		if (ipCheck != null && ipCheck.id != app.id)
		{
			state.error_clientIP = "Address ${clientIP} is already in use by ${ipCheck.label}."
			app.removeSetting("clientIP")
			return parent.waitPage("Validating IP Address...")
		}
	}

	// Discover hubs
	List foundHubs = []
	parent.getDiscoveredHubs().each
	{
		if (parent.getAllConnectedHubs().find{ip -> it == ip} == false) foundHubs << ["${parent.convertHexToIP(it.key)}": it.value.name]
	}

	if (useProxy && (remoteType != "local" || localConnectionType != "socket")) app.updateSetting("useProxy", [type: "bool", value: false])
	if (clientIP && clientName == null) app.updateSetting("clientName", [type: "string", value: "Temporary Hub"])

	// Force a page refresh so the setting applies
	if (remoteType == "smartthings" && (localConnectionType != "http" && localConnectionType != "hubaction"))
	{
		app.updateSetting("localConnectionType", [type: "enum", value: "http"])
		return parent.waitPage()
	}

	if (state?.connectStatus == "disconnecting")
	{
		app.removeSetting("proxyIP")
		app.removeSetting("localProxyPort")
	 	app.removeSetting("remoteProxyPort")
		app.updateSetting("useProxy", [type: "bool", value: false])
		app.updateSetting("localConnectionType", [type: "enum", value: null])
		app.updateSetting("remoteType", [type: "enum", value: null])
		state.connectStatus = "disconnected"
		return parent.waitPage()
	}

	String connectString = getConnectString()
	dynamicPage(name: "connectPage", uninstall: ((state?.clientURI == null && state.installedVersion == null) ? true : false), install: (isConfigured && state?.installValid ? true : false))
	{
		if (!isConfigured || state?.clientURI == null)
		{
			section(menuHeader("Configure Remote"))
			{
				if (foundHubs?.size() > 0)
				{
					input "clientIPSelected", "enum", title: "Discovered Hubs:", options: foundHubs + [0: "-- Internet/SmartThings (Manual Entry) --"], required: false, defaultValue: null, submitOnChange: true
				}
				else paragraph "No new hubs were located on the local network. Manual configuration is required."

				if (foundHubs?.size() == 0 || clientIPSelected == "0" || (clientIPSelected == null && clientIP)) input "clientIP", "string", title: "Private LAN IP Address of Client Hub:", required: false, defaultValue: null, submitOnChange: true

				if (state.error_clientIP != null)
				{
					paragraph "<b style=\"color:red\">${state.error_clientIP}</b>"
					state.remove("error_clientIP")
				}
				if (clientIP) input "remoteType", "enum", title: "Type of Remote Hub:", options: [local: "Hubitat (LAN)", remote: "Hubitat (Internet)", homebridge: "HomeBridge", smartthings: "SmartThings"], required: false, defaultValue: null, submitOnChange: true
				if (clientIP && remoteType == "local" || remoteType == "homebridge")
				{
					input "localConnectionType", "enum", title: "Local Connection Type:", options: [http: "Hubitat oAuth (http)", socket: "Hubitat Event Socket"], required: false, defaultValue: null, submitOnChange: true
					if (remoteType == "local" && localConnectionType == "socket") input "useProxy", "bool", title: "Use HubConnect Web Socket Proxy?", defaultValue: false, submitOnChange: true
					if (clientIP && state?.connectStatus == "online") input "updateDeviceIPs", "bool", title: "Update child devices with new IP address?", defaultValue: false
					if (!isConfigured) input "refresh", "button", title: "Refresh"
				}
				else if (clientIP && remoteType == "smartthings")
				{
					if (!hasSTHub) input "hasSTHub", "bool", title: "Is there a SmartThings Hub connected?  (This <b>cannot</b> be changed without uninstalling this remote!)", defaultValue: false, submitOnChange: true
					if (hasSTHub) input "localConnectionType", "enum", title: "Local Connection Type:", options: [http: "SmartThings oAuth (http)", hubaction: "HubAction (http)"], required: false, defaultValue: "http", submitOnChange: true

					if (clientIP && state?.connectStatus == "online") input "updateDeviceIPs", "bool", title: "Update child devices with new IP address?", defaultValue: false
				}
			}
			if (clientIP && remoteType == "local" && localConnectionType == "socket" && useProxy)
			{
				section(menuHeader("HubConnect Proxy"))
				{
					paragraph "Please complete the setup of the HubConnect Proxy nodeJs application before proceeding"
					input "proxyIP", "string", title: "IP Address of the HubConnect Proxy Server", required: true, submitOnChange: true
					if (proxyIP)
					{
						input "localProxyPort", "number", title: "Websocket Port Number for THIS Hub", required: true, submitOnChange: true
						if (localProxyPort) input "remoteProxyPort", "number", title: "Websocket Port Number for the REMOTE hub", required: true, submitOnChange: true}
					}
			}
		}
		// Show connection key?
		if (isConfigured)
		{
			section(menuHeader("Connection Key"))
			{
				if (!sendKey) paragraph("${remoteType == "local" || remoteType == "homebridge" ? "Local LAN Hub:" : "Internet Hub:"} Copy &amp; Paste this Connection Key into the Remote hub's configuration:<textarea rows=\"3\" style=\"width:80%; font-family:Consolas,Monaco,Lucida Console,Liberation Mono,DejaVu Sans Mono,Bitstream Vera Sans Mono,Courier New, monospace;\" onclick=\"this.select()\" onclick=\"this.focus()\">${connectString}</textarea>\n${state?.clientURI != null ? "<b style=\"color:green\">Connected!</b>" : ""}")
				if (remoteType == "local" && state?.connectStatus == "online")
				{
					input "sendKey", "bool", title: "Send connection key and automatically configure the remote hub?", submitOnChange: true
				}
				if (sendKey) paragraph "<b style=\"color:green\">Connect key will be pushed to the remote hub after clicking [Done] on the home page.</b>"

				if (state.lastError)
				{
					paragraph "<b style=\"color:red\">${state.lastError}</b>"
					state.remove("lastError")
				}
				if (state.installedVersion == null && state?.installValid == null || state?.connectStatus != "online")
				{
					input "validateInstall", "button", title: "Verify Connection"
					input "resetConnection", "button", title: "Reset"
				}
				else
				{
					input "disconnect", "button", title: "Disconnect"
				}
			}
			if (state?.clientURI != null)
			{
				section(menuHeader("Client Details"))
				{
					input "clientName", "string", title: "Friendly Name of Client Hub:", required: false, defaultValue: null, submitOnChange: true
				}
			}
		}
	}
}


/*
	systemSetCommType

	Purpose: Sets communications to [http/socket/proxy].

	URL Format: (GET) /system/setCommType/:type

	Notes: Called by the server hub or by the child device.
*/
Boolean systemSetCommType(Map params)
{
	if (params?.type == null) return
	if (params.type == "socket")
	{
		app.updateSetting("localConnectionType", [type: "string", value: "socket"])
		app.updateSetting("useProxy", [type: "bool", value: false])
	}
	else if (params.type == "proxy")
	{
		if (proxyIP.length() > 0 && remoteProxyPort > 0)
		{
			app.updateSetting("localConnectionType", [type: "string", value: "socket"])
			app.updateSetting("useProxy", [type: "bool", value: true])
		}
	}
	else if (params.type == "http")
	{
		app.updateSetting("localConnectionType", [type: "string", value: "http"])
	}
	else
	{
		log.error("systemSetCommType: Unknown connection type.")
		return false
	}

	if (enableDebug) log.info "Switching connection type to ${params.type}"

	// Schedule
	runIn(1, initialize)

	// Notify the remote hub of the change
	sendGetCommand("/system/setCommType/${params.type}")

	return true
}


/*
	connectRemoteHub

	Purpose: Receives URL and token from client (remote) hub.

	URL Format: GET /connect/:data

	Notes: 	This happens only after a successful installation of the server hubs connection key.
*/
def connectRemoteHub()
{
	log.info "connectRemoteHub: ${params}"
	if (params.data == null) return

	def accessData = parseJson(new String(params.data.decodeBase64()))
	if (!accessData || !accessData?.token || !accessData?.mac)
	{
		return jsonResponse([status: "error", message: "Invalid connect Key"])
	}

	if (state?.clientMac && (state.clientMac != accessData.mac))
	{
		return jsonResponse([status: "error", message: "Instance in use by another hub"])
	}

	log.info "Setting remote hub URI: ${accessData.uri} with token ${accessData.token}"
	state.clientURI = accessData.uri
	state.clientToken = accessData.token
	state.clientMac = accessData.mac
	state.connectStatus = "online"

	String[] connURI = state.clientURI.split(":")
	state.clientPort = connURI.size() > 2 ? connURI[2] : "80"

	if (settings?.clientName == null || settings.clientName == "Temporary Hub") app.updateSetting("clientName", [type: "string", value: accessData.name])

	// Push custom drivers?
	Map result = [status: "success"]
	if ((remoteType != "smartthings") && (state.customDriverDBVersion != accessData.customDriverDBVersion)) //**
	{
		log.info "Custom Driver database is out of date, pushing changes."
		result = saveCustomDrivers(state.customDrivers, state.customDriverDBVersion)
	}
	else log.info "Custom Driver database is current."

	jsonResponse(result)
}


/*
	uninstallPage

	Purpose: Displays options for removing an instance.

	Notes: 	Really should create a proper token exchange someday.
*/
def uninstallPage()
{
	dynamicPage(name: "uninstallPage", title: "Uninstall HubConnect", uninstall: true, install: false)
	{
		section(menuHeader("Warning!"))
		{
			paragraph "It is strongly recommended to back up your hub before proceeding. This action cannot be undone!\n\nClick the [Remove] button below to disconnect and remove this instance."
		}
		section(menuHeader("Options"))
		{
			input "removeDevices", "bool", title: "Remove virtual HubConnect shadow devices on this hub?", required: false, defaultValue: false, submitOnChange: true
		}
		section(menuHeader("Factory Reset"))
		{
			href "resetPage", title: "Factory Reset..", description: "Perform a factory reset of this instance.", state: null
		}
		section()
		{
			href "mainPage", title: "Cancel and return to the main menu..", description: "", state: null
		}
	}
}


/*
	resetPage

	Purpose:	Prompts a user to "factory reset" this app.

	Notes:		DO NOT USE unless directed by support
*/
def resetPage()
{
	dynamicPage(name: "resetPage", title: "Factory Reset HubConnect Remote", uninstall: false, install: true)
	{
		if (settings?.serverIP == null && state?.installedVersion == null)
		{
			section()
			{
				paragraph "Reset is complete; please check the logs for details."
				href "mainPage", title: "Return to the main menu..", description: "", state: null
			}
		}
		else
		{
			section(menuHeader("Warning!"))
			{
				paragraph "Please DO NOT reset unless directed to by support!!"
				paragraph "It is strongly recommended to back up your hub before proceeding. This action cannot be undone!"
				paragraph "The remote client MUST be manually reset following the reset of this instance."
			}
			section(menuHeader("Factory Reset"))
			{
				input "resetConfirmText", "text", title: "Please confirm", description: "Please enter the word \"reset\" (without quotes) to confirm.", required: false
				input "resetToFactoryDefaults", "button", title: "RESET TO DEFAULTS"
			}
		}
		section()
		{
			href "mainPage", title: "Cancel and return to the main menu..", description: "", state: null
		}
	}
}


/*
	registerPing

	Purpose: Handles a hub health ping event from a remote hub.

	Notes: 	If a hub was previously offline, the virtual hub device presence state will be set to "present".
*/
def registerPing()
{
	if (enableDebug) log.trace "Received ping from ${clientName}."
	state.lastCheckIn = now()

	if (state?.connectStatus == "warning" || state?.connectStatus == "offline")
	{
		state.connectStatus = "online"
		app.updateLabel(clientName + "<span style=\"color:green\"> Online</span>")
		log.info "${clientName} is online."


		sendEvent(state.hubDeviceDNI, [name: "presence", value: "present"])

		// A little recovery for system mode, in case the hub coming online missed a mode change
		if (pushModes)
		{
			sendGetCommand("/modes/set/${URLEncoder.encode(location.mode)}")
		}
	}

	jsonResponse([status: "received"])
}


/*
	appHealth

	Purpose: Scheduled health check task to ensure remote hubs are checking in regularly.

	Notes: 	Hubs are considered in a warning state after missing 2 pings (2 minutes).
			Hubs are considered offline after missing 5 pings (5 minutes).
			When a hub is offline, the virtual hub device presence state will be set to "not present".
*/
void appHealth()
{
	if (state.commDisabled) return

	// There should always be an event at least every minute.  If it's been 5 minutes (4 missed pings, the hub may be offline.
	if (state.lastCheckIn < (now() - 300000)) // 5 minutes - offline
	{
		state.connectStatus = "offline"
		app.updateLabel(clientName + "<span style=\"color:red\"> Offline</span>")
		log.error "${clientName} is offline."

		sendEvent(state.hubDeviceDNI, [name: "presence", value: "not present"])
	}
	else if (state.lastCheckIn < (now() - 120000)) // 2 minutes - warning
	{
		state.connectStatus = "warning"
		app.updateLabel(clientName + "<span style=\"color:orange\"> Warning</span>")
		log.warn "${clientName} has missed a ping and may be offline."
	}
}


/*
	setCommStatus

	Purpose: Disables events communications between hubs.

	URL Format: /system/setCommStatus/true|false

	Notes: 	This is useful if the coordinator has to be rebooted to prevent HTTP errors on the remote hubs.
*/
void setCommStatus(Boolean commDisabled = false)
{
	if (state.commDisabled == commDisabled) return

	log.info "Setting event communication status from remote hub: [status: ${commDisabled ? "paused" : "online"}]"
	state.commDisabled = commDisabled
	response = httpGetWithReturn("/system/setCommStatus/${commDisabled}")
	sendEvent(state.hubDeviceDNI, [name: "switch", value: response.switch])
	app.updateLabel(clientName + (commDisabled ? "<span style=\"color:orange\"> Paused</span>" : "<span style=\"color:green\"> Online</span>"))
}


/*
	pushCurrentMode

	Purpose: Pushes the current mode out to remote hubs.

	URL Format: /modes/set/modeName

	Notes: Called by system start event to make sure the correct mode is pushed to all remote hubs.
*/
void pushCurrentMode()
{
	if (state.commDisabled) return
	sendGetCommand("/modes/set/${URLEncoder.encode(location.mode)}")
}


/*
	getAllRemoteModes

	Purpose: Queries the remote hub for all configured modes.

	URL Format: GET /modes/get

	Notes: Called by parent app.
*/
def getAllRemoteModes()
{
	return httpGetWithReturn("/modes/get")
}


/*
	getAllModes

	Purpose: 	Returns a list of all configured modes on this hub.

	URL Format: GET /modes/get

	API:		https://hubconnect.to/knowledgebase/8/getAllModes.html
*/
def getAllModes()
{
	jsonResponse(modes: location.modes, active: location.mode)
}


/*
	getAllRemoteHSMStates

	Purpose: Queries the remote hub for all HSM states and current state.

	URL Format: (GET) /modes/get

	Notes: Called by parent app.
*/
def getAllRemoteHSMStates()
{
	return httpGetWithReturn("/hsm/get")
}


/*
	getAllHSMStates

	Purpose:	Returns a list of all configured HSM States and the active state on this hub.

	URL Format: GET /hsm/get

	API:		https://hubconnect.to/knowledgebase/10/getAllHSMStates.html

*/
def getAllHSMStates()
{
	jsonResponse(hsmSetArm: ["armAway", "armHome", "armNight", "disarm", "armRules", "disarmRules", "disarmAll", "armAll", "cancelAlerts"], hsmStatus: location.hsmStatus)
}


/*
	getAllDevices

	Purpose: Queries the remote hub for all configured modes.

	URL Format: GET /devices/get

	Notes: Called by remote client.
*/
def getAllDevices()
{
	List response = []
	NATIVE_DEVICES.each
	{
	  groupname, device ->
		List devices = []

		settings."${device.selector}".each
		{
			devices << [id: it.id, label: it.label ?: it.name, attr: getAttributeMap(it, groupname), commands: getCommandMap(it)]
		}
		if (devices.size()) response << [deviceclass: groupname, devices: devices]
	}

	jsonResponse(response)
}


/*
	getAllVersions

	Purpose: Queries the remote hub for all app and driver versions.

	URL Format: GET /system/versions/get

	Notes: Called by parent app.
*/
def getAllVersions()
{
	return httpGetWithReturn("/system/versions/get")
}


/*
	saveCustomDrivers

	Purpose: Saves custom drivers defined in the parent app to this server instance.

	Notes: Called by parent app.
*/
def saveCustomDrivers(customDrivers, customDriverDBVersion)
{
	// Clean up from deleted drivers
	state.customDrivers.each
	{
  	  key, driver ->
		if (customDrivers?.findAll{it.key == key}.size() == 0)
		{
			if (enableDebug) log.debug "Unsubscribing from events and removing device selector for ${key}"
			unsubscribe(settings."custom_${key}")
			app.removeSetting("custom_${key}")
		}
	}

	state.customDrivers = customDrivers
	state.customDriverDBVersion = customDriverDBVersion

	if (appHealthStatus == "online")
	{
		return sendPostCommand("/system/drivers/save", [customdrivers: customDrivers, customdriverdbversion: customDriverDBVersion])
	}
	else return [status: "error", message: "Remote hub ${clientName} is ${appHealthStatus}."]
}


/*
	installed

	Purpose: Standard install function.

	Notes: Doesn't do much.
*/
void installed()
{
	log.info "${app.name} Installed"

	if (state.clientToken)
	{
		initialize()
	}
	else
	{
		// Set an error state
		state.lastCheckIn = 0
		state.connectStatus = "error"
	}

	if (!state?.customDrivers)
	{
		state.customDrivers = (Map) [:]
		state.customDriverDBVersion = 0
	}

	state.installedVersion = appVersion
}


/*
	updated

	Purpose: Standard update function.

	Notes: Still doesn't do much.
*/
void updated()
{
	log.info "${app.name} Updated with settings: ${settings}"

	if (state?.customDrivers == null)
	{
		state.customDrivers = (Map) [:]
	}

	unsubscribe()

	if (state?.hubDeviceDNI == null) state.hubDeviceDNI = "hub-${clientIP}:${state.clientPort}"

	// Clean up ghost hub devices
	childDevices.findAll{it.typeName == "HubConnect Remote Hub" && it.deviceNetworkId != state.hubDeviceDNI}.each{deleteChildDevice(it.deviceNetworkId)}

	// HC 1.6 DNI change for Homebridge
	if (appVersion.major == 1 && appVersion.minor == 6)
	{
		log.debug "changing DNI"
		String[] connURI = state?.clientURI?.split(":")
		String clientPort = connURI.size() > 2 ? connURI[2] : "80"
		getHubDevice()?.deviceNetworkId = state.hubDeviceDNI
	}

	app.updateSetting("quickSelect", [type: "enum", value: ""])

	initialize()

	sendGetCommand("/system/update")
	state.installedVersion = appVersion
}


/*
	uninstalled

	Purpose: Standard uninstall function.

	Notes: Tries to clean up just in case Hubitat misses something.
*/
void uninstalled()
{
	// Remove virtual hub device
	deleteChildDevice(state.hubDeviceDNI)

	// Remove all devices if not explicity told to keep.
	if (removeDevices) childDevices.each { deleteChildDevice(it.deviceNetworkId) }

	log.info "HubConnect server instance has been uninstalled."
}


/*
	initialize

	Purpose: Initialize the server instance.

	Notes: Parses the oAuth link into the token and base URL.  A real token exchange would obviate the need for this.
*/
void initialize()
{
	log.info "${app.name} Initialized"

	// Build a lookup table & update device IPs if necessary
	String[] parts = []
	state.deviceIdList = new HashSet<>()
	childDevices.each
	{
		parts = it.deviceNetworkId.split(":")
        if (parts?.size() > 1)
		{
			state.deviceIdList << (localConnectionType != "socket" ? parts[1].toString() : parts[1].toInteger())
			if (updateDeviceIPs) it.deviceNetworkId = "${clientIP}:${parts[1]}"
		}
	}
	String[] connURI = state?.clientURI?.split(":")
	state.clientPort = connURI?.size() > 2 ? connURI[2] : "80"

	String hubDeviceDNI = "hub-${clientIP}:${state.clientPort}"

	// Fetch the hub device, update DNI if necessary
	com.hubitat.app.DeviceWrapper hubDevice = getHubDevice()
	if (hubDevice)
	{
		hubDevice.label = clientName

		// Changing DNI?
		if (hubDeviceDNI != state.hubDeviceDNI)
		{
			if (logDebug) log.info "Changing HubDevice DNI from ${state.hubDeviceDNI} to ${hubDeviceDNI}"
			hubDevice.deviceNetworkId = state.hubDeviceDNI = hubDeviceDNI
		}
		hubDevice.setConnectionType(localConnectionType, clientIP, state.clientPort, proxyIP, remoteProxyPort.toString(), useProxy)
		hubDevice.updateDeviceIdList(state.deviceIdList)
	}
	else if (state.clientToken)
	{
		state.hubDeviceDNI = hubDeviceDNI
		hubDevice = createHubChildDevice()
		if (hubDevice == null)
		{
			// Failed to create device
			log.error "HubConnect could not be initialized.  A remote hub device with a DNI of [${hubDeviceDNI}] was found.  Please manually remove this device before using HubConnect."
			state.hubDeviceDNI = null
			return
		}
		hubDevice.setConnectionType(localConnectionType, clientIP, state.clientPort, proxyIP, remoteProxyPort.toString(), useProxy)
		hubDevice.updateDeviceIdList(state.deviceIdList)
	}

	app.updateSetting("updateDeviceIPs", [type: "bool", value: false])

	saveDevicesToClient()
	subscribeLocalEvents()

	if (localConnectionType == "http" || localConnectionType == "hubaction")
	{
		if (pushModes) subscribe(location, "mode", realtimeModeChangeHandler)
		if (pushHSM)
		{
			subscribe(location, "hsmSetArm", realtimeHSMChangeHandler)
			subscribe(location, "hsmStatus", realtimeHSMStatusHandler)
		}
	}

	state.lastCheckIn = now()
	state.commDisabled = false

	state.remove("installValid")
	atomicState.remove("rsStatus")
	atomicState.remove("rsProgress")

	// Update remote hub comm key?
	if (sendKey)
	{
		log.warn localConnectionType
		app.updateSetting("sendKey", [type: "bool", value: false])
		sendGetCommand("/system/setConnectString/${connectString}")
	}

	app.updateLabel("${ clientName ? clientName.replaceAll(/[^0-9a-zA-Z&_ ]/, "") + "${ state?.connectStatus == "online" ? '<span style=\"color:green\"> Online</span>' : '<span style=\"color:red\"> Offline</span>' }" : 'HubConnect Remote Client' }")
	runEvery5Minutes("appHealth")
}


/*
	remoteInitialize

	Purpose: Allows the server to re-initialize this remote.

	URL Format: GET /system/initialize
*/
def remoteInitialize()
{
	return httpGetWithReturn("/system/initialize")
}


/*
	jsonResponse

	Purpose: Helper function to render JSON responses
*/
def jsonResponse(respMap)
{
	render contentType: 'application/json', data: JsonOutput.toJson(respMap)
}


/*
	devicePage

	Purpose: Displays the page where devices are selected to be linked to the controller hub.

	Notes: 	Really could stand to be better organized.
*/
def devicePage()
{
	Integer totalNativeDevices = 0
	String requiredDrivers = ""
	NATIVE_DEVICES.each
	{devicegroup, device ->
		if (settings."${device.selector}"?.size())
		{
			totalNativeDevices += settings."${device.selector}"?.size()
			requiredDrivers += "<li><a href=\"https://raw.githubusercontent.com/HubitatCommunity/HubConnect/master/UniversalDrivers/HubConnect-${device.driver.replace(" ","-")}.groovy\">HubConnect ${device.driver}</a></li>"
		}
	}

	Integer totalCustomDevices = 0
	state.customDrivers?.each
	{devicegroup, device ->
		totalCustomDevices += settings."custom_${devicegroup}"?.size() ?: 0
	}

	def quickNavOpts = NATIVE_DEVICES.findResults {devicegroup, driver ->
		if (!driver?.platform || driver?.platform == appVersion.platform)  ["${devicegroup}": driver.displayName ?: driver.driver]
	}

	Integer totalDevices = totalNativeDevices + totalCustomDevices

	// Changes in the quick select list?
	if (devicesChanged) state.saveDevices = true
	state.quickSelectState = null

	dynamicPage(name: "devicePage", uninstall: false, install: false, nextPage: "mainPage")
	{
		section(menuHeader("Quick Select"))
		{
			input "quickSelect", "enum", options: quickNavOpts, title: "Device Types", description: "Select the type of device to connect.", required: false, submitOnChange: true
			if (quickSelect)
			{
				String selector = renderDeviceSelector(NATIVE_DEVICES.find{devicegroup, device -> devicegroup == quickSelect}?.value, true)
				state.quickSelectState = [name: selector, devices: settings?."${selector}".collect{it.id}]
			}
		}

		section(menuHeader("Device Categories  (${totalDevices} connected)"))
		{
			DEVICE_GROUPS.each
			{
			  groupname, group ->
				if (!group?.parent) href "dynamicDevicePage", title: group.title, description: group.description, state: deviceCategoryStatus(groupname) ? "complete" : null, params: [prefGroup: groupname, title: group.title]
			}
			href "customDevicePage", title: "Custom Devices", description: "Devices with user-defined drivers.", state: devicePageStatus.custom ? "complete" : null
		}
		if (state.saveDevices)
		{
			section()
			{
				paragraph "<b style=\"color:red\">Changes to remote devices will be saved on exit.</b>"
				input "cleanupDevices", "bool", title: "Remove unused devices on the ${getConnectedInstanceType()} hub?", required: false, defaultValue: true
			}
		}
		if (requiredDrivers?.size())
		{
			section(menuHeader("Required Drivers"))
			{
				paragraph "Please make sure the following native drivers are installed on the ${getConnectedInstanceType()} hub before clicking \"Done\": <ul>${requiredDrivers}</ul>"
			}
		}
	}
}


/*
	dynamicDevicePage

	Purpose: Displays a device selection page.
*/
def dynamicDevicePage(Map params)
{
	state.saveDevices = true
	if (settings?.quickSelect) app.updateSetting("quickSelect", [type: "enum", value: ""])

	dynamicPage(name: "dynamicDevicePage", title: params.title, uninstall: false, install: false, nextPage: "devicePage")
	{
		if (DEVICE_GROUPS.find{key, val -> val?.parent == params.prefGroup})
		{
			section(menuHeader("Device Categories"))
			{
				DEVICE_GROUPS.each
				{
				  groupname, group ->
					if (group?.parent == params.prefGroup) href "dynamicDevicePage", title: group.title, description: group.description, state: devicePageStatus."${groupname}" ? "complete" : null, params: [prefGroup: groupname, title: group.title]
				}
			}
		}
		NATIVE_DEVICES.each
		{
		  groupname, device ->
			if (device.prefGroup == params.prefGroup)
			{
				if (device?.platform && device?.platform != appVersion.platform) return
				section(menuHeader("Select ${device.driver} Devices (${settings?."${device.selector}"?.size() ?: "0"} connected)"))
				{
					renderDeviceSelector(device)

					// Customizations
					if (groupname == "irissmartplug")
					{
						input "sp_EnablePower", "bool", title: "Enable power meter reporting?", required: false, defaultValue: true
						input "sp_EnableVolts", "bool", title: "Enable voltage reporting?", required: false, defaultValue: true
					}
					else if (groupname == "power")
					{
						input "pm_EnableVolts", "bool", title: "Enable voltage reporting?", required: false, defaultValue: true
					}
				}
			}
		}
	}
}


/*
	customDevicePage

	Purpose: Displays the page where custom (user-defined) devices are selected to be linked to the controller hub.

	Notes: 	First attempt at remotely defined device definitions.
*/
def customDevicePage()
{
	state.saveDevices = true

	dynamicPage(name: "customDevicePage", uninstall: false, install: false)
	{
		state.customDrivers.each
		{
		  groupname, driver ->
			String customSel = settings."custom_${groupname}"
			section(menuHeader("${driver.driver} Devices (${customSel?.size() ?: "0"} connected)"))
			{
				input "custom_${groupname}", "capability.${driver.selector.substring(driver.selector.lastIndexOf("_") + 1)}", title: "${driver.driver} Devices (${driver.attr}):", required: false, multiple: true, defaultValue: null
			}
		}
	}
}


/*
	resyncAllDevicesPage

	Purpose: Landing page to confirm action to sync() all devices.
*/
def resyncAllDevicesPage()
{
	if (atomicState?.rsStatus == "start")
	{
		runIn(1, "resyncAllDevices")
		atomicState.rsStatus = "starting"
		atomicState.rsProgress = 0
	}
	if (atomicState?.rsStatus == "starting" || atomicState?.rsStatus == "running")
	{
		return parent.waitPage("HubConnect is re-syncing devices; this may take several minutes...\n\nStatus: ${atomicState?.rsStatus?.capitalize()} &nbsp; ${atomicState.rsProgress}/${childDevices?.size()} complete.")
	}

	dynamicPage(name: "resyncAllDevicesPage", uninstall: false, install: false)
	{
		section(menuHeader("Re-synchronize Device Attributes"))
		{
			if (!atomicState?.rsStatus)
			{
				paragraph "There are ${childDevices?.size()} HubConnected devices on this hub that will be resynchronized...  This may take several minutes."
				paragraph "This process is resource intensive; it is not recommended to perform any other tasks on your Hubitat sytem while the resync runs."
				input "rsRunButton", "button", title: "Resync Devices"
			}
			else
			{
				paragraph "<b style=\"color:green\">Device re-syncing is complete.</b>\n${atomicState.rsProgress} devices have been processed."
				atomicState.remove("rsStatus")
				atomicState.remove("rsProgress")
			}
		}
	}

}


/*
	resyncAllDevices

	Purpose: Simply calls sync() on all devices.
*/
void resyncAllDevices()
{
	atomicState.rsStatus = "running"
 	childDevices?.each
	{
	  device ->
		if (device.hasCommand("sync")) device.sync()
		atomicState.rsProgress++
	}
	atomicState.rsStatus = "complete"
}


/*
	appButtonHandler

	Purpose: Handles button events for various pages.
*/
void appButtonHandler(String btnPressed)
{
	switch(btnPressed)
	{
		case "validateInstall":
			state.installValid = null
			state.lastError = null
			if (state?.clientPort == null)
			{
				state.lastError = "Remote hub has not completed the connection handshake.\nPlease confirm the settings on the remote are correct."
			}
			else if (state?.connectStatus != "online")
			{
				state.lastError = "Remote hub is not connected.\nPlease check the configuration of the remote hub."
			}

			state.hubDeviceDNI = "hub-${clientIP}:${state.clientPort}"
			if (state.lastError == null && createHubChildDevice() == null)
			{
				state.lastError = "Could not create the Remote Hub Device.\nPlease check the logs for further information."
				state.hubDeviceDNI = null
			}
			else
			{
				// Fetch the app version
				def tsReport = getRemoteTSReport()

				if (tsReport?.app?.installedVersion == null)
				{
					state.lastError = "Remote installation is not complete.\nPlease click the [Install] button on the remote client."
				}
            	else state.installValid = true
			}
			break

		case "disconnect":
			hubDevice?.off()
			if (appHealthStatus == "online") sendGetCommand("/system/disconnect")
			state.remove("clientURI")
			state.remove("clientToken")
			state.remove("clientMac")
			state.remove("clientPort")
			state.connectStatus = "disconnecting"
			state.commDisabled = true

			unsubscribe()
			unschedule()
			break

		case "resetConnection":
			state.remove("clientURI")
			state.remove("clientToken")
			state.remove("clientPort")
			state.connectStatus = "disconnecting"
			break

		case "rsRunButton":
			atomicState.rsStatus = "start"
			break

		case "resetToFactoryDefaults":
			if (settings.resetConfirmText == "reset") resetToFactoryDefaults()
			break

		default:
			break
	}
}


/*
	resetToFactoryDefaults

	Purpose: 	Resets everything to a freshly-installed state.

	Notes:		This will disconnect this hub.  Do not use ubnless directed to by support.
*/
void resetToFactoryDefaults()
{
	log.warn "!!! HubConnect resetToFactoryDefaults() Called !!!"
	log.warn "** Resetting all settings and app storage to defaults; device selections and child devices will be preserved. **"
	log.warn "** This hub will be disconnected... **"

	// Destroy state
	log.info ">> Clearing state..."
	state.clear()

	// Destroy atomicState
	log.info ">> Clearing atomicState..."
	atomicState.each{k, v -> atomicState."${k}" = null}

	// Destroy all settings except for device selection
	log.info ">> Clearing settings..."
	settings.each
	{
	  k, v ->
		log.debug "checking: ${k}"

		if (settings?."${k}" != null && k.startsWith("custom_") == false && NATIVE_DEVICES.find{groupname, driver -> k == driver.selector} == null)
		{
			log.info ">>>> Remove setting: ${k}"
			app.removeSetting(k)
		}
	}

	// Remove all Hub Devices
	log.info ">> Removing all hub devices..."
	childDevices.findAll{it.typeName == "HubConnect Remote Hub"}.each{deleteChildDevice(it.deviceNetworkId)}

	log.warn "!!! HubConnect resetToFactoryDefaults() COMPLETE !!!"
}


/*
	renderDeviceSelector

	Purpose: Renders the DeviceMatch device selection dropdown.
*/
private String renderDeviceSelector(Map device, submitOnChange = false)
{
	if (device == null) return
	String capability =
		(device.type == "attr") ? (device.capability.contains("device.") ? device.capability : "capability.${device.capability}")
		: (device.type == "hcapp") ? "device." + device.driver.replace(" ", "")
			: (!settings?."syn_${device.selector}" || settings."syn_${device.selector}" == "attribute") ? "capability.${device.capability}"
			: (settings."syn_${device.selector}" == "physical") ? "device." + device.driver.replace(" ", "")
			: "device.HubConnect" + device.driver.replace(" ", "")

	input "${device.selector}", "${capability}", title: "${device.driver} Device(s) ${device.attr}:", required: false, multiple: true, defaultValue: null, submitOnChange: submitOnChange
	if (device.type=="synth") input "syn_${device.selector}", "enum", title: "DeviceMatch Selection Type? ${settings."${device.selector}"?.size() ? " (Changing may affect the availability of previously selected devices)" : ""}", options: [physical: "Device Driver", synthetic: "HubConnect Driver", attribute: "Primary Attribute"], required: false, defaultValue: (capability.startsWith("device") ? "physical" : "attribute"), submitOnChange: true
}


/*
	getIsConfigured

	Purpose: Helper function to determine if a remote is fully configured.
*/
private Boolean getIsConfigured()
{
	(clientIP && remoteType
		&& remoteType == "remote"
		|| (remoteType == "smartthings"
			|| (remoteType != "smartthings" && localConnectionType
				&& (localConnectionType != "socket"
					|| (localConnectionType == "socket"
						&& (useProxy == false || remoteType == "homebridge"
							|| (useProxy && proxyIP && localProxyPort && remoteProxyPort)))))))
}


/*
	getSelectedDeviceIds

	Purpose: Returns a list of all device IDs selected in this instance.
*/
List getSelectedDeviceIds()
{
	// Fetch all devices and attributes for each device group and send them to the master.
	List idList = []
	NATIVE_DEVICES.each
	{
	  groupname, device ->
		settings."${device.selector}".each
		{
			idList << it.id
		}
	}

	// Custom defined device drivers
	state.customDrivers.each
	{
	  groupname, driver ->
		settings?."custom_${groupname}"?.each
		{
			idList << it.id
		}
	}
	idList
}


/*
	registerServerTSReport

	Purpose: Saves a TSR received from the server to state.
*/
def registerServerTSReport(Map eventData)
{
	parent.registerServerTSReport(eventData)
}


/*
	getRemoteTSReport

	Purpose: Returns a technical support report from the remote client.

	URL Format: (GET) /system/tsreport/get

	Notes: Called by parent app.
*/
def getRemoteTSReport()
{
	return httpGetWithReturn("/system/tsreport/get")
}
String menuHeader(titleText){"<div style=\"width:102%;background-color:#696969;color:white;padding:4px;font-weight: bold;box-shadow: 1px 2px 2px #bababa;margin-left: -10px\">${titleText}</div>"}
com.hubitat.app.DeviceWrapper getHubDevice() { getChildDevice(state.hubDeviceDNI) }
String getConnectString() {remoteType ? new groovy.json.JsonBuilder([uri: (remoteType == "local" || remoteType == "homebridge" || (remoteType == "smartthings" && localConnectionType == "hubaction")) ? getFullLocalApiServerUrl() : getFullApiServerUrl(), serverIP: location?.hubs[0]?.data?.localIP, name: location.name, type: remoteType, token: state.accessToken, connectionType: localConnectionType ?: "", proxyIP: proxyIP, proxyPort: localProxyPort, useProxy: useProxy ?: false]).toString().bytes.encodeBase64() : ""}
def getPref(setting) {return settings."${setting}"}
def getDevicesChanged() {state.saveDevices || (state?.quickSelectState && state?.quickSelectState.devices != (settings?."${state?.quickSelectState?.name}"?.collect{it.id} ?: []))}
String getAppHealthStatus() {state?.connectStatus}
String getConnectedInstanceType() {"Remote"}
String getAppCopyright(){"&copy; 2019-2020 Steve White, Retail Media Concepts LLC <a href=\"https://hubconnect.to/knowledgebase/5/HubConnect-License-Agreement.html\" target=\"_blank\">HubConnect License Agreement</a>"}
